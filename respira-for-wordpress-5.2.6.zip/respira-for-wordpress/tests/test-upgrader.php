<?php
/**
 * Version migration engine tests.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests
 * @since      5.2.0
 */

/**
 * Tests for Respira_Upgrader.
 *
 * @since 5.2.0
 */
class Respira_Upgrader_Test extends WP_UnitTestCase {

	/**
	 * Clean up after each test.
	 */
	public function tearDown(): void {
		delete_option( 'respira_version' );
		delete_option( 'respira_tool_governance_disabled' );
		delete_transient( 'respira_show_whats_new' );
		wp_clear_scheduled_hook( 'respira_snapshot_cleanup_daily' );
		parent::tearDown();
	}

	/**
	 * Fresh install should run all migrations and set version.
	 */
	public function test_fresh_install_runs_migrations() {
		// No version option = fresh install (defaults to 0.0.0).
		Respira_Upgrader::maybe_upgrade();

		$this->assertEquals( RESPIRA_VERSION, get_option( 'respira_version' ) );
		$this->assertEquals( '[]', get_option( 'respira_tool_governance_disabled' ) );
		$this->assertNotFalse( get_transient( 'respira_show_whats_new' ) );
	}

	/**
	 * Upgrade from pre-5.2.0 should run 5.2.0 migrations.
	 */
	public function test_upgrade_from_old_version_runs_520_migration() {
		update_option( 'respira_version', '4.4.4' );

		Respira_Upgrader::maybe_upgrade();

		$this->assertEquals( RESPIRA_VERSION, get_option( 'respira_version' ) );
		$this->assertEquals( '[]', get_option( 'respira_tool_governance_disabled' ) );
		$this->assertNotFalse( wp_next_scheduled( 'respira_snapshot_cleanup_daily' ) );
	}

	/**
	 * Running on current version should be a no-op.
	 */
	public function test_current_version_is_noop() {
		update_option( 'respira_version', RESPIRA_VERSION );

		Respira_Upgrader::maybe_upgrade();

		// Governance option should NOT be created (migration didn't run).
		$this->assertFalse( get_option( 'respira_tool_governance_disabled' ) );
	}
}
