<?php
/**
 * Divi 5 Intelligence tests.
 *
 * Tests for Divi 5 modules, patterns, design tokens, and validator.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests
 * @since      5.2.0
 */

/**
 * Tests for Divi 5 Intelligence (WS3).
 *
 * @since 5.2.0
 */
class Respira_Divi5_Intelligence_Test extends WP_UnitTestCase {

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();

		// Load the intelligence files.
		$base = dirname( __DIR__ ) . '/includes/divi-intelligence/';
		require_once $base . 'divi5-modules.php';
		require_once $base . 'divi5-patterns.php';
		require_once $base . 'divi5-design-tokens.php';
		require_once $base . 'class-divi-validator.php';
	}

	// =========================================================================
	// Module Definitions
	// =========================================================================

	public function test_module_definitions_returns_array() {
		$modules = respira_get_divi5_module_definitions();
		$this->assertIsArray( $modules );
		$this->assertNotEmpty( $modules );
	}

	public function test_all_modules_have_required_fields() {
		$modules = respira_get_divi5_module_definitions();
		foreach ( $modules as $name => $def ) {
			$this->assertArrayHasKey( 'title', $def, "Module $name missing 'title'." );
			$this->assertArrayHasKey( 'type', $def, "Module $name missing 'type'." );
			$this->assertContains( $def['type'], array( 'container', 'self-closing' ), "Module $name has invalid type." );
		}
	}

	public function test_container_modules_have_children_key() {
		$modules = respira_get_divi5_module_definitions();
		foreach ( $modules as $name => $def ) {
			if ( 'container' === $def['type'] ) {
				$this->assertArrayHasKey( 'children', $def, "Container module $name missing 'children'." );
			}
		}
	}

	public function test_core_modules_exist() {
		$modules = respira_get_divi5_module_definitions();
		$required = array(
			'divi/section', 'divi/row', 'divi/column',
			'divi/text', 'divi/heading', 'divi/image', 'divi/button',
		);
		foreach ( $required as $name ) {
			$this->assertArrayHasKey( $name, $modules, "Core module $name not found." );
		}
	}

	// =========================================================================
	// Module Type Registry
	// =========================================================================

	public function test_module_types_registry() {
		$types = respira_get_divi5_module_types();
		$this->assertArrayHasKey( 'self_closing', $types );
		$this->assertArrayHasKey( 'container', $types );
		$this->assertContains( 'divi/text', $types['self_closing'] );
		$this->assertContains( 'divi/section', $types['container'] );
	}

	public function test_module_types_consistent_with_definitions() {
		$modules = respira_get_divi5_module_definitions();
		$types   = respira_get_divi5_module_types();

		foreach ( $modules as $name => $def ) {
			if ( 'self-closing' === $def['type'] ) {
				$this->assertContains( $name, $types['self_closing'], "$name should be in self_closing registry." );
			} elseif ( 'container' === $def['type'] ) {
				$this->assertContains( $name, $types['container'], "$name should be in container registry." );
			}
		}
	}

	// =========================================================================
	// Patterns
	// =========================================================================

	public function test_patterns_returns_array() {
		$patterns = respira_get_divi5_patterns();
		$this->assertIsArray( $patterns );
		$this->assertNotEmpty( $patterns );
	}

	public function test_all_patterns_have_required_fields() {
		$patterns = respira_get_divi5_patterns();
		foreach ( $patterns as $name => $pattern ) {
			$this->assertArrayHasKey( 'name', $pattern, "Pattern $name missing 'name'." );
			$this->assertArrayHasKey( 'description', $pattern, "Pattern $name missing 'description'." );
			$this->assertArrayHasKey( 'structure', $pattern, "Pattern $name missing 'structure'." );
		}
	}

	public function test_flex_fractions() {
		$fractions = respira_get_divi5_flex_fractions();
		$this->assertArrayHasKey( '24_24', $fractions );
		$this->assertEquals( '100%', $fractions['24_24'] );
		$this->assertArrayHasKey( '12_24', $fractions );
		$this->assertEquals( '50%', $fractions['12_24'] );
		$this->assertArrayHasKey( '8_24', $fractions );
		$this->assertEquals( '33.333%', $fractions['8_24'] );
	}

	public function test_breakpoints() {
		$breakpoints = respira_get_divi5_breakpoints();
		$this->assertArrayHasKey( 'desktop', $breakpoints );
		$this->assertEquals( 981, $breakpoints['desktop'] );
		$this->assertArrayHasKey( 'phone', $breakpoints );
		$this->assertEquals( 0, $breakpoints['phone'] );
	}

	public function test_nesting_rules() {
		$rules = respira_get_divi5_nesting_rules();
		$this->assertArrayHasKey( 'root', $rules );
		$this->assertContains( 'divi/section', $rules['root'] );
		$this->assertContains( 'divi/row', $rules['divi/section'] );
		$this->assertContains( 'divi/column', $rules['divi/row'] );
	}

	// =========================================================================
	// Design Tokens
	// =========================================================================

	public function test_color_variable_syntax() {
		$ref = respira_divi5_color_variable( 'gcid-abc123' );
		$this->assertStringContainsString( '$variable(', $ref );
		$this->assertStringContainsString( '"type":"color"', $ref );
		$this->assertStringContainsString( '"name":"gcid-abc123"', $ref );
		$this->assertStringContainsString( '"settings":{}', $ref );
		$this->assertStringEndsWith( ')$', $ref );
	}

	public function test_content_variable_syntax() {
		$ref = respira_divi5_content_variable( 'gvid-font001' );
		$this->assertStringContainsString( '"type":"content"', $ref );
		$this->assertStringContainsString( '"name":"gvid-font001"', $ref );
		$this->assertStringContainsString( '"settings":{}', $ref );
	}

	public function test_parse_valid_variable() {
		$ref    = respira_divi5_color_variable( 'gcid-test123' );
		$parsed = respira_divi5_parse_variable( $ref );

		$this->assertNotNull( $parsed );
		$this->assertEquals( 'color', $parsed['type'] );
		$this->assertEquals( 'gcid-test123', $parsed['name'] );
		$this->assertIsArray( $parsed['settings'] );
	}

	public function test_parse_invalid_variable_returns_null() {
		$this->assertNull( respira_divi5_parse_variable( 'not a variable' ) );
		$this->assertNull( respira_divi5_parse_variable( 42 ) );
	}

	public function test_validate_variable_missing_settings() {
		$bad_ref = '$variable({"type":"color","value":{"name":"gcid-test"}})$';
		$result  = respira_divi5_validate_variable( $bad_ref );
		$this->assertFalse( $result['valid'] );
		$this->assertStringContainsString( 'settings', $result['error'] );
	}

	public function test_validate_variable_valid() {
		$ref    = respira_divi5_color_variable( 'gcid-abc' );
		$result = respira_divi5_validate_variable( $ref );
		$this->assertTrue( $result['valid'] );
		$this->assertNull( $result['error'] );
	}

	public function test_is_variable_reference() {
		$ref = respira_divi5_color_variable( 'gcid-abc' );
		$this->assertTrue( respira_divi5_is_variable_reference( $ref ) );
		$this->assertFalse( respira_divi5_is_variable_reference( '#ff0000' ) );
		$this->assertFalse( respira_divi5_is_variable_reference( 42 ) );
	}

	public function test_escape_variable_for_json() {
		$ref     = respira_divi5_color_variable( 'gcid-abc' );
		$escaped = respira_divi5_escape_variable_for_json( $ref );
		$this->assertStringNotContainsString( '"', $escaped );
		$this->assertStringContainsString( '\\"', $escaped );
	}

	public function test_global_colors_format() {
		$format = respira_get_divi5_global_colors_format();
		$this->assertArrayHasKey( 'example', $format );
		$this->assertIsArray( $format['example'] );
		$this->assertCount( 2, $format['example'][0] ); // [id, {color, status, label}] tuple.
	}

	public function test_global_variables_format() {
		$format = respira_get_divi5_global_variables_format();
		$this->assertArrayHasKey( 'example', $format );
		$this->assertArrayHasKey( 'id', $format['example'][0] );
		$this->assertArrayHasKey( 'type', $format['example'][0] );
	}

	public function test_builder_version() {
		$version = respira_get_divi5_builder_version();
		$this->assertEquals( '5.0.1', $version );
	}

	// =========================================================================
	// Divi 5 Payload Validator — 13-point checklist
	// =========================================================================

	public function test_validate_missing_context() {
		$payload = array( 'data' => array( '123' => 'content' ) );
		$result  = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertFalse( $result['valid'] );
		$this->assertStringContainsString( 'context', $result['errors'][0] );
	}

	public function test_validate_wrong_data_structure() {
		$payload = array(
			'context' => 'et_builder',
			'data'    => array(
				'123' => array(
					'post_content' => 'nested',
					'post_title'   => 'wrong',
				),
			),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertFalse( $result['valid'] );
		$this->assertStringContainsString( 'string, not an object', $result['errors'][0] );
	}

	public function test_validate_missing_placeholder_wrapper() {
		$payload = array(
			'context' => 'et_builder',
			'data'    => array(
				'123' => '<!-- wp:divi/section {"builderVersion":"5.0.1"} --><!-- /wp:divi/section -->',
			),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertFalse( $result['valid'] );
		$this->assertStringContainsString( 'wp:divi/placeholder', $result['errors'][0] );
	}

	public function test_validate_valid_minimal_payload() {
		$content = '<!-- wp:divi/placeholder -->'
			. '<!-- wp:divi/section {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/row {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/column {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/text {"builderVersion":"5.0.1"} /-->'
			. '<!-- /wp:divi/column -->'
			. '<!-- /wp:divi/row -->'
			. '<!-- /wp:divi/section -->'
			. '<!-- /wp:divi/placeholder -->';

		$payload = array(
			'context' => 'et_builder',
			'data'    => array( '123' => $content ),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertTrue( $result['valid'], 'Expected valid payload. Errors: ' . implode( ', ', $result['errors'] ) );
	}

	public function test_validate_missing_builder_version() {
		$content = '<!-- wp:divi/placeholder -->'
			. '<!-- wp:divi/section {} -->'
			. '<!-- wp:divi/row {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/column {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/text {"builderVersion":"5.0.1"} /-->'
			. '<!-- /wp:divi/column -->'
			. '<!-- /wp:divi/row -->'
			. '<!-- /wp:divi/section -->'
			. '<!-- /wp:divi/placeholder -->';

		$payload = array(
			'context' => 'et_builder',
			'data'    => array( '123' => $content ),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertFalse( $result['valid'] );
		$error_text = implode( ' ', $result['errors'] );
		$this->assertStringContainsString( 'builderVersion', $error_text );
	}

	public function test_validate_self_closing_syntax() {
		$content = '<!-- wp:divi/placeholder -->'
			. '<!-- wp:divi/section {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/row {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/column {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/text {"builderVersion":"5.0.1"} -->'  // Missing /-->
			. '<!-- /wp:divi/column -->'
			. '<!-- /wp:divi/row -->'
			. '<!-- /wp:divi/section -->'
			. '<!-- /wp:divi/placeholder -->';

		$payload = array(
			'context' => 'et_builder',
			'data'    => array( '123' => $content ),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$this->assertFalse( $result['valid'] );
		$error_text = implode( ' ', $result['errors'] );
		$this->assertStringContainsString( 'self-closing', $error_text );
	}

	public function test_validate_sync_boolean_mistake() {
		$content = '<!-- wp:divi/placeholder -->'
			. '<!-- wp:divi/section {"builderVersion":"5.0.1","module":{"decoration":{"spacing":{"desktop":{"value":{"padding":{"syncVertical":true}}}}}}} -->'
			. '<!-- wp:divi/row {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/column {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/text {"builderVersion":"5.0.1"} /-->'
			. '<!-- /wp:divi/column -->'
			. '<!-- /wp:divi/row -->'
			. '<!-- /wp:divi/section -->'
			. '<!-- /wp:divi/placeholder -->';

		$payload = array(
			'context' => 'et_builder',
			'data'    => array( '123' => $content ),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$error_text = implode( ' ', $result['errors'] );
		$this->assertStringContainsString( 'syncVertical', $error_text );
	}

	public function test_validate_button_wrong_attrs() {
		$content = '<!-- wp:divi/placeholder -->'
			. '<!-- wp:divi/section {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/row {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/column {"builderVersion":"5.0.1"} -->'
			. '<!-- wp:divi/button {"builderVersion":"5.0.1","url":"https://example.com"} /-->'
			. '<!-- /wp:divi/column -->'
			. '<!-- /wp:divi/row -->'
			. '<!-- /wp:divi/section -->'
			. '<!-- /wp:divi/placeholder -->';

		$payload = array(
			'context' => 'et_builder',
			'data'    => array( '123' => $content ),
		);
		$result = Respira_Divi_Validator::validate_divi5_payload( $payload );
		$error_text = implode( ' ', $result['errors'] );
		$this->assertStringContainsString( 'linkUrl', $error_text );
	}

	public function test_validate_non_array_payload() {
		$result = Respira_Divi_Validator::validate_divi5_payload( 'not an array' );
		$this->assertFalse( $result['valid'] );
	}

	// =========================================================================
	// Legacy Divi 4 Validation (existing tests preserved)
	// =========================================================================

	public function test_legacy_structure_validation() {
		$modules = array(
			array(
				'type'       => 'et_pb_section',
				'attributes' => array(),
				'children'   => array(
					array(
						'type'       => 'et_pb_row',
						'attributes' => array(),
						'children'   => array(),
					),
				),
			),
		);
		$result = Respira_Divi_Validator::validate_structure( $modules );
		$this->assertTrue( $result['valid'] );
	}

	public function test_legacy_invalid_type() {
		$modules = array(
			array( 'type' => '' ),
		);
		$result = Respira_Divi_Validator::validate_structure( $modules );
		$this->assertFalse( $result['valid'] );
	}
}
