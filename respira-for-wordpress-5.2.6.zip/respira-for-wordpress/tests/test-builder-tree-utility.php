<?php
/**
 * Tree utility tests.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests
 * @since      5.2.0
 */

/**
 * Tests for Respira_Builder_Tree_Utility.
 *
 * @since 5.2.0
 */
class Respira_Builder_Tree_Utility_Test extends WP_UnitTestCase {

	/**
	 * Sample Elementor-style tree for testing.
	 *
	 * @var array
	 */
	private $elementor_tree;

	/**
	 * Sample Divi-style tree for testing.
	 *
	 * @var array
	 */
	private $divi_tree;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();

		$this->elementor_tree = array(
			array(
				'type'        => 'section',
				'id'          => 'sec-1',
				'admin_label' => 'Hero Section',
				'settings'    => array(),
				'elements'    => array(
					array(
						'type'        => 'column',
						'id'          => 'col-1',
						'settings'    => array(),
						'elements'    => array(
							array(
								'type'     => 'widget',
								'widget'   => 'heading',
								'id'       => 'h-1',
								'settings' => array( 'title' => 'Hello World' ),
								'elements' => array(),
							),
							array(
								'type'     => 'widget',
								'widget'   => 'text-editor',
								'id'       => 'txt-1',
								'settings' => array(),
								'content'  => 'Some paragraph text',
								'elements' => array(),
							),
						),
					),
				),
			),
			array(
				'type'        => 'section',
				'id'          => 'sec-2',
				'admin_label' => 'CTA Section',
				'settings'    => array(),
				'elements'    => array(),
			),
		);

		$this->divi_tree = array(
			array(
				'type'        => 'et_pb_section',
				'attributes'  => array( 'admin_label' => 'Hero' ),
				'admin_label' => 'Hero',
				'content'     => '',
				'children'    => array(
					array(
						'type'       => 'et_pb_row',
						'attributes' => array(),
						'content'    => '',
						'children'   => array(
							array(
								'type'       => 'et_pb_text',
								'attributes' => array( 'text_font_size' => '24px' ),
								'content'    => 'Welcome to my site',
								'children'   => array(),
							),
						),
					),
				),
			),
		);
	}

	// --- Find tests ---

	public function test_find_by_id() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'id', 'h-1', 'elements' );

		$this->assertNotNull( $found );
		$this->assertEquals( 'heading', $found['widget'] );
		$this->assertEquals( array( 0, 0, 0 ), $found['_path'] );
	}

	public function test_find_by_admin_label() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'admin_label', 'Hero Section', 'elements' );

		$this->assertNotNull( $found );
		$this->assertEquals( 'sec-1', $found['id'] );
		$this->assertEquals( array( 0 ), $found['_path'] );
	}

	public function test_find_by_admin_label_case_insensitive() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'admin_label', 'hero section', 'elements' );

		$this->assertNotNull( $found );
		$this->assertEquals( 'sec-1', $found['id'] );
	}

	public function test_find_by_type() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'type', 'heading', 'elements' );

		$this->assertNotNull( $found );
		$this->assertEquals( 'h-1', $found['id'] );
	}

	public function test_find_by_type_with_content_match() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'type', 'text-editor', 'elements', 'paragraph' );

		$this->assertNotNull( $found );
		$this->assertEquals( 'txt-1', $found['id'] );
	}

	public function test_find_returns_null_when_not_found() {
		$found = Respira_Builder_Tree_Utility::find( $this->elementor_tree, 'id', 'nonexistent', 'elements' );

		$this->assertNull( $found );
	}

	public function test_find_works_with_divi_children_key() {
		$found = Respira_Builder_Tree_Utility::find( $this->divi_tree, 'type', 'et_pb_text', 'children' );

		$this->assertNotNull( $found );
		$this->assertEquals( array( 0, 0, 0 ), $found['_path'] );
	}

	// --- Count tests ---

	public function test_count_elements() {
		$count = Respira_Builder_Tree_Utility::count_elements( $this->elementor_tree, 'elements' );

		// sec-1, col-1, h-1, txt-1, sec-2 = 5
		$this->assertEquals( 5, $count );
	}

	public function test_count_empty_tree() {
		$this->assertEquals( 0, Respira_Builder_Tree_Utility::count_elements( array(), 'elements' ) );
	}

	// --- Get at path tests ---

	public function test_get_at_path() {
		$element = Respira_Builder_Tree_Utility::get_at( $this->elementor_tree, array( 0, 0, 0 ), 'elements' );

		$this->assertNotNull( $element );
		$this->assertEquals( 'heading', $element['widget'] );
	}

	public function test_get_at_invalid_path_returns_null() {
		$element = Respira_Builder_Tree_Utility::get_at( $this->elementor_tree, array( 5, 0 ), 'elements' );

		$this->assertNull( $element );
	}

	// --- Remove tests ---

	public function test_remove_element() {
		$tree = Respira_Builder_Tree_Utility::remove( $this->elementor_tree, array( 0, 0, 0 ), 'elements' );

		// Heading removed, only text-editor remains in column.
		$this->assertCount( 1, $tree[0]['elements'][0]['elements'] );
		$this->assertEquals( 'text-editor', $tree[0]['elements'][0]['elements'][0]['widget'] );
	}

	public function test_remove_root_element() {
		$tree = Respira_Builder_Tree_Utility::remove( $this->elementor_tree, array( 1 ), 'elements' );

		$this->assertCount( 1, $tree );
		$this->assertEquals( 'sec-1', $tree[0]['id'] );
	}

	// --- Insert tests ---

	public function test_insert_at_end() {
		$new_element = array( 'type' => 'widget', 'widget' => 'button', 'id' => 'btn-1', 'elements' => array() );
		$tree = Respira_Builder_Tree_Utility::insert( $this->elementor_tree, array( 0, 0 ), $new_element, -1, 'elements' );

		$this->assertCount( 3, $tree[0]['elements'][0]['elements'] );
		$this->assertEquals( 'button', $tree[0]['elements'][0]['elements'][2]['widget'] );
	}

	public function test_insert_at_position() {
		$new_element = array( 'type' => 'widget', 'widget' => 'button', 'id' => 'btn-1', 'elements' => array() );
		$tree = Respira_Builder_Tree_Utility::insert( $this->elementor_tree, array( 0, 0 ), $new_element, 1, 'elements' );

		$this->assertCount( 3, $tree[0]['elements'][0]['elements'] );
		$this->assertEquals( 'button', $tree[0]['elements'][0]['elements'][1]['widget'] );
		$this->assertEquals( 'text-editor', $tree[0]['elements'][0]['elements'][2]['widget'] );
	}

	// --- Clone tests ---

	public function test_clone_with_new_ids() {
		$element = $this->elementor_tree[0]; // Section with nested elements.
		$cloned  = Respira_Builder_Tree_Utility::clone_with_new_ids( $element, 'elements', 'id' );

		$this->assertNotEquals( $element['id'], $cloned['id'] );
		$this->assertNotEquals(
			$element['elements'][0]['id'],
			$cloned['elements'][0]['id']
		);
		// Content preserved.
		$this->assertEquals(
			$element['elements'][0]['elements'][0]['settings']['title'],
			$cloned['elements'][0]['elements'][0]['settings']['title']
		);
	}

	public function test_clone_without_id_key() {
		$element = $this->divi_tree[0];
		$cloned  = Respira_Builder_Tree_Utility::clone_with_new_ids( $element, 'children', null );

		// Should be a deep copy with same structure.
		$this->assertEquals( $element['type'], $cloned['type'] );
		$this->assertEquals( $element['children'][0]['type'], $cloned['children'][0]['type'] );
	}

	// --- Update at tests ---

	public function test_update_at_path() {
		$tree = Respira_Builder_Tree_Utility::update_at(
			$this->elementor_tree,
			array( 0, 0, 0 ),
			array( 'settings' => array( 'title' => 'Updated Title' ) ),
			'elements'
		);

		$this->assertEquals( 'Updated Title', $tree[0]['elements'][0]['elements'][0]['settings']['title'] );
	}

	// --- Reorder tests ---

	public function test_reorder_children() {
		$tree = Respira_Builder_Tree_Utility::reorder(
			$this->elementor_tree,
			array( 0, 0 ),
			array( 1, 0 ), // Swap: text-editor first, heading second.
			'elements'
		);

		$this->assertNotInstanceOf( 'WP_Error', $tree );
		$this->assertEquals( 'text-editor', $tree[0]['elements'][0]['elements'][0]['widget'] );
		$this->assertEquals( 'heading', $tree[0]['elements'][0]['elements'][1]['widget'] );
	}

	public function test_reorder_count_mismatch_returns_error() {
		$result = Respira_Builder_Tree_Utility::reorder(
			$this->elementor_tree,
			array( 0, 0 ),
			array( 0 ), // Only 1 index but 2 children.
			'elements'
		);

		$this->assertInstanceOf( 'WP_Error', $result );
		$this->assertEquals( 'respira_reorder_count_mismatch', $result->get_error_code() );
	}

	// --- Depth guard tests ---

	public function test_depth_guard_prevents_infinite_recursion() {
		// Build a tree deeper than MAX_DEPTH.
		$deep_tree = array();
		$current   = &$deep_tree;
		for ( $i = 0; $i < 60; $i++ ) {
			$current[] = array(
				'type'     => 'section',
				'id'       => 'deep-' . $i,
				'elements' => array(),
			);
			$current = &$current[0]['elements'];
		}
		// The deepest element should not be found due to MAX_DEPTH.
		$found = Respira_Builder_Tree_Utility::find( $deep_tree, 'id', 'deep-55', 'elements' );
		$this->assertNull( $found );

		// Elements within depth should still be found.
		$found = Respira_Builder_Tree_Utility::find( $deep_tree, 'id', 'deep-10', 'elements' );
		$this->assertNotNull( $found );
	}

	// --- Find all tests ---

	public function test_find_all() {
		$results = Respira_Builder_Tree_Utility::find_all(
			$this->elementor_tree,
			function ( $el ) {
				return isset( $el['type'] ) && 'widget' === $el['type'];
			},
			'elements'
		);

		$this->assertCount( 2, $results ); // heading + text-editor.
	}
}
