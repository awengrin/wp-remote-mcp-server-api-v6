<?php
/**
 * Builder interface safety guard.
 *
 * Prevents accidental addition of abstract methods to Respira_Builder_Interface,
 * which would cause fatal errors in ALL 11 builder implementations.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests
 * @since      5.2.0
 * @see        memory/feedback_interface_signatures.md — v5.0.5 site-down incident
 */

/**
 * Safety test for the builder interface abstract method contract.
 *
 * @since 5.2.0
 */
class Respira_Builder_Interface_Safety_Test extends WP_UnitTestCase {

	/**
	 * The allowed abstract methods on the builder interface.
	 *
	 * Adding a new abstract method requires updating ALL 11 builder implementations
	 * in the same commit. Use a public method with a default implementation instead.
	 *
	 * @var array
	 */
	private $allowed_abstract_methods = array(
		'detect',
		'get_name',
		'get_version',
		'extract_content',
		'inject_content',
		'create_code_block',
		'get_documentation',
		'get_available_modules',
	);

	/**
	 * No new abstract methods may be added to the builder interface.
	 *
	 * This test will FAIL if someone adds an abstract method to
	 * Respira_Builder_Interface without updating this allowlist AND
	 * all 11 builder implementations.
	 *
	 * To add a new method to the builder interface:
	 * 1. Add it as a public method with a safe default return value.
	 * 2. Override it in specific builders that need custom behavior.
	 * 3. Do NOT make it abstract.
	 *
	 * @since 5.2.0
	 */
	public function test_no_new_abstract_methods() {
		$rc = new ReflectionClass( 'Respira_Builder_Interface' );
		$abstract_methods = $rc->getMethods( ReflectionMethod::IS_ABSTRACT );

		foreach ( $abstract_methods as $method ) {
			$this->assertContains(
				$method->getName(),
				$this->allowed_abstract_methods,
				sprintf(
					'SAFETY: "%s" is abstract on Respira_Builder_Interface — this WILL cause a fatal error on all 11 builder implementations. Use a public method with a default implementation instead. If this is intentional, update all builders AND add the method name to $allowed_abstract_methods in this test.',
					$method->getName()
				)
			);
		}
	}

	/**
	 * The expected abstract methods must still exist.
	 *
	 * Ensures no one accidentally removes a required abstract method,
	 * which could silently break the contract.
	 *
	 * @since 5.2.0
	 */
	public function test_required_abstract_methods_exist() {
		$rc = new ReflectionClass( 'Respira_Builder_Interface' );
		$abstract_names = array_map(
			function ( $m ) {
				return $m->getName();
			},
			$rc->getMethods( ReflectionMethod::IS_ABSTRACT )
		);

		foreach ( $this->allowed_abstract_methods as $expected ) {
			$this->assertContains(
				$expected,
				$abstract_names,
				sprintf(
					'SAFETY: Required abstract method "%s" is missing from Respira_Builder_Interface. This changes the builder contract.',
					$expected
				)
			);
		}
	}
}
