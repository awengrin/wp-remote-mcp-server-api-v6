<?php
/**
 * Content filter regression tests.
 *
 * @package Respira_For_WordPress
 */

/**
 * Ensures content-filter callbacks never return null into typed builder hooks.
 */
class Respira_Content_Filter_Test extends WP_UnitTestCase {

	/**
	 * the_content callbacks should normalize null to an empty string.
	 */
	public function test_the_content_callbacks_normalize_null_input() {
		$this->assertSame( '', Respira_Content_Filter::ensure_string_content( null ) );
		$this->assertSame( '', Respira_Content_Filter::preserve_html_content_scripts( null ) );
		$this->assertSame( '', Respira_Content_Filter::prevent_wpautop_on_scripts( null ) );
		$this->assertSame( '', Respira_Content_Filter::ensure_scripts_render( null ) );
	}

	/**
	 * Divi-facing callbacks should also normalize null input.
	 */
	public function test_divi_callbacks_normalize_null_input() {
		$this->assertSame( '', Respira_Content_Filter::decode_divi_module_output( null, 'et_pb_code', null ) );
		$this->assertSame( '', Respira_Content_Filter::decode_divi5_block_output( null, array( 'blockName' => 'divi/code' ) ) );
	}
}
