<?php
/**
 * Elementor Schema Generator tests.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests
 * @since      5.2.0
 */

/**
 * Tests for Respira_Elementor_Schema_Generator and Respira_Elementor_Settings_Validator.
 *
 * @since 5.2.0
 */
class Respira_Elementor_Schema_Generator_Test extends WP_UnitTestCase {

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();

		$base = dirname( __DIR__ ) . '/includes/elementor-intelligence/';
		require_once $base . 'class-elementor-schema-generator.php';
		require_once $base . 'class-elementor-settings-validator.php';
	}

	// =========================================================================
	// Schema Generator — Control Type Mapping
	// =========================================================================

	public function test_parse_responsive_name_with_suffix() {
		$result = Respira_Elementor_Schema_Generator::parse_responsive_name( 'title_color_mobile' );
		$this->assertEquals( 'title_color', $result['base_name'] );
		$this->assertEquals( '_mobile', $result['suffix'] );
	}

	public function test_parse_responsive_name_tablet() {
		$result = Respira_Elementor_Schema_Generator::parse_responsive_name( 'padding_tablet' );
		$this->assertEquals( 'padding', $result['base_name'] );
		$this->assertEquals( '_tablet', $result['suffix'] );
	}

	public function test_parse_responsive_name_widescreen() {
		$result = Respira_Elementor_Schema_Generator::parse_responsive_name( 'font_size_widescreen' );
		$this->assertEquals( 'font_size', $result['base_name'] );
		$this->assertEquals( '_widescreen', $result['suffix'] );
	}

	public function test_parse_responsive_name_without_suffix() {
		$result = Respira_Elementor_Schema_Generator::parse_responsive_name( 'title_color' );
		$this->assertEquals( 'title_color', $result['base_name'] );
		$this->assertNull( $result['suffix'] );
	}

	public function test_valid_responsive_suffix() {
		$this->assertTrue( Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( '_mobile' ) );
		$this->assertTrue( Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( '_tablet' ) );
		$this->assertTrue( Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( '_widescreen' ) );
		$this->assertFalse( Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( '_desktop' ) );
		$this->assertFalse( Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( '_phone' ) );
	}

	public function test_generate_widget_schema_without_elementor() {
		// Without Elementor loaded, should return null gracefully.
		$result = Respira_Elementor_Schema_Generator::generate_widget_schema( 'heading' );
		$this->assertNull( $result );
	}

	// =========================================================================
	// Settings Validator
	// =========================================================================

	public function test_validate_without_schema_generator() {
		// Without Elementor, validator should return valid with warning.
		$result = Respira_Elementor_Settings_Validator::validate( 'heading', array( 'title' => 'Hello' ) );
		$this->assertTrue( $result['valid'] );
	}

	public function test_validate_returns_correct_structure() {
		$result = Respira_Elementor_Settings_Validator::validate( 'heading', array() );
		$this->assertArrayHasKey( 'valid', $result );
		$this->assertArrayHasKey( 'errors', $result );
		$this->assertArrayHasKey( 'warnings', $result );
	}

	// =========================================================================
	// Settings Validator — Value Validation (unit tests with mock schema)
	// =========================================================================

	public function test_find_closest_match() {
		// Use reflection to test private method.
		$method = new ReflectionMethod( 'Respira_Elementor_Settings_Validator', 'find_closest_match' );
		$method->setAccessible( true );

		$haystack = array( 'title', 'title_color', 'typography_font_size', 'alignment' );

		$this->assertEquals( 'title', $method->invoke( null, 'titel', $haystack ) );
		$this->assertEquals( 'alignment', $method->invoke( null, 'allignment', $haystack ) );
		$this->assertNull( $method->invoke( null, 'completely_different_name', $haystack ) );
	}

	public function test_validate_value_number_range() {
		$method = new ReflectionMethod( 'Respira_Elementor_Settings_Validator', 'validate_value' );
		$method->setAccessible( true );

		$property = array( 'type' => 'number', 'minimum' => 0, 'maximum' => 100 );

		// Valid value.
		$errors = $method->invoke( null, 'opacity', 50, $property, 'test_widget' );
		$this->assertEmpty( $errors );

		// Too high.
		$errors = $method->invoke( null, 'opacity', 150, $property, 'test_widget' );
		$this->assertNotEmpty( $errors );
		$this->assertStringContainsString( '<= 100', $errors[0] );

		// Too low.
		$errors = $method->invoke( null, 'opacity', -5, $property, 'test_widget' );
		$this->assertNotEmpty( $errors );
		$this->assertStringContainsString( '>= 0', $errors[0] );
	}

	public function test_validate_value_enum() {
		$method = new ReflectionMethod( 'Respira_Elementor_Settings_Validator', 'validate_value' );
		$method->setAccessible( true );

		$property = array( 'type' => 'string', 'enum' => array( 'left', 'center', 'right' ) );

		$errors = $method->invoke( null, 'align', 'center', $property, 'test_widget' );
		$this->assertEmpty( $errors );

		$errors = $method->invoke( null, 'align', 'middle', $property, 'test_widget' );
		$this->assertNotEmpty( $errors );
		$this->assertStringContainsString( 'left, center, right', $errors[0] );
	}

	public function test_validate_value_color() {
		$method = new ReflectionMethod( 'Respira_Elementor_Settings_Validator', 'validate_value' );
		$method->setAccessible( true );

		$property = array( 'type' => 'string', 'format' => 'color' );

		// Valid hex.
		$errors = $method->invoke( null, 'color', '#FF0000', $property, 'test_widget' );
		$this->assertEmpty( $errors );

		// Valid rgba.
		$errors = $method->invoke( null, 'color', 'rgba(255,0,0,0.5)', $property, 'test_widget' );
		$this->assertEmpty( $errors );

		// Invalid.
		$errors = $method->invoke( null, 'color', 'not-a-color', $property, 'test_widget' );
		$this->assertNotEmpty( $errors );
	}

	public function test_validate_value_boolean_switcher() {
		$method = new ReflectionMethod( 'Respira_Elementor_Settings_Validator', 'validate_value' );
		$method->setAccessible( true );

		$property = array( 'type' => 'boolean' );

		// Elementor uses 'yes' for true.
		$errors = $method->invoke( null, 'show_title', 'yes', $property, 'test_widget' );
		$this->assertEmpty( $errors );

		// Empty string for false.
		$errors = $method->invoke( null, 'show_title', '', $property, 'test_widget' );
		$this->assertEmpty( $errors );

		// Invalid.
		$errors = $method->invoke( null, 'show_title', 'true', $property, 'test_widget' );
		$this->assertNotEmpty( $errors );
	}
}
