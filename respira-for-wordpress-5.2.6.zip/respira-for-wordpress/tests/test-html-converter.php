<?php
/**
 * HTML Converter regression tests.
 *
 * @package Respira_For_WordPress
 */

/**
 * Test suite for HTML converter asset preservation.
 */
class Respira_HTML_Converter_Tests extends WP_UnitTestCase {

	/**
	 * Converter instance under test.
	 *
	 * @var Respira_HTML_Converter
	 */
	private $converter;

	/**
	 * Reflection handle for asset extraction.
	 *
	 * @var ReflectionMethod
	 */
	private $extract_assets_method;

	/**
	 * Reflection handle for Elementor asset prepending.
	 *
	 * @var ReflectionMethod
	 */
	private $prepend_assets_method;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();

		$this->converter             = new Respira_HTML_Converter();
		$this->extract_assets_method = new ReflectionMethod( $this->converter, 'extract_presentational_head_assets' );
		$this->extract_assets_method->setAccessible( true );
		$this->prepend_assets_method = new ReflectionMethod( $this->converter, 'prepend_elementor_global_assets' );
		$this->prepend_assets_method->setAccessible( true );
	}

	/**
	 * Source head assets should preserve Google Fonts links and style blocks.
	 */
	public function test_extract_presentational_head_assets_keeps_fonts_and_styles() {
		$html = <<<'HTML'
<!DOCTYPE html>
<html lang="de">
<head>
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet" />
	<style>:root { --color-primary: #4ecece; } .hero { background: var(--color-primary); }</style>
</head>
<body><div class="hero">Hero</div></body>
</html>
HTML;

		$assets = $this->extract_assets_method->invoke( $this->converter, $html );

		$this->assertStringContainsString( 'fonts.googleapis.com', $assets );
		$this->assertStringContainsString( 'fonts.gstatic.com', $assets );
		$this->assertStringContainsString( '<style>', $assets );
		$this->assertStringContainsString( '--color-primary', $assets );
	}

	/**
	 * Elementor payload should gain a dedicated top-level assets container.
	 */
	public function test_prepend_elementor_global_assets_adds_html_widget_container() {
		$payload = array(
			array(
				'id'       => 'respira_existing',
				'elType'   => 'container',
				'settings' => array(),
				'isInner'  => false,
				'elements' => array(),
			),
		);

		$updated = $this->prepend_assets_method->invoke(
			$this->converter,
			$payload,
			'<link rel="preconnect" href="https://fonts.googleapis.com" /><style>.hero{color:red;}</style>'
		);

		$this->assertCount( 2, $updated );
		$this->assertSame( 'container', $updated[0]['elType'] );
		$this->assertSame( 'widget', $updated[0]['elements'][0]['elType'] );
		$this->assertSame( 'html', $updated[0]['elements'][0]['widgetType'] );
		$this->assertStringContainsString( 'fonts.googleapis.com', $updated[0]['elements'][0]['settings']['html'] );
		$this->assertSame( 'respira_existing', $updated[1]['id'] );
	}
}
