<?php
/**
 * Breakdance Builder Tests
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests/builders
 * @since      2.0.0
 */

/**
 * Test suite for Breakdance builder support.
 *
 * @since 2.0.0
 */
class Respira_Breakdance_Tests extends WP_UnitTestCase {

	/**
	 * Builder instance.
	 *
	 * @var Respira_Builder_Breakdance
	 */
	private $builder;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();
		$this->builder = new Respira_Builder_Breakdance();
	}

	/**
	 * Test that the builder returns the correct name.
	 */
	public function test_get_name() {
		$this->assertEquals( 'Breakdance', $this->builder->get_name() );
	}

	/**
	 * Test page detection via _breakdance_data post meta.
	 */
	public function test_breakdance_page_detection() {
		$post_id = $this->factory->post->create();

		// Should not be detected without meta.
		$this->assertFalse( $this->builder->is_builder_used( $post_id ) );

		// Add Breakdance data meta.
		update_post_meta( $post_id, '_breakdance_data', '{"tree":{"children":[]}}' );

		// Now should be detected.
		$this->assertTrue( $this->builder->is_builder_used( $post_id ) );
	}

	/**
	 * Test content extraction from Breakdance JSON structure.
	 */
	public function test_extract_content() {
		$post_id        = $this->factory->post->create();
		$breakdance_data = array(
			'tree' => array(
				'children' => array(
					array(
						'id'       => 'section-1',
						'type'     => 'EssentialElements\\Section',
						'data'     => array( 'label' => 'Hero Section' ),
						'children' => array(
							array(
								'id'       => 'heading-1',
								'type'     => 'EssentialElements\\Heading',
								'data'     => array( 'content' => 'Welcome' ),
								'children' => array(),
							),
						),
					),
				),
			),
		);

		update_post_meta( $post_id, '_breakdance_data', wp_json_encode( $breakdance_data ) );

		$extracted = $this->builder->extract_content( $post_id );

		$this->assertIsArray( $extracted );
		$this->assertCount( 1, $extracted );
		$this->assertEquals( 'section-1', $extracted[0]['id'] );
		$this->assertEquals( 'EssentialElements\\Section', $extracted[0]['type'] );
		$this->assertCount( 1, $extracted[0]['children'] );
		$this->assertEquals( 'heading-1', $extracted[0]['children'][0]['id'] );
	}

	/**
	 * Test extract_content returns empty array when no data exists.
	 */
	public function test_extract_content_no_data() {
		$post_id   = $this->factory->post->create();
		$extracted = $this->builder->extract_content( $post_id );

		$this->assertIsArray( $extracted );
		$this->assertEmpty( $extracted );
	}

	/**
	 * Test CSS injection via Code Block element.
	 */
	public function test_css_injection_via_code_block() {
		$post_id        = $this->factory->post->create();
		$breakdance_data = array(
			'tree' => array(
				'children' => array(),
			),
		);

		update_post_meta( $post_id, '_breakdance_data', wp_json_encode( $breakdance_data ) );

		$result = $this->builder->create_code_block(
			$post_id,
			'',
			'.page-id-' . $post_id . ' .bde-heading { color: blue; }'
		);

		$this->assertTrue( $result );

		// Verify Code Block was created with respiraManaged marker.
		$updated_raw  = get_post_meta( $post_id, '_breakdance_data', true );
		$updated_data = json_decode( $updated_raw, true );

		$this->assertIsArray( $updated_data );

		$found_code_block = false;
		foreach ( $updated_data['tree']['children'] as $element ) {
			if (
				isset( $element['data']['respiraManaged'] ) &&
				true === $element['data']['respiraManaged']
			) {
				$found_code_block = true;
				$this->assertStringContainsString( 'bde-heading', $element['data']['html'] );
			}
		}

		$this->assertTrue( $found_code_block, 'Respira-managed Code Block element was not created.' );
	}

	/**
	 * Test that a second create_code_block call updates the existing block.
	 */
	public function test_css_injection_updates_existing_code_block() {
		$post_id        = $this->factory->post->create();
		$breakdance_data = array(
			'tree' => array(
				'children' => array(),
			),
		);

		update_post_meta( $post_id, '_breakdance_data', wp_json_encode( $breakdance_data ) );

		// First injection.
		$this->builder->create_code_block( $post_id, '', '.first { color: red; }' );

		// Second injection.
		$this->builder->create_code_block( $post_id, '', '.second { color: green; }' );

		// Should only have one Respira-managed block.
		$updated_data = json_decode( get_post_meta( $post_id, '_breakdance_data', true ), true );
		$respira_blocks = array_filter(
			$updated_data['tree']['children'],
			function( $el ) {
				return isset( $el['data']['respiraManaged'] ) && true === $el['data']['respiraManaged'];
			}
		);

		$this->assertCount( 1, $respira_blocks, 'Expected exactly one Respira-managed Code Block.' );
	}

	/**
	 * Test inject_content returns WP_Error when no data exists.
	 */
	public function test_inject_content_no_data_returns_error() {
		$post_id = $this->factory->post->create();
		$result  = $this->builder->inject_content( $post_id, array() );

		$this->assertInstanceOf( 'WP_Error', $result );
		$this->assertEquals( 'breakdance_no_data', $result->get_error_code() );
	}

	/**
	 * Test that duplicate_post copies Breakdance data.
	 *
	 * The Respira_Duplicator copies all post meta, so _breakdance_data
	 * is automatically carried over without builder-specific code.
	 */
	public function test_duplicate_copies_breakdance_data() {
		$original_id     = $this->factory->post->create();
		$breakdance_data = '{"tree":{"children":[]}}';

		update_post_meta( $original_id, '_breakdance_data', $breakdance_data );
		update_post_meta( $original_id, '_breakdance_settings', '{"disable_theme":false}' );

		$duplicate_id = Respira_Duplicator::duplicate_post( $original_id );

		$this->assertIsInt( $duplicate_id );
		$this->assertEquals(
			$breakdance_data,
			get_post_meta( $duplicate_id, '_breakdance_data', true )
		);
		$this->assertEquals(
			'{"disable_theme":false}',
			get_post_meta( $duplicate_id, '_breakdance_settings', true )
		);
	}

	/**
	 * Test get_documentation returns the expected keys.
	 */
	public function test_get_documentation() {
		$docs = $this->builder->get_documentation();

		$this->assertIsArray( $docs );
		$this->assertArrayHasKey( 'name', $docs );
		$this->assertArrayHasKey( 'selectors', $docs );
		$this->assertArrayHasKey( 'notes', $docs );
		$this->assertEquals( 'Breakdance', $docs['name'] );
		$this->assertArrayHasKey( 'container', $docs['selectors'] );
		$this->assertEquals( '.breakdance', $docs['selectors']['container'] );
	}

	/**
	 * Test get_available_modules returns a non-empty array.
	 */
	public function test_get_available_modules() {
		$modules = $this->builder->get_available_modules();

		$this->assertIsArray( $modules );
		$this->assertNotEmpty( $modules );

		// Check that each module has required keys.
		foreach ( $modules as $module ) {
			$this->assertArrayHasKey( 'name', $module );
			$this->assertArrayHasKey( 'title', $module );
			$this->assertArrayHasKey( 'description', $module );
		}
	}

	/**
	 * Test is_themeless_mode returns a bool.
	 */
	public function test_is_themeless_mode() {
		// Without settings, should return false.
		$this->assertFalse( $this->builder->is_themeless_mode() );

		// Simulate themeless mode enabled.
		update_option( 'breakdance_settings', array( 'disable_theme' => true ) );
		$this->assertTrue( $this->builder->is_themeless_mode() );

		// Clean up.
		delete_option( 'breakdance_settings' );
	}
}
