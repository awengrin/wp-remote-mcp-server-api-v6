<?php
/**
 * Divi Builder Tests
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests/builders
 * @since      2.0.1
 */

/**
 * Test suite for Divi 4/5 builder behavior.
 *
 * @since 2.0.1
 */
class Respira_Divi_Tests extends WP_UnitTestCase {

	/**
	 * Builder instance.
	 *
	 * @var Respira_Builder_Divi
	 */
	private $builder;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();
		$this->builder = new Respira_Builder_Divi();
	}

	/**
	 * Divi 5 pages should be detected from block markers.
	 */
	public function test_is_builder_used_detects_divi5_blocks() {
		$post_id = $this->factory->post->create(
			array(
				'post_content' => '<!-- wp:divi/text {"module_id":"hero-title"} -->Hello<!-- /wp:divi/text -->',
			)
		);

		$this->assertTrue( $this->builder->is_builder_used( $post_id ) );
	}

	/**
	 * Divi 5 extraction should return block-based simplified nodes.
	 */
	public function test_extract_content_divi5_returns_block_nodes() {
		$post_id = $this->factory->post->create(
			array(
				'post_content' => '<!-- wp:divi/text {"module_id":"hero-title"} -->Hello<!-- /wp:divi/text -->',
			)
		);

		$extracted = $this->builder->extract_content( $post_id );

		$this->assertIsArray( $extracted );
		$this->assertNotEmpty( $extracted );
		$this->assertEquals( 'divi/text', $extracted[0]['type'] );
		$this->assertArrayHasKey( 'attributes', $extracted[0] );
	}

	/**
	 * Divi 5 inject should not overwrite Divi 4 shortcode meta fields.
	 */
	public function test_inject_content_divi5_preserves_divi4_meta_fields() {
		$post_id = $this->factory->post->create(
			array(
				'post_content' => '<!-- wp:divi/text {"module_id":"intro"} -->Old<!-- /wp:divi/text -->',
			)
		);

		update_post_meta( $post_id, '_et_pb_page_content', '[et_pb_text]Legacy[/et_pb_text]' );
		update_post_meta( $post_id, '_et_pb_layout_content', '[et_pb_row][/et_pb_row]' );

		$new_content = array(
			array(
				'type'       => 'divi/text',
				'attributes' => array(
					'module_id' => 'intro',
				),
				'content'    => 'Updated',
				'children'   => array(),
			),
		);

		$result = $this->builder->inject_content( $post_id, $new_content );

		$this->assertTrue( $result );
		$this->assertEquals( '[et_pb_text]Legacy[/et_pb_text]', get_post_meta( $post_id, '_et_pb_page_content', true ) );
		$this->assertEquals( '[et_pb_row][/et_pb_row]', get_post_meta( $post_id, '_et_pb_layout_content', true ) );
	}

	/**
	 * Divi 5 inject should serialize and save block markup.
	 */
	public function test_inject_content_divi5_saves_block_markup() {
		$post_id = $this->factory->post->create(
			array(
				'post_content' => '',
			)
		);

		$new_content = array(
			array(
				'type'       => 'divi/text',
				'attributes' => array(
					'module_id' => 'cta-title',
				),
				'content'    => '<h2>CTA</h2>',
				'children'   => array(),
			),
		);

		$result = $this->builder->inject_content( $post_id, $new_content );
		$saved  = get_post_field( 'post_content', $post_id );

		$this->assertTrue( $result );
		$this->assertStringContainsString( 'wp:divi/text', $saved );
	}
}
