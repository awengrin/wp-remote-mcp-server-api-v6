<?php
/**
 * Elementor Builder Tests
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests/builders
 * @since      4.0.7
 */

if ( ! class_exists( 'Respira_Test_Builder_Validator' ) ) {
	/**
	 * Test helper to expose protected validator methods.
	 */
	class Respira_Test_Builder_Validator extends Respira_Builder_Validator_Base {

		/**
		 * Required abstract implementation.
		 *
		 * @param mixed $content Content payload.
		 * @return array
		 */
		public function validate_layout( $content ) {
			return array(
				'valid'  => true,
				'errors' => array(),
			);
		}

		/**
		 * Public proxy for validate_url().
		 *
		 * @param mixed $value URL value.
		 * @return bool
		 */
		public function public_validate_url( $value ) {
			return $this->validate_url( $value );
		}
	}
}

if ( ! class_exists( 'Respira_Test_Elementor_Plugin_Stub' ) ) {
	/**
	 * Minimal stub used by tests when Elementor is unavailable.
	 */
	class Respira_Test_Elementor_Plugin_Stub {
		/**
		 * Mimics Elementor\Plugin::$instance.
		 *
		 * @var object|null
		 */
		public static $instance;
	}
}

/**
 * Test suite for Elementor regression coverage.
 *
 * @since 4.0.7
 */
class Respira_Elementor_Tests extends WP_UnitTestCase {

	/**
	 * Builder instance.
	 *
	 * @var Respira_Builder_Elementor
	 */
	private $builder;

	/**
	 * Reflection handle for complexify_structure().
	 *
	 * @var ReflectionMethod
	 */
	private $complexify_method;

	/**
	 * Reflection handle for decode_elementor_meta_elements().
	 *
	 * @var ReflectionMethod
	 */
	private $decode_method;

	/**
	 * Preserved Elementor instance for cleanup.
	 *
	 * @var mixed
	 */
	private $original_elementor_instance;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();
		$this->builder = new Respira_Builder_Elementor();
		$this->complexify_method = new ReflectionMethod( $this->builder, 'complexify_structure' );
		$this->complexify_method->setAccessible( true );
		$this->decode_method = new ReflectionMethod( $this->builder, 'decode_elementor_meta_elements' );
		$this->decode_method->setAccessible( true );
		$this->original_elementor_instance = null;

		if ( class_exists( '\Elementor\Plugin', false ) && property_exists( '\Elementor\Plugin', 'instance' ) ) {
			$this->original_elementor_instance = \Elementor\Plugin::$instance;
		}
	}

	/**
	 * Tear down test fixtures.
	 */
	public function tearDown(): void {
		if ( class_exists( '\Elementor\Plugin', false ) && property_exists( '\Elementor\Plugin', 'instance' ) ) {
			\Elementor\Plugin::$instance = $this->original_elementor_instance;
		}

		parent::tearDown();
	}

	/**
	 * URL validation should accept Elementor link control arrays.
	 */
	public function test_validate_url_accepts_elementor_link_array() {
		$validator = new Respira_Test_Builder_Validator();
		$link = array(
			'url'               => 'https://example.com',
			'is_external'       => 'on',
			'nofollow'          => '',
			'custom_attributes' => '',
		);

		$this->assertTrue( $validator->public_validate_url( $link ) );
	}

	/**
	 * URL validation should reject malicious link values in Elementor arrays.
	 */
	public function test_validate_url_rejects_invalid_elementor_link_array() {
		$validator = new Respira_Test_Builder_Validator();
		$link = array(
			'url' => 'javascript:alert(1)',
		);

		$this->assertFalse( $validator->public_validate_url( $link ) );
	}

	/**
	 * Nested widgets should not be re-wrapped after root conversion.
	 */
	public function test_complexify_structure_wraps_only_at_root() {
		$simplified = array(
			array(
				'type'     => 'container',
				'settings' => array(),
				'elements' => array(
					array(
						'type'     => 'widget',
						'widget'   => 'heading',
						'settings' => array(
							'title' => 'Hero',
						),
						'elements' => array(),
					),
				),
			),
		);

		$complex = $this->invoke_complexify( $simplified );

		$this->assertSame( 'container', $complex[0]['elType'] );
		$this->assertNotEmpty( $complex[0]['elements'] );
		$this->assertSame( 'widget', $complex[0]['elements'][0]['elType'] );
	}

	/**
	 * Recursion guard should cap malformed deeply nested trees.
	 */
	public function test_complexify_structure_depth_guard_limits_nested_trees() {
		$node = array(
			'type'     => 'widget',
			'widget'   => 'text-editor',
			'settings' => array(
				'editor' => 'leaf',
			),
			'elements' => array(),
		);

		for ( $i = 0; $i < 70; $i++ ) {
			$node = array(
				'type'     => 'container',
				'settings' => array(),
				'elements' => array( $node ),
			);
		}

		$complex = $this->invoke_complexify( array( $node ) );
		$max_depth = $this->get_max_element_depth( $complex );

		$this->assertLessThanOrEqual( 61, $max_depth );
	}

	/**
	 * Generated Elementor IDs must be unique across the whole nested tree.
	 */
	public function test_complexify_structure_generates_unique_ids_across_nested_tree() {
		$simplified = array(
			array(
				'type'     => 'container',
				'settings' => array(),
				'elements' => array(
					array(
						'type'     => 'container',
						'settings' => array(),
						'elements' => array(
							array(
								'type'     => 'widget',
								'widget'   => 'heading',
								'settings' => array(
									'title' => 'Hero',
								),
							),
						),
					),
					array(
						'type'     => 'container',
						'settings' => array(),
						'elements' => array(
							array(
								'type'     => 'widget',
								'widget'   => 'text-editor',
								'settings' => array(
									'editor' => '<p>Body</p>',
								),
							),
						),
					),
				),
			),
		);

		$complex = $this->invoke_complexify( $simplified );
		$ids     = $this->collect_element_ids( $complex );

		$this->assertNotEmpty( $ids );
		$this->assertCount( count( array_unique( $ids ) ), $ids );
	}

	/**
	 * Leaf widgets must not keep nested child elements.
	 */
	public function test_complexify_structure_strips_children_from_leaf_widgets() {
		$simplified = array(
			array(
				'type'     => 'widget',
				'widget'   => 'text-editor',
				'settings' => array(
					'editor' => '<p>Parent</p>',
				),
				'elements' => array(
					array(
						'type'     => 'widget',
						'widget'   => 'heading',
						'settings' => array(
							'title' => 'Child',
						),
					),
				),
			),
		);

		$complex = $this->invoke_complexify( $simplified );

		$this->assertSame( 'widget', $complex[0]['elType'] );
		$this->assertArrayNotHasKey( 'elements', $complex[0] );
	}

	/**
	 * Injectable flow should catch Error throwables from protected save_elements().
	 */
	public function test_inject_content_catches_protected_save_elements_error() {
		if ( class_exists( '\Elementor\Plugin', false ) && ! is_a( '\Elementor\Plugin', 'Respira_Test_Elementor_Plugin_Stub', true ) ) {
			$this->markTestSkipped( 'Elementor\\Plugin is already loaded in this test runtime.' );
		}

		if ( ! class_exists( '\Elementor\Plugin', false ) ) {
			class_alias( 'Respira_Test_Elementor_Plugin_Stub', 'Elementor\\Plugin' );
		}

		$document = new class {
			protected function save_elements( $elements ) {
				return true;
			}

			public function save_builder_state() {
				return true;
			}
		};

		$documents = new class( $document ) {
			private $document;

			public function __construct( $document ) {
				$this->document = $document;
			}

			public function get( $post_id, $with_cache = false ) {
				return $this->document;
			}
		};

		$files_manager = new class {
			public $cache_cleared = false;

			public function clear_cache() {
				$this->cache_cleared = true;
			}
		};

		$plugin_instance = new class( $documents, $files_manager ) {
			public $documents;
			public $files_manager;

			public function __construct( $documents, $files_manager ) {
				$this->documents = $documents;
				$this->files_manager = $files_manager;
			}

			public function get_version() {
				return '3.35.5';
			}
		};

		\Elementor\Plugin::$instance = $plugin_instance;

		$post_id = $this->factory->post->create();
		update_post_meta( $post_id, '_elementor_element_cache', 'stale' );

		$result = $this->builder->inject_content( $post_id, array() );

		$this->assertTrue( $result );
		$this->assertTrue( $files_manager->cache_cleared );
		$this->assertSame( '', get_post_meta( $post_id, '_elementor_element_cache', true ) );
		$this->assertSame( 'builder', get_post_meta( $post_id, '_elementor_edit_mode', true ) );
		$this->assertEquals( array(), json_decode( wp_unslash( get_post_meta( $post_id, '_elementor_data', true ) ), true ) );
	}

	/**
	 * Extraction should unwrap serialized single-item wrappers around JSON.
	 */
	public function test_decode_elementor_meta_elements_unwraps_serialized_wrapper() {
		$post_id = $this->factory->post->create();
		$elements = array(
			array(
				'id'         => 'abc123',
				'elType'     => 'widget',
				'widgetType' => 'text-editor',
				'settings'   => array(
					'editor' => '<p>Hello</p>',
				),
			),
		);

		$raw = maybe_serialize(
			array(
				wp_json_encode( $elements ),
			)
		);

		$decoded = $this->decode_method->invoke( $this->builder, $raw, $post_id );

		$this->assertIsArray( $decoded );
		$this->assertSame( 'abc123', $decoded[0]['id'] );
		$this->assertSame( 'text-editor', $decoded[0]['widgetType'] );
	}

	/**
	 * Extraction should tolerate a UTF-8 BOM before valid Elementor JSON.
	 */
	public function test_decode_elementor_meta_elements_strips_utf8_bom() {
		$post_id = $this->factory->post->create();
		$elements = array(
			array(
				'id'         => 'bom123',
				'elType'     => 'widget',
				'widgetType' => 'heading',
				'settings'   => array(
					'title' => 'Headline',
				),
			),
		);

		$raw = "\xEF\xBB\xBF" . wp_json_encode( $elements );

		$decoded = $this->decode_method->invoke( $this->builder, $raw, $post_id );

		$this->assertIsArray( $decoded );
		$this->assertSame( 'bom123', $decoded[0]['id'] );
		$this->assertSame( 'heading', $decoded[0]['widgetType'] );
	}

	/**
	 * Extraction decode should recover from double-escaped JSON payloads.
	 */
	public function test_decode_elementor_meta_elements_recovers_double_escaped_json() {
		$post_id = $this->factory->post->create();
		$elements = array(
			array(
				'id'         => 'slash123',
				'elType'     => 'widget',
				'widgetType' => 'text-editor',
				'settings'   => array(
					'editor' => '<p>Slashed</p>',
				),
			),
		);

		$raw = wp_slash( wp_slash( wp_json_encode( $elements ) ) );
		$decoded = $this->decode_method->invoke( $this->builder, $raw, $post_id );

		$this->assertIsArray( $decoded );
		$this->assertSame( 'slash123', $decoded[0]['id'] );
		$this->assertSame( 'text-editor', $decoded[0]['widgetType'] );
	}

	/**
	 * Extraction should fallback to Elementor document API when raw JSON decode fails.
	 */
	public function test_extract_content_falls_back_to_document_api_when_decode_fails() {
		if ( class_exists( '\Elementor\Plugin', false ) && ! is_a( '\Elementor\Plugin', 'Respira_Test_Elementor_Plugin_Stub', true ) ) {
			$this->markTestSkipped( 'Elementor\\Plugin is already loaded in this test runtime.' );
		}

		if ( ! class_exists( '\Elementor\Plugin', false ) ) {
			class_alias( 'Respira_Test_Elementor_Plugin_Stub', 'Elementor\\Plugin' );
		}

		$document = new class {
			public function get_elements_data() {
				return array(
					array(
						'id'         => 'doc123',
						'elType'     => 'widget',
						'widgetType' => 'text-editor',
						'settings'   => array(
							'editor' => '<p>Recovered</p>',
						),
						'elements'   => array(),
					),
				);
			}
		};

		$documents = new class( $document ) {
			private $document;

			public function __construct( $document ) {
				$this->document = $document;
			}

			public function get( $post_id, $with_cache = false ) {
				return $this->document;
			}
		};

		$plugin_instance = new class( $documents ) {
			public $documents;

			public function __construct( $documents ) {
				$this->documents = $documents;
			}

			public function get_version() {
				return '3.35.7';
			}
		};

		\Elementor\Plugin::$instance = $plugin_instance;

		$post_id = $this->factory->post->create();
		update_post_meta( $post_id, '_elementor_data', '{this is not json' );

		$extracted = $this->builder->extract_content( $post_id );

		$this->assertIsArray( $extracted );
		$this->assertCount( 1, $extracted );
		$this->assertSame( 'doc123', $extracted[0]['id'] );
		$this->assertSame( 'text-editor', $extracted[0]['widget'] );

		$stored = json_decode( wp_unslash( get_post_meta( $post_id, '_elementor_data', true ) ), true );
		$this->assertIsArray( $stored );
		$this->assertSame( 'doc123', $stored[0]['id'] );
	}

	/**
	 * Invoke protected complexify_structure().
	 *
	 * @param array $simplified Simplified structure.
	 * @return array
	 */
	private function invoke_complexify( $simplified ) {
		return $this->complexify_method->invoke( $this->builder, $simplified );
	}

	/**
	 * Measure maximum depth in Elementor element trees.
	 *
	 * @param array $elements Element tree.
	 * @param int   $depth Current depth.
	 * @return int
	 */
	private function get_max_element_depth( $elements, $depth = 0 ) {
		if ( empty( $elements ) || ! is_array( $elements ) ) {
			return $depth;
		}

		$max_depth = $depth;
		foreach ( $elements as $element ) {
			$current_depth = $depth + 1;
			$child_depth = $this->get_max_element_depth( $element['elements'] ?? array(), $current_depth );
			if ( $child_depth > $max_depth ) {
				$max_depth = $child_depth;
			}
		}

		return $max_depth;
	}

	/**
	 * Collect element IDs from a nested Elementor tree.
	 *
	 * @param array $elements Element tree.
	 * @return array
	 */
	private function collect_element_ids( $elements ) {
		$ids = array();

		if ( empty( $elements ) || ! is_array( $elements ) ) {
			return $ids;
		}

		foreach ( $elements as $element ) {
			if ( isset( $element['id'] ) ) {
				$ids[] = $element['id'];
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$ids = array_merge( $ids, $this->collect_element_ids( $element['elements'] ) );
			}
		}

		return $ids;
	}
}
