<?php
/**
 * Bricks Builder Tests
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/tests/builders
 * @since      4.2.1
 */

/**
 * Test suite for Bricks Builder regression coverage.
 *
 * Covers inject_content, extract_content, the CSS-regeneration hook, and the
 * bricks/use_duplicate_content gate in Respira_Duplicator.
 *
 * Data flow:
 *   inject_content(simplified) → complexify → update_post_meta(BRICKS_META_KEY)
 *                               → bricks_clear_page_cache (if available)
 *                               → do_action('bricks/generate_css_file', $post_id)
 *
 *   extract_content($post_id) → get_post_meta(BRICKS_META_KEY) → simplify
 *
 * @since 4.2.1
 */
class Respira_Bricks_Tests extends WP_UnitTestCase {

	/**
	 * Builder instance under test.
	 *
	 * @var Respira_Builder_Bricks
	 */
	private $builder;

	/**
	 * Set up test fixtures.
	 */
	public function setUp(): void {
		parent::setUp();
		$this->builder = new Respira_Builder_Bricks();
	}

	// -------------------------------------------------------------------------
	// Meta key constant
	// -------------------------------------------------------------------------

	/**
	 * BRICKS_META_KEY constant must be the 2.x key, not the legacy 1.x key.
	 */
	public function test_meta_key_constant_is_bricks_page_content_2() {
		$this->assertSame( '_bricks_page_content_2', Respira_Builder_Bricks::BRICKS_META_KEY );
	}

	// -------------------------------------------------------------------------
	// inject_content — happy path
	// -------------------------------------------------------------------------

	/**
	 * inject_content should persist elements under BRICKS_META_KEY and mark the
	 * post as Bricks-built.
	 */
	public function test_inject_content_writes_to_correct_meta_key() {
		$post_id = $this->factory->post->create();

		$content = array(
			array(
				'id'       => 'aabbcc',
				'name'     => 'heading',
				'parent'   => 0,
				'settings' => array( 'text' => 'Hello' ),
			),
		);

		$result = $this->builder->inject_content( $post_id, $content );

		$this->assertTrue( $result );
		$stored = get_post_meta( $post_id, Respira_Builder_Bricks::BRICKS_META_KEY, true );
		$this->assertIsArray( $stored );
		$this->assertNotEmpty( $stored );
	}

	/**
	 * inject_content should set _bricks_editor_mode to 'bricks'.
	 */
	public function test_inject_content_marks_editor_mode() {
		$post_id = $this->factory->post->create();

		$this->builder->inject_content( $post_id, array() );

		$this->assertSame( 'bricks', get_post_meta( $post_id, '_bricks_editor_mode', true ) );
	}

	/**
	 * inject_content should accept JSON-encoded string payloads and decode them.
	 */
	public function test_inject_content_accepts_json_string_payload() {
		$post_id = $this->factory->post->create();

		$elements = array(
			array(
				'id'       => 'ddeeff',
				'name'     => 'text',
				'parent'   => 0,
				'settings' => array( 'text' => 'World' ),
			),
		);

		$result = $this->builder->inject_content( $post_id, wp_json_encode( $elements ) );

		$this->assertTrue( $result );
		$stored = get_post_meta( $post_id, Respira_Builder_Bricks::BRICKS_META_KEY, true );
		$this->assertIsArray( $stored );
	}

	// -------------------------------------------------------------------------
	// inject_content — CSS regen hook
	// -------------------------------------------------------------------------

	/**
	 * inject_content must fire bricks/generate_css_file after the meta write.
	 *
	 * This is the CSS-regeneration fix for the Bricks 2.2 "success but no
	 * visible change" bug — without this hook, Bricks' external-file CSS
	 * loading mode serves stale styles after a content update.
	 */
	public function test_inject_content_fires_generate_css_file_action() {
		$post_id = $this->factory->post->create();

		$hook_fired    = false;
		$hook_post_id  = null;

		add_action(
			'bricks/generate_css_file',
			function ( $pid ) use ( &$hook_fired, &$hook_post_id ) {
				$hook_fired   = true;
				$hook_post_id = $pid;
			}
		);

		$this->builder->inject_content( $post_id, array() );

		$this->assertTrue( $hook_fired, 'bricks/generate_css_file was not fired after inject_content' );
		$this->assertSame( $post_id, $hook_post_id );
	}

	// -------------------------------------------------------------------------
	// extract_content
	// -------------------------------------------------------------------------

	/**
	 * extract_content should return an empty array when the post has no Bricks data.
	 */
	public function test_extract_content_returns_empty_for_non_bricks_post() {
		$post_id = $this->factory->post->create();

		$result = $this->builder->extract_content( $post_id );

		$this->assertSame( array(), $result );
	}

	/**
	 * extract_content should simplify and return elements stored under BRICKS_META_KEY.
	 */
	public function test_extract_content_reads_from_correct_meta_key() {
		$post_id = $this->factory->post->create();

		$elements = array(
			array(
				'id'       => 'xxyyzz',
				'name'     => 'image',
				'parent'   => 0,
				'settings' => array( 'image' => array( 'id' => 99 ) ),
			),
		);

		update_post_meta( $post_id, Respira_Builder_Bricks::BRICKS_META_KEY, $elements );

		$extracted = $this->builder->extract_content( $post_id );

		$this->assertIsArray( $extracted );
		$this->assertCount( 1, $extracted );
		$this->assertSame( 'xxyyzz', $extracted[0]['id'] );
		$this->assertSame( 'image', $extracted[0]['type'] );
	}

	/**
	 * is_builder_used should return true when BRICKS_META_KEY holds an array.
	 */
	public function test_is_builder_used_returns_true_when_meta_set() {
		$post_id = $this->factory->post->create();

		update_post_meta( $post_id, Respira_Builder_Bricks::BRICKS_META_KEY, array( array( 'id' => 'a1' ) ) );

		$this->assertTrue( $this->builder->is_builder_used( $post_id ) );
	}

	/**
	 * is_builder_used should return false for a vanilla WP post.
	 */
	public function test_is_builder_used_returns_false_when_meta_absent() {
		$post_id = $this->factory->post->create();

		$this->assertFalse( $this->builder->is_builder_used( $post_id ) );
	}

	// -------------------------------------------------------------------------
	// get_documentation — browser_events
	// -------------------------------------------------------------------------

	/**
	 * get_documentation() must include the browser_events key for WebMCP
	 * consumers that need to await Bricks AJAX events.
	 */
	public function test_get_documentation_includes_browser_events() {
		$docs = $this->builder->get_documentation();

		$this->assertArrayHasKey( 'browser_events', $docs );
		$this->assertArrayHasKey( 'bricks/ajax/end', $docs['browser_events'] );
		$this->assertArrayHasKey( 'bricks/ajax/query_result/displayed', $docs['browser_events'] );
	}

	/**
	 * get_documentation() must expose the correct meta_key so AI context is accurate.
	 */
	public function test_get_documentation_includes_correct_meta_key() {
		$docs = $this->builder->get_documentation();

		$this->assertArrayHasKey( 'meta_key', $docs );
		$this->assertSame( '_bricks_page_content_2', $docs['meta_key'] );
	}

	// -------------------------------------------------------------------------
	// Duplicator — bricks/use_duplicate_content gate
	// -------------------------------------------------------------------------

	/**
	 * Duplicator must honour a false return from bricks/use_duplicate_content
	 * when Bricks is active.
	 */
	public function test_duplicator_respects_bricks_use_duplicate_content_false() {
		if ( ! defined( 'BRICKS_VERSION' ) && ! class_exists( 'Bricks\Database' ) ) {
			// Simulate Bricks being active so the gate code runs.
			if ( ! defined( 'BRICKS_VERSION' ) ) {
				define( 'BRICKS_VERSION', '2.2.0-test' );
			}
		}

		$post_id = $this->factory->post->create();

		add_filter( 'bricks/use_duplicate_content', '__return_false' );

		$result = Respira_Duplicator::duplicate_post( $post_id );

		remove_filter( 'bricks/use_duplicate_content', '__return_false' );

		$this->assertWPError( $result );
		$this->assertSame( 'respira_bricks_duplicate_blocked', $result->get_error_code() );
	}

	/**
	 * Duplicator must proceed normally when bricks/use_duplicate_content returns true.
	 */
	public function test_duplicator_proceeds_when_bricks_use_duplicate_content_true() {
		$post_id = $this->factory->post->create(
			array( 'post_title' => 'Original Bricks Page' )
		);

		update_post_meta( $post_id, Respira_Builder_Bricks::BRICKS_META_KEY, array( array( 'id' => 'orig1' ) ) );

		add_filter( 'bricks/use_duplicate_content', '__return_true' );

		$duplicate_id = Respira_Duplicator::duplicate_post( $post_id );

		remove_filter( 'bricks/use_duplicate_content', '__return_true' );

		$this->assertIsInt( $duplicate_id );
		$this->assertNotSame( $post_id, $duplicate_id );

		$dup_meta = get_post_meta( $duplicate_id, Respira_Builder_Bricks::BRICKS_META_KEY, true );
		$this->assertIsArray( $dup_meta );
	}
}
