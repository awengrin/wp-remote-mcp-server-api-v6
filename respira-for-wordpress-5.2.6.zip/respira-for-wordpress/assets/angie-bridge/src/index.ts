import { AngieMcpSdk } from '@elementor/angie-sdk';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  type CallToolResult,
  type Tool,
} from '@modelcontextprotocol/sdk/types.js';

type BridgeConfig = {
  toolsEndpoint: string;
  executeBase: string;
  nonce: string;
  version: string;
  serverName: string;
  serverLabel: string;
};

declare global {
  interface Window {
    respiraAngieBridge?: BridgeConfig;
    __respiraAngieBridgeInit?: boolean;
  }
}

declare const wp: {
  apiFetch: (options: {
    url: string;
    method?: string;
    data?: unknown;
    headers?: Record<string, string>;
  }) => Promise<unknown>;
};

function getConfig(): BridgeConfig | null {
  return typeof window !== 'undefined' && window.respiraAngieBridge
    ? window.respiraAngieBridge
    : null;
}

async function fetchTools(config: BridgeConfig): Promise<Tool[]> {
  const response = (await wp.apiFetch({
    url: config.toolsEndpoint,
    method: 'GET',
    headers: {
      'X-WP-Nonce': config.nonce,
    },
  })) as { tools?: Tool[] };

  return Array.isArray(response.tools) ? response.tools : [];
}

async function executeTool(
  config: BridgeConfig,
  name: string,
  args: Record<string, unknown>,
): Promise<CallToolResult> {
  try {
    return (await wp.apiFetch({
      url: config.executeBase + encodeURIComponent(name),
      method: 'POST',
      data: args,
      headers: {
        'X-WP-Nonce': config.nonce,
      },
    })) as CallToolResult;
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Respira tool execution failed.';
    return {
      content: [
        {
          type: 'text',
          text: message,
        },
      ],
      isError: true,
    };
  }
}

async function init() {
  if (window.__respiraAngieBridgeInit) {
    return;
  }

  const config = getConfig();
  if (!config || typeof wp === 'undefined' || typeof wp.apiFetch !== 'function') {
    return;
  }

  window.__respiraAngieBridgeInit = true;

  const sdk = new AngieMcpSdk();
  await sdk.waitForReady();

  const server = new McpServer({
    name: config.serverName,
    version: config.version,
  }, {
    capabilities: {
      tools: {
        listChanged: true,
      },
    },
  });

  server.server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: await fetchTools(config),
  }));

  server.server.setRequestHandler(CallToolRequestSchema, async (request) =>
    executeTool(
      config,
      request.params.name,
      (request.params.arguments as Record<string, unknown> | undefined) ?? {},
    ),
  );

  await sdk.registerServer({
    name: config.serverName,
    version: config.version,
    description:
      'Respira for WordPress: safe duplicate-first editing, builder-aware extraction and injection, and WooCommerce product management.',
    server,
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    void init();
  });
} else {
  void init();
}
