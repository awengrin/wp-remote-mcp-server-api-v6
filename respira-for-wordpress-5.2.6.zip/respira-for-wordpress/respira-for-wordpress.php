<?php
/**
 * Plugin Name: Respira for WordPress
 * Plugin URI: https://respira.press
 * Description: Vibe code your WordPress site. No SSH required. Connect AI coding assistants like Cursor and Claude Code to edit your WordPress site through a secure REST API.
 * Version: 5.2.6
 * Author: Respira
 * Author URI: https://respira.press
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: respira-for-wordpress
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package Respira_For_WordPress
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Current plugin version.
 */
if ( ! defined( 'RESPIRA_VERSION' ) ) {
	define( 'RESPIRA_VERSION', '5.2.6' );
}

/**
 * Plugin directory path.
 */
if ( ! defined( 'RESPIRA_PLUGIN_DIR' ) ) {
	define( 'RESPIRA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

/**
 * Plugin directory URL.
 */
if ( ! defined( 'RESPIRA_PLUGIN_URL' ) ) {
	define( 'RESPIRA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Plugin basename.
 */
if ( ! defined( 'RESPIRA_PLUGIN_BASENAME' ) ) {
	define( 'RESPIRA_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * REST API namespace.
 */
if ( ! defined( 'RESPIRA_REST_NAMESPACE' ) ) {
	define( 'RESPIRA_REST_NAMESPACE', 'respira/v1' );
}

/**
 * Explicit v1 REST namespace.
 */
if ( ! defined( 'RESPIRA_REST_NAMESPACE_V1' ) ) {
	define( 'RESPIRA_REST_NAMESPACE_V1', 'respira/v1' );
}

/**
 * V2 REST namespace.
 */
if ( ! defined( 'RESPIRA_REST_NAMESPACE_V2' ) ) {
	define( 'RESPIRA_REST_NAMESPACE_V2', 'respira/v2' );
}

/**
 * Convert PHP_VERSION_ID style integer to a human-readable version string.
 *
 * @param int $php_version_id PHP version ID (for example 70400).
 * @return string
 */
function respira_php_version_id_to_string( $php_version_id ) {
	$php_version_id = (int) $php_version_id;
	if ( $php_version_id <= 0 ) {
		return 'unknown';
	}

	$major = (int) floor( $php_version_id / 10000 );
	$minor = (int) floor( ( $php_version_id % 10000 ) / 100 );
	$patch = (int) ( $php_version_id % 100 );

	return $major . '.' . $minor . '.' . $patch;
}

/**
 * Detect Composer vendor platform PHP requirement from platform_check.php.
 *
 * @return int|null PHP_VERSION_ID requirement or null when not detected.
 */
function respira_detect_vendor_php_requirement() {
	$platform_check_file = RESPIRA_PLUGIN_DIR . 'vendor/composer/platform_check.php';

	if ( ! file_exists( $platform_check_file ) || ! is_readable( $platform_check_file ) ) {
		return null;
	}

	$platform_check = (string) file_get_contents( $platform_check_file );
	if ( '' === $platform_check ) {
		return null;
	}

	if ( preg_match( '/PHP_VERSION_ID\s*>=\s*(\d{5,6})/', $platform_check, $matches ) ) {
		return (int) $matches[1];
	}

	return null;
}

/**
 * Halt bootstrap safely when runtime PHP is lower than package requirements.
 *
 * Prevents hard fatals from Composer's platform_check when release artifacts are
 * built with incompatible dependency constraints.
 */
function respira_guard_php_runtime() {
	$declared_min_php_id = 70400; // Keep aligned with plugin header/readme requirement.
	$vendor_min_php_id   = respira_detect_vendor_php_requirement();
	$required_php_id     = max( $declared_min_php_id, (int) $vendor_min_php_id );

	if ( PHP_VERSION_ID >= $required_php_id ) {
		return true;
	}

	$required_php = respira_php_version_id_to_string( $required_php_id );
	$current_php  = PHP_VERSION;

	if ( is_admin() ) {
		add_action(
			'admin_notices',
			function () use ( $required_php, $current_php ) {
				if ( ! current_user_can( 'activate_plugins' ) ) {
					return;
				}
				?>
				<div class="notice notice-error">
					<p><strong><?php esc_html_e( 'Respira for WordPress could not start.', 'respira-for-wordpress' ); ?></strong></p>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: required PHP version, 2: current PHP version */
								__( 'This build requires PHP %1$s or newer. Current server PHP is %2$s.', 'respira-for-wordpress' ),
								$required_php,
								$current_php
							)
						);
						?>
					</p>
					<p><?php esc_html_e( 'Please upgrade PHP on this site or install a Respira build compatible with your server version.', 'respira-for-wordpress' ); ?></p>
				</div>
				<?php
			}
		);
	}

	error_log( sprintf( '[Respira] Bootstrap blocked: requires PHP %s+, current %s.', $required_php, $current_php ) );

	return false;
}

if ( ! respira_guard_php_runtime() ) {
	return;
}

/**
 * Dev mode warning and REST header.
 * RESPIRA_DEV_MODE is defined in wp-config.php for local testing only.
 */
if ( defined( 'RESPIRA_DEV_MODE' ) && RESPIRA_DEV_MODE ) {
	add_action(
		'admin_notices',
		function () {
			?>
			<div class="notice notice-error" style="border-left-color: #d63638;">
				<p><strong style="color: #d63638;"><?php echo esc_html( '⚠️ RESPIRA DEV MODE ACTIVE' ); ?></strong> — <?php esc_html_e( 'License checks are bypassed. Do not use in production.', 'respira-for-wordpress' ); ?></p>
			</div>
			<?php
		}
	);
	add_filter(
		'rest_post_dispatch',
		function ( $response ) {
			$response->header( 'X-Respira-Dev-Mode', 'true' );
			return $response;
		}
	);
}

/**
 * Sentry DSN for error tracking (optional).
 * Set via wp-config.php or environment variable.
 */
if ( ! defined( 'RESPIRA_SENTRY_DSN' ) ) {
	define( 'RESPIRA_SENTRY_DSN', getenv( 'RESPIRA_SENTRY_DSN' ) ?: '' );
}

/**
 * The code that runs during plugin activation.
 */
function activate_respira_for_wordpress() {
	require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-activator.php';
	Respira_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_respira_for_wordpress() {
	require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-deactivator.php';
	Respira_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_respira_for_wordpress' );
register_deactivation_hook( __FILE__, 'deactivate_respira_for_wordpress' );

/**
 * Load Composer autoloader for dependencies (Sentry SDK).
 */
if ( file_exists( RESPIRA_PLUGIN_DIR . 'vendor/autoload.php' ) ) {
	require_once RESPIRA_PLUGIN_DIR . 'vendor/autoload.php';
}

/**
 * Initialize Sentry error tracking.
 */
require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-sentry.php';
Respira_Sentry::get_instance();

/**
 * Bundled WebMCP plugin constants.
 */
require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-webmcp-integration.php';

/**
 * Bundled WebMCP bridge (requires PHP 8.1+ due upstream codebase syntax).
 */
if ( version_compare( PHP_VERSION, '8.1', '>=' ) ) {
	if ( ! defined( 'RESPIRA_WMCP_VERSION' ) ) {
		define( 'RESPIRA_WMCP_VERSION', '0.6.1' );
	}
	if ( ! defined( 'RESPIRA_WMCP_PLUGIN_DIR' ) ) {
		define( 'RESPIRA_WMCP_PLUGIN_DIR', RESPIRA_PLUGIN_DIR . 'includes/webmcp/' );
	}
	if ( ! defined( 'RESPIRA_WMCP_PLUGIN_URL' ) ) {
		define( 'RESPIRA_WMCP_PLUGIN_URL', RESPIRA_PLUGIN_URL . 'includes/webmcp/' );
	}

	require_once RESPIRA_PLUGIN_DIR . 'includes/webmcp/class-plugin.php';

	/**
	 * Disable upstream built-in starter tools; Respira exposes its own full registry.
	 */
	add_filter( 'wmcp_include_builtin_tools', '__return_false' );
}

/**
 * Boot bundled WebMCP bridge + Respira ability registry.
 */
add_action(
	'plugins_loaded',
	function () {
		if ( version_compare( PHP_VERSION, '8.1', '>=' ) && class_exists( 'Respira\\WebMCP\\Plugin' ) ) {
			Respira\WebMCP\Plugin::instance();
		}

		if ( class_exists( 'Respira_WebMCP_Integration' ) ) {
			new Respira_WebMCP_Integration();

			if ( null === get_option( 'respira_webmcp_tools', null ) ) {
				update_option( 'respira_webmcp_tools', array( 'all' ) );
			}

			$selected_tool_groups = get_option( 'respira_webmcp_tools', array( 'all' ) );
			$all_tools_selected   = is_array( $selected_tool_groups ) && 1 === count( $selected_tool_groups ) && 'all' === (string) reset( $selected_tool_groups );

			if ( method_exists( 'Respira_WebMCP_Integration', 'get_ability_ids_for_adapter' ) ) {
				// Run after init so REST/permalink globals are ready in multisite + WP-CLI bootstrap.
				add_action(
					'init',
					static function () use ( $all_tools_selected ) {
						if ( 1 !== (int) get_option( 'wmcp_enabled', 1 ) ) {
							update_option( 'wmcp_enabled', 1 );
						}

						if ( null === get_option( 'wmcp_exposed_tools', null ) || $all_tools_selected ) {
							update_option( 'wmcp_exposed_tools', Respira_WebMCP_Integration::get_ability_ids_for_adapter() );
						}
					},
					20
				);
			}
		}
	},
	5
);

/**
 * Boot optional Angie bridge only when Angie is present.
 */
add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'Angie\\Plugin' ) && ! defined( 'ANGIE_VERSION' ) ) {
			return;
		}

		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-angie-integration.php';

		if ( class_exists( 'Respira_Angie_Integration' ) ) {
			Respira_Angie_Integration::boot();
		}
	},
	20
);

/**
 * Version migration engine — runs before core loads.
 */
require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-upgrader.php';
add_action( 'plugins_loaded', array( 'Respira_Upgrader', 'maybe_upgrade' ), 4 );

/**
 * WordPress MCP Adapter integration.
 * Registers Respira as a custom MCP server in the official adapter.
 */
require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-mcp-adapter.php';
new Respira_MCP_Adapter();

/**
 * The core plugin class.
 */
require RESPIRA_PLUGIN_DIR . 'includes/class-respira-core.php';

/**
 * Begins execution of the plugin.
 *
 * @since 1.0.0
 */
function run_respira_for_wordpress() {
	$plugin = new Respira_Core();
	$plugin->run();
}

run_respira_for_wordpress();
