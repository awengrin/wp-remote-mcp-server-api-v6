<?php
/**
 * What's New in Respira v5.2.0 "Elemental"
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_screen = 'respira-whats-new';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
?>

<div class="respira-page-body respira-whats-new">

	<!-- Hero banner — compact strip with overlay text -->
	<div class="respira-wn-hero">
		<img src="<?php echo esc_url( plugins_url( 'admin/assets/images/elemental-hero.jpg', RESPIRA_PLUGIN_DIR . 'respira-for-wordpress.php' ) ); ?>"
			alt=""
			class="respira-wn-hero-img"
			aria-hidden="true">
		<div class="respira-wn-hero-overlay">
			<img src="<?php echo esc_url( plugins_url( 'admin/assets/images/respira-logo-square.png', RESPIRA_PLUGIN_DIR . 'respira-for-wordpress.php' ) ); ?>"
				alt="Respira"
				style="width: 96px; height: 96px; margin-bottom: 12px; filter: drop-shadow(0 4px 16px rgba(0,0,0,0.4));">
			<h2 class="respira-wn-hero-title"><?php esc_html_e( 'v5.2.0 Elemental', 'respira-for-wordpress' ); ?></h2>
			<p class="respira-wn-hero-subtitle"><?php esc_html_e( '65 new tools. Element-level precision. HTML-to-builder conversion.', 'respira-for-wordpress' ); ?></p>
		</div>
	</div>

	<!-- Stat pills -->
	<div class="respira-wn-stats">
		<span class="respira-wn-stat"><?php esc_html_e( '65 new tools', 'respira-for-wordpress' ); ?></span>
		<span class="respira-wn-stat"><?php esc_html_e( '11 builders', 'respira-for-wordpress' ); ?></span>
		<span class="respira-wn-stat"><?php esc_html_e( '151 total', 'respira-for-wordpress' ); ?></span>
		<span class="respira-wn-stat"><?php esc_html_e( 'Fidelity scoring', 'respira-for-wordpress' ); ?></span>
	</div>

	<!-- Headline features — 2-column grid, larger cards -->
	<h3 class="respira-wn-section-title"><?php esc_html_e( 'Headline Features', 'respira-for-wordpress' ); ?></h3>

	<div class="respira-wn-features-grid respira-wn-features-grid--headline">

		<div class="respira-wn-feature respira-wn-feature--headline">
			<div class="respira-wn-feature-icon">&#9998;</div>
			<h4><?php esc_html_e( 'Element-Level Editing', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Find, update, move, duplicate, and remove individual widgets without downloading the entire page. 7 new tools that work across all 11 builders.', 'respira-for-wordpress' ); ?></p>
			<div class="respira-wn-feature-tools">
				<code>find_element</code> <code>update_element</code> <code>move_element</code> <code>duplicate_element</code> <code>remove_element</code> <code>batch_update</code> <code>reorder_elements</code>
			</div>
		</div>

		<div class="respira-wn-feature respira-wn-feature--headline">
			<div class="respira-wn-feature-icon">&#8644;</div>
			<h4><?php esc_html_e( 'HTML-to-Builder Conversion', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Convert polished HTML drafts into native builder elements. CSS properties map to builder settings, media queries map to responsive breakpoints, and a fidelity report shows exactly what transferred.', 'respira-for-wordpress' ); ?></p>
			<a href="https://respira.press/releases/5.2.0" class="respira-wn-feature-link" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'See the release story', 'respira-for-wordpress' ); ?> &rarr;
			</a>
		</div>

		<div class="respira-wn-feature respira-wn-feature--headline">
			<div class="respira-wn-feature-icon">&#9783;</div>
			<h4><?php esc_html_e( 'Build Full Pages', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Create complete pages from a declarative structure in a single API call. AI sends native builder format, Respira handles the rest. Plus 27 widget shortcuts for quick additions.', 'respira-for-wordpress' ); ?></p>
			<div class="respira-wn-feature-tools">
				<code>build_page</code> + 27 <code>add_*</code> <?php esc_html_e( 'shortcuts', 'respira-for-wordpress' ); ?>
			</div>
		</div>

		<div class="respira-wn-feature respira-wn-feature--headline">
			<div class="respira-wn-feature-icon">&#128247;</div>
			<h4><?php esc_html_e( 'Stock Images via Openverse', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Search millions of openly-licensed images and sideload them into your Media Library with automatic Creative Commons attribution. SSRF-protected with domain allowlist.', 'respira-for-wordpress' ); ?></p>
			<div class="respira-wn-feature-tools">
				<code>search_stock_images</code> <code>sideload_image</code>
			</div>
		</div>

	</div>

	<!-- More in this release — smaller cards, 2-column -->
	<h3 class="respira-wn-section-title"><?php esc_html_e( 'More in This Release', 'respira-for-wordpress' ); ?></h3>

	<div class="respira-wn-features-grid">

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Dynamic Schemas for Elementor', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Reads the Elementor control registry at runtime and generates JSON Schemas for every widget. Includes "did you mean?" suggestions for typos.', 'respira-for-wordpress' ); ?></p>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Divi 5 Intelligence', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( '40+ module definitions, 7 real-world page patterns, design token system, and 13-point payload validation with 16 actionable error messages.', 'respira-for-wordpress' ); ?></p>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Tool Governance', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Disable sensitive tools per-category or individually. Governance blocks all access paths — REST, MCP, and WebMCP.', 'respira-for-wordpress' ); ?></p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-governance' ) ); ?>" class="respira-wn-feature-link">
				<?php esc_html_e( 'Configure governance', 'respira-for-wordpress' ); ?> &rarr;
			</a>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'MCP Server Compatibility', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Version negotiation endpoint checks plugin/server compatibility on startup. All REST responses include a version header.', 'respira-for-wordpress' ); ?></p>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'API Key Access Profiles', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Generate keys with scoped permissions — Full Access, Read Only, Content Editor, or Builder. Layered security alongside governance.', 'respira-for-wordpress' ); ?></p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>" class="respira-wn-feature-link">
				<?php esc_html_e( 'Generate a scoped key', 'respira-for-wordpress' ); ?> &rarr;
			</a>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Direct Edit Mode', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'When enabled, AI writes go straight to the original post without queuing a duplicate. Ideal for trusted workflows.', 'respira-for-wordpress' ); ?></p>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Built-in AI Workflow Guide', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'The MCP server now includes comprehensive instructions that teach AI models how to use Respira — per-builder content formats, common task recipes, and workflow patterns. No more SQL hacking or theme file editing.', 'respira-for-wordpress' ); ?></p>
		</div>

		<div class="respira-wn-feature">
			<h4><?php esc_html_e( 'Admin UI Polish', 'respira-for-wordpress' ); ?></h4>
			<p><?php esc_html_e( 'Risk-based settings grouping, auto-save with undo, confirmation dialogs for dangerous settings, new transparent logo, and alternating row colors.', 'respira-for-wordpress' ); ?></p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-settings' ) ); ?>" class="respira-wn-feature-link">
				<?php esc_html_e( 'See new settings', 'respira-for-wordpress' ); ?> &rarr;
			</a>
		</div>

	</div>

	<!-- Builder Support Levels -->
	<h3 class="respira-wn-section-title"><?php esc_html_e( 'Builder Support Levels', 'respira-for-wordpress' ); ?></h3>

	<div class="respira-card" style="padding: 0; overflow: hidden;">
		<table class="respira-wn-builder-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Level', 'respira-for-wordpress' ); ?></th>
					<th><?php esc_html_e( 'Builders', 'respira-for-wordpress' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr class="respira-wn-builder-row--full">
					<td>
						<span class="respira-wn-builder-dot respira-wn-builder-dot--full"></span>
						<?php esc_html_e( 'Full Intelligence', 'respira-for-wordpress' ); ?>
					</td>
					<td><?php esc_html_e( 'Elementor, Divi 5, Gutenberg', 'respira-for-wordpress' ); ?></td>
				</tr>
				<tr class="respira-wn-builder-row--smart">
					<td>
						<span class="respira-wn-builder-dot respira-wn-builder-dot--smart"></span>
						<?php esc_html_e( 'Smart Defaults', 'respira-for-wordpress' ); ?>
					</td>
					<td><?php esc_html_e( 'Beaver Builder, Bricks, Breakdance, Oxygen, WPBakery', 'respira-for-wordpress' ); ?></td>
				</tr>
				<tr class="respira-wn-builder-row--basic">
					<td>
						<span class="respira-wn-builder-dot respira-wn-builder-dot--basic"></span>
						<?php esc_html_e( 'Basic Support', 'respira-for-wordpress' ); ?>
					</td>
					<td><?php esc_html_e( 'Brizy, Thrive, Visual Composer', 'respira-for-wordpress' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- CTA section -->
	<div class="respira-wn-cta">
		<h3><?php esc_html_e( 'Ready to try Elemental?', 'respira-for-wordpress' ); ?></h3>
		<div class="respira-wn-cta-buttons">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-approvals' ) ); ?>" class="button button-primary">
				<?php esc_html_e( 'Open Changes Page', 'respira-for-wordpress' ); ?>
			</a>
			<a href="https://respira.press/docs" class="button" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Read the docs', 'respira-for-wordpress' ); ?>
			</a>
			<a href="https://respira.press/releases/5.2.0" class="button" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Full release story', 'respira-for-wordpress' ); ?> &rarr;
			</a>
		</div>
	</div>

	<!-- Changelog — collapsible -->
	<details class="respira-wn-changelog-details">
		<summary class="respira-wn-changelog-summary"><?php esc_html_e( 'View full changelog', 'respira-for-wordpress' ); ?></summary>

		<div class="respira-wn-changelog-body">
			<h4 class="respira-changelog-version"><?php echo esc_html( '[5.2.0] - 2026-03-23 "Elemental"' ); ?></h4>

			<h5 class="respira-changelog-category respira-changelog-added"><?php esc_html_e( 'Added', 'respira-for-wordpress' ); ?></h5>
			<ul class="respira-changelog-list">
				<li><strong><?php esc_html_e( 'Element-level operations', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'find, update, move, duplicate, remove, batch update, and reorder elements across all 11 builders.', 'respira-for-wordpress' ); ?></li>
				<li><strong>build_page</strong> — <?php esc_html_e( 'Create complete pages from a declarative structure in a single API call.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Stock images via Openverse', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'search and sideload CC-licensed images with attribution.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Tool governance', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Per-tool enable/disable with fail-open safety and audit logging.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Elementor dynamic schemas', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Runtime control registry with JSON Schema types and "did you mean?" suggestions.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Divi 5 intelligence', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( '40+ module definitions, 7 page patterns, design tokens, 13-point validation.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Builder tree utility', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Generic traversal for find/insert/remove/clone/reorder with MAX_DEPTH=50 guard.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Version migration engine', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Sequential migrations on plugins_loaded with snapshot cleanup and governance defaults.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Version negotiation', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Compatibility endpoint and X-Respira-Plugin-Version header on all REST responses.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'HTML-to-builder conversion', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'CSS extraction, section mapping, style translation, fidelity scoring.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Bulk page operations', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Apply changes across up to 100 pages with rate limiting and snapshots.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Widget shortcuts', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( '27 convenience tools via data-driven registry.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Dual tool registration', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'All tools available as both respira_* (preferred) and wordpress_* (deprecated).', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'UTF-8 passthrough', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Multibyte characters returned as readable text instead of escape sequences.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Frontend cache purge', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Automatic invalidation of 9 cache plugins after live edits and approvals.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'API key access profiles', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Generate keys with scoped permissions: Full Access, Read Only, Content Editor, or Builder.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Admin UI/UX polish', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Risk-based settings, auto-save with undo, new logo, builder support badges.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Beaver Builder HTML conversion', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Full HTML-to-Beaver pipeline with type mapping and multi-column layouts.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Builder cache invalidation on merge', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Approval merge now clears caches for Bricks, Elementor, Beaver Builder, and Divi.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Direct edit mode', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'When enabled, AI writes go directly to the original post without queuing a duplicate.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Built-in AI workflow guide', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'MCP server instructions teach AI models per-builder content formats and common task recipes.', 'respira-for-wordpress' ); ?></li>
			</ul>

			<h5 class="respira-changelog-category respira-changelog-fixed"><?php esc_html_e( 'Fixed', 'respira-for-wordpress' ); ?></h5>
			<ul class="respira-changelog-list">
				<li><strong><?php esc_html_e( 'Oxygen ct_template detection', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Templates storing content in ct_builder_json only were not detected. Now checks both meta keys.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Changes page empty on SQLite', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'MySQL-specific SQL syntax replaced with SQLite-compatible queries for WordPress Playground.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Trial-to-paid license orphan sites', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Webhook now finds and converts existing trial licenses instead of creating duplicates.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Duplicate admin banners', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'License validation notices deduplicated with unique slugs.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Direct edit mode not applied', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Write endpoints now respect the auto-duplicate setting for direct editing.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Trial email sent to paid users', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Cron and webhook now skip users with active paid licenses.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Gemini MCP schema compliance', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Array schemas now include required items property for strict validators.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Bricks approval merge cache', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Approving changes now triggers Bricks CSS regeneration.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Beaver Builder injection 500', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Builder name resolver now matches single-word identifiers like "beaver" to multi-word names like "Beaver Builder".', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Confirmation before validation', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'inject_builder_content now validates the builder before showing the confirmation prompt.', 'respira-for-wordpress' ); ?></li>
				<li><strong><?php esc_html_e( 'Gutenberg block validation', 'respira-for-wordpress' ); ?></strong> — <?php esc_html_e( 'Validator now accepts both "type" and "blockName" fields, and unwraps {blocks: [...]} wrappers.', 'respira-for-wordpress' ); ?></li>
			</ul>
		</div>
	</details>

	<!-- Acknowledgements -->
	<h3 class="respira-wn-section-title"><?php esc_html_e( 'Acknowledgements', 'respira-for-wordpress' ); ?></h3>

	<div class="respira-card" style="padding: 20px 24px;">
		<p style="margin: 0 0 16px; color: var(--respira-muted); font-size: 14px;">
			<?php esc_html_e( 'This release was shaped by the early adopters whose reports and patience pushed Elemental far beyond what we originally planned.', 'respira-for-wordpress' ); ?>
		</p>
		<ul style="margin: 0; padding: 0; list-style: none;">
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Glen &amp; Dave</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Detailed Beaver Builder bug report with reproduction steps that fixed the builder name resolver, confirmation ordering, and Gutenberg format handling.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Sam</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Bricks builder reports that drove CSS regeneration on inject, approval merge cache invalidation, and the comprehensive Bricks test suite.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Jeroen</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Caught the trial-to-paid license orphan bug and the duplicate admin banner issue.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">William</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Reported dead support links, SQLite/Playground compatibility issues, and other site-level bugs.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Yoliveras</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Reported the Gemini/Antigravity MCP schema compliance issue that was blocking strict validators.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Rixxter</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'Challenged us to do better with Elementor intelligence. His report about dropped sections and lost styles led directly to the entire HTML-to-builder conversion system.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0; border-bottom: 1px solid var(--respira-border);">
				<strong style="color: var(--respira-heading);">Sergei</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'For the idea of shipping built-in AI workflow instructions so models know how to use page builder tools correctly.', 'respira-for-wordpress' ); ?></span>
			</li>
			<li style="padding: 8px 0;">
				<strong style="color: var(--respira-heading);">Walter</strong>
				<span style="color: var(--respira-muted); font-size: 13px;"> — <?php esc_html_e( 'For reporting that Chinese characters were returned as Unicode escapes instead of readable text, leading to the UTF-8 passthrough fix.', 'respira-for-wordpress' ); ?></span>
			</li>
		</ul>
	</div>

</div>

<?php
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
