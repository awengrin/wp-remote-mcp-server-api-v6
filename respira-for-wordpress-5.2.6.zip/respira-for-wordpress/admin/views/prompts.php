<?php
/**
 * Prompt library view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$prompt_sections = array(
	array(
		'title'   => __( 'Planning & Safe Workflow', 'respira-for-wordpress' ),
		'prompts' => array(
			array(
				'title' => __( 'Site audit + prioritized plan', 'respira-for-wordpress' ),
				'text'  => 'Analyze this WordPress site and create a prioritized action plan for conversion, accessibility, SEO, and performance. Group recommendations into quick wins (under 30 minutes), medium tasks, and deep tasks.',
			),
			array(
				'title' => __( 'Duplicate first, then edit', 'respira-for-wordpress' ),
				'text'  => 'Duplicate the "Services" page and perform all edits on the duplicate only. Keep layout and global styles intact. Return a summary of every change made and do not publish automatically.',
			),
			array(
				'title' => __( 'High-confidence edits only', 'respira-for-wordpress' ),
				'text'  => 'Apply only high-confidence edits where the target element is unambiguous. Skip uncertain edits and list them with reasons in a "Needs manual review" section.',
			),
			array(
				'title' => __( 'Staging-safe batch update', 'respira-for-wordpress' ),
				'text'  => 'Create a batch plan for updating homepage, services, and contact pages. For each page: backup/duplicate, apply edits, verify links, verify mobile layout, and return before/after summary.',
			),
		),
	),
	array(
		'title'   => __( 'Copy & Conversion', 'respira-for-wordpress' ),
		'prompts' => array(
			array(
				'title' => __( 'Rewrite hero for local intent', 'respira-for-wordpress' ),
				'text'  => 'Rewrite the homepage hero for local intent: "Trusted legal services for Los Angeles". Keep tone professional and concise. Update headline, subheadline, and primary CTA text only.',
			),
			array(
				'title' => __( 'CTA optimization pass', 'respira-for-wordpress' ),
				'text'  => 'Review all CTA buttons on top pages and improve clarity, urgency, and consistency. Keep brand voice. Return old CTA text vs new CTA text in a table.',
			),
			array(
				'title' => __( 'Service page clarity rewrite', 'respira-for-wordpress' ),
				'text'  => 'Rewrite the main service page for non-technical readers: shorter paragraphs, clearer benefits, stronger social proof, and one focused CTA per section.',
			),
			array(
				'title' => __( 'FAQ generation from existing content', 'respira-for-wordpress' ),
				'text'  => 'Generate a practical FAQ section from existing site copy and insert it near the bottom of the target page. Include 6 questions and concise answers.',
			),
		),
	),
	array(
		'title'   => __( 'Design & Layout', 'respira-for-wordpress' ),
		'prompts' => array(
			array(
				'title' => __( 'Spacing and rhythm cleanup', 'respira-for-wordpress' ),
				'text'  => 'Normalize vertical spacing across the target page. Keep global design system. Fix inconsistent margins/padding and preserve responsive behavior on mobile/tablet.',
			),
			array(
				'title' => __( 'Section hierarchy improvement', 'respira-for-wordpress' ),
				'text'  => 'Improve section hierarchy using headings, supporting copy, and visual grouping. Keep current brand colors and typography. Do not redesign from scratch.',
			),
			array(
				'title' => __( 'Mobile-first polish pass', 'respira-for-wordpress' ),
				'text'  => 'Review top templates on mobile width and fix overflow, cramped spacing, and CTA visibility issues. Keep desktop layout unchanged unless necessary.',
			),
			array(
				'title' => __( 'Landing page builder prompt', 'respira-for-wordpress' ),
				'text'  => 'Create a new landing page called "Record Expungement" with: hero, proof bar, 3 benefit cards, process steps, FAQ, and a final contact CTA section.',
			),
		),
	),
	array(
		'title'   => __( 'Accessibility & Compliance', 'respira-for-wordpress' ),
		'prompts' => array(
			array(
				'title' => __( 'WCAG quick fix pass', 'respira-for-wordpress' ),
				'text'  => 'Run an accessibility pass and fix common issues: missing alt text, low-contrast text, unlabeled form fields, and empty links/buttons.',
			),
			array(
				'title' => __( 'Heading structure normalization', 'respira-for-wordpress' ),
				'text'  => 'Normalize heading hierarchy to a logical order (H1 → H2 → H3) across the current page. Do not skip levels. Preserve visual appearance.',
			),
			array(
				'title' => __( 'Form accessibility hardening', 'respira-for-wordpress' ),
				'text'  => 'Audit all visible forms and ensure every input has a proper label, useful error copy, and keyboard accessibility. Summarize remaining manual checks.',
			),
			array(
				'title' => __( 'Accessibility report summary', 'respira-for-wordpress' ),
				'text'  => 'Generate a plain-language summary of current accessibility issues by severity (critical/serious/moderate/minor) and list recommended next actions.',
			),
		),
	),
	array(
		'title'   => __( 'SEO & Content Operations', 'respira-for-wordpress' ),
		'prompts' => array(
			array(
				'title' => __( 'On-page SEO refresh', 'respira-for-wordpress' ),
				'text'  => 'Update title tag, meta description, H1, and intro paragraph for the target page around its primary keyword. Keep copy natural and avoid keyword stuffing.',
			),
			array(
				'title' => __( 'Internal linking pass', 'respira-for-wordpress' ),
				'text'  => 'Find linking opportunities between core service pages and blog posts. Add contextual internal links with clear anchor text and no over-linking.',
			),
			array(
				'title' => __( 'Global phrase replacement', 'respira-for-wordpress' ),
				'text'  => 'Find all pages mentioning "free consultation" and update to "strategy call". Keep surrounding grammar correct and return affected pages list.',
			),
			array(
				'title' => __( 'Schema-ready content cleanup', 'respira-for-wordpress' ),
				'text'  => 'Refactor service page content into structure suitable for schema markup (service summary, eligibility, process, pricing notes, FAQs).',
			),
		),
	),
);
if ( ! $respira_embed ) {
	$respira_screen = 'respira-prompts';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">
		<div class="respira-card respira-prompts-intro">
			<h2><?php esc_html_e( 'Prompt Library', 'respira-for-wordpress' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Use these prompt packs in Cursor, Codex, or Claude after MCP is configured on the Dashboard page.', 'respira-for-wordpress' ); ?>
			</p>
			<p class="respira-prompts-links">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-for-wordpress' ) ); ?>"><?php esc_html_e( 'Go back to Dashboard setup →', 'respira-for-wordpress' ); ?></a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-changes' ) ); ?>"><?php esc_html_e( 'View Changes →', 'respira-for-wordpress' ); ?></a>
			</p>
		</div>

		<?php foreach ( $prompt_sections as $section ) : ?>
			<div class="respira-card respira-prompts-section">
				<h3><?php echo esc_html( $section['title'] ); ?></h3>
				<div class="respira-dashboard-grid respira-prompts-grid">
					<?php foreach ( $section['prompts'] as $prompt ) : ?>
						<div class="respira-card respira-prompt-card">
							<div class="respira-prompt-card-header">
								<h4><?php echo esc_html( $prompt['title'] ); ?></h4>
								<button class="button button-small respira-copy-btn respira-copy-btn-inline" data-copy="<?php echo esc_attr( $prompt['text'] ); ?>"><?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?></button>
							</div>
							<div class="respira-code-block respira-code-block-large respira-prompt-block">
								<pre class="respira-prompt-pre"><code><?php echo esc_html( $prompt['text'] ); ?></code></pre>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endforeach; ?>
</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
