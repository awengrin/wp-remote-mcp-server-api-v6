<?php
/**
 * Skills marketplace admin view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      4.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

// Mark that this user has visited the Skills page (dismisses the NEW badge).
$current_user_id = get_current_user_id();
if ( $current_user_id > 0 ) {
	update_user_meta( $current_user_id, 'respira_skills_page_visited', gmdate( 'Y-m-d H:i:s' ) );
}

// Fetch skills catalog.
$skills_catalog = Respira_Admin::fetch_skills_catalog();
$skills         = isset( $skills_catalog['skills'] ) ? $skills_catalog['skills'] : array();
$fetch_error    = isset( $skills_catalog['error'] ) ? $skills_catalog['error'] : '';

// Extract unique categories.
$categories = array();
foreach ( $skills as $skill ) {
	$cat = isset( $skill['category'] ) ? $skill['category'] : 'uncategorized';
	if ( ! in_array( $cat, $categories, true ) ) {
		$categories[] = $cat;
	}
}
// Pin "onboarding" first, then sort the rest alphabetically.
usort( $categories, function ( $a, $b ) {
	if ( 'onboarding' === $a ) return -1;
	if ( 'onboarding' === $b ) return 1;
	return strcmp( $a, $b );
} );

if ( ! $respira_embed ) {
	$respira_screen = 'respira-skills';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body respira-skills-page">

	<div class="respira-section">
		<div class="respira-section-header">
			<h2>
				<span class="dashicons dashicons-welcome-learn-more"></span>
				<?php esc_html_e( 'Skills Marketplace', 'respira-for-wordpress' ); ?>
			</h2>
			<p><?php esc_html_e( 'Ready-to-run AI skills for WordPress. Install any skill into your project with one command.', 'respira-for-wordpress' ); ?></p>
		</div>

		<?php if ( $fetch_error ) : ?>
			<div class="respira-skills-error">
				<?php echo esc_html( $fetch_error ); ?>
			</div>
		<?php endif; ?>

		<!-- Filters -->
		<div class="respira-skills-filters">
			<div class="respira-skills-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Skill categories', 'respira-for-wordpress' ); ?>">
				<button type="button" class="respira-skills-tab is-active" role="tab" aria-selected="true" data-category="all">
					<?php esc_html_e( 'All', 'respira-for-wordpress' ); ?>
					<span class="respira-skills-tab-count"><?php echo count( $skills ); ?></span>
				</button>
				<?php foreach ( $categories as $cat ) : ?>
					<?php
					$cat_count = 0;
					foreach ( $skills as $s ) {
						if ( ( isset( $s['category'] ) ? $s['category'] : 'uncategorized' ) === $cat ) {
							$cat_count++;
						}
					}
					?>
					<button type="button" class="respira-skills-tab" role="tab" aria-selected="false" data-category="<?php echo esc_attr( $cat ); ?>">
						<?php echo esc_html( ucfirst( $cat ) ); ?>
						<span class="respira-skills-tab-count"><?php echo (int) $cat_count; ?></span>
					</button>
				<?php endforeach; ?>
			</div>
			<div class="respira-skills-search-wrap">
				<input type="search" id="respira-skills-search" class="respira-skills-search" placeholder="<?php esc_attr_e( 'Search skills...', 'respira-for-wordpress' ); ?>" />
			</div>
		</div>

		<!-- Skills grid -->
		<?php if ( ! empty( $skills ) ) : ?>
			<div class="respira-skills-grid">
				<?php foreach ( $skills as $skill ) :
					$name        = isset( $skill['name'] ) ? $skill['name'] : '';
					$slug        = isset( $skill['slug'] ) ? $skill['slug'] : '';
					$description = isset( $skill['description'] ) ? $skill['description'] : '';
					$category    = isset( $skill['category'] ) ? $skill['category'] : 'uncategorized';
					$author      = isset( $skill['author'] ) ? $skill['author'] : '';
					$version     = isset( $skill['version'] ) ? $skill['version'] : '';
					$requires_addon = isset( $skill['requires_addon'] ) ? $skill['requires_addon'] : '';
					$github_url  = isset( $skill['github_url'] ) ? $skill['github_url'] : '';
					$install_prompt = sprintf(
						'Install the %s WordPress skill: fetch %s and save it to .claude/commands/%s.md',
						$name,
						isset( $skill['raw_url'] ) ? $skill['raw_url'] : '',
						$slug
					);
				?>
					<div class="respira-skill-card" data-category="<?php echo esc_attr( $category ); ?>" data-name="<?php echo esc_attr( strtolower( $name ) ); ?>" data-description="<?php echo esc_attr( strtolower( $description ) ); ?>">
						<div class="respira-skill-card-header">
							<h3 class="respira-skill-name"><?php echo esc_html( $name ); ?></h3>
							<div class="respira-skill-badges">
								<span class="respira-skill-category-badge"><?php echo esc_html( ucfirst( $category ) ); ?></span>
								<?php if ( $requires_addon ) : ?>
									<span class="respira-skill-addon-badge" title="<?php echo esc_attr( sprintf( __( 'Requires %s Add-on', 'respira-for-wordpress' ), ucfirst( $requires_addon ) ) ); ?>">
										<?php echo esc_html( ucfirst( $requires_addon ) ); ?>
									</span>
								<?php endif; ?>
							</div>
						</div>
						<div class="respira-skill-card-body">
							<p class="respira-skill-description"><?php echo esc_html( $description ); ?></p>
							<?php if ( $author || $version ) : ?>
								<div class="respira-skill-meta">
									<?php if ( $author ) : ?>
										<span class="respira-skill-author"><?php echo esc_html( $author ); ?></span>
									<?php endif; ?>
									<?php if ( $version ) : ?>
										<span class="respira-skill-version">v<?php echo esc_html( $version ); ?></span>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
						<div class="respira-skill-card-actions">
							<button type="button" class="button button-primary respira-skill-one-click-install" data-skill-slug="<?php echo esc_attr( $slug ); ?>" data-skill-name="<?php echo esc_attr( $name ); ?>">
								<span class="dashicons dashicons-download" aria-hidden="true"></span>
								<?php esc_html_e( 'Install', 'respira-for-wordpress' ); ?>
							</button>
							<button type="button" class="button respira-copy-btn respira-skill-install-btn" data-copy="<?php echo esc_attr( $install_prompt ); ?>">
								<span class="dashicons dashicons-clipboard" aria-hidden="true"></span>
								<?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?>
							</button>
							<?php if ( $github_url ) : ?>
								<a href="<?php echo esc_url( $github_url ); ?>" target="_blank" rel="noopener noreferrer" class="button button-secondary respira-skill-github-btn">
									<span class="dashicons dashicons-external" aria-hidden="true"></span>
									<?php esc_html_e( 'GitHub', 'respira-for-wordpress' ); ?>
								</a>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php elseif ( ! $fetch_error ) : ?>
			<p class="respira-empty-state">
				<?php esc_html_e( 'No skills available yet. Check back soon.', 'respira-for-wordpress' ); ?>
			</p>
		<?php endif; ?>

		<div class="respira-skills-footer">
			<p>
				<?php esc_html_e( 'Want to learn more about Respira skills?', 'respira-for-wordpress' ); ?>
				<a href="https://www.respira.press/skills" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Visit respira.press/skills', 'respira-for-wordpress' ); ?></a>
			</p>
		</div>
	</div>

</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
