<?php
/**
 * Add-ons admin view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$context   = Respira_Context::get_site_info();
$addons    = isset( $context['addons'] ) ? $context['addons'] : array();
$woo_addon = isset( $addons['woocommerce'] ) ? $addons['woocommerce'] : array( 'installed' => false, 'licensed' => false );
$a11y_active = apply_filters( 'respira_accessibility_addon_active', false );
if ( ! $respira_embed ) {
	$respira_screen = 'respira-addons';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">

		<div class="respira-section">
			<div class="respira-section-header">
				<h2>
					<span class="dashicons dashicons-admin-plugins"></span>
					<?php esc_html_e( 'Add-ons', 'respira-for-wordpress' ); ?>
				</h2>
				<p><?php esc_html_e( 'Respira add-ons extend core with WooCommerce, accessibility scanning, and more.', 'respira-for-wordpress' ); ?></p>
			</div>

			<div class="respira-dashboard-grid">
				<!-- WooCommerce Add-on -->
				<div class="respira-card">
					<div class="respira-card-header">
						<h3><?php esc_html_e( 'WooCommerce Add-on', 'respira-for-wordpress' ); ?></h3>
						<?php if ( ! empty( $woo_addon['installed'] ) && ! empty( $woo_addon['licensed'] ) ) : ?>
							<span class="respira-badge respira-badge-success"><?php esc_html_e( 'Installed & Active', 'respira-for-wordpress' ); ?></span>
						<?php elseif ( ! empty( $woo_addon['installed'] ) ) : ?>
							<span class="respira-badge respira-badge-warning"><?php esc_html_e( 'Installed', 'respira-for-wordpress' ); ?></span>
						<?php else : ?>
							<span class="respira-badge respira-badge-secondary"><?php esc_html_e( 'Not installed', 'respira-for-wordpress' ); ?></span>
						<?php endif; ?>
					</div>
					<div class="respira-card-content">
						<?php if ( ! empty( $woo_addon['installed'] ) && ! empty( $woo_addon['licensed'] ) ) : ?>
							<p><?php esc_html_e( 'Products, orders, and inventory are available to your AI workflow.', 'respira-for-wordpress' ); ?></p>
						<?php elseif ( ! empty( $woo_addon['installed'] ) ) : ?>
							<p><?php esc_html_e( 'Add-on is installed. Activate your subscription at respira.press to use WooCommerce features.', 'respira-for-wordpress' ); ?></p>
							<p><a href="https://respira.press/dashboard/billing" target="_blank" rel="noopener noreferrer" class="button button-secondary"><?php esc_html_e( 'Manage billing →', 'respira-for-wordpress' ); ?></a></p>
						<?php else : ?>
							<p><?php esc_html_e( 'Manage products, orders, and inventory from your AI workflow.', 'respira-for-wordpress' ); ?></p>
							<p><a href="https://respira.press/addons/woocommerce" target="_blank" rel="noopener noreferrer" class="button button-primary"><?php esc_html_e( 'Get WooCommerce Add-on →', 'respira-for-wordpress' ); ?></a></p>
						<?php endif; ?>
					</div>
				</div>

				<!-- Accessibility Add-on -->
				<div class="respira-card">
					<div class="respira-card-header">
						<h3><?php esc_html_e( 'Accessibility Add-on', 'respira-for-wordpress' ); ?></h3>
						<?php if ( $a11y_active ) : ?>
							<span class="respira-badge respira-badge-success"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
						<?php else : ?>
							<span class="respira-badge respira-badge-secondary"><?php esc_html_e( 'Not active', 'respira-for-wordpress' ); ?></span>
						<?php endif; ?>
					</div>
					<div class="respira-card-content">
						<?php if ( $a11y_active ) : ?>
							<p><?php esc_html_e( 'WCAG 2.2 AA scanning, auto-fixes, and AI fix prompts for Cursor and Claude.', 'respira-for-wordpress' ); ?></p>
							<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=accessibility' ) ); ?>" class="button button-secondary"><?php esc_html_e( 'Open Accessibility →', 'respira-for-wordpress' ); ?></a></p>
						<?php else : ?>
							<p><?php esc_html_e( 'ADA & WCAG accessibility scanning, auto-fixes, and AI prompts for Elementor sites.', 'respira-for-wordpress' ); ?></p>
							<p><a href="https://respira.press/pricing" target="_blank" rel="noopener noreferrer" class="button button-primary"><?php esc_html_e( 'Get Accessibility Add-on →', 'respira-for-wordpress' ); ?></a></p>
							<p class="respira-addon-hint">
								<?php esc_html_e( 'A free Chrome extension is also available for basic scanning.', 'respira-for-wordpress' ); ?>
								<a href="https://chromewebstore.google.com/search/Respira%20ADA%20WCAG%20Scanner" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Install extension', 'respira-for-wordpress' ); ?></a>
							</p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>

</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
