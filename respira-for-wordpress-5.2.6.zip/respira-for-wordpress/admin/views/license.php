<?php
/**
 * License activation view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$license_info = Respira_License::get_license_info();
$license_key = $license_info['key'];
$license_status = $license_info['status'];
$is_active = $license_info['is_pro'];
if ( ! $respira_embed ) {
	$respira_screen = 'respira-license';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">
		<?php if ( empty( $respira_embed ) ) { settings_errors( 'respira_messages' ); } ?>

		<div class="respira-card">
			<h2><?php esc_html_e( 'Activate License', 'respira-for-wordpress' ); ?></h2>

			<?php if ( empty( $license_key ) || 'inactive' === $license_status ) : ?>

				<div class="respira-license-hint">
					<p>
						<strong><?php esc_html_e( 'Where to find your license key:', 'respira-for-wordpress' ); ?></strong>
						<?php esc_html_e( 'Log in to', 'respira-for-wordpress' ); ?>
						<a href="https://respira.press/dashboard" target="_blank">respira.press/dashboard</a>
						<?php esc_html_e( 'and copy the key that starts with', 'respira-for-wordpress' ); ?>
						<code>respira_</code>.
					</p>
					<p class="description">
						<?php esc_html_e( 'This is not the same as the LemonSqueezy order key from your purchase email. Your Respira key is generated in your account dashboard after signup.', 'respira-for-wordpress' ); ?>
					</p>
				</div>

				<form method="post" action="" id="respira-activate-license-form">
					<?php wp_nonce_field( 'respira_activate_license' ); ?>
					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="license_key"><?php esc_html_e( 'License Key', 'respira-for-wordpress' ); ?></label>
							</th>
							<td>
								<input type="text" name="license_key" id="license_key" class="regular-text" placeholder="respira_xxxxxxxxxxxx" value="<?php echo esc_attr( $license_key ); ?>" required>
								<p class="description">
									<a href="https://respira.press/dashboard" target="_blank"><?php esc_html_e( 'Open your Respira dashboard to copy the key →', 'respira-for-wordpress' ); ?></a>
								</p>
							</td>
						</tr>
					</table>

					<!-- Privacy Policy and Terms Agreement -->
					<div class="respira-agreement-section" >
						<h3 >
							<?php esc_html_e( 'Agreement Required', 'respira-for-wordpress' ); ?>
						</h3>
						<p >
							<?php esc_html_e( 'Please read and confirm that you agree to our Privacy Policy and Terms of Service before activating your license.', 'respira-for-wordpress' ); ?>
						</p>
						
						<div class="respira-agreement-checkboxes">
							<label >
								<input 
									type="checkbox" 
									name="agree_privacy" 
									id="agree_privacy" 
									value="1" 
									required
																	>
								<span>
									<?php
									printf(
										/* translators: %1$s: Privacy Policy link */
										esc_html__( 'I have read and agree to the %1$s.', 'respira-for-wordpress' ),
										'<a href="https://respira.press/privacy" target="_blank" rel="noopener noreferrer" >' . esc_html__( 'Privacy Policy', 'respira-for-wordpress' ) . '</a>'
									);
									?>
									<span class="respira-required">*</span>
								</span>
							</label>
							
							<label >
								<input 
									type="checkbox" 
									name="agree_terms" 
									id="agree_terms" 
									value="1" 
									required
																	>
								<span>
									<?php
									printf(
										/* translators: %1$s: Terms of Service link */
										esc_html__( 'I have read and agree to the %1$s.', 'respira-for-wordpress' ),
										'<a href="https://respira.press/terms" target="_blank" rel="noopener noreferrer" >' . esc_html__( 'Terms of Service', 'respira-for-wordpress' ) . '</a>'
									);
									?>
									<span class="respira-required">*</span>
								</span>
							</label>
						</div>

						<div class="respira-agreement-privacy-note">
							<p >
								<strong ><?php esc_html_e( 'Privacy Note:', 'respira-for-wordpress' ); ?></strong>
								<?php esc_html_e( 'By using Respira, you acknowledge that we collect anonymous usage statistics (page counts, line estimates) to improve the product. Your actual WordPress content, code, and data are NEVER transmitted or stored on our servers.', 'respira-for-wordpress' ); ?>
							</p>
						</div>
					</div>

					<p class="submit">
						<input type="submit" name="respira_activate_license" id="respira-activate-submit" class="button button-primary" value="<?php esc_attr_e( 'Activate License', 'respira-for-wordpress' ); ?>">
					</p>
				</form>

			<?php else : ?>
				<div class="respira-license-status">
					<table class="form-table">
						<tr>
							<th scope="row"><?php esc_html_e( 'License Status', 'respira-for-wordpress' ); ?></th>
							<td>
								<?php if ( 'active' === $license_status || 'trial' === $license_status ) : ?>
									<span class="respira-status-active"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
								<?php else : ?>
									<span class="respira-status-inactive"><?php esc_html_e( 'Inactive', 'respira-for-wordpress' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'License Key', 'respira-for-wordpress' ); ?></th>
							<td>
								<code><?php echo esc_html( $license_key ); ?></code>
							</td>
						</tr>
						<?php if ( isset( $license_info['data']['max_sites'] ) ) : ?>
							<tr>
								<th scope="row"><?php esc_html_e( 'Max Sites', 'respira-for-wordpress' ); ?></th>
								<td><?php echo esc_html( $license_info['data']['max_sites'] ); ?></td>
							</tr>
						<?php endif; ?>
					</table>
					<form method="post" action="" class="respira-license-deactivate-form">
						<?php wp_nonce_field( 'respira_deactivate_license' ); ?>
						<p class="submit">
							<input type="submit" name="respira_deactivate_license" class="button button-secondary" value="<?php esc_attr_e( 'Deactivate License', 'respira-for-wordpress' ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to deactivate this license?', 'respira-for-wordpress' ); ?>');">
						</p>
					</form>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( empty( $license_key ) || 'inactive' === $license_status ) : ?>
			<div class="respira-card">
				<h3><?php esc_html_e( 'Don\'t have a license?', 'respira-for-wordpress' ); ?></h3>
				<p>
					<?php esc_html_e( 'Start with a free 7-day trial or purchase a license to unlock all features.', 'respira-for-wordpress' ); ?>
				</p>
				<p>
					<a href="https://respira.press/dashboard" target="_blank" class="button button-primary">
						<?php esc_html_e( 'Get License Key →', 'respira-for-wordpress' ); ?>
					</a>
				</p>
			</div>
		<?php endif; ?>
</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
