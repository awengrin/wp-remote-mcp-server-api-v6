<?php
/**
 * Dashboard view — Overview page.
 *
 * State-aware: shows progressive onboarding for unconfigured sites,
 * full dashboard with MCP reference for connected sites.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

// --- Data fetches ---

$context        = Respira_Context::get_site_info();
$license_info   = Respira_License::get_license_info();
$license_key    = isset( $license_info['key'] ) ? (string) $license_info['key'] : '';
$license_status = isset( $license_info['status'] ) ? (string) $license_info['status'] : 'inactive';
$is_licensed    = ! empty( $license_info['is_pro'] ) || in_array( $license_status, array( 'active', 'trial' ), true );

$user_id   = get_current_user_id();
$user_keys = Respira_Auth::get_user_keys( $user_id );
$new_key   = get_user_meta( $user_id, 'respira_new_api_key', true );
if ( $new_key ) {
	delete_user_meta( $user_id, 'respira_new_api_key' );
}

// Copyable API key: prefer newly generated, then first active.
$copyable_api_key = '';
if ( ! empty( $new_key ) ) {
	$copyable_api_key = (string) $new_key;
} else {
	foreach ( $user_keys as $key ) {
		if ( empty( $key->is_active ) ) {
			continue;
		}
		$plaintext = Respira_Auth::get_plaintext_key( (int) $key->id, (int) $user_id );
		if ( $plaintext ) {
			$copyable_api_key = $plaintext;
			break;
		}
	}
}

// Active key count.
$active_key_count = 0;
foreach ( $user_keys as $key ) {
	if ( ! empty( $key->is_active ) ) {
		$active_key_count++;
	}
}

// Content counts.
$page_count = (int) wp_count_posts( 'page' )->publish;
$post_count = (int) wp_count_posts( 'post' )->publish;

// Snapshot count (guard: table may not exist).
global $wpdb;
$snapshot_table = $wpdb->prefix . 'respira_snapshots';
$snapshot_count = 0;
if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $snapshot_table ) ) === $snapshot_table ) {
	$snapshot_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$snapshot_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

// Pending approvals.
$pending_approvals = (int) $wpdb->get_var(
	$wpdb->prepare( "SELECT COUNT(*) FROM $wpdb->postmeta WHERE meta_key = %s", '_respira_duplicate' )
);

// Recent activity (7 days).
$audit_table           = $wpdb->prefix . 'respira_audit_log';
$recent_activity_count = 0;
$recent_logs           = array();
if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $audit_table ) ) === $audit_table ) {
	$seven_days_ago        = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
	$recent_activity_count = (int) $wpdb->get_var(
		$wpdb->prepare( "SELECT COUNT(*) FROM `$audit_table` WHERE created_at >= %s", $seven_days_ago ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	);
	$recent_logs = $wpdb->get_results( "SELECT * FROM `$audit_table` ORDER BY created_at DESC LIMIT 5" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

// Builder detection.
$builder_name    = '';
$builder_version = '';
if ( method_exists( 'Respira_Context', 'get_builder_info' ) ) {
	$builder_info = Respira_Context::get_builder_info();
	if ( ! empty( $builder_info['active_builder']['name'] ) ) {
		$builder_name    = $builder_info['active_builder']['name'];
		$builder_version = isset( $builder_info['active_builder']['version'] ) ? $builder_info['active_builder']['version'] : '';
	}
}

// Usage stats.
if ( ! class_exists( 'Respira_Dashboard_Stats' ) ) {
	require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-dashboard-stats.php';
}
$usage_stats   = Respira_Dashboard_Stats::get_stats();
$top_keys      = Respira_Dashboard_Stats::get_top_api_keys( 'month', 10 );

// URLs and MCP config.
$wordpress_url  = untrailingslashit( home_url() );
$endpoint_v1    = rest_url( defined( 'RESPIRA_REST_NAMESPACE_V1' ) ? RESPIRA_REST_NAMESPACE_V1 : 'respira/v1' );
$endpoint_v2    = rest_url( defined( 'RESPIRA_REST_NAMESPACE_V2' ) ? RESPIRA_REST_NAMESPACE_V2 : 'respira/v2' );
$status_v2      = untrailingslashit( $endpoint_v2 ) . '/status';
$config_api_key = $copyable_api_key ? $copyable_api_key : 'your-respira-api-key';
$mcp_config     = wp_json_encode(
	array(
		'mcpServers' => array(
			'respira-wordpress' => array(
				'command' => 'npx',
				'args'    => array( '-y', '@respira/wordpress-mcp-server' ),
				'env'     => array(
					'WORDPRESS_URL'     => $wordpress_url,
					'WORDPRESS_API_KEY' => $config_api_key,
				),
			),
		),
	),
	JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
);

$getting_started_prompt = 'Connect to my WordPress site at ' . esc_url( site_url() ) . ' via the Respira MCP server.' . "\n\n" .
	'1) Call wordpress_get_active_site and wordpress_get_site_context to verify the connection.' . "\n" .
	'2) Call wordpress_list_plugins, wordpress_get_builder_info, wordpress_list_post_types, and wordpress_list_pages to discover my site architecture.' . "\n" .
	'3) Produce a site briefing: connection status, theme, builder, active plugins, content overview (pages, posts, and custom post types with counts), and a categorized list of everything you can help me with based on what you found.';

// Dashboard state.
if ( ! $is_licensed ) {
	$dashboard_state = 'unlicensed';
} elseif ( 0 === $active_key_count ) {
	$dashboard_state = 'no_key';
} elseif ( 0 === $recent_activity_count ) {
	$dashboard_state = 'not_connected';
} else {
	$dashboard_state = 'connected';
}

// Usage stats (extracted here so they render for all licensed states).
$edits_month    = isset( $usage_stats['edits_this_month'] ) ? $usage_stats['edits_this_month'] : 0;
$edits_total    = isset( $usage_stats['edits_all_time'] ) ? $usage_stats['edits_all_time'] : 0;
$pages_ed_month = isset( $usage_stats['pages_edited_month'] ) ? $usage_stats['pages_edited_month'] : 0;
$posts_ed_month = isset( $usage_stats['posts_edited_month'] ) ? $usage_stats['posts_edited_month'] : 0;
$pages_ed_total = isset( $usage_stats['pages_edited_total'] ) ? $usage_stats['pages_edited_total'] : 0;
$posts_ed_total = isset( $usage_stats['posts_edited_total'] ) ? $usage_stats['posts_edited_total'] : 0;
$actions_month  = isset( $usage_stats['total_actions_month'] ) ? $usage_stats['total_actions_month'] : 0;
$actions_total  = isset( $usage_stats['total_actions_all_time'] ) ? $usage_stats['total_actions_all_time'] : 0;
$top_agents     = isset( $usage_stats['top_agents'] ) ? $usage_stats['top_agents'] : array();
$is_lite        = defined( 'RESPIRA_LITE_MONTHLY_LIMIT' );
$edit_limit     = $is_lite ? RESPIRA_LITE_MONTHLY_LIMIT : 0;
$edit_pct       = ( $is_lite && $edit_limit > 0 ) ? min( 100, round( ( $edits_month / $edit_limit ) * 100 ) ) : 0;

// Shell.
if ( ! $respira_embed ) {
	$respira_screen = 'respira-for-wordpress';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">
	<div class="respira-page-headline">
		<h2><?php esc_html_e( 'Overview', 'respira-for-wordpress' ); ?></h2>
		<p><?php esc_html_e( 'Connection status, quick actions, and recent activity.', 'respira-for-wordpress' ); ?></p>
	</div>

	<?php settings_errors( 'respira_messages' ); ?>

	<!-- Status Bar (always visible) -->
	<div class="respira-status-bar">
		<div class="respira-status-tile">
			<div class="respira-status-tile-label"><?php esc_html_e( 'License', 'respira-for-wordpress' ); ?></div>
			<div class="respira-status-tile-value">
				<?php if ( 'active' === $license_status ) : ?>
					<span class="respira-status-active"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
				<?php elseif ( 'trial' === $license_status ) : ?>
					<span class="respira-status-trial"><?php esc_html_e( 'Trial', 'respira-for-wordpress' ); ?></span>
				<?php else : ?>
					<span class="respira-status-inactive"><?php esc_html_e( 'Inactive', 'respira-for-wordpress' ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<div class="respira-status-tile">
			<div class="respira-status-tile-label"><?php esc_html_e( 'API Keys', 'respira-for-wordpress' ); ?></div>
			<div class="respira-status-tile-value">
				<?php
				if ( $active_key_count > 0 ) {
					/* translators: %d: number of active API keys */
					printf( esc_html__( '%d active', 'respira-for-wordpress' ), $active_key_count );
				} else {
					esc_html_e( 'None', 'respira-for-wordpress' );
				}
				?>
			</div>
		</div>
		<div class="respira-status-tile">
			<div class="respira-status-tile-label"><?php esc_html_e( 'Builder', 'respira-for-wordpress' ); ?></div>
			<div class="respira-status-tile-value">
				<?php
				if ( $builder_name ) {
					echo esc_html( $builder_name );
					if ( $builder_version ) {
						echo ' <span class="description">' . esc_html( $builder_version ) . '</span>';
					}
				} else {
					esc_html_e( 'None detected', 'respira-for-wordpress' );
				}
				?>
			</div>
		</div>
		<div class="respira-status-tile">
			<div class="respira-status-tile-label"><?php esc_html_e( 'Connection', 'respira-for-wordpress' ); ?></div>
			<div class="respira-status-tile-value">
				<?php if ( $recent_activity_count > 0 ) : ?>
					<span class="respira-status-active"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
				<?php else : ?>
					<?php esc_html_e( 'Waiting', 'respira-for-wordpress' ); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php if ( $is_licensed ) : ?>
		<!-- Edit Counter (visible for all licensed users) -->
		<div class="respira-edit-counter">
			<div class="respira-edit-counter-header">
				<h3>
					<?php if ( $is_lite ) : ?>
						<?php
						/* translators: 1: edits used, 2: monthly limit */
						printf( esc_html__( '%1$s / %2$s edits this month', 'respira-for-wordpress' ), '<strong>' . esc_html( number_format_i18n( $edits_month ) ) . '</strong>', esc_html( number_format_i18n( $edit_limit ) ) );
						?>
					<?php else : ?>
						<strong><?php echo esc_html( number_format_i18n( $edits_month ) ); ?></strong> <?php esc_html_e( 'edits this month', 'respira-for-wordpress' ); ?>
					<?php endif; ?>
				</h3>
				<span class="respira-edit-counter-total">
					<?php if ( ! $is_lite ) : ?>
						<?php esc_html_e( 'Unlimited', 'respira-for-wordpress' ); ?> &middot;
					<?php endif; ?>
					<?php
					/* translators: %s: total edits all-time */
					printf( esc_html__( '%s all-time', 'respira-for-wordpress' ), number_format_i18n( $edits_total ) );
					?>
				</span>
			</div>
			<?php if ( $is_lite ) : ?>
				<div class="respira-edit-progress">
					<div class="respira-edit-progress-bar<?php echo $edit_pct >= 90 ? ' is-warning' : ''; ?><?php echo $edit_pct >= 100 ? ' is-exhausted' : ''; ?>" style="width:<?php echo esc_attr( $edit_pct ); ?>%"></div>
				</div>
				<?php if ( $edit_pct >= 80 ) : ?>
					<p class="respira-edit-upgrade-hint">
						<?php if ( $edit_pct >= 100 ) : ?>
							<?php esc_html_e( 'Monthly limit reached.', 'respira-for-wordpress' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'Running low on edits.', 'respira-for-wordpress' ); ?>
						<?php endif; ?>
						<a href="https://respira.press?utm_source=lite&utm_medium=dashboard&utm_campaign=edit_counter" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Upgrade for unlimited edits', 'respira-for-wordpress' ); ?></a>
					</p>
				<?php endif; ?>
			<?php endif; ?>
		</div>

		<!-- Metrics (visible for all licensed users) -->
		<div class="respira-metric-grid respira-metric-grid-6">
			<div class="respira-metric-card">
				<div class="respira-metric-number"><?php echo esc_html( number_format_i18n( $pages_ed_month ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'Pages Edited', 'respira-for-wordpress' ); ?></div>
				<div class="respira-metric-sub"><?php echo esc_html( number_format_i18n( $pages_ed_total ) ); ?> <?php esc_html_e( 'total', 'respira-for-wordpress' ); ?></div>
			</div>
			<div class="respira-metric-card">
				<div class="respira-metric-number"><?php echo esc_html( number_format_i18n( $posts_ed_month ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'Posts Edited', 'respira-for-wordpress' ); ?></div>
				<div class="respira-metric-sub"><?php echo esc_html( number_format_i18n( $posts_ed_total ) ); ?> <?php esc_html_e( 'total', 'respira-for-wordpress' ); ?></div>
			</div>
			<div class="respira-metric-card">
				<div class="respira-metric-number"><?php echo esc_html( number_format_i18n( $actions_month ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'API Calls', 'respira-for-wordpress' ); ?></div>
				<div class="respira-metric-sub"><?php echo esc_html( number_format_i18n( $actions_total ) ); ?> <?php esc_html_e( 'total', 'respira-for-wordpress' ); ?></div>
			</div>
			<div class="respira-metric-card">
				<div class="respira-metric-number"><?php echo esc_html( number_format_i18n( $page_count ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'Pages', 'respira-for-wordpress' ); ?></div>
			</div>
			<div class="respira-metric-card">
				<div class="respira-metric-number"><?php echo esc_html( number_format_i18n( $snapshot_count ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'Snapshots', 'respira-for-wordpress' ); ?></div>
			</div>
			<div class="respira-metric-card">
				<div class="respira-metric-number<?php echo $pending_approvals > 0 ? ' respira-metric-accent' : ''; ?>"><?php echo esc_html( number_format_i18n( $pending_approvals ) ); ?></div>
				<div class="respira-metric-label"><?php esc_html_e( 'Pending Changes', 'respira-for-wordpress' ); ?></div>
			</div>
		</div>

		<?php if ( ! empty( $top_agents ) ) : ?>
		<!-- AI Agent Breakdown (visible for all licensed users) -->
		<div class="respira-card respira-agents-card">
			<h3><?php esc_html_e( 'AI Agents', 'respira-for-wordpress' ); ?></h3>
			<div class="respira-agents-list">
				<?php
				$agent_total = 0;
				foreach ( $top_agents as $agent ) {
					$agent_total += $agent['count'];
				}
				foreach ( $top_agents as $agent ) :
					$agent_pct = $agent_total > 0 ? round( ( $agent['count'] / $agent_total ) * 100 ) : 0;
				?>
				<div class="respira-agent-row">
					<span class="respira-agent-name"><?php echo esc_html( $agent['name'] ); ?></span>
					<div class="respira-agent-bar-wrap">
						<div class="respira-agent-bar" style="width:<?php echo esc_attr( $agent_pct ); ?>%"></div>
					</div>
					<span class="respira-agent-count"><?php echo esc_html( number_format_i18n( $agent['count'] ) ); ?></span>
					<span class="respira-agent-pct"><?php echo esc_html( $agent_pct ); ?>%</span>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if ( ! empty( $top_keys ) ) : ?>
		<!-- Top API Keys -->
		<div class="respira-card respira-top-keys-card">
			<h3><?php esc_html_e( 'Top API Keys', 'respira-for-wordpress' ); ?> <span class="description"><?php esc_html_e( 'this month', 'respira-for-wordpress' ); ?></span></h3>
			<div class="respira-table-wrapper">
				<table class="widefat respira-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Key', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'AI Agent', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Edits', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'API Calls', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Last Active', 'respira-for-wordpress' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $top_keys as $tk ) : ?>
						<tr>
							<td>
								<?php
								$display_name = ! empty( $tk->key_name ) ? $tk->key_name : ( $tk->key_prefix ? $tk->key_prefix . '...' : __( 'Unnamed', 'respira-for-wordpress' ) );
								echo esc_html( $display_name );
								if ( empty( $tk->is_active ) ) {
									echo ' <span class="respira-status-inactive">' . esc_html__( '(revoked)', 'respira-for-wordpress' ) . '</span>';
								}
								?>
							</td>
							<td><?php echo esc_html( $tk->primary_agent ? $tk->primary_agent : '—' ); ?></td>
							<td><strong><?php echo esc_html( number_format_i18n( $tk->edits ) ); ?></strong></td>
							<td><?php echo esc_html( number_format_i18n( $tk->total_calls ) ); ?></td>
							<td>
								<?php
								if ( $tk->last_activity ) {
									echo esc_html( human_time_diff( strtotime( $tk->last_activity ), current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'respira-for-wordpress' ) );
								} else {
									echo '—';
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>"><?php esc_html_e( 'Manage API keys', 'respira-for-wordpress' ); ?></a></p>
		</div>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( 'unlicensed' === $dashboard_state ) : ?>
		<!-- ═══ State: Unlicensed ═══ -->
		<div class="respira-dashboard-grid">
			<div class="respira-card">
				<h3><?php esc_html_e( '1) Activate License', 'respira-for-wordpress' ); ?></h3>
				<div class="respira-license-hint">
					<p>
						<strong><?php esc_html_e( 'Your license key starts with', 'respira-for-wordpress' ); ?> <code>respira_</code></strong>
						<?php esc_html_e( '— find it at', 'respira-for-wordpress' ); ?>
						<a href="https://respira.press/dashboard" target="_blank">respira.press/dashboard</a>.
					</p>
					<p class="description"><?php esc_html_e( 'This is not the LemonSqueezy key from your purchase email.', 'respira-for-wordpress' ); ?></p>
				</div>
				<form method="post" action="" id="respira-dashboard-license-form">
					<?php wp_nonce_field( 'respira_activate_license' ); ?>
					<p>
						<input type="text" name="license_key" class="regular-text" placeholder="respira_xxxxxxxxxxxx" value="<?php echo esc_attr( $license_key ); ?>" required>
					</p>
					<p>
						<label><input type="checkbox" name="agree_privacy" id="respira_dash_agree_privacy" value="1" required> <?php esc_html_e( 'I agree to the Privacy Policy', 'respira-for-wordpress' ); ?></label>
						<a href="https://respira.press/privacy" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Read', 'respira-for-wordpress' ); ?></a>
					</p>
					<p>
						<label><input type="checkbox" name="agree_terms" id="respira_dash_agree_terms" value="1" required> <?php esc_html_e( 'I agree to the Terms of Service', 'respira-for-wordpress' ); ?></label>
						<a href="https://respira.press/terms" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Read', 'respira-for-wordpress' ); ?></a>
					</p>
					<p class="submit">
						<input type="submit" name="respira_activate_license" id="respira-dash-activate-submit" class="button button-primary" value="<?php esc_attr_e( 'Activate License', 'respira-for-wordpress' ); ?>">
					</p>
				</form>
				<p><a href="https://respira.press/dashboard" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Need a license? Visit respira.press', 'respira-for-wordpress' ); ?></a></p>
			</div>

			<div class="respira-card">
				<h3><?php esc_html_e( '2) Generate API Key', 'respira-for-wordpress' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Create an API key used by Cursor, Codex, Claude Code, and MCP clients.', 'respira-for-wordpress' ); ?></p>
				<p class="respira-text-muted"><?php esc_html_e( 'Activate your license first to generate API keys.', 'respira-for-wordpress' ); ?></p>
			</div>
		</div>

	<?php elseif ( 'no_key' === $dashboard_state ) : ?>
		<!-- ═══ State: Licensed, No Key ═══ -->
		<div class="respira-dashboard-grid">
			<div class="respira-card">
				<h3>
					<span class="respira-onboarding-check">&#10003;</span>
					<?php esc_html_e( '1) License Active', 'respira-for-wordpress' ); ?>
				</h3>
				<p><code><?php echo esc_html( $license_key ); ?></code></p>
				<form method="post" action="">
					<?php wp_nonce_field( 'respira_deactivate_license' ); ?>
					<p class="submit">
						<input type="submit" name="respira_deactivate_license" class="button button-secondary" value="<?php esc_attr_e( 'Deactivate License', 'respira-for-wordpress' ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to deactivate this license?', 'respira-for-wordpress' ); ?>');">
					</p>
				</form>
			</div>

			<div class="respira-card respira-card-highlight">
				<h3><?php esc_html_e( '2) Generate API Key', 'respira-for-wordpress' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Create an API key used by Cursor, Codex, Claude Code, and MCP clients.', 'respira-for-wordpress' ); ?></p>
				<form method="post" action="">
					<?php wp_nonce_field( 'respira_generate_key' ); ?>
					<p>
						<input type="text" name="key_name" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., Cursor on MacBook', 'respira-for-wordpress' ); ?>">
					</p>
					<p class="submit">
						<input type="submit" name="respira_generate_key" class="button button-primary" value="<?php esc_attr_e( 'Generate API Key', 'respira-for-wordpress' ); ?>">
					</p>
				</form>
				<?php if ( $new_key ) : ?>
					<div class="respira-api-key-success-box">
						<p><strong><?php esc_html_e( 'New API key:', 'respira-for-wordpress' ); ?></strong></p>
						<div class="respira-endpoint">
							<code><?php echo esc_html( $new_key ); ?></code>
							<button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $new_key ); ?>"><?php esc_html_e( 'Copy', 'respira-for-wordpress' ); ?></button>
						</div>
					</div>
				<?php endif; ?>
				<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>"><?php esc_html_e( 'Manage all API keys', 'respira-for-wordpress' ); ?></a></p>
			</div>
		</div>

	<?php elseif ( 'not_connected' === $dashboard_state ) : ?>
		<!-- ═══ State: Has Key, Not Connected Yet ═══ -->
		<p>
			<span class="respira-onboarding-check">&#10003;</span> <?php esc_html_e( 'License active', 'respira-for-wordpress' ); ?>
			&nbsp;&middot;&nbsp;
			<span class="respira-onboarding-check">&#10003;</span> <?php esc_html_e( 'API key ready', 'respira-for-wordpress' ); ?>
		</p>

		<?php if ( $new_key ) : ?>
			<div class="respira-api-key-success-box">
				<p><strong><?php esc_html_e( 'New API key:', 'respira-for-wordpress' ); ?></strong></p>
				<div class="respira-endpoint">
					<code><?php echo esc_html( $new_key ); ?></code>
					<button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $new_key ); ?>"><?php esc_html_e( 'Copy', 'respira-for-wordpress' ); ?></button>
				</div>
			</div>
		<?php endif; ?>

		<!-- Install + Config -->
		<div class="respira-dashboard-grid">
			<div class="respira-card">
				<h3><?php esc_html_e( '3) Install MCP Server', 'respira-for-wordpress' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Run setup first (prompts for site URL + API key), or install globally.', 'respira-for-wordpress' ); ?></p>
				<div class="respira-code-block">
					<code>npx @respira/wordpress-mcp-server --setup</code>
				</div>
				<p class="description"><?php esc_html_e( 'Or install globally:', 'respira-for-wordpress' ); ?></p>
				<div class="respira-code-block">
					<code>npm i -g @respira/wordpress-mcp-server</code>
				</div>
			</div>

			<div class="respira-card respira-card-highlight">
				<h3><?php esc_html_e( '4) Add MCP Config', 'respira-for-wordpress' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Paste this in your AI tool\'s MCP settings (Cursor, Claude Code, Codex), then restart.', 'respira-for-wordpress' ); ?></p>
				<div class="respira-code-block respira-code-block-large">
					<pre><code><?php echo esc_html( $mcp_config ); ?></code></pre>
					<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $mcp_config ); ?>"><?php esc_html_e( 'Copy MCP Config', 'respira-for-wordpress' ); ?></button>
				</div>
			</div>
		</div>

		<!-- Verify prompt -->
		<div class="respira-card respira-card-verify">
			<h3><?php esc_html_e( 'Verify Connection', 'respira-for-wordpress' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Paste this prompt into your AI coding tool to verify the connection and discover everything your site can do.', 'respira-for-wordpress' ); ?></p>
			<div class="respira-code-block respira-code-block-large">
				<pre><code><?php echo esc_html( $getting_started_prompt ); ?></code></pre>
				<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $getting_started_prompt ); ?>"><?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?></button>
			</div>
		</div>

	<?php else : ?>
		<!-- ═══ State: Connected ═══ -->

		<!-- Quick Actions -->
		<div class="respira-quick-actions">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-changes' ) ); ?>" class="respira-quick-action">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php esc_html_e( 'Review Changes', 'respira-for-wordpress' ); ?>
				<?php if ( $pending_approvals > 0 ) : ?>
					<span class="respira-quick-action-badge"><?php echo esc_html( $pending_approvals ); ?></span>
				<?php endif; ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=prompts' ) ); ?>" class="respira-quick-action">
				<span class="dashicons dashicons-editor-code"></span>
				<?php esc_html_e( 'Prompt Library', 'respira-for-wordpress' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-skills' ) ); ?>" class="respira-quick-action">
				<span class="dashicons dashicons-admin-plugins"></span>
				<?php esc_html_e( 'Skills', 'respira-for-wordpress' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-audit-log' ) ); ?>" class="respira-quick-action">
				<span class="dashicons dashicons-list-view"></span>
				<?php esc_html_e( 'Audit Log', 'respira-for-wordpress' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-settings' ) ); ?>" class="respira-quick-action">
				<span class="dashicons dashicons-admin-generic"></span>
				<?php esc_html_e( 'Settings', 'respira-for-wordpress' ); ?>
			</a>
		</div>

		<!-- Multi-site agency CTA -->
		<div class="respira-card respira-card-agency">
			<h3><?php esc_html_e( 'Managing multiple sites?', 'respira-for-wordpress' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Account-wide multi-site MCP exports, installer commands, and AI setup prompts live in your hosted Respira dashboard so the config always matches all connected sites on your account.', 'respira-for-wordpress' ); ?></p>
			<p>
				<a href="https://www.respira.press/dashboard/mcp" target="_blank" rel="noopener noreferrer" class="button button-primary"><?php esc_html_e( 'Open Agency MCP Setup', 'respira-for-wordpress' ); ?></a>
			</p>
		</div>

		<!-- MCP Reference (collapsible) -->
		<details class="respira-card respira-mcp-reference">
			<summary class="respira-mcp-reference-toggle">
				<span class="dashicons dashicons-admin-tools"></span>
				<?php esc_html_e( 'MCP Connection Reference', 'respira-for-wordpress' ); ?>
			</summary>
			<div class="respira-mcp-reference-body">
				<div class="respira-dashboard-grid">
					<div>
						<h4><?php esc_html_e( 'Site URL', 'respira-for-wordpress' ); ?></h4>
						<div class="respira-endpoint">
							<code><?php echo esc_html( $wordpress_url ); ?></code>
							<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $wordpress_url ); ?>"><?php esc_html_e( 'Copy', 'respira-for-wordpress' ); ?></button>
						</div>

						<h4><?php esc_html_e( 'API Endpoints', 'respira-for-wordpress' ); ?></h4>
						<div class="respira-endpoint">
							<code><?php echo esc_html( $endpoint_v2 ); ?></code>
							<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $endpoint_v2 ); ?>"><?php esc_html_e( 'v2', 'respira-for-wordpress' ); ?></button>
						</div>
						<div class="respira-endpoint">
							<code><?php echo esc_html( $endpoint_v1 ); ?></code>
							<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $endpoint_v1 ); ?>"><?php esc_html_e( 'v1', 'respira-for-wordpress' ); ?></button>
						</div>
						<div class="respira-endpoint">
							<code><?php echo esc_html( $status_v2 ); ?></code>
							<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $status_v2 ); ?>"><?php esc_html_e( 'Status', 'respira-for-wordpress' ); ?></button>
						</div>

						<h4><?php esc_html_e( 'Install Command', 'respira-for-wordpress' ); ?></h4>
						<div class="respira-code-block">
							<code>npx @respira/wordpress-mcp-server --setup</code>
						</div>
					</div>
					<div>
						<h4><?php esc_html_e( 'MCP Config (JSON)', 'respira-for-wordpress' ); ?></h4>
						<div class="respira-code-block respira-code-block-large">
							<pre><code><?php echo esc_html( $mcp_config ); ?></code></pre>
							<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $mcp_config ); ?>"><?php esc_html_e( 'Copy MCP Config', 'respira-for-wordpress' ); ?></button>
						</div>
					</div>
				</div>
			</div>
		</details>

		<!-- Getting Started Prompt -->
		<details class="respira-card respira-verify-prompt">
			<summary class="respira-mcp-reference-toggle">
				<span class="dashicons dashicons-welcome-learn-more"></span>
				<?php esc_html_e( 'Getting Started Prompt', 'respira-for-wordpress' ); ?>
			</summary>
			<div class="respira-mcp-reference-body">
				<p class="description"><?php esc_html_e( 'Paste this into your AI tool to verify the connection and discover everything your site can do.', 'respira-for-wordpress' ); ?></p>
				<div class="respira-code-block respira-code-block-large">
					<pre><code><?php echo esc_html( $getting_started_prompt ); ?></code></pre>
					<button class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $getting_started_prompt ); ?>"><?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?></button>
				</div>
				<p class="description">
					<?php
					printf(
						/* translators: %s: link to Skills Marketplace */
						esc_html__( 'Want a deeper onboarding? Install the %s skill from the Skills Marketplace.', 'respira-for-wordpress' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=respira-skills' ) ) . '">Site Onboarding</a>'
					);
					?>
				</p>
			</div>
		</details>

		<!-- Activity + Site Info -->
		<div class="respira-dashboard-grid">
			<div class="respira-card">
				<h3><?php esc_html_e( 'Recent Activity', 'respira-for-wordpress' ); ?></h3>
				<?php if ( $recent_logs ) : ?>
					<div class="respira-table-wrapper">
						<table class="widefat respira-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Action', 'respira-for-wordpress' ); ?></th>
									<th><?php esc_html_e( 'Time', 'respira-for-wordpress' ); ?></th>
								</tr>
							</thead>
							<tbody>
							<?php foreach ( $recent_logs as $log ) : ?>
								<tr>
									<td><?php echo esc_html( $log->action ); ?></td>
									<td><?php echo esc_html( human_time_diff( strtotime( $log->created_at ), current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'respira-for-wordpress' ) ); ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-audit-log' ) ); ?>"><?php esc_html_e( 'View full audit log', 'respira-for-wordpress' ); ?></a></p>
				<?php else : ?>
					<div class="respira-empty-state">
						<p class="respira-empty-state-description"><?php esc_html_e( 'No activity yet. Connect an AI tool to get started.', 'respira-for-wordpress' ); ?></p>
					</div>
				<?php endif; ?>
			</div>

			<div class="respira-card">
				<h3><?php esc_html_e( 'Site Information', 'respira-for-wordpress' ); ?></h3>
				<div class="respira-site-info-grid">
					<div class="respira-site-info-item">
						<strong><?php esc_html_e( 'Respira', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( RESPIRA_VERSION ); ?>
					</div>
					<div class="respira-site-info-item">
						<strong><?php esc_html_e( 'WordPress', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $context['wordpress_version'] ); ?>
					</div>
					<div class="respira-site-info-item">
						<strong><?php esc_html_e( 'PHP', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $context['php_version'] ); ?>
					</div>
					<div class="respira-site-info-item">
						<strong><?php esc_html_e( 'Theme', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( isset( $context['active_theme']['name'] ) ? $context['active_theme']['name'] : __( 'Unknown', 'respira-for-wordpress' ) ); ?>
					</div>
					<?php if ( $builder_name ) : ?>
					<div class="respira-site-info-item">
						<strong><?php esc_html_e( 'Builder', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $builder_name . ( $builder_version ? ' ' . $builder_version : '' ) ); ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<!-- Footer Links -->
		<div class="respira-dashboard-footer">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-changes' ) ); ?>"><?php esc_html_e( 'Review Changes', 'respira-for-wordpress' ); ?></a>
			<a href="https://respira.press/installation" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Installation Guide', 'respira-for-wordpress' ); ?></a>
			<a href="https://respira.press/dashboard" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Respira Dashboard', 'respira-for-wordpress' ); ?></a>
			<a href="https://respira.press/dashboard/mcp" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Agency MCP Setup', 'respira-for-wordpress' ); ?></a>
		</div>
		<p class="respira-dashboard-footer-credit">
			<?php esc_html_e( 'Includes WebMCP integration based on WebMCP Abilities by Code Atlantic (GPL v2).', 'respira-for-wordpress' ); ?>
		</p>

	<?php endif; ?>
</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
