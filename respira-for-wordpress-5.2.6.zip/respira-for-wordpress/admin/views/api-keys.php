<?php
/**
 * API Keys view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$user_id  = get_current_user_id();
$user_keys = Respira_Auth::get_user_keys( $user_id );
$new_key = get_user_meta( $user_id, 'respira_new_api_key', true );
if ( $new_key ) {
	delete_user_meta( $user_id, 'respira_new_api_key' );
}

// Get license info for conditional display
$license_info = Respira_License::get_license_info();
$license_key = $license_info['key'];
$license_status = $license_info['status'];
if ( ! $respira_embed ) {
	$respira_screen = 'respira-api-keys';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">
		<?php if ( $new_key ) : ?>
			<div class="notice notice-success respira-new-key-box">
				<p><strong><?php esc_html_e( 'Your new API key – copy it now:', 'respira-for-wordpress' ); ?></strong></p>
				<div class="respira-new-key">
					<input type="text" readonly value="<?php echo esc_attr( $new_key ); ?>" class="respira-api-key-input" onclick="this.select();" />
					<button type="button" class="button button-primary respira-copy-btn" data-copy="<?php echo esc_attr( $new_key ); ?>">
						<?php esc_html_e( 'Copy to clipboard', 'respira-for-wordpress' ); ?>
					</button>
				</div>
				<p class="description">
					<?php esc_html_e( 'Add this key to your MCP config or Cursor setup. It will not be shown again.', 'respira-for-wordpress' ); ?>
				</p>
			</div>
		<?php endif; ?>
		<?php if ( empty( $respira_embed ) ) { settings_errors( 'respira_messages' ); } ?>

		<div class="respira-card">
			<h2><?php esc_html_e( 'Generate New API Key', 'respira-for-wordpress' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>">
				<?php wp_nonce_field( 'respira_generate_key' ); ?>

				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="key_name"><?php esc_html_e( 'Key Name', 'respira-for-wordpress' ); ?></label>
						</th>
						<td>
							<input type="text" name="key_name" id="key_name" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., My MCP Server', 'respira-for-wordpress' ); ?>">
							<p class="description"><?php esc_html_e( 'Optional. A label to identify this key.', 'respira-for-wordpress' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Access Profile', 'respira-for-wordpress' ); ?></th>
						<td>
							<div class="respira-access-profiles">
								<?php
								require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-tool-governance.php';
								$profiles   = Respira_Tool_Governance::get_access_profiles();
								$categories = Respira_Tool_Governance::get_tool_categories();
								$disabled   = Respira_Tool_Governance::get_disabled_tools();
								$first      = true;
								foreach ( $profiles as $profile_key => $profile ) :
								?>
									<label class="respira-profile-option<?php echo $first ? ' is-selected' : ''; ?>">
										<input type="radio" name="respira_access_profile" value="<?php echo esc_attr( $profile_key ); ?>" <?php checked( $first ); ?>>
										<span class="respira-profile-option-inner">
											<strong><?php echo esc_html( $profile['label'] ); ?></strong>
											<span class="respira-profile-desc"><?php echo esc_html( $profile['description'] ); ?></span>
										</span>
									</label>
								<?php
								$first = false;
								endforeach;
								?>
							</div>

							<details class="respira-tool-scope-details" style="margin-top: 16px;">
								<summary style="cursor: pointer; color: var(--respira-muted); font-size: 13px;">
									<?php esc_html_e( 'View tools included in this profile', 'respira-for-wordpress' ); ?>
								</summary>
								<p style="font-size: 12px; color: var(--respira-muted); margin: 8px 0;">
									<?php
									printf(
										/* translators: %s: link to Governance page */
										esc_html__( 'Tools with strikethrough are disabled site-wide in %s and cannot be granted to any key.', 'respira-for-wordpress' ),
										'<a href="' . esc_url( admin_url( 'admin.php?page=respira-governance' ) ) . '">' . esc_html__( 'Governance', 'respira-for-wordpress' ) . '</a>'
									);
									?>
								</p>
								<div class="respira-tool-scope-grid" style="margin-top: 12px;">
									<?php
									$category_labels = array(
										'pages'     => __( 'Pages', 'respira-for-wordpress' ),
										'posts'     => __( 'Posts', 'respira-for-wordpress' ),
										'media'     => __( 'Media', 'respira-for-wordpress' ),
										'builder'   => __( 'Builder', 'respira-for-wordpress' ),
										'analysis'  => __( 'Analysis', 'respira-for-wordpress' ),
										'stock'     => __( 'Stock Images', 'respira-for-wordpress' ),
										'context'   => __( 'Context', 'respira-for-wordpress' ),
										'menus'     => __( 'Menus', 'respira-for-wordpress' ),
										'snapshots' => __( 'Snapshots', 'respira-for-wordpress' ),
										'plugins'   => __( 'Plugins', 'respira-for-wordpress' ),
										'users'     => __( 'Users', 'respira-for-wordpress' ),
									);
									foreach ( $categories as $cat_slug => $tools ) :
										$cat_label = isset( $category_labels[ $cat_slug ] ) ? $category_labels[ $cat_slug ] : ucfirst( $cat_slug );
									?>
										<div class="respira-tool-scope-category" data-category="<?php echo esc_attr( $cat_slug ); ?>">
											<div class="respira-tool-scope-category-header">
												<label>
													<input type="checkbox" class="respira-scope-category-toggle" name="respira_allowed_categories[]" value="<?php echo esc_attr( $cat_slug ); ?>">
													<strong><?php echo esc_html( $cat_label ); ?></strong>
												</label>
												<span class="respira-tool-scope-count"><?php echo esc_html( count( $tools ) ); ?></span>
											</div>
											<div class="respira-tool-scope-tools">
												<?php foreach ( $tools as $tool ) :
													$is_gov_disabled = in_array( $tool, $disabled, true );
												?>
													<label class="respira-tool-scope-tool<?php echo $is_gov_disabled ? ' is-governance-disabled' : ''; ?>">
														<input type="checkbox" name="respira_allowed_tools[]" value="<?php echo esc_attr( $tool ); ?>" data-category="<?php echo esc_attr( $cat_slug ); ?>" <?php disabled( $is_gov_disabled ); ?>>
														<code><?php echo esc_html( $tool ); ?></code>
														<?php if ( $is_gov_disabled ) : ?>
															<span class="respira-governance-badge"><?php esc_html_e( 'disabled by governance', 'respira-for-wordpress' ); ?></span>
														<?php endif; ?>
													</label>
												<?php endforeach; ?>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</details>
						</td>
					</tr>
				</table>

				<p class="submit">
					<input type="submit" name="respira_generate_key" class="button button-primary" value="<?php esc_attr_e( 'Generate API Key', 'respira-for-wordpress' ); ?>">
				</p>
			</form>

			<div class="respira-privacy-note respira-mt-md">
				<p>
					<strong><?php esc_html_e( 'Privacy Note:', 'respira-for-wordpress' ); ?></strong>
					<?php esc_html_e( 'Usage statistics (pages updated, lines of code estimates) may be collected to help improve the product. Your actual content, code, and data are NEVER transmitted or stored on our servers.', 'respira-for-wordpress' ); ?>
					<a href="https://respira.press/privacy" target="_blank">
						<?php esc_html_e( 'Privacy Policy', 'respira-for-wordpress' ); ?>
					</a>
				</p>
			</div>
		</div>

		<div class="respira-card">
			<h2><?php esc_html_e( 'Your API Keys', 'respira-for-wordpress' ); ?></h2>
			<?php if ( ! empty( $user_keys ) ) : ?>
				<div class="respira-table-wrapper">
					<table class="wp-list-table widefat fixed striped respira-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Name', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Profile', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Key Prefix', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Created', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Last Used', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Status', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'respira-for-wordpress' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $user_keys as $key ) : ?>
							<?php
							$full_key = Respira_Auth::get_plaintext_key( (int) $key->id, (int) $user_id );
							?>
							<tr>
								<td><strong><?php echo esc_html( $key->name ?: __( '(Unnamed)', 'respira-for-wordpress' ) ); ?></strong></td>
								<td>
									<?php
									$key_perms   = json_decode( $key->permissions, true );
									$key_profile = 'Full Access'; // default for legacy.
									if ( is_array( $key_perms ) && isset( $key_perms['profile'] ) ) {
										$profile_defs = Respira_Tool_Governance::get_access_profiles();
										$key_profile  = isset( $profile_defs[ $key_perms['profile'] ]['label'] )
											? $profile_defs[ $key_perms['profile'] ]['label']
											: ucwords( str_replace( '_', ' ', $key_perms['profile'] ) );
									}
									echo esc_html( $key_profile );
									?>
								</td>
								<td>
									<?php if ( ! empty( $key->key_prefix ) ) : ?>
										<code class="respira-key-prefix" title="<?php esc_attr_e( 'Prefix for identification only – full key shown once at creation', 'respira-for-wordpress' ); ?>"><?php echo esc_html( $key->key_prefix ); ?>...</code>
										<button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $key->key_prefix ); ?>..." title="<?php esc_attr_e( 'Copy key prefix only (full API key is shown once at creation)', 'respira-for-wordpress' ); ?>">
											<?php esc_html_e( 'Copy Prefix', 'respira-for-wordpress' ); ?>
										</button>
									<?php else : ?>
										<span class="respira-text-muted-italic"><?php esc_html_e( 'Legacy key', 'respira-for-wordpress' ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( mysql2date( 'Y-m-d H:i', $key->created_at ) ); ?></td>
								<td>
									<?php
									if ( $key->last_used ) {
										echo esc_html( human_time_diff( strtotime( $key->last_used ), current_time( 'timestamp' ) ) . ' ago' );
									} else {
										esc_html_e( 'Never', 'respira-for-wordpress' );
									}
									?>
								</td>
								<td>
									<?php if ( $key->is_active ) : ?>
										<span class="respira-status-active"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
									<?php else : ?>
										<span class="respira-status-revoked"><?php esc_html_e( 'Revoked', 'respira-for-wordpress' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( $full_key ) : ?>
										<button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $full_key ); ?>" title="<?php esc_attr_e( 'Copy full API key', 'respira-for-wordpress' ); ?>">
											<?php esc_html_e( 'Copy Full Key', 'respira-for-wordpress' ); ?>
										</button>
									<?php endif; ?>
									<?php if ( $key->is_active ) : ?>
										<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>" class="respira-form-inline">
											<?php wp_nonce_field( 'respira_revoke_key' ); ?>
											<input type="hidden" name="respira_action" value="revoke_key">
											<input type="hidden" name="key_id" value="<?php echo esc_attr( $key->id ); ?>">
											<button type="submit" name="respira_revoke_key" value="1" class="button button-small button-link-delete" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to revoke this API key?', 'respira-for-wordpress' ); ?>');">
												<?php esc_html_e( 'Revoke', 'respira-for-wordpress' ); ?>
											</button>
										</form>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<p class="description respira-mt-md">
				<?php esc_html_e( 'Note: New keys can be copied later with "Copy Full Key". Older keys created before this update remain non-recoverable and should be replaced if needed.', 'respira-for-wordpress' ); ?>
			</p>
			<?php else : ?>
				<p><?php esc_html_e( 'No API keys yet. Generate one above to get started.', 'respira-for-wordpress' ); ?></p>
			<?php endif; ?>
		</div>
	</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
	// Profile definitions (categories per profile).
	var profileCategories = <?php echo wp_json_encode( array_map( function( $p ) { return $p['categories']; }, $profiles ) ); ?>;
	var profileExtraTools = <?php echo wp_json_encode( array_map( function( $p ) { return isset( $p['extra_tools'] ) ? $p['extra_tools'] : []; }, $profiles ) ); ?>;

	var profileRadios = document.querySelectorAll('input[name="respira_access_profile"]');
	var categoryToggles = document.querySelectorAll('.respira-scope-category-toggle');
	var toolCheckboxes = document.querySelectorAll('input[name="respira_allowed_tools[]"]');

	function applyProfile(profileKey) {
		var cats = profileCategories[profileKey] || [];
		var extras = profileExtraTools[profileKey] || [];

		// Update profile card highlights.
		document.querySelectorAll('.respira-profile-option').forEach(function(el) {
			el.classList.toggle('is-selected', el.querySelector('input').value === profileKey);
		});

		// Update category toggles.
		categoryToggles.forEach(function(toggle) {
			toggle.checked = cats.indexOf(toggle.value) !== -1;
		});

		// Update individual tool checkboxes.
		toolCheckboxes.forEach(function(cb) {
			if (cb.disabled) return; // governance-disabled.
			var inCategory = cats.indexOf(cb.dataset.category) !== -1;
			var inExtras = extras.indexOf(cb.value) !== -1;
			cb.checked = inCategory || inExtras;
		});
	}

	profileRadios.forEach(function(radio) {
		radio.addEventListener('change', function() {
			applyProfile(this.value);
		});
	});

	// Category toggle: check/uncheck all tools in category.
	categoryToggles.forEach(function(toggle) {
		toggle.addEventListener('change', function() {
			var cat = this.value;
			var checked = this.checked;
			toolCheckboxes.forEach(function(cb) {
				if (cb.dataset.category === cat && !cb.disabled) {
					cb.checked = checked;
				}
			});
		});
	});

	// Individual tool change: update category toggle state.
	toolCheckboxes.forEach(function(cb) {
		cb.addEventListener('change', function() {
			var cat = this.dataset.category;
			var allChecked = true;
			document.querySelectorAll('input[name="respira_allowed_tools[]"][data-category="' + cat + '"]').forEach(function(sibling) {
				if (!sibling.disabled && !sibling.checked) allChecked = false;
			});
			var catToggle = document.querySelector('.respira-scope-category-toggle[value="' + cat + '"]');
			if (catToggle) catToggle.checked = allChecked;
		});
	});

	// Initialize with first profile.
	applyProfile('full_access');
});
</script>

<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
