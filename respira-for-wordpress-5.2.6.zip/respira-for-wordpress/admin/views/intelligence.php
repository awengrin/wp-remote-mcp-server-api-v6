<?php
/**
 * Intelligence view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$context          = Respira_Context::get_site_info();
$builder_info     = Respira_Context::get_builder_info();
$builders         = isset( $builder_info['builders'] ) && is_array( $builder_info['builders'] ) ? $builder_info['builders'] : array();
$active_builder   = isset( $builder_info['active_builder'] ) && is_array( $builder_info['active_builder'] ) ? $builder_info['active_builder'] : null;
$detected_builders = isset( $builder_info['detected_builders'] ) && is_array( $builder_info['detected_builders'] ) ? $builder_info['detected_builders'] : array();
$theme_info       = isset( $builder_info['theme'] ) && is_array( $builder_info['theme'] ) ? $builder_info['theme'] : Respira_Theme_Detector::get_theme_info();

$primary_builder_name = '';
if ( ! empty( $active_builder['name'] ) ) {
	$primary_builder_name = (string) $active_builder['name'];
} elseif ( ! empty( $detected_builders ) && ! empty( $detected_builders[0]['name'] ) ) {
	$primary_builder_name = (string) $detected_builders[0]['name'];
} else {
	foreach ( $builders as $builder_name => $builder_data ) {
		if ( ! empty( $builder_data['detected'] ) ) {
			$primary_builder_name = (string) $builder_name;
			break;
		}
	}
}

$primary_builder_data = ( ! empty( $primary_builder_name ) && isset( $builders[ $primary_builder_name ] ) && is_array( $builders[ $primary_builder_name ] ) )
	? $builders[ $primary_builder_name ]
	: array();

$primary_docs = isset( $primary_builder_data['documentation'] ) && is_array( $primary_builder_data['documentation'] )
	? $primary_builder_data['documentation']
	: array();

if ( empty( $primary_docs ) && ! empty( $primary_builder_name ) ) {
	$maybe_builder = Respira_Builder_Interface::get_builder( $primary_builder_name );
	if ( ! is_wp_error( $maybe_builder ) && method_exists( $maybe_builder, 'get_documentation' ) ) {
		$primary_docs = $maybe_builder->get_documentation();
	}
}

/**
 * Map builder name to support level for badge display.
 *
 * @param string $name Builder name.
 * @return array{label:string, bg:string, color:string}|null
 */
$respira_get_support_badge = function ( $name ) {
	$full = array( 'Elementor', 'Divi', 'Gutenberg' );
	$smart = array( 'Beaver Builder', 'Bricks', 'Breakdance', 'Oxygen', 'WPBakery' );
	$basic = array( 'Brizy', 'Thrive Architect', 'Visual Composer' );

	if ( in_array( $name, $full, true ) ) {
		return array(
			'label' => __( 'Full Intelligence', 'respira-for-wordpress' ),
			'bg'    => 'rgba(16, 185, 129, 0.15)',
			'color' => '#10b981',
		);
	}
	if ( in_array( $name, $smart, true ) ) {
		return array(
			'label' => __( 'Smart Defaults', 'respira-for-wordpress' ),
			'bg'    => 'rgba(245, 158, 11, 0.15)',
			'color' => '#f59e0b',
		);
	}
	if ( in_array( $name, $basic, true ) ) {
		return array(
			'label' => __( 'Basic Support', 'respira-for-wordpress' ),
			'bg'    => 'rgba(249, 115, 22, 0.15)',
			'color' => '#f97316',
		);
	}
	return null;
};

$module_label_map = array(
	'Divi'            => __( 'modules', 'respira-for-wordpress' ),
	'Elementor'       => __( 'widgets', 'respira-for-wordpress' ),
	'Gutenberg'       => __( 'blocks', 'respira-for-wordpress' ),
	'Bricks'          => __( 'elements', 'respira-for-wordpress' ),
	'Beaver Builder'  => __( 'modules', 'respira-for-wordpress' ),
	'Oxygen'          => __( 'components', 'respira-for-wordpress' ),
	'WPBakery'        => __( 'shortcodes', 'respira-for-wordpress' ),
	'Visual Composer' => __( 'elements', 'respira-for-wordpress' ),
	'Brizy'           => __( 'elements', 'respira-for-wordpress' ),
	'Thrive Architect' => __( 'elements', 'respira-for-wordpress' ),
	'Breakdance'      => __( 'elements', 'respira-for-wordpress' ),
);

$builder_label   = ! empty( $primary_builder_name ) ? $primary_builder_name : __( 'No builder detected', 'respira-for-wordpress' );
$module_label    = isset( $module_label_map[ $primary_builder_name ] ) ? $module_label_map[ $primary_builder_name ] : __( 'modules', 'respira-for-wordpress' );
$module_count    = isset( $primary_builder_data['module_count'] ) ? absint( $primary_builder_data['module_count'] ) : 0;
$pattern_count   = isset( $primary_docs['patterns']['count'] ) ? absint( $primary_docs['patterns']['count'] ) : 0;
$primary_detected = ! empty( $primary_builder_data['detected'] );
$primary_intelligence = ! empty( $primary_builder_data['intelligence_active'] );
$generation      = isset( $primary_docs['generation'] ) ? (string) $primary_docs['generation'] : '';

$site_pages = array();
if ( $primary_detected && ! empty( $primary_builder_name ) ) {
	$maybe_builder = Respira_Builder_Interface::get_builder( $primary_builder_name );
	if ( ! is_wp_error( $maybe_builder ) && method_exists( $maybe_builder, 'is_builder_used' ) ) {
		$candidate_ids = get_posts(
			array(
				'post_type'      => array( 'page', 'post' ),
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 50,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);

		foreach ( $candidate_ids as $candidate_id ) {
			if ( ! $maybe_builder->is_builder_used( (int) $candidate_id ) ) {
				continue;
			}

			$page_title = trim( (string) get_the_title( $candidate_id ) );
			if ( '' === $page_title ) {
				$page_title = sprintf(
					/* translators: %d: post ID. */
					__( '(no title) #%d', 'respira-for-wordpress' ),
					(int) $candidate_id
				);
			}

			$site_pages[] = array(
				'id'         => (int) $candidate_id,
				'title'      => $page_title,
				'edit_link'  => get_edit_post_link( $candidate_id, 'raw' ),
				'public_link' => get_permalink( $candidate_id ),
			);

			if ( count( $site_pages ) >= 3 ) {
				break;
			}
		}
	}
}

$primary_page_title   = ! empty( $site_pages[0]['title'] ) ? $site_pages[0]['title'] : __( 'Homepage', 'respira-for-wordpress' );
$secondary_page_title = ! empty( $site_pages[1]['title'] ) ? $site_pages[1]['title'] : __( 'About page', 'respira-for-wordpress' );
$tertiary_page_title  = ! empty( $site_pages[2]['title'] ) ? $site_pages[2]['title'] : __( 'Services page', 'respira-for-wordpress' );
$site_name            = ! empty( $context['site_name'] ) ? (string) $context['site_name'] : __( 'your site', 'respira-for-wordpress' );

$capabilities = array(
	sprintf(
		/* translators: %s: Builder label. */
		__( 'Read and extract existing %s layouts', 'respira-for-wordpress' ),
		$builder_label
	),
	sprintf(
		/* translators: 1: Builder label, 2: Module label. */
		__( 'Modify %1$s %2$s on any page', 'respira-for-wordpress' ),
		$builder_label,
		$module_label
	),
	sprintf(
		/* translators: %s: Builder label. */
		__( 'Create new %s pages from scratch', 'respira-for-wordpress' ),
		$builder_label
	),
	__( 'Preserve JavaScript, custom CSS, and existing responsive behavior', 'respira-for-wordpress' ),
	__( 'Use duplicate-first safety and approval workflow before going live', 'respira-for-wordpress' ),
);

if ( $primary_intelligence && $module_count > 0 ) {
	$capabilities[] = sprintf(
		/* translators: 1: count, 2: module label. */
		__( 'Schema-aware support for %1$d+ %2$s', 'respira-for-wordpress' ),
		$module_count,
		$module_label
	);
}

if ( $pattern_count > 0 ) {
	$capabilities[] = sprintf(
		/* translators: %d: pattern count. */
		__( 'Pattern intelligence available (%d reusable layout patterns)', 'respira-for-wordpress' ),
		$pattern_count
	);
}

$prompt_examples = array(
	array(
		'label' => __( 'Read & Modify', 'respira-for-wordpress' ),
		'text'  => sprintf(
			/* translators: 1: page title, 2: builder label, 3: site name. */
			__( 'Read the "%1$s" %2$s layout and update the hero heading to "Welcome to %3$s".', 'respira-for-wordpress' ),
			$primary_page_title,
			$builder_label,
			$site_name
		),
	),
	array(
		'label' => __( 'Extract & Analyze', 'respira-for-wordpress' ),
		'text'  => sprintf(
			/* translators: 1: page title, 2: module label. */
			__( 'Show the structure of "%1$s" and list all %2$s used with their key settings.', 'respira-for-wordpress' ),
			$secondary_page_title,
			$module_label
		),
	),
	array(
		'label' => __( 'Create New', 'respira-for-wordpress' ),
		'text'  => sprintf(
			/* translators: %s: builder label. */
			__( 'Create a new %s landing page with hero, proof section, FAQ, and contact CTA.', 'respira-for-wordpress' ),
			$builder_label
		),
	),
	array(
		'label' => __( 'Accessibility', 'respira-for-wordpress' ),
		'text'  => sprintf(
			/* translators: 1: page title, 2: module label. */
			__( 'Audit "%1$s" for WCAG issues, then generate builder-aware fixes for images, headings, links, and forms in the affected %2$s.', 'respira-for-wordpress' ),
			$tertiary_page_title,
			$module_label
		),
	),
	array(
		'label' => __( 'Safe Publish Flow', 'respira-for-wordpress' ),
		'text'  => __( 'Duplicate the target page, apply the requested changes on the duplicate, and return the approval URL for review before publishing.', 'respira-for-wordpress' ),
	),
);

if ( ! empty( $generation ) ) {
	$prompt_examples[] = array(
		'label' => __( 'Builder Generation', 'respira-for-wordpress' ),
		'text'  => sprintf(
			/* translators: 1: builder label, 2: generation string. */
			__( 'Use %1$s generation "%2$s" rules when extracting and injecting content to avoid structural regressions.', 'respira-for-wordpress' ),
			$builder_label,
			$generation
		),
	);
}

if ( ! $respira_embed ) {
	$respira_screen = 'respira-intelligence';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">
		<div class="respira-section">
				<div class="respira-section-header">
					<h2>
						<span class="dashicons dashicons-admin-plugins"></span>
						<?php esc_html_e( 'Builder & Theme Detection', 'respira-for-wordpress' ); ?>
					</h2>
					<p>
						<?php esc_html_e( 'Detected page builders and active theme context for AI-safe edits.', 'respira-for-wordpress' ); ?>
						<a class="respira-refresh-link" href="<?php echo esc_url( add_query_arg( 'respira_refresh_builders', '1' ) ); ?>">
							<?php esc_html_e( 'Refresh detection', 'respira-for-wordpress' ); ?>
						</a>
					</p>
				</div>

			<div class="respira-card respira-theme-card">
				<h3><?php esc_html_e( 'Active Theme', 'respira-for-wordpress' ); ?></h3>
				<div class="respira-info-grid">
					<div>
						<strong><?php esc_html_e( 'Site:', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $site_name ); ?>
					</div>
					<div>
						<strong><?php esc_html_e( 'Theme:', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $theme_info['name'] ?? __( 'Unknown', 'respira-for-wordpress' ) ); ?>
					</div>
					<div>
						<strong><?php esc_html_e( 'Version:', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $theme_info['version'] ?? __( 'Unknown', 'respira-for-wordpress' ) ); ?>
					</div>
					<?php if ( ! empty( $theme_info['is_child'] ) && ! empty( $theme_info['parent_theme']['name'] ) ) : ?>
						<div>
							<strong><?php esc_html_e( 'Parent Theme:', 'respira-for-wordpress' ); ?></strong>
							<?php echo esc_html( $theme_info['parent_theme']['name'] ); ?>
							(<?php echo esc_html( $theme_info['parent_theme']['version'] ?? '' ); ?>)
						</div>
					<?php endif; ?>
					<div>
						<strong><?php esc_html_e( 'Primary Builder:', 'respira-for-wordpress' ); ?></strong>
						<?php echo esc_html( $builder_label ); ?>
						<?php
						$primary_support_badge = $respira_get_support_badge( $primary_builder_name );
						if ( $primary_support_badge ) :
						?>
							<span style="background: <?php echo esc_attr( $primary_support_badge['bg'] ); ?>; color: <?php echo esc_attr( $primary_support_badge['color'] ); ?>; border-radius: 6px; padding: 2px 10px; font-size: 12px; font-weight: 600; margin-left: 6px;">
								<?php echo esc_html( $primary_support_badge['label'] ); ?>
							</span>
						<?php endif; ?>
					</div>
					<div>
						<strong><?php esc_html_e( 'Builder Version:', 'respira-for-wordpress' ); ?></strong>
						<?php
						echo esc_html(
							( $primary_detected && ! empty( $primary_builder_data['version'] ) )
								? (string) $primary_builder_data['version']
								: __( 'Not detected', 'respira-for-wordpress' )
						);
						?>
					</div>
				</div>
			</div>

			<div class="respira-builder-list">
				<?php
				// Sort: detected first, then alphabetical.
				$sorted_builders = $builders;
				uksort(
					$sorted_builders,
					function ( $a, $b ) use ( $sorted_builders, $primary_builder_name ) {
						$a_detected = ! empty( $sorted_builders[ $a ]['detected'] );
						$b_detected = ! empty( $sorted_builders[ $b ]['detected'] );
						if ( $a === $primary_builder_name ) {
							return -1;
						}
						if ( $b === $primary_builder_name ) {
							return 1;
						}
						if ( $a_detected !== $b_detected ) {
							return $b_detected ? 1 : -1;
						}
						return strcasecmp( $a, $b );
					}
				);
				?>
				<?php foreach ( $sorted_builders as $builder_name => $builder_data ) : ?>
					<?php
					$is_builder_detected = ! empty( $builder_data['detected'] );
					$is_builder_primary  = ! empty( $primary_builder_name ) && 0 === strcasecmp( (string) $builder_name, (string) $primary_builder_name );
					$card_support_badge  = $respira_get_support_badge( $builder_name );
					$row_module_label    = isset( $module_label_map[ $builder_name ] ) ? $module_label_map[ $builder_name ] : __( 'modules', 'respira-for-wordpress' );
					$row_class           = 'respira-builder-row';
					$row_class          .= $is_builder_detected ? ' is-detected' : ' is-idle';
					$row_class          .= $is_builder_primary ? ' is-primary' : '';
					?>
					<div class="<?php echo esc_attr( $row_class ); ?>">
						<div class="respira-builder-row-name">
							<?php if ( $card_support_badge ) : ?>
								<span class="respira-builder-dot" style="color: <?php echo esc_attr( $card_support_badge['color'] ); ?>;">&#9679;</span>
							<?php endif; ?>
							<span class="respira-builder-row-label"><?php echo esc_html( $builder_name ); ?></span>
							<?php if ( $is_builder_primary ) : ?>
								<span class="respira-badge respira-badge-primary"><?php esc_html_e( 'Primary', 'respira-for-wordpress' ); ?></span>
							<?php endif; ?>
						</div>
						<div class="respira-builder-row-support">
							<?php if ( $card_support_badge ) : ?>
								<span class="respira-builder-support-label" style="color: <?php echo esc_attr( $card_support_badge['color'] ); ?>;">
									<?php echo esc_html( $card_support_badge['label'] ); ?>
								</span>
							<?php endif; ?>
						</div>
						<div class="respira-builder-row-version">
							<?php if ( $is_builder_detected && ! empty( $builder_data['version'] ) ) : ?>
								<?php echo esc_html( $builder_data['version'] ); ?>
							<?php else : ?>
								<span class="respira-builder-row-muted">&mdash;</span>
							<?php endif; ?>
						</div>
						<div class="respira-builder-row-modules">
							<?php if ( $is_builder_detected && isset( $builder_data['module_count'] ) ) : ?>
								<?php echo esc_html( absint( $builder_data['module_count'] ) . ' ' . $row_module_label ); ?>
							<?php else : ?>
								<span class="respira-builder-row-muted">&mdash;</span>
							<?php endif; ?>
						</div>
						<div class="respira-builder-row-status">
							<?php if ( ! $is_builder_detected ) : ?>
								<span class="respira-badge respira-badge-secondary"><?php esc_html_e( 'Not detected', 'respira-for-wordpress' ); ?></span>
							<?php elseif ( ! empty( $builder_data['intelligence_active'] ) ) : ?>
								<span class="respira-badge respira-badge-success"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
							<?php elseif ( ! empty( $builder_data['intelligence_available'] ) ) : ?>
								<span class="respira-badge respira-badge-info"><?php esc_html_e( 'Available', 'respira-for-wordpress' ); ?></span>
							<?php else : ?>
								<span class="respira-badge respira-badge-secondary"><?php esc_html_e( 'Inactive', 'respira-for-wordpress' ); ?></span>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<?php if ( ! empty( $primary_builder_name ) ) : ?>
			<div class="respira-section respira-divi-section respira-intelligence-primary">
				<div class="respira-section-header">
					<h2>
						<span class="dashicons dashicons-lightbulb"></span>
						<?php echo esc_html( sprintf( __( '%s Intelligence', 'respira-for-wordpress' ), $builder_label ) ); ?>
						<?php if ( $primary_intelligence ) : ?>
							<span class="respira-badge respira-badge-success"><?php esc_html_e( 'Active', 'respira-for-wordpress' ); ?></span>
						<?php elseif ( $primary_detected ) : ?>
							<span class="respira-badge respira-badge-info"><?php esc_html_e( 'Detected', 'respira-for-wordpress' ); ?></span>
						<?php else : ?>
							<span class="respira-badge respira-badge-secondary"><?php esc_html_e( 'Inactive', 'respira-for-wordpress' ); ?></span>
						<?php endif; ?>
					</h2>
					<p>
						<?php
						if ( $primary_detected && ! empty( $primary_docs['overview'] ) ) {
							echo esc_html( (string) $primary_docs['overview'] );
						} elseif ( $primary_detected ) {
							echo esc_html__( 'Builder-specific intelligence is available for safe extraction, updates, and prompt-driven edits.', 'respira-for-wordpress' );
						} else {
							echo esc_html__( 'Activate this builder on your site to enable builder-specific intelligence details.', 'respira-for-wordpress' );
						}
						?>
					</p>
				</div>

				<div class="respira-divi-grid">
					<div class="respira-card respira-card-divi">
						<div class="respira-card-icon">
							<span class="dashicons dashicons-admin-tools"></span>
						</div>
						<h3><?php echo esc_html( sprintf( __( 'What AI Can Do with %s', 'respira-for-wordpress' ), $builder_label ) ); ?></h3>
						<ul class="respira-feature-list">
							<?php foreach ( $capabilities as $capability ) : ?>
								<li>
									<span class="dashicons dashicons-yes-alt"></span>
									<?php echo esc_html( $capability ); ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>

					<div class="respira-card respira-card-divi">
						<div class="respira-card-icon">
							<span class="dashicons dashicons-format-chat"></span>
						</div>
						<h3><?php esc_html_e( 'Example Cursor Prompts', 'respira-for-wordpress' ); ?></h3>
						<div class="respira-prompt-examples">
							<?php foreach ( $prompt_examples as $prompt_example ) : ?>
								<div class="respira-prompt-item">
									<strong><?php echo esc_html( $prompt_example['label'] ); ?>:</strong>
									<code><?php echo esc_html( $prompt_example['text'] ); ?></code>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>

				<?php if ( ! empty( $site_pages ) ) : ?>
					<div class="respira-card respira-mt-md">
						<h3><?php esc_html_e( 'Detected Pages Using This Builder', 'respira-for-wordpress' ); ?></h3>
						<ul class="respira-links">
							<?php foreach ( $site_pages as $site_page ) : ?>
								<li>
									<a href="<?php echo esc_url( $site_page['edit_link'] ); ?>"><?php echo esc_html( $site_page['title'] ); ?></a>
									<?php if ( ! empty( $site_page['public_link'] ) ) : ?>
										(<a href="<?php echo esc_url( $site_page['public_link'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'view', 'respira-for-wordpress' ); ?></a>)
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<div class="respira-divi-workflow">
					<h3><?php esc_html_e( 'How It Works', 'respira-for-wordpress' ); ?></h3>
					<div class="respira-workflow-steps">
						<div class="respira-workflow-step">
							<div class="respira-workflow-number">1</div>
							<div class="respira-workflow-content">
								<h4><?php esc_html_e( 'AI Reads Your Layout', 'respira-for-wordpress' ); ?></h4>
								<p><?php echo esc_html( sprintf( __( 'Respira extracts the %1$s structure from "%2$s" and prepares it for safe edits.', 'respira-for-wordpress' ), $builder_label, $primary_page_title ) ); ?></p>
							</div>
						</div>
						<div class="respira-workflow-step">
							<div class="respira-workflow-number">2</div>
							<div class="respira-workflow-content">
								<h4><?php esc_html_e( 'AI Uses Builder Intelligence', 'respira-for-wordpress' ); ?></h4>
								<p><?php echo esc_html( sprintf( __( 'Module schemas, patterns, and %1$s-specific rules guide accurate updates.', 'respira-for-wordpress' ), $builder_label ) ); ?></p>
							</div>
						</div>
						<div class="respira-workflow-step">
							<div class="respira-workflow-number">3</div>
							<div class="respira-workflow-content">
								<h4><?php esc_html_e( 'Changes Are Applied Safely', 'respira-for-wordpress' ); ?></h4>
								<p><?php esc_html_e( 'Edits are applied to duplicates first, then validated before anything goes live.', 'respira-for-wordpress' ); ?></p>
							</div>
						</div>
						<div class="respira-workflow-step">
							<div class="respira-workflow-number">4</div>
							<div class="respira-workflow-content">
								<h4><?php esc_html_e( 'You Review & Publish', 'respira-for-wordpress' ); ?></h4>
								<p><?php esc_html_e( 'Approve the duplicate after review, then publish with confidence.', 'respira-for-wordpress' ); ?></p>
							</div>
						</div>
					</div>
				</div>

				<?php if ( ! empty( $primary_docs['resources'] ) && is_array( $primary_docs['resources'] ) ) : ?>
					<div class="respira-card respira-mt-md">
						<h3><?php esc_html_e( 'Builder Resources', 'respira-for-wordpress' ); ?></h3>
						<ul class="respira-links">
							<?php foreach ( array_slice( $primary_docs['resources'], 0, 3 ) as $resource ) : ?>
								<li><a href="<?php echo esc_url( $resource ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $resource ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<div class="respira-card">
				<h3><?php esc_html_e( 'No Builder Detected Yet', 'respira-for-wordpress' ); ?></h3>
				<p><?php esc_html_e( 'Respira will show builder-aware intelligence here as soon as a supported page builder is detected on this site.', 'respira-for-wordpress' ); ?></p>
			</div>
		<?php endif; ?>
</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
