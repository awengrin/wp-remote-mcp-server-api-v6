<?php
/**
 * Tool Governance view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_screen = 'respira-governance';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';

$categories    = Respira_Tool_Governance::get_tool_categories();
$disabled      = Respira_Tool_Governance::get_disabled_tools();

$category_labels = array(
	'pages'     => __( 'Pages', 'respira-for-wordpress' ),
	'posts'     => __( 'Posts', 'respira-for-wordpress' ),
	'media'     => __( 'Media', 'respira-for-wordpress' ),
	'builder'   => __( 'Builder', 'respira-for-wordpress' ),
	'analysis'  => __( 'Analysis', 'respira-for-wordpress' ),
	'stock'     => __( 'Stock Images', 'respira-for-wordpress' ),
	'context'   => __( 'Context', 'respira-for-wordpress' ),
	'menus'     => __( 'Menus', 'respira-for-wordpress' ),
	'snapshots' => __( 'Snapshots', 'respira-for-wordpress' ),
	'plugins'   => __( 'Plugins', 'respira-for-wordpress' ),
	'users'     => __( 'Users', 'respira-for-wordpress' ),
);
?>
<div class="respira-page-body">

	<?php settings_errors( 'respira_governance_messages' ); ?>

	<div class="respira-card" style="margin-bottom: 20px; border-left: 3px solid var(--respira-emerald);">
		<h3 style="margin-top: 0;"><?php esc_html_e( 'How Governance Works', 'respira-for-wordpress' ); ?></h3>
		<p><?php esc_html_e( 'Governance is a site-wide kill switch. Tools you disable here are blocked for ALL API keys — regardless of their Access Profile.', 'respira-for-wordpress' ); ?></p>
		<p style="color: var(--respira-muted); margin-bottom: 0;">
			<?php
			printf(
				/* translators: %s: link to API Keys page */
				esc_html__( 'To control what individual API keys can do, use %s when generating keys.', 'respira-for-wordpress' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ) . '">' . esc_html__( 'Access Profiles', 'respira-for-wordpress' ) . '</a>'
			);
			?>
		</p>
	</div>

	<form method="post" action="">
		<?php wp_nonce_field( 'respira_update_governance' ); ?>

		<?php foreach ( $categories as $cat_slug => $tools ) : ?>
			<?php
			$cat_label   = isset( $category_labels[ $cat_slug ] ) ? $category_labels[ $cat_slug ] : ucfirst( $cat_slug );
			$tool_count  = count( $tools );
			$all_enabled = true;
			foreach ( $tools as $tool ) {
				if ( in_array( $tool, $disabled, true ) ) {
					$all_enabled = false;
					break;
				}
			}
			?>
			<div class="respira-card">
				<details>
					<summary style="cursor:pointer;">
						<strong><?php echo esc_html( $cat_label ); ?></strong>
						<span class="description">&mdash; <?php echo esc_html( (string) $tool_count ); ?> <?php esc_html_e( 'tools', 'respira-for-wordpress' ); ?></span>
						<label style="float:right;margin-right:8px;" onclick="event.stopPropagation();">
							<input type="checkbox" class="respira-toggle-category" data-category="<?php echo esc_attr( $cat_slug ); ?>" <?php checked( $all_enabled ); ?>>
							<?php esc_html_e( 'Toggle all', 'respira-for-wordpress' ); ?>
						</label>
					</summary>
					<table class="form-table">
						<?php foreach ( $tools as $tool_name ) : ?>
							<?php $is_enabled = ! in_array( $tool_name, $disabled, true ); ?>
							<tr>
								<td>
									<label class="respira-toggle">
										<input type="checkbox" name="respira_enabled_tools[]" value="<?php echo esc_attr( $tool_name ); ?>" class="respira-tool-checkbox" data-category="<?php echo esc_attr( $cat_slug ); ?>" <?php checked( $is_enabled ); ?>>
										<span class="respira-toggle-slider"></span>
										<span class="respira-toggle-label"><code><?php echo esc_html( $tool_name ); ?></code></span>
									</label>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</details>
			</div>
		<?php endforeach; ?>

		<p class="submit">
			<input type="submit" name="respira_update_governance" class="button button-primary" value="<?php esc_attr_e( 'Save Governance Rules', 'respira-for-wordpress' ); ?>">
		</p>
	</form>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
	document.querySelectorAll('.respira-toggle-category').forEach(function(toggle) {
		toggle.addEventListener('change', function() {
			var cat = this.dataset.category;
			var checked = this.checked;
			document.querySelectorAll('.respira-tool-checkbox[data-category="' + cat + '"]').forEach(function(cb) {
				cb.checked = checked;
			});
		});
	});

	document.querySelectorAll('.respira-tool-checkbox').forEach(function(cb) {
		cb.addEventListener('change', function() {
			var cat = this.dataset.category;
			var allChecked = true;
			document.querySelectorAll('.respira-tool-checkbox[data-category="' + cat + '"]').forEach(function(sibling) {
				if (!sibling.checked) allChecked = false;
			});
			var toggle = document.querySelector('.respira-toggle-category[data-category="' + cat + '"]');
			if (toggle) toggle.checked = allChecked;
		});
	});
});
</script>
<?php
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
