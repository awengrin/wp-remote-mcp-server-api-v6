<?php
/**
 * Shared Respira admin shell end.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	</div>
</div>
