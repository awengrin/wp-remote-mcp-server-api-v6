<?php
/**
 * Admin Header Partial.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$license_info       = Respira_License::get_license_info();
$is_license_active = ! empty( $license_info['is_pro'] );
$header_class      = $is_license_active ? 'respira-header-licensed' : 'respira-header-unlicensed';
$update_info       = false;
$remote_notice     = null;

if ( class_exists( 'Respira_Updater' ) ) {
	try {
		$update_info = Respira_Updater::check_update_available();
	} catch ( Exception $e ) {
		$update_info = false;
	}
}

if ( class_exists( 'Respira_Remote_Notifications' ) ) {
	$remote_notice = Respira_Remote_Notifications::get_current_plugin_notice();
}
?>
<header class="respira-admin-header <?php echo esc_attr( $header_class ); ?>">
	<div class="respira-admin-header-inner">
		<div class="respira-admin-header-main">
			<img src="<?php echo esc_url( RESPIRA_PLUGIN_URL . 'admin/assets/images/respira-logo-square.png' ); ?>" alt="<?php esc_attr_e( 'Respira logo', 'respira-for-wordpress' ); ?>" class="respira-admin-logo" width="52" height="52" />
			<div class="respira-admin-header-copy">
				<h1 class="respira-admin-title wp-heading-inline">
					<span class="respira-wordmark-primary">Respira</span>
					<span class="respira-wordmark-secondary">for WordPress</span>
					<span class="respira-admin-version-badge" aria-label="<?php esc_attr_e( 'Version', 'respira-for-wordpress' ); ?>">v<?php echo esc_html( RESPIRA_VERSION ); ?></span>
					<?php
					if ( class_exists( 'Respira_Trial_Status' ) ) {
						echo Respira_Trial_Status::render_trial_badge(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					?>
				</h1>
				<p class="respira-admin-subtitle"><?php esc_html_e( 'Calm controls for safe AI-assisted WordPress editing.', 'respira-for-wordpress' ); ?></p>
			</div>
		</div>
	</div>

	<?php if ( $update_info && ! empty( $update_info['available'] ) ) : ?>
		<div class="respira-update-notification" role="status">
			<span class="respira-update-text">
				<?php
				printf(
					/* translators: %s: version number. */
					esc_html__( 'New %s version available.', 'respira-for-wordpress' ),
					esc_html( $update_info['version'] )
				);
				?>
			</span>
			<button type="button" class="button button-primary respira-update-now-button" data-nonce="<?php echo esc_attr( wp_create_nonce( 'respira_admin_nonce' ) ); ?>">
				<?php esc_html_e( 'Update now', 'respira-for-wordpress' ); ?>
			</button>
			<a class="button button-link" href="https://respira.press/releases" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'View changelog', 'respira-for-wordpress' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $remote_notice ) ) : ?>
		<div class="respira-remote-notification" role="status" data-respira-remote-notice>
			<div class="respira-remote-notification-copy">
				<p class="respira-remote-notification-kicker">
					<?php esc_html_e( 'Latest release story', 'respira-for-wordpress' ); ?>
					<?php if ( ! empty( $remote_notice['release_version'] ) ) : ?>
						<span class="respira-remote-notification-version">
							<?php echo esc_html( 'v' . $remote_notice['release_version'] ); ?>
						</span>
					<?php endif; ?>
				</p>
				<p class="respira-remote-notification-title">
					<?php echo esc_html( $remote_notice['title'] ); ?>
				</p>
				<p class="respira-remote-notification-message">
					<?php echo esc_html( $remote_notice['message'] ); ?>
				</p>
			</div>
			<div class="respira-remote-notification-actions">
				<?php if ( ! empty( $remote_notice['cta_url'] ) ) : ?>
					<a class="button button-primary" href="<?php echo esc_url( $remote_notice['cta_url'] ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( ! empty( $remote_notice['cta_label'] ) ? $remote_notice['cta_label'] : __( 'Read update', 'respira-for-wordpress' ) ); ?>
					</a>
				<?php endif; ?>
				<button
					type="button"
					class="button button-link respira-remote-notice-dismiss"
					data-notice="<?php echo esc_attr( $remote_notice['notice_key'] ); ?>"
				>
					<?php esc_html_e( 'Dismiss', 'respira-for-wordpress' ); ?>
				</button>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( ! $is_license_active ) : ?>
		<div class="respira-license-notice-inline">
			<span class="dashicons dashicons-warning" aria-hidden="true"></span>
			<span><?php esc_html_e( 'License required for full functionality.', 'respira-for-wordpress' ); ?></span>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=license' ) ); ?>">
				<?php esc_html_e( 'Activate license', 'respira-for-wordpress' ); ?>
			</a>
		</div>
	<?php endif; ?>
</header>
<hr class="wp-header-end" style="display:none" />
