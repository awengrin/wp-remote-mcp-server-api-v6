<?php
/**
 * Respira IA sub navigation.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'respira-for-wordpress';
$items = array(
	'respira-for-wordpress' => __( 'Overview', 'respira-for-wordpress' ),
	'respira-setup'         => __( 'Setup', 'respira-for-wordpress' ),
	'respira-changes'       => __( 'The Undo Button', 'respira-for-wordpress' ),
	'respira-reports'       => __( 'Reports', 'respira-for-wordpress' ),
	'respira-addons'        => __( 'Add-ons', 'respira-for-wordpress' ),
	'respira-skills'        => __( 'Skills', 'respira-for-wordpress' ),
	'respira-governance'    => __( 'Governance', 'respira-for-wordpress' ),
	'respira-audit-log'     => __( 'Logs', 'respira-for-wordpress' ),
	'respira-settings'      => __( 'Settings', 'respira-for-wordpress' ),
	'respira-whats-new'     => __( "What's New", 'respira-for-wordpress' ),
);
?>
<nav class="respira-admin-subnav" aria-label="<?php esc_attr_e( 'Respira sections', 'respira-for-wordpress' ); ?>">
	<ul class="respira-admin-subnav-list">
		<?php foreach ( $items as $slug => $label ) : ?>
			<?php $is_keycap = ( 'respira-changes' === $slug ); ?>
			<li class="respira-admin-subnav-item">
				<a class="respira-admin-subnav-link<?php echo $current_page === $slug ? ' is-active' : ''; ?><?php echo $is_keycap ? ' respira-keycap' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=' . $slug ) ); ?>"<?php echo $current_page === $slug ? ' aria-current="page"' : ''; ?>>
					<?php echo esc_html( $label ); ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
