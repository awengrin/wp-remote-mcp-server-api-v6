<?php
/**
 * Shared Respira admin shell start.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_screen = isset( $respira_screen ) ? sanitize_key( (string) $respira_screen ) : '';
if ( '' === $respira_screen ) {
	$respira_screen = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'respira-for-wordpress';
}
?>
<div class="wrap respira-admin-wrap">
	<div class="respira-admin" data-respira-admin="1" data-respira-screen="<?php echo esc_attr( $respira_screen ); ?>">
		<style>
			.respira-admin h1,
			.respira-admin h2,
			.respira-admin h3,
			.respira-admin h4,
			.respira-admin h5,
			.respira-admin h6,
			.respira-admin .respira-admin-title,
			.respira-admin .respira-page-title,
			.respira-admin .respira-column-title,
			.respira-admin .respira-page-headline h2,
			.respira-admin .respira-section-header h2 { color: #f3f7ff !important; }
		</style>
		<div class="respira-admin-announcer" aria-live="polite" aria-atomic="true"></div>
