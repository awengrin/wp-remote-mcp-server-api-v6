<?php
/**
 * Admin Footer Partial.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<footer class="respira-admin-footer">
	<div class="respira-admin-footer-inner">
		<nav class="respira-admin-footer-links" aria-label="<?php esc_attr_e( 'Respira links', 'respira-for-wordpress' ); ?>">
			<a href="https://www.respira.press/docs" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Documentation', 'respira-for-wordpress' ); ?></a>
			<a href="https://respira.press/dashboard" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Add more sites', 'respira-for-wordpress' ); ?></a>
			<a href="https://respira.press/dashboard" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Become an affiliate', 'respira-for-wordpress' ); ?></a>
		</nav>
		<div class="respira-admin-footer-credit">
			<?php
			printf(
				/* translators: %s: plugin version. */
				esc_html__( 'Respira for WordPress v%s', 'respira-for-wordpress' ),
				esc_html( RESPIRA_VERSION )
			);
			?>
		</div>
	</div>
</footer>
