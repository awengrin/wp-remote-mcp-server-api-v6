<?php
/**
 * Shared UI helpers for Respira admin pages.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'respira_admin_render_notice' ) ) {
	/**
	 * Render a scoped notice block.
	 *
	 * @param string $type Notice type.
	 * @param string $title Notice title.
	 * @param string $body Notice body.
	 * @return void
	 */
	function respira_admin_render_notice( $type, $title, $body ) {
		$type_class = sanitize_html_class( (string) $type );
		?>
		<div class="respira-notice respira-notice-<?php echo esc_attr( $type_class ); ?>">
			<?php if ( '' !== trim( (string) $title ) ) : ?>
				<strong class="respira-notice-title"><?php echo esc_html( $title ); ?></strong>
			<?php endif; ?>
			<?php if ( '' !== trim( (string) $body ) ) : ?>
				<p class="respira-notice-body"><?php echo esc_html( $body ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'respira_admin_render_empty_state' ) ) {
	/**
	 * Render simple empty state.
	 *
	 * @param string $title Empty title.
	 * @param string $description Empty description.
	 * @return void
	 */
	function respira_admin_render_empty_state( $title, $description ) {
		?>
		<div class="respira-empty-state" role="status">
			<h3 class="respira-empty-state-title"><?php echo esc_html( $title ); ?></h3>
			<p class="respira-empty-state-description"><?php echo esc_html( $description ); ?></p>
		</div>
		<?php
	}
}
