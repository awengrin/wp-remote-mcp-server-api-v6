<?php
/**
 * Settings view — risk-based layout with auto-save.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$plugin_management_available = isset( $plugin_management_available ) ? (bool) $plugin_management_available : true;
$plugin_management_reason    = isset( $plugin_management_reason ) ? (string) $plugin_management_reason : '';
$plugin_management_enabled   = $plugin_management_available && ( 1 === (int) get_option( 'respira_enable_plugin_management', 0 ) );
$webmcp_available            = isset( $webmcp_available ) ? (bool) $webmcp_available : false;
$webmcp_unavailable_reason   = isset( $webmcp_unavailable_reason ) ? (string) $webmcp_unavailable_reason : '';
$webmcp_tool_groups          = isset( $webmcp_tool_groups ) && is_array( $webmcp_tool_groups ) ? $webmcp_tool_groups : array();
$webmcp_selected_groups      = isset( $webmcp_selected_groups ) && is_array( $webmcp_selected_groups ) ? $webmcp_selected_groups : array( 'all' );
$webmcp_all_selected         = in_array( 'all', $webmcp_selected_groups, true );
$webmcp_total_tools          = 0;
$webmcp_woo_tools            = 0;

foreach ( $webmcp_tool_groups as $group_slug => $group_data ) {
	$group_count = isset( $group_data['count'] ) ? (int) $group_data['count'] : 0;
	$webmcp_total_tools += $group_count;
	if ( 'woocommerce' === $group_slug ) {
		$webmcp_woo_tools = $group_count;
	}
}
$webmcp_wordpress_tools = max( 0, $webmcp_total_tools - $webmcp_woo_tools );

/* ── Safety status calculation ── */
$opt_auto_dup      = (int) get_option( 'respira_auto_duplicate', 1 );
$opt_security      = (int) get_option( 'respira_security_checks', 1 );
$opt_audit         = (int) get_option( 'respira_audit_logging', 1 );
$opt_direct_edit   = (int) get_option( 'respira_allow_direct_edit', 0 );
$opt_approval_mode = (int) get_option( 'respira_preserve_product_ids_on_approve', 1 );
$opt_bulk          = (int) get_option( 'respira_enable_bulk_approvals', 0 );
$opt_rate_limit    = (int) get_option( 'respira_rate_limit', 100 );

$safety_issues = array();
if ( ! $opt_auto_dup ) {
	$safety_issues[] = __( 'Auto Duplicate is OFF', 'respira-for-wordpress' );
}
if ( ! $opt_security ) {
	$safety_issues[] = __( 'Security Checks are OFF', 'respira-for-wordpress' );
}
if ( $opt_direct_edit ) {
	$safety_issues[] = __( 'Direct Editing is ON', 'respira-for-wordpress' );
}
if ( $plugin_management_enabled ) {
	$safety_issues[] = __( 'Plugin Management is ON', 'respira-for-wordpress' );
}
$is_safe = empty( $safety_issues );

/* ── Post types for swap mode ── */
$exclude_csv     = (string) get_option( 'respira_preserve_id_cpt_slugs', '' );
$excluded_slugs  = array_filter( array_map( 'trim', explode( ',', $exclude_csv ) ) );
$available_types = get_post_types( array( 'public' => true ), 'objects' );
$builtin_order   = array( 'post', 'page' );
$ordered_types   = array();
foreach ( $builtin_order as $slug ) {
	if ( isset( $available_types[ $slug ] ) ) {
		$ordered_types[ $slug ] = $available_types[ $slug ];
	}
}
foreach ( $available_types as $slug => $obj ) {
	if ( ! isset( $ordered_types[ $slug ] ) && 'attachment' !== $slug ) {
		$ordered_types[ $slug ] = $obj;
	}
}

if ( ! $respira_embed ) {
	$respira_screen = 'respira-settings';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">

	<?php settings_errors( 'respira_messages' ); ?>

	<!-- ── Safety status banner ── -->
	<div class="respira-safety-banner <?php echo $is_safe ? 'is-safe' : 'is-warning'; ?>">
		<?php if ( $is_safe ) : ?>
			<span class="respira-safety-icon">&#10003;</span>
			<div class="respira-safety-copy">
				<strong><?php esc_html_e( 'Your site is protected.', 'respira-for-wordpress' ); ?></strong>
				<?php esc_html_e( 'Respira\'s safety defaults are active: auto-duplicate ON, security checks ON, direct editing OFF.', 'respira-for-wordpress' ); ?>
			</div>
		<?php else : ?>
			<span class="respira-safety-icon">&#9888;</span>
			<div class="respira-safety-copy">
				<strong>
				<?php
				printf(
					/* translators: %d: number of changed settings. */
					esc_html( _n(
						'%d safety setting changed from recommended defaults.',
						'%d safety settings changed from recommended defaults.',
						count( $safety_issues ),
						'respira-for-wordpress'
					) ),
					count( $safety_issues )
				);
				?>
				</strong>
				<span class="respira-safety-details"><?php echo esc_html( implode( ' · ', $safety_issues ) ); ?></span>
			</div>
		<?php endif; ?>
	</div>

	<!-- ══════════════════════════════════════════
	     GREEN ZONE — Safe to change anytime
	     ══════════════════════════════════════════ -->
	<div class="respira-settings-zone respira-zone-green">
		<div class="respira-zone-header">
			<div class="respira-zone-indicator"></div>
			<h3><?php esc_html_e( 'Safe Settings', 'respira-for-wordpress' ); ?></h3>
			<span class="respira-zone-hint"><?php esc_html_e( 'No production risk. Change these anytime.', 'respira-for-wordpress' ); ?></span>
		</div>

		<div class="respira-zone-body">
			<div class="respira-setting-row" data-option="respira_audit_logging" data-default="1">
				<div class="respira-setting-main">
					<label class="respira-toggle">
						<input type="checkbox" value="1" <?php checked( $opt_audit, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Audit Logging', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Log all API activity', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Records every action performed through the Respira API with timestamps, API key, and details.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Only disable if you have an external logging solution and want to reduce database writes.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'None. Disabling just removes the audit trail — no content is affected.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>

			<div class="respira-setting-row" data-option="respira_security_checks" data-default="1">
				<div class="respira-setting-main">
					<label class="respira-toggle">
						<input type="checkbox" value="1" <?php checked( $opt_security, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Security Checks', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Validate content for security issues', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Scans AI-generated content for XSS, SQL injection, and other common security risks before saving.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Almost nobody. Only disable temporarily if a specific legitimate piece of content is being incorrectly flagged.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Low. Content still goes through WordPress sanitization, but Respira\'s extra checks add a safety net.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>

			<div class="respira-setting-row respira-setting-row--number" data-option="respira_rate_limit" data-default="100" data-type="number">
				<div class="respira-setting-main">
					<div class="respira-setting-text">
						<span class="respira-setting-name">
							<label for="respira-rate-limit"><?php esc_html_e( 'Rate Limit', 'respira-for-wordpress' ); ?></label>
						</span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Maximum API requests per hour per key', 'respira-for-wordpress' ); ?></span>
					</div>
					<div class="respira-setting-number-input">
						<input type="number" id="respira-rate-limit" value="<?php echo esc_attr( $opt_rate_limit ); ?>" min="1" max="1000" class="small-text">
						<span class="respira-setting-unit"><?php esc_html_e( '/ hour', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Limits how many API requests each key can make per hour. Prevents runaway scripts from overwhelming your site.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Power users running bulk operations may need a higher limit. Most sites are fine at 100.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'None. Setting it too low just means API requests get temporarily blocked. Setting it too high just removes the throttle.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>
		</div>
	</div>

	<!-- ══════════════════════════════════════════
	     YELLOW ZONE — Workflow changes
	     ══════════════════════════════════════════ -->
	<details class="respira-settings-zone respira-zone-yellow" open>
		<summary class="respira-zone-header">
			<div class="respira-zone-indicator"></div>
			<h3><?php esc_html_e( 'Workflow Settings', 'respira-for-wordpress' ); ?></h3>
			<span class="respira-zone-hint"><?php esc_html_e( 'Affect how content is managed, not data safety.', 'respira-for-wordpress' ); ?></span>
			<span class="respira-zone-chevron"></span>
		</summary>

		<div class="respira-zone-body">
			<div class="respira-setting-row" data-option="respira_auto_duplicate" data-default="1">
				<div class="respira-setting-main">
					<label class="respira-toggle">
						<input type="checkbox" value="1" <?php checked( $opt_auto_dup, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Auto Duplicate', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Always create duplicates before editing', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Before the AI edits any page, Respira creates a duplicate draft. The original stays untouched until you approve.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Developers who want AI to edit drafts or staging content directly, without the approval workflow.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Medium. Without duplicates, AI edits go straight to your content (still protected by snapshots).', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>

			<div class="respira-setting-row" data-option="respira_preserve_product_ids_on_approve" data-default="1">
				<div class="respira-setting-main">
					<label class="respira-toggle">
						<input type="checkbox" value="1" <?php checked( $opt_approval_mode, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Approval Mode', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Use merge mode (recommended)', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'Merge mode (ON):', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Approving a duplicate pushes its content into the original post. The URL, post ID, and menu links stay intact. The duplicate becomes a private backup.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Swap mode (OFF):', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'The duplicate replaces the original and takes over its URL slot. The original becomes private. Menu links may need updating.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Use swap mode only if you need to preserve the exact duplicate post object (rare).', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>

			<div class="respira-setting-row respira-setting-row--tags" data-option="respira_preserve_id_cpt_slugs" data-type="tags">
				<div class="respira-setting-main respira-setting-main--stacked">
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Use Swap Mode For', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Select post types that should use swap mode instead of merge when approving duplicates.', 'respira-for-wordpress' ); ?></span>
					</div>
					<div class="respira-tag-list">
						<?php foreach ( $ordered_types as $slug => $type_obj ) :
							$is_excluded = in_array( $slug, $excluded_slugs, true );
						?>
							<label class="respira-tag <?php echo $is_excluded ? 'is-active' : ''; ?>">
								<input type="checkbox" name="preserve_id_cpt_slugs[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $is_excluded ); ?>>
								<span class="respira-tag-label"><?php echo esc_html( $type_obj->labels->singular_name ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<div class="respira-setting-row" data-option="respira_enable_bulk_approvals" data-default="0">
				<div class="respira-setting-main">
					<label class="respira-toggle">
						<input type="checkbox" value="1" <?php checked( $opt_bulk, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Bulk Approvals', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Enable bulk approve in Changes page', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Lets admins select multiple duplicates on the Changes page and approve them in one action instead of one by one.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Agencies or power users managing many AI-edited pages at once.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Low. Bulk approve still requires confirmation. But it makes it easier to approve many changes at once without reviewing each individually.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>
		</div>
	</details>

	<!-- ══════════════════════════════════════════
	     RED ZONE — Dangerous settings
	     ══════════════════════════════════════════ -->
	<details class="respira-settings-zone respira-zone-red">
		<summary class="respira-zone-header">
			<div class="respira-zone-indicator"></div>
			<h3><?php esc_html_e( 'Advanced Settings', 'respira-for-wordpress' ); ?></h3>
			<span class="respira-zone-hint"><?php esc_html_e( 'These affect live content safety. Change with care.', 'respira-for-wordpress' ); ?></span>
			<span class="respira-zone-chevron"></span>
		</summary>

		<div class="respira-zone-body">
			<div class="respira-zone-warning">
				<span class="respira-zone-warning-icon">&#9888;</span>
				<p><?php esc_html_e( 'Settings in this section can affect your live site. Changing them reduces Respira\'s safety guardrails. Only change these if you understand the implications.', 'respira-for-wordpress' ); ?></p>
			</div>

			<div class="respira-setting-row respira-setting-row--danger" data-option="respira_allow_direct_edit" data-default="0" data-confirm="red">
				<div class="respira-setting-main">
					<label class="respira-toggle respira-toggle--danger">
						<input type="checkbox" value="1" <?php checked( $opt_direct_edit, 1 ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Allow Direct Editing', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Allow AI to edit original content directly', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'When enabled, AI can overwrite your live published pages using force=true with confirm_live_edit=true. Without this, AI can only edit Respira-created duplicates.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Developers working on staging sites or those who want AI to edit content without the duplicate workflow.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'HIGH. AI can modify live pages that your visitors see. Changes are still logged and snapshotted, but they go live immediately.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>

			<div class="respira-setting-row respira-setting-row--danger" data-option="respira_enable_plugin_management" data-default="0" data-confirm="red">
				<div class="respira-setting-main">
					<label class="respira-toggle respira-toggle--danger">
						<input type="checkbox" value="1" <?php checked( $plugin_management_enabled, true ); ?> <?php disabled( $plugin_management_available, false ); ?>>
						<span class="respira-toggle-slider"></span>
					</label>
					<div class="respira-setting-text">
						<span class="respira-setting-name"><?php esc_html_e( 'Plugin Management', 'respira-for-wordpress' ); ?></span>
						<span class="respira-setting-desc"><?php esc_html_e( 'Allow AI to install, activate, deactivate, and delete plugins', 'respira-for-wordpress' ); ?></span>
					</div>
					<button type="button" class="respira-help-btn" aria-label="<?php esc_attr_e( 'More info', 'respira-for-wordpress' ); ?>">?</button>
				</div>
				<?php if ( ! $plugin_management_available && ! empty( $plugin_management_reason ) ) : ?>
				<div class="respira-notice respira-notice-error" style="margin-top: 8px;">
					<p><strong><?php esc_html_e( 'Unavailable:', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( $plugin_management_reason ); ?></p>
				</div>
				<?php endif; ?>
				<div class="respira-help-tooltip" hidden>
					<p><strong><?php esc_html_e( 'What it does:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Gives AI the ability to install new plugins, activate or deactivate existing ones, update plugins, and delete them entirely.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Who should change it:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Agencies or developers who want AI to manage plugins as part of site setup or maintenance workflows.', 'respira-for-wordpress' ); ?></p>
					<p><strong><?php esc_html_e( 'Risk:', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'HIGH. AI can install untrusted code or deactivate critical plugins. All actions are logged, but the damage may already be done.', 'respira-for-wordpress' ); ?></p>
				</div>
			</div>
		</div>
	</details>

	<!-- ══════════════════════════════════════════
	     INTEGRATIONS — WebMCP & Angie
	     ══════════════════════════════════════════ -->
	<details class="respira-settings-zone respira-zone-neutral">
		<summary class="respira-zone-header">
			<div class="respira-zone-indicator"></div>
			<h3><?php esc_html_e( 'Integrations', 'respira-for-wordpress' ); ?></h3>
			<span class="respira-zone-hint"><?php esc_html_e( 'Browser AI and third-party connections.', 'respira-for-wordpress' ); ?></span>
			<span class="respira-zone-chevron"></span>
		</summary>

		<div class="respira-zone-body">

			<!-- WebMCP -->
			<div class="respira-setting-row respira-setting-row--block">
				<div class="respira-setting-text">
					<span class="respira-setting-name"><?php esc_html_e( 'Browser AI (WebMCP)', 'respira-for-wordpress' ); ?></span>
				</div>

				<div class="notice inline <?php echo $webmcp_available && is_ssl() ? 'notice-success' : 'notice-info'; ?>" style="margin: 8px 0;">
					<?php if ( $webmcp_available && is_ssl() ) : ?>
						<p><strong><?php esc_html_e( 'WebMCP is active.', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Browser AI tools are ready for Chrome 146+.', 'respira-for-wordpress' ); ?></p>
					<?php elseif ( $webmcp_available ) : ?>
						<p><strong><?php esc_html_e( 'WebMCP loaded, but HTTPS is required.', 'respira-for-wordpress' ); ?></strong></p>
					<?php else : ?>
						<p><strong><?php esc_html_e( 'WebMCP is unavailable.', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( $webmcp_unavailable_reason ); ?></p>
					<?php endif; ?>
				</div>

				<p class="respira-setting-desc">
					<?php
					printf(
						/* translators: 1: WordPress tool count, 2: WooCommerce tool count. */
						esc_html__( 'Tool inventory: %1$d WordPress tools + %2$d WooCommerce tools.', 'respira-for-wordpress' ),
						(int) $webmcp_wordpress_tools,
						(int) $webmcp_woo_tools
					);
					?>
				</p>

				<form method="post" action="" class="respira-integrations-form">
					<?php wp_nonce_field( 'respira_update_settings' ); ?>
					<p>
						<label>
							<input type="checkbox" name="respira_webmcp_tools[]" value="all" <?php checked( $webmcp_all_selected ); ?>>
							<?php
							printf(
								/* translators: %d: total number of tools. */
								esc_html__( 'Enable all %d tools (recommended)', 'respira-for-wordpress' ),
								(int) $webmcp_total_tools
							);
							?>
						</label>
					</p>

					<details class="respira-tool-categories">
						<summary><?php esc_html_e( 'Choose specific tool categories', 'respira-for-wordpress' ); ?></summary>
						<div class="respira-tool-categories-list">
							<?php foreach ( $webmcp_tool_groups as $group_slug => $group_data ) : ?>
								<?php
								$group_label = isset( $group_data['label'] ) ? (string) $group_data['label'] : $group_slug;
								$group_count = isset( $group_data['count'] ) ? (int) $group_data['count'] : 0;
								$checked     = $webmcp_all_selected || in_array( $group_slug, $webmcp_selected_groups, true );
								?>
								<label>
									<input type="checkbox" name="respira_webmcp_tools[]" value="<?php echo esc_attr( $group_slug ); ?>" <?php checked( $checked ); ?>>
									<?php echo esc_html( $group_label ); ?>
									(<?php echo esc_html( (string) $group_count ); ?>)
								</label>
							<?php endforeach; ?>
						</div>
					</details>

					<!-- Angie -->
					<div class="respira-setting-row respira-setting-row--block" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--respira-border);">
						<div class="respira-setting-text">
							<span class="respira-setting-name"><?php esc_html_e( 'Angie Integration', 'respira-for-wordpress' ); ?></span>
							<span class="respira-setting-desc"><?php esc_html_e( 'Register Respira as an MCP server inside Elementor\'s Angie AI assistant.', 'respira-for-wordpress' ); ?></span>
						</div>

						<div class="notice inline <?php echo $angie_active ? 'notice-success' : 'notice-info'; ?>" style="margin: 8px 0;">
							<?php if ( $angie_active ) : ?>
								<p><strong><?php esc_html_e( 'Angie detected.', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'Respira can expose its browser tools to Angie across wp-admin.', 'respira-for-wordpress' ); ?></p>
							<?php else : ?>
								<p><strong><?php esc_html_e( 'Angie not detected.', 'respira-for-wordpress' ); ?></strong> <?php esc_html_e( 'No bridge code loads unless Angie is installed and active.', 'respira-for-wordpress' ); ?></p>
							<?php endif; ?>
						</div>

						<p>
							<label>
								<input type="checkbox" name="respira_enable_angie_integration" value="1" <?php checked( $angie_enabled ); ?> <?php disabled( ! $angie_active ); ?>>
								<?php esc_html_e( 'Enable Respira for Angie', 'respira-for-wordpress' ); ?>
							</label>
						</p>
					</div>

					<p class="submit" style="margin-top: 16px;">
						<input type="submit" name="respira_update_settings" class="button button-primary" value="<?php esc_attr_e( 'Save Integrations', 'respira-for-wordpress' ); ?>">
					</p>
				</form>
			</div>

		</div>
	</details>


</div>

<!-- Toast + dialog — outside .respira-admin so fixed positioning works -->
<div id="respira-toast-container" class="respira-toast-container"></div>

<!-- Confirmation dialog -->
<div id="respira-confirm-dialog" hidden>
	<div class="respira-confirm-dialog-backdrop"></div>
	<div class="respira-confirm-dialog-box">
		<h4 id="respira-confirm-title"></h4>
		<p id="respira-confirm-message"></p>
		<div class="respira-confirm-dialog-actions">
			<button type="button" class="button respira-confirm-cancel"><?php esc_html_e( 'Keep safe defaults', 'respira-for-wordpress' ); ?></button>
			<button type="button" class="button respira-confirm-proceed"><?php esc_html_e( 'Enable anyway', 'respira-for-wordpress' ); ?></button>
		</div>
	</div>
</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
