<?php
/**
 * Changes view — unified approvals + version history.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      5.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">

	<!-- Storage Panel (collapsible) -->
	<details class="respira-storage-panel" open>
		<summary class="respira-storage-toggle">
			<span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'Storage', 'respira-for-wordpress' ); ?>
			<span class="respira-storage-summary" id="respira-storage-inline"></span>
		</summary>
		<div class="respira-storage-body">
			<div class="respira-storage-stats">
				<div class="respira-stat">
					<span id="respira-stat-count">&mdash;</span>
					<label><?php esc_html_e( 'Versions', 'respira-for-wordpress' ); ?></label>
				</div>
				<div class="respira-stat">
					<span id="respira-stat-size">&mdash;</span>
					<label><?php esc_html_e( 'Total size', 'respira-for-wordpress' ); ?></label>
				</div>
				<div class="respira-stat">
					<span id="respira-stat-oldest">&mdash;</span>
					<label><?php esc_html_e( 'Oldest', 'respira-for-wordpress' ); ?></label>
				</div>
			</div>
			<div class="respira-storage-actions">
				<button type="button" class="button" id="respira-purge-btn">
					<?php esc_html_e( 'Purge versions older than 30 days', 'respira-for-wordpress' ); ?>
				</button>
				<button type="button" class="button respira-btn-danger-ghost" id="respira-purge-all-btn">
					<?php esc_html_e( 'Delete all versions', 'respira-for-wordpress' ); ?>
				</button>
			</div>
		</div>
	</details>

	<!-- Filters -->
	<div class="respira-changes-filters">
		<div class="respira-search-wrap">
			<input type="search" id="respira-changes-search" placeholder="<?php esc_attr_e( 'Search posts...', 'respira-for-wordpress' ); ?>" autocomplete="off" />
			<div id="respira-changes-search-results" class="respira-search-dropdown" style="display:none;"></div>
		</div>
		<select id="respira-changes-type-filter">
			<option value=""><?php esc_html_e( 'All kinds', 'respira-for-wordpress' ); ?></option>
			<option value="page"><?php esc_html_e( 'Pages', 'respira-for-wordpress' ); ?></option>
			<option value="post"><?php esc_html_e( 'Posts', 'respira-for-wordpress' ); ?></option>
			<option value="product"><?php esc_html_e( 'Products', 'respira-for-wordpress' ); ?></option>
		</select>
	</div>

	<!-- Post cards -->
	<div id="respira-changes-list"></div>

	<div id="respira-changes-empty" class="respira-empty-state" style="display:none;">
		<span class="dashicons dashicons-yes-alt respira-empty-state-icon"></span>
		<p><?php esc_html_e( 'No changes found. When AI edits your content, posts will appear here with their version history.', 'respira-for-wordpress' ); ?></p>
	</div>

	<div id="respira-changes-loadmore" class="respira-changes-loadmore" style="display:none;">
		<button type="button" class="button" id="respira-loadmore-btn">
			<?php esc_html_e( 'Load more posts', 'respira-for-wordpress' ); ?>
		</button>
	</div>

</div>

<!-- Confirm Modal -->
<div id="respira-confirm-modal" class="respira-modal" style="display:none;" role="dialog" aria-modal="true">
	<div class="respira-modal-backdrop"></div>
	<div class="respira-modal-dialog">
		<h3 id="respira-confirm-title"></h3>
		<div id="respira-confirm-body"></div>
		<div class="respira-modal-footer">
			<button type="button" class="button" id="respira-confirm-cancel"><?php esc_html_e( 'Cancel', 'respira-for-wordpress' ); ?></button>
			<button type="button" class="button button-primary" id="respira-confirm-ok"><?php esc_html_e( 'Confirm', 'respira-for-wordpress' ); ?></button>
		</div>
	</div>
</div>

<!-- Preview Modal -->
<div id="respira-preview-modal" class="respira-modal" style="display:none;" role="dialog" aria-modal="true">
	<div class="respira-modal-backdrop"></div>
	<div class="respira-modal-dialog respira-modal-wide">
		<div class="respira-modal-header">
			<h3><?php esc_html_e( 'Version preview', 'respira-for-wordpress' ); ?></h3>
			<button type="button" class="respira-modal-close" id="respira-preview-close">&times;</button>
		</div>
		<div id="respira-preview-body" class="respira-modal-body"></div>
	</div>
</div>

<!-- Toast -->
<div id="respira-changes-toast" class="respira-toast" style="display:none;"></div>

<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
?>
