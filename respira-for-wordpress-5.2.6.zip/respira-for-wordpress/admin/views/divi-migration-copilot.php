<?php
/**
 * Divi 5 Migration Copilot view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      2.0.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

$report  = isset( $report ) && is_array( $report ) ? $report : array();
$prompts = isset( $prompts ) && is_array( $prompts ) ? $prompts : array();

$risk = $report['risk'] ?? array( 'level' => 'N/A', 'score' => 0 );
$totals = $report['totals'] ?? array();
$disclaimer = Respira_Divi_Migration_Copilot::DISCLAIMER;
if ( ! $respira_embed ) {
	$respira_screen = 'respira-divi-migration-copilot';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body">

	<?php settings_errors( 'respira_messages' ); ?>

	<div class="respira-section">
		<div class="respira-section-header">
			<h2>
				<span class="dashicons dashicons-update"></span>
				<?php esc_html_e( 'Divi 5 Migration Copilot', 'respira-for-wordpress' ); ?>
			</h2>
			<p><?php esc_html_e( 'Readiness scanner + prompt pack for safe Divi 4 to Divi 5 migration planning.', 'respira-for-wordpress' ); ?></p>
			<p class="respira-copilot-disclaimer"><?php echo esc_html( $disclaimer ); ?></p>
		</div>

		<div class="respira-dashboard-grid">
			<div class="respira-card">
				<div class="respira-card-header">
					<h3><?php esc_html_e( 'Migration Readiness Report', 'respira-for-wordpress' ); ?></h3>
				</div>
				<div class="respira-card-content">
					<p><?php esc_html_e( 'Scan posts/pages/templates for Divi 4, Divi 5, mixed states, and compatibility mode risk.', 'respira-for-wordpress' ); ?></p>
					<form method="post">
						<?php wp_nonce_field( 'respira_generate_migration_report' ); ?>
						<p>
							<button type="submit" name="respira_generate_migration_report" class="button button-primary">
								<?php esc_html_e( 'Run readiness report', 'respira-for-wordpress' ); ?>
							</button>
						</p>
					</form>

					<?php if ( ! empty( $report ) ) : ?>
						<div class="respira-info-grid respira-mt-sm">
							<div><strong><?php esc_html_e( 'Risk level:', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( $risk['level'] ?? 'N/A' ); ?> (<?php echo esc_html( (string) ( $risk['score'] ?? 0 ) ); ?>)</div>
							<div><strong><?php esc_html_e( 'Divi 4 pages:', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( (string) ( $totals['divi4_pages'] ?? 0 ) ); ?></div>
							<div><strong><?php esc_html_e( 'Divi 5 pages:', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( (string) ( $totals['divi5_pages'] ?? 0 ) ); ?></div>
							<div><strong><?php esc_html_e( 'Mixed pages:', 'respira-for-wordpress' ); ?></strong> <?php echo esc_html( (string) ( $totals['mixed_pages'] ?? 0 ) ); ?></div>
						</div>
						<div class="respira-copilot-actions">
							<form method="post">
								<?php wp_nonce_field( 'respira_export_migration_report_json' ); ?>
								<button type="submit" name="respira_export_migration_report_json" class="button"><?php esc_html_e( 'Export report (JSON)', 'respira-for-wordpress' ); ?></button>
							</form>
							<form method="post">
								<?php wp_nonce_field( 'respira_export_prompt_pack_md' ); ?>
								<button type="submit" name="respira_export_prompt_pack_md" class="button"><?php esc_html_e( 'Export prompt pack (Markdown)', 'respira-for-wordpress' ); ?></button>
							</form>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="respira-card">
				<div class="respira-card-header">
					<h3><?php esc_html_e( 'Migration Notes', 'respira-for-wordpress' ); ?></h3>
				</div>
				<div class="respira-card-content">
					<ul class="respira-feature-list">
						<li><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Divi 5 pages are block-based and should be edited as block trees.', 'respira-for-wordpress' ); ?></li>
						<li><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Divi 4 pages remain shortcode-based and stay fully supported.', 'respira-for-wordpress' ); ?></li>
						<li><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Mixed pages often indicate compatibility mode and higher QA overhead.', 'respira-for-wordpress' ); ?></li>
						<li><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Legacy/third-party shortcode wrappers are treated as opaque for safety.', 'respira-for-wordpress' ); ?></li>
					</ul>
					<p class="respira-copilot-disclaimer respira-mt-sm"><?php echo esc_html( $disclaimer ); ?></p>
				</div>
			</div>
		</div>
	</div>

	<?php if ( ! empty( $report ) ) : ?>
	<div class="respira-section">
		<div class="respira-section-header">
			<h2><span class="dashicons dashicons-flag"></span> <?php esc_html_e( 'High-Risk Pages', 'respira-for-wordpress' ); ?></h2>
			<p><?php esc_html_e( 'Pages likely to trigger compatibility mode or third-party module issues.', 'respira-for-wordpress' ); ?></p>
		</div>
		<div class="respira-card">
			<div class="respira-card-content">
				<?php $high_risk_pages = $report['high_risk_pages'] ?? array(); ?>
				<?php if ( empty( $high_risk_pages ) ) : ?>
					<p><?php esc_html_e( 'No high-risk pages detected in this scan.', 'respira-for-wordpress' ); ?></p>
				<?php else : ?>
					<table class="widefat striped">
						<thead>
							<tr>
								<th><?php esc_html_e( 'ID', 'respira-for-wordpress' ); ?></th>
								<th><?php esc_html_e( 'Title', 'respira-for-wordpress' ); ?></th>
								<th><?php esc_html_e( 'Reasons', 'respira-for-wordpress' ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $high_risk_pages as $item ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $item['id'] ); ?></td>
								<td>
									<?php if ( ! empty( $item['url'] ) ) : ?>
										<a href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $item['title'] ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $item['title'] ); ?>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( implode( ' | ', (array) ( $item['reasons'] ?? array() ) ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="respira-section">
		<div class="respira-section-header">
			<h2><span class="dashicons dashicons-text-page"></span> <?php esc_html_e( 'Prompt Pack', 'respira-for-wordpress' ); ?></h2>
			<p><?php esc_html_e( 'One-click prompts generated from your site readiness data.', 'respira-for-wordpress' ); ?></p>
			<p class="respira-copilot-disclaimer"><?php echo esc_html( $disclaimer ); ?></p>
		</div>
		<div class="respira-dashboard-grid">
			<?php foreach ( $prompts as $prompt ) : ?>
				<div class="respira-card">
					<div class="respira-card-header">
						<h3><?php echo esc_html( $prompt['title'] ); ?></h3>
					</div>
					<div class="respira-card-content">
						<p><?php echo esc_html( $prompt['description'] ); ?></p>
						<p><em><?php esc_html_e( 'What this does:', 'respira-for-wordpress' ); ?></em> <?php echo esc_html( $prompt['description'] ); ?></p>
						<textarea readonly class="respira-copilot-textarea" id="respira-prompt-<?php echo esc_attr( $prompt['id'] ); ?>"><?php echo esc_textarea( $prompt['prompt'] ); ?></textarea>
						<p class="respira-copilot-actions">
							<button type="button" class="button button-secondary respira-copy-prompt-btn" data-target="respira-prompt-<?php echo esc_attr( $prompt['id'] ); ?>">
								<?php esc_html_e( 'Copy prompt', 'respira-for-wordpress' ); ?>
							</button>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-for-wordpress' ) ); ?>" class="button">
								<?php esc_html_e( 'Run with Respira AI', 'respira-for-wordpress' ); ?>
							</a>
						</p>
						<p class="respira-copilot-fine-print"><?php echo esc_html( Respira_Divi_Migration_Copilot::DISCLAIMER ); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php endif; ?>

	<script>
	document.addEventListener('click', function (event) {
		const btn = event.target.closest('.respira-copy-prompt-btn');
		if (!btn) return;
		const targetId = btn.getAttribute('data-target');
		const textarea = document.getElementById(targetId);
		if (!textarea) return;
		textarea.select();
		textarea.setSelectionRange(0, 99999);
		try {
			document.execCommand('copy');
			btn.textContent = 'Copied';
			setTimeout(function () { btn.textContent = 'Copy prompt'; }, 1200);
		} catch (err) {}
		});
		</script>

	</div>
	<?php
	if ( ! $respira_embed ) {
		require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
		require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
	}
