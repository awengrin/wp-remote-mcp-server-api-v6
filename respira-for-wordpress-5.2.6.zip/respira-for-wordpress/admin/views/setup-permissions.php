<?php
/**
 * Setup: Health & Permissions (focused view).
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$context       = Respira_Context::get_site_info();
$license_info  = Respira_License::get_license_info();
$license_state = strtoupper( (string) ( $license_info['status'] ?? 'inactive' ) );
$site_name     = (string) ( $context['site_name'] ?? get_bloginfo( 'name' ) );
$wp_version    = (string) ( $context['wordpress_version'] ?? get_bloginfo( 'version' ) );
$php_version   = (string) ( $context['php_version'] ?? PHP_VERSION );
$rest_v2_url   = rest_url( defined( 'RESPIRA_REST_NAMESPACE_V2' ) ? RESPIRA_REST_NAMESPACE_V2 : 'respira/v2' );
$status_v2_url = untrailingslashit( $rest_v2_url ) . '/status';
$webmcp_tool_groups     = isset( $webmcp_tool_groups ) && is_array( $webmcp_tool_groups ) ? $webmcp_tool_groups : array();
$webmcp_selected_groups = isset( $webmcp_selected_groups ) && is_array( $webmcp_selected_groups ) ? $webmcp_selected_groups : array( 'all' );

$on_label  = __( 'On', 'respira-for-wordpress' );
$off_label = __( 'Off', 'respira-for-wordpress' );

$setting_rows = array(
	array(
		'label'  => __( 'Auto Duplicate', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_auto_duplicate', 1 ),
		'detail' => __( 'Always create duplicates before editing.', 'respira-for-wordpress' ),
	),
	array(
		'label'  => __( 'Security Checks', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_security_checks', 1 ),
		'detail' => __( 'Validate content for security risks.', 'respira-for-wordpress' ),
	),
	array(
		'label'  => __( 'Audit Logging', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_audit_logging', 1 ),
		'detail' => __( 'Log all API activity.', 'respira-for-wordpress' ),
	),
	array(
		'label'  => __( 'Allow Direct Editing', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_allow_direct_edit', 0 ),
		'detail' => __( 'Allow force edits on originals with explicit confirm_live_edit.', 'respira-for-wordpress' ),
	),
	array(
		'label'  => __( 'Preserve IDs on Approval', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_preserve_product_ids_on_approve', 1 ),
		'detail' => __( 'Keep original URLs and IDs for pages, posts, and products when approving.', 'respira-for-wordpress' ),
	),
	array(
		'label'  => __( 'Bulk Approvals', 'respira-for-wordpress' ),
		'value'  => 1 === (int) get_option( 'respira_enable_bulk_approvals', 0 ),
		'detail' => __( 'Allow multi-select approve actions in queue.', 'respira-for-wordpress' ),
	),
);

$rate_limit = (int) get_option( 'respira_rate_limit', 100 );

$webmcp_all_selected = in_array( 'all', $webmcp_selected_groups, true );
$selected_group_labels = array();
if ( ! $webmcp_all_selected ) {
	foreach ( $webmcp_selected_groups as $group_slug ) {
		if ( isset( $webmcp_tool_groups[ $group_slug ]['label'] ) ) {
			$selected_group_labels[] = (string) $webmcp_tool_groups[ $group_slug ]['label'];
		}
	}
}
?>

<div class="respira-card respira-health-summary-card">
	<h3><?php esc_html_e( 'Health Snapshot', 'respira-for-wordpress' ); ?></h3>
	<div class="respira-info-grid">
		<div>
			<strong><?php esc_html_e( 'Site', 'respira-for-wordpress' ); ?></strong>
			<?php echo esc_html( $site_name ); ?>
		</div>
		<div>
			<strong><?php esc_html_e( 'License', 'respira-for-wordpress' ); ?></strong>
			<?php echo esc_html( $license_state ); ?>
		</div>
		<div>
			<strong><?php esc_html_e( 'WordPress', 'respira-for-wordpress' ); ?></strong>
			<?php echo esc_html( $wp_version ); ?>
		</div>
		<div>
			<strong><?php esc_html_e( 'PHP', 'respira-for-wordpress' ); ?></strong>
			<?php echo esc_html( $php_version ); ?>
		</div>
		<div>
			<strong><?php esc_html_e( 'Respira v2 Status URL', 'respira-for-wordpress' ); ?></strong>
			<code><?php echo esc_html( $status_v2_url ); ?></code>
		</div>
	</div>
</div>

<div class="respira-card">
	<h3><?php esc_html_e( 'Safety Controls (Current)', 'respira-for-wordpress' ); ?></h3>
	<table class="widefat striped respira-table-lite">
		<tbody>
			<?php foreach ( $setting_rows as $row ) : ?>
				<tr>
					<th><?php echo esc_html( $row['label'] ); ?></th>
					<td>
						<span class="respira-badge <?php echo $row['value'] ? 'respira-badge-success' : 'respira-badge-secondary'; ?>">
							<?php echo esc_html( $row['value'] ? $on_label : $off_label ); ?>
						</span>
						<span class="description respira-detail-hint"><?php echo esc_html( $row['detail'] ); ?></span>
					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th><?php esc_html_e( 'Rate Limit', 'respira-for-wordpress' ); ?></th>
				<td><?php echo esc_html( sprintf( __( '%d requests per hour per API key', 'respira-for-wordpress' ), $rate_limit ) ); ?></td>
			</tr>
		</tbody>
	</table>
</div>

<div class="respira-card">
	<h3><?php esc_html_e( 'Browser AI Permission Scope (Current)', 'respira-for-wordpress' ); ?></h3>
	<?php if ( $webmcp_all_selected ) : ?>
		<p><span class="respira-badge respira-badge-success"><?php esc_html_e( 'All Categories Enabled', 'respira-for-wordpress' ); ?></span></p>
	<?php elseif ( ! empty( $selected_group_labels ) ) : ?>
		<p><span class="respira-badge respira-badge-info"><?php esc_html_e( 'Selected Categories', 'respira-for-wordpress' ); ?></span></p>
		<p><?php echo esc_html( implode( ', ', $selected_group_labels ) ); ?></p>
	<?php else : ?>
		<p><span class="respira-badge respira-badge-warning"><?php esc_html_e( 'No Categories Selected', 'respira-for-wordpress' ); ?></span></p>
	<?php endif; ?>
	<p class="description"><?php esc_html_e( 'Settings editing lives in one place now: the Settings page.', 'respira-for-wordpress' ); ?></p>
	<p>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-settings' ) ); ?>"><?php esc_html_e( 'Open Settings', 'respira-for-wordpress' ); ?></a>
	</p>
</div>
