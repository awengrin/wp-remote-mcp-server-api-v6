<?php
/**
 * Accessibility tab admin view.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin/views
 * @since      2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$respira_embed = isset( $respira_embed ) ? (bool) $respira_embed : false;

// Check if the Accessibility Add-on is active.
$addon_active = apply_filters( 'respira_accessibility_addon_active', false );
$action_param = isset( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : '';

// Fetch recent scan stats from transient / option if addon is active.
$recent_scans  = $addon_active ? get_option( 'respira_accessibility_recent_scans', array() ) : array();
$total_issues  = $addon_active ? (int) get_option( 'respira_accessibility_total_issues', 0 ) : 0;
$last_scan_at  = $addon_active ? get_option( 'respira_accessibility_last_scan', '' ) : '';
if ( ! is_array( $recent_scans ) ) {
	$recent_scans = array();
}
$recent_scans = array_values( array_filter( $recent_scans, 'is_array' ) );
$recent_scans = array_reverse( $recent_scans );

// Color helpers (dark-theme equivalents for dynamic PHP-generated styles).
$severity_colors = array(
	'critical' => '#ef4444',
	'serious'  => '#f97316',
	'moderate' => '#f59e0b',
	'minor'    => '#10b981',
);

$selected_scan_id = isset( $_GET['scan_id'] ) ? sanitize_text_field( wp_unslash( $_GET['scan_id'] ) ) : '';
$selected_scan    = null;
if ( $addon_active && ! empty( $recent_scans ) ) {
	foreach ( $recent_scans as $scan_candidate ) {
		if ( ! empty( $selected_scan_id ) && isset( $scan_candidate['id'] ) && $selected_scan_id === (string) $scan_candidate['id'] ) {
			$selected_scan = $scan_candidate;
			break;
		}
	}
	if ( null === $selected_scan ) {
		$selected_scan = $recent_scans[0];
	}
}

$selected_scan_violations = ( $selected_scan && ! empty( $selected_scan['violations'] ) && is_array( $selected_scan['violations'] ) ) ? $selected_scan['violations'] : array();
$selected_scan_prompts    = ( $selected_scan && ! empty( $selected_scan['prompts'] ) && is_array( $selected_scan['prompts'] ) ) ? $selected_scan['prompts'] : array();
$selected_scan_prompts    = array_values(
	array_filter(
		$selected_scan_prompts,
		static function( $prompt ) {
			return is_array( $prompt ) && '' !== trim( (string) ( $prompt['prompt'] ?? '' ) );
		}
	)
);

$all_prompt_items = array();
if ( $addon_active ) {
	foreach ( $recent_scans as $scan_candidate ) {
		$scan_prompts = ( isset( $scan_candidate['prompts'] ) && is_array( $scan_candidate['prompts'] ) ) ? $scan_candidate['prompts'] : array();
		foreach ( $scan_prompts as $prompt_index => $prompt ) {
			if ( ! is_array( $prompt ) ) {
				continue;
			}

			$prompt_text = (string) ( $prompt['prompt'] ?? '' );
			if ( '' === trim( $prompt_text ) ) {
				continue;
			}

			$all_prompt_items[] = array(
				'id'         => sanitize_key( (string) ( $scan_candidate['id'] ?? '' ) ) . '-' . (int) $prompt_index,
				'scan_id'    => sanitize_text_field( (string) ( $scan_candidate['id'] ?? '' ) ),
				'scan_title' => sanitize_text_field(
					(string) ( $scan_candidate['title'] ?? $scan_candidate['url'] ?? __( 'Untitled page', 'respira-for-wordpress' ) )
				),
				'scan_url'   => esc_url_raw( (string) ( $scan_candidate['url'] ?? '' ) ),
				'scanned_at' => sanitize_text_field( (string) ( $scan_candidate['scanned_at'] ?? '' ) ),
				'title'      => sanitize_text_field( (string) ( $prompt['title'] ?? __( 'Accessibility fix prompt', 'respira-for-wordpress' ) ) ),
				'severity'   => sanitize_key( (string) ( $prompt['severity'] ?? 'moderate' ) ),
				'rule_id'    => sanitize_key( (string) ( $prompt['ruleId'] ?? $prompt['rule_id'] ?? '' ) ),
				'wcag'       => sanitize_text_field( (string) ( $prompt['wcag'] ?? '' ) ),
				'prompt'     => $prompt_text,
			);
		}
	}
}

$queue_count = count( $all_prompt_items );

$show_queue_panel  = $addon_active && 'view_queue' === $action_param;
$show_report_panel = $addon_active && ! empty( $selected_scan );

$resolve_violation_selector = static function( $violation ) {
	if ( ! is_array( $violation ) ) {
		return '';
	}
	$nodes = isset( $violation['nodes'] ) && is_array( $violation['nodes'] ) ? $violation['nodes'] : array();
	if ( empty( $nodes ) || ! is_array( $nodes[0] ) ) {
		return '';
	}
	$target = isset( $nodes[0]['target'] ) && is_array( $nodes[0]['target'] ) ? $nodes[0]['target'] : array();
	return isset( $target[0] ) ? (string) $target[0] : '';
};

if ( ! $respira_embed ) {
	$respira_screen = 'respira-accessibility';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
}
?>
<div class="respira-page-body respira-accessibility-page">

	<!-- Page Header -->
	<div class="respira-a11y-page-header">
		<div>
			<h1 class="respira-page-title respira-a11y-page-title">
				<svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" aria-hidden="true">
					<path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
				</svg>
				<?php esc_html_e( 'ADA & WCAG Accessibility', 'respira-for-wordpress' ); ?>
				<span class="respira-a11y-badge-experimental">
					<?php esc_html_e( 'Experimental', 'respira-for-wordpress' ); ?>
				</span>
			</h1>
			<p class="respira-page-subtitle">
				<?php esc_html_e( 'WCAG 2.2 AA · ADA Title III · Section 508 · EAA 2025', 'respira-for-wordpress' ); ?>
			</p>
		</div>

		<?php if ( $addon_active ) : ?>
			<button
				type="button"
				id="respira-scan-now-btn"
				class="button button-primary respira-btn-primary"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'respira_admin_nonce' ) ); ?>"
				data-home-url="<?php echo esc_attr( home_url() ); ?>"
				data-ajax-url="<?php echo esc_attr( admin_url( 'admin-ajax.php' ) ); ?>"
				data-auto-run="<?php echo 'scan_now' === $action_param ? '1' : '0'; ?>"
			>
				<?php esc_html_e( 'Scan Now', 'respira-for-wordpress' ); ?>
			</button>
			<span id="respira-scan-now-feedback" class="respira-a11y-scan-feedback"></span>
		<?php else : ?>
			<a
				href="https://respira.press/pricing"
				target="_blank"
				rel="noopener noreferrer"
				class="button button-primary respira-btn-primary"
			>
				<?php esc_html_e( 'Upgrade to Unlock ↗', 'respira-for-wordpress' ); ?>
			</a>
		<?php endif; ?>
	</div>

	<?php if ( ! $addon_active ) : ?>
	<!-- ── Upsell / Locked State ─────────────────────────────── -->
	<div class="respira-card respira-accessibility-locked respira-a11y-locked">

		<div class="respira-a11y-locked-emoji" aria-hidden="true">♿</div>
		<h2 class="respira-a11y-locked-heading">
			<?php esc_html_e( 'Accessibility Add-on', 'respira-for-wordpress' ); ?>
		</h2>
		<p class="respira-a11y-locked-desc">
			<?php
			esc_html_e(
				'Automatically detect and fix ADA & WCAG violations on your Elementor site. '
				. '60% of issues are fixed instantly via direct PHP — the rest via AI prompts for Cursor, Claude, or Codex.',
				'respira-for-wordpress'
			);
			?>
		</p>

		<!-- Feature grid -->
		<div class="respira-a11y-feature-grid">
			<?php
			$features = array(
				array(
					'icon'  => '⚡',
					'title' => __( '60% auto-fixed', 'respira-for-wordpress' ),
					'desc'  => __( 'Contrast, alt text, labels fixed directly via PHP', 'respira-for-wordpress' ),
				),
				array(
					'icon'  => '🤖',
					'title' => __( '40% via AI prompts', 'respira-for-wordpress' ),
					'desc'  => __( 'Batch queue to Cursor / Claude / Codex', 'respira-for-wordpress' ),
				),
				array(
					'icon'  => '📊',
					'title' => __( 'PDF reports', 'respira-for-wordpress' ),
					'desc'  => __( 'McKinsey-style for clients and compliance teams', 'respira-for-wordpress' ),
				),
				array(
					'icon'  => '🔄',
					'title' => __( 'Scheduled scans', 'respira-for-wordpress' ),
					'desc'  => __( 'Weekly regression testing with email alerts', 'respira-for-wordpress' ),
				),
				array(
					'icon'  => '🛡️',
					'title' => __( 'Standards coverage', 'respira-for-wordpress' ),
					'desc'  => __( 'WCAG 2.2 AA · ADA Title III · Section 508 · EAA', 'respira-for-wordpress' ),
				),
				array(
					'icon'  => '📈',
					'title' => __( 'Trend tracking', 'respira-for-wordpress' ),
					'desc'  => __( 'Score history and improvement over time', 'respira-for-wordpress' ),
				),
			);
			foreach ( $features as $feature ) :
				?>
				<div class="respira-a11y-feature-item">
					<span class="respira-a11y-feature-icon" aria-hidden="true"><?php echo esc_html( $feature['icon'] ); ?></span>
					<div>
						<strong class="respira-a11y-feature-title"><?php echo esc_html( $feature['title'] ); ?></strong>
						<span class="respira-a11y-feature-desc"><?php echo esc_html( $feature['desc'] ); ?></span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<!-- Pricing CTA -->
		<div class="respira-a11y-pricing-cta">
			<div class="respira-a11y-pricing-amount">€49<span>/month</span></div>
			<div class="respira-a11y-pricing-includes"><?php esc_html_e( 'Includes Respira Core', 'respira-for-wordpress' ); ?></div>
			<div class="respira-a11y-pricing-note"><?php esc_html_e( 'Already own Core? Upgrade for €20/month.', 'respira-for-wordpress' ); ?></div>
			<a
				href="https://respira.press/pricing"
				target="_blank"
				rel="noopener noreferrer"
				class="respira-a11y-pricing-btn"
			>
				<?php esc_html_e( 'Get Accessibility Add-on →', 'respira-for-wordpress' ); ?>
			</a>
		</div>

		<!-- Free extension note -->
		<p class="respira-a11y-free-note">
			<?php
			printf(
				/* translators: %s: link to Chrome extension */
				esc_html__( 'Already using the free scanner? %s to see your cloud reports.', 'respira-for-wordpress' ),
				'<a href="https://respira.press/dashboard/accessibility" target="_blank" rel="noopener noreferrer">'
				. esc_html__( 'View Dashboard', 'respira-for-wordpress' )
				. '</a>'
			);
			?>
		</p>
	</div>

	<!-- Free extension promo -->
	<div class="respira-card respira-a11y-promo-card">
		<div class="respira-a11y-promo-emoji" aria-hidden="true">🔍</div>
		<div class="respira-a11y-promo-body">
			<strong class="respira-a11y-promo-title">
				<?php esc_html_e( 'Free Chrome Extension available', 'respira-for-wordpress' ); ?>
			</strong>
			<p class="respira-a11y-promo-desc">
				<?php esc_html_e( 'Scan any Elementor page for free in your browser. Get AI fix prompts for Cursor and Claude.', 'respira-for-wordpress' ); ?>
			</p>
		</div>
		<a
			href="https://chromewebstore.google.com/search/Respira%20ADA%20WCAG%20Scanner"
			target="_blank"
			rel="noopener noreferrer"
			class="button button-secondary"
		>
			<?php esc_html_e( 'Install Free Extension', 'respira-for-wordpress' ); ?>
		</a>
	</div>

	<?php else : ?>
	<!-- ── Add-on Active: Full Dashboard ─────────────────────── -->

	<!-- KPI Row -->
	<div class="respira-a11y-kpi-grid">
		<?php
		$kpis = array(
			array(
				'label' => __( 'Last Scan Score', 'respira-for-wordpress' ),
				'value' => get_option( 'respira_accessibility_last_score', '–' ),
				'color' => '#10b981',
				'sub'   => __( 'out of 100', 'respira-for-wordpress' ),
			),
			array(
				'label' => __( 'Open Issues', 'respira-for-wordpress' ),
				'value' => $total_issues,
				'color' => $total_issues > 0 ? '#ef4444' : '#10b981',
				'sub'   => __( 'across all pages', 'respira-for-wordpress' ),
			),
			array(
				'label' => __( 'Auto-fixable', 'respira-for-wordpress' ),
				'value' => get_option( 'respira_accessibility_autofixable', '–' ),
				'color' => '#10b981',
				'sub'   => __( '~60% of issues', 'respira-for-wordpress' ),
			),
			array(
				'label' => __( 'Last Scanned', 'respira-for-wordpress' ),
				'value' => $last_scan_at ? wp_date( 'M j', strtotime( $last_scan_at ) ) : '–',
				'color' => '',
				'sub'   => $last_scan_at ? wp_date( 'g:i a', strtotime( $last_scan_at ) ) : __( 'Never', 'respira-for-wordpress' ),
			),
		);
		foreach ( $kpis as $kpi ) :
			$border_style = ! empty( $kpi['color'] ) ? 'border-left:4px solid ' . esc_attr( $kpi['color'] ) : '';
			?>
			<div class="respira-card" <?php echo $border_style ? 'style="' . $border_style . '"' : ''; ?>>
				<div class="respira-a11y-kpi-value" <?php echo ! empty( $kpi['color'] ) ? 'style="color:' . esc_attr( $kpi['color'] ) . '"' : ''; ?>>
					<?php echo esc_html( $kpi['value'] ); ?>
				</div>
				<div class="respira-a11y-kpi-label">
					<?php echo esc_html( $kpi['label'] ); ?>
				</div>
				<div class="respira-a11y-kpi-sub">
					<?php echo esc_html( $kpi['sub'] ); ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<!-- Standards bar -->
	<div class="respira-card respira-a11y-standards-bar">
		<span class="respira-a11y-standards-label"><?php esc_html_e( 'Standards:', 'respira-for-wordpress' ); ?></span>
		<?php foreach ( array( 'ADA Title III', 'WCAG 2.2 AA', 'Section 508', 'EAA 2025' ) as $std ) : ?>
			<span class="respira-a11y-standard-pill">
				✓ <?php echo esc_html( $std ); ?>
			</span>
		<?php endforeach; ?>
		<span class="respira-a11y-standards-powered">
			<?php esc_html_e( 'Powered by axe-core · ~57% automated detection', 'respira-for-wordpress' ); ?>
		</span>
	</div>

	<!-- Recent scans placeholder -->
	<div class="respira-card respira-a11y-scans-card">
		<div class="respira-a11y-scans-header">
			<h3><?php esc_html_e( 'Recent Scans', 'respira-for-wordpress' ); ?></h3>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=accessibility&action=new_scan' ) ); ?>" class="button button-primary respira-btn-primary respira-a11y-new-scan-btn">
				<?php esc_html_e( '+ New Scan', 'respira-for-wordpress' ); ?>
			</a>
		</div>

		<?php if ( empty( $recent_scans ) ) : ?>
			<div class="respira-a11y-empty-state">
				<div class="respira-a11y-empty-emoji" aria-hidden="true">🔍</div>
				<p><?php esc_html_e( 'No scans yet. Run your first scan to get started.', 'respira-for-wordpress' ); ?></p>
			</div>
		<?php else : ?>
			<table class="widefat respira-a11y-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Page', 'respira-for-wordpress' ); ?></th>
						<th><?php esc_html_e( 'Score', 'respira-for-wordpress' ); ?></th>
						<th><?php esc_html_e( 'Critical', 'respira-for-wordpress' ); ?></th>
						<th><?php esc_html_e( 'Total Issues', 'respira-for-wordpress' ); ?></th>
						<th><?php esc_html_e( 'Scanned', 'respira-for-wordpress' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $recent_scans as $scan ) : ?>
						<?php
						$scan_score      = (int) ( $scan['score'] ?? 0 );
						$score_css_class = $scan_score >= 80 ? 'respira-a11y-score-good' : ( $scan_score >= 50 ? 'respira-a11y-score-ok' : 'respira-a11y-score-bad' );
						?>
						<tr>
							<td><strong><?php echo esc_html( $scan['title'] ?? $scan['url'] ?? '' ); ?></strong></td>
							<td><strong class="<?php echo esc_attr( $score_css_class ); ?>"><?php echo esc_html( $scan['score'] ?? '–' ); ?></strong></td>
							<td><span class="respira-a11y-critical-count"><?php echo esc_html( $scan['critical_count'] ?? 0 ); ?></span></td>
							<td><?php echo esc_html( $scan['violation_count'] ?? 0 ); ?></td>
							<td><?php echo esc_html( isset( $scan['scanned_at'] ) ? wp_date( 'M j, Y', strtotime( $scan['scanned_at'] ) ) : '–' ); ?></td>
							<td>
								<?php $scan_id = sanitize_text_field( (string) ( $scan['id'] ?? '' ) ); ?>
								<?php if ( ! empty( $scan_id ) ) : ?>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=accessibility&action=view_report&scan_id=' . rawurlencode( $scan_id ) . '#respira-a11y-report' ) ); ?>" class="button button-small">
										<?php esc_html_e( 'View Details', 'respira-for-wordpress' ); ?>
									</a>
								<?php endif; ?>
								<?php if ( ! empty( $scan['report_url'] ) ) : ?>
									<a href="<?php echo esc_url( $scan['report_url'] ); ?>" class="button button-small">
										<?php esc_html_e( 'View Report', 'respira-for-wordpress' ); ?>
									</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<!-- AI Prompt Queue -->
	<div class="respira-card respira-a11y-section-card">
		<h3 class="respira-a11y-section-title"><?php esc_html_e( 'AI Fix Prompt Queue', 'respira-for-wordpress' ); ?></h3>
		<p class="respira-a11y-section-desc">
			<?php esc_html_e( 'Remaining violations that require AI assistance (Cursor, Claude, or Codex).', 'respira-for-wordpress' ); ?>
		</p>
		<?php if ( 0 === $queue_count ) : ?>
			<div class="respira-a11y-success-text">✓ <?php esc_html_e( 'No pending prompts in queue.', 'respira-for-wordpress' ); ?></div>
		<?php else : ?>
			<div class="respira-a11y-queue-row">
				<span class="respira-a11y-queue-count"><?php echo esc_html( $queue_count ); ?></span>
				<span class="respira-a11y-queue-label"><?php esc_html_e( 'prompts waiting', 'respira-for-wordpress' ); ?></span>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=accessibility&action=view_queue#respira-a11y-queue' ) ); ?>" class="button button-secondary respira-a11y-queue-view-btn">
					<?php esc_html_e( 'View Queue', 'respira-for-wordpress' ); ?>
				</a>
			</div>
		<?php endif; ?>
	</div>

	<?php if ( $show_report_panel ) : ?>
		<?php
		$selected_scan_title = (string) ( $selected_scan['title'] ?? $selected_scan['url'] ?? __( 'Untitled page', 'respira-for-wordpress' ) );
		$selected_scan_url   = (string) ( $selected_scan['url'] ?? '' );
		$selected_scan_id    = (string) ( $selected_scan['id'] ?? '' );
		$selected_scan_date  = ! empty( $selected_scan['scanned_at'] ) ? wp_date( 'M j, Y g:i a', strtotime( (string) $selected_scan['scanned_at'] ) ) : '';
		$selected_scan_score = isset( $selected_scan['score'] ) ? (int) $selected_scan['score'] : 0;
		$selected_scan_source = sanitize_text_field( (string) ( $selected_scan['scan_source'] ?? $selected_scan['scanSource'] ?? '' ) );
		?>
		<div id="respira-a11y-report" class="respira-card respira-a11y-section-card respira-a11y-mt">
			<div class="respira-a11y-report-header">
				<div>
					<h3 class="respira-a11y-report-title"><?php esc_html_e( 'Scan Report Details', 'respira-for-wordpress' ); ?></h3>
					<div class="respira-a11y-report-page-title"><?php echo esc_html( $selected_scan_title ); ?></div>
					<div class="respira-a11y-report-meta">
						<?php
						printf(
							/* translators: 1: score, 2: scan date */
							esc_html__( 'Score %1$d · Scanned %2$s', 'respira-for-wordpress' ),
							$selected_scan_score,
							$selected_scan_date ? $selected_scan_date : __( 'Unknown time', 'respira-for-wordpress' )
						);
						?>
						<?php if ( ! empty( $selected_scan_source ) ) : ?>
							· <?php echo esc_html( ucfirst( str_replace( '_', ' ', $selected_scan_source ) ) ); ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="respira-a11y-report-actions">
					<?php if ( ! empty( $selected_scan_url ) ) : ?>
						<a href="<?php echo esc_url( $selected_scan_url ); ?>" target="_blank" rel="noopener noreferrer" class="button button-secondary">
							<?php esc_html_e( 'Open Page', 'respira-for-wordpress' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( ! empty( $selected_scan_id ) ) : ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=accessibility&action=view_report&scan_id=' . rawurlencode( $selected_scan_id ) . '#respira-a11y-report' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Permalink', 'respira-for-wordpress' ); ?>
						</a>
					<?php endif; ?>
				</div>
			</div>

			<h4 class="respira-a11y-subsection-title"><?php esc_html_e( 'Detected Issues', 'respira-for-wordpress' ); ?></h4>
			<?php if ( empty( $selected_scan_violations ) ) : ?>
				<div class="respira-a11y-success-box">
					✓ <?php esc_html_e( 'No violations stored for this scan.', 'respira-for-wordpress' ); ?>
				</div>
			<?php else : ?>
				<table class="widefat respira-a11y-table-mb">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Rule', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Impact', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Nodes', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Example Selector', 'respira-for-wordpress' ); ?></th>
							<th><?php esc_html_e( 'Help', 'respira-for-wordpress' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $selected_scan_violations as $violation ) : ?>
							<?php
							$rule_id       = sanitize_text_field( (string) ( $violation['id'] ?? '' ) );
							$impact        = sanitize_key( (string) ( $violation['impact'] ?? 'minor' ) );
							$impact_color  = $severity_colors[ $impact ] ?? '#a7b4c9';
							$node_count    = isset( $violation['nodes'] ) && is_array( $violation['nodes'] ) ? count( $violation['nodes'] ) : 0;
							$selector      = $resolve_violation_selector( $violation );
							$help_label    = sanitize_text_field( (string) ( $violation['help'] ?? '' ) );
							$help_url      = esc_url_raw( (string) ( $violation['helpUrl'] ?? '' ) );
							?>
							<tr>
								<td><code><?php echo esc_html( $rule_id ?: 'unknown' ); ?></code></td>
								<td>
									<span class="respira-a11y-severity-badge" style="color:<?php echo esc_attr( $impact_color ); ?>">
										<?php echo esc_html( $impact ?: 'minor' ); ?>
									</span>
								</td>
								<td><?php echo esc_html( $node_count ); ?></td>
								<td>
									<?php if ( ! empty( $selector ) ) : ?>
										<code><?php echo esc_html( $selector ); ?></code>
									<?php else : ?>
										<span class="respira-a11y-muted-dash">—</span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( ! empty( $help_label ) ) : ?>
										<div class="respira-a11y-help-text"><?php echo esc_html( $help_label ); ?></div>
									<?php endif; ?>
									<?php if ( ! empty( $help_url ) ) : ?>
										<a href="<?php echo esc_url( $help_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'WCAG reference', 'respira-for-wordpress' ); ?></a>
									<?php elseif ( empty( $help_label ) ) : ?>
										<span class="respira-a11y-muted-dash">—</span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<h4 class="respira-a11y-subsection-title"><?php esc_html_e( 'Fixing Prompts (Respira MCP)', 'respira-for-wordpress' ); ?></h4>
			<?php if ( empty( $selected_scan_prompts ) ) : ?>
				<div class="respira-a11y-no-data-box">
					<?php esc_html_e( 'No prompts were stored for this scan.', 'respira-for-wordpress' ); ?>
				</div>
			<?php else : ?>
				<div class="respira-a11y-prompt-grid">
					<?php foreach ( $selected_scan_prompts as $prompt_index => $prompt_item ) : ?>
						<?php
						if ( ! is_array( $prompt_item ) || empty( $prompt_item['prompt'] ) ) {
							continue;
						}
						$prompt_title    = sanitize_text_field( (string) ( $prompt_item['title'] ?? __( 'Accessibility fix prompt', 'respira-for-wordpress' ) ) );
						$prompt_severity = sanitize_key( (string) ( $prompt_item['severity'] ?? 'moderate' ) );
						$prompt_wcag     = sanitize_text_field( (string) ( $prompt_item['wcag'] ?? '' ) );
						$prompt_rule     = sanitize_key( (string) ( $prompt_item['ruleId'] ?? $prompt_item['rule_id'] ?? '' ) );
						$prompt_text     = (string) $prompt_item['prompt'];
						$prompt_area_id  = 'respira-selected-prompt-' . (int) $prompt_index;
						?>
						<div class="respira-a11y-prompt-card">
							<div class="respira-a11y-prompt-header">
								<div class="respira-a11y-prompt-title"><?php echo esc_html( $prompt_title ); ?></div>
								<div class="respira-a11y-prompt-badges">
									<?php if ( ! empty( $prompt_rule ) ) : ?>
										<span class="respira-a11y-rule-badge"><code><?php echo esc_html( $prompt_rule ); ?></code></span>
									<?php endif; ?>
									<span class="respira-a11y-severity-text" style="color:<?php echo esc_attr( $severity_colors[ $prompt_severity ] ?? '#a7b4c9' ); ?>"><?php echo esc_html( strtoupper( $prompt_severity ) ); ?></span>
								</div>
							</div>
							<?php if ( ! empty( $prompt_wcag ) ) : ?>
								<div class="respira-a11y-wcag-note"><?php echo esc_html( $prompt_wcag ); ?></div>
							<?php endif; ?>
							<textarea id="<?php echo esc_attr( $prompt_area_id ); ?>" readonly><?php echo esc_textarea( $prompt_text ); ?></textarea>
							<div class="respira-a11y-prompt-actions">
								<button
									type="button"
									class="button button-secondary"
									data-respira-copy-target="<?php echo esc_attr( $prompt_area_id ); ?>"
									data-copy-label="<?php echo esc_attr__( 'Copy Prompt', 'respira-for-wordpress' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Copied!', 'respira-for-wordpress' ); ?>"
								>
									<?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?>
								</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( $show_queue_panel ) : ?>
		<div id="respira-a11y-queue" class="respira-card respira-a11y-section-card respira-a11y-mt">
			<h3 class="respira-a11y-section-title-sm"><?php esc_html_e( 'Prompt Queue Details', 'respira-for-wordpress' ); ?></h3>
			<p class="respira-a11y-section-desc-sm">
				<?php esc_html_e( 'All queued fixing prompts across recent scans. Copy a prompt into Cursor, Claude, or Codex.', 'respira-for-wordpress' ); ?>
			</p>
			<?php if ( empty( $all_prompt_items ) ) : ?>
				<div class="respira-a11y-success-box">
					✓ <?php esc_html_e( 'Prompt queue is empty.', 'respira-for-wordpress' ); ?>
				</div>
			<?php else : ?>
				<div class="respira-a11y-prompt-grid">
					<?php foreach ( $all_prompt_items as $queue_index => $queue_prompt ) : ?>
						<?php
						$queue_area_id = 'respira-queue-prompt-' . (int) $queue_index;
						$scan_permalink = '';
						if ( ! empty( $queue_prompt['scan_id'] ) ) {
							$scan_permalink = admin_url( 'admin.php?page=respira-reports&tab=accessibility&action=view_report&scan_id=' . rawurlencode( $queue_prompt['scan_id'] ) . '#respira-a11y-report' );
						}
						?>
						<div class="respira-a11y-prompt-card">
							<div class="respira-a11y-prompt-header-start">
								<div>
									<div class="respira-a11y-prompt-title"><?php echo esc_html( $queue_prompt['title'] ); ?></div>
									<div class="respira-a11y-scan-meta">
										<?php echo esc_html( $queue_prompt['scan_title'] ); ?>
										<?php if ( ! empty( $queue_prompt['scanned_at'] ) ) : ?>
											· <?php echo esc_html( wp_date( 'M j, Y g:i a', strtotime( $queue_prompt['scanned_at'] ) ) ); ?>
										<?php endif; ?>
									</div>
								</div>
								<div class="respira-a11y-prompt-badges">
									<?php if ( ! empty( $queue_prompt['rule_id'] ) ) : ?>
										<span class="respira-a11y-rule-badge"><code><?php echo esc_html( $queue_prompt['rule_id'] ); ?></code></span>
									<?php endif; ?>
									<span class="respira-a11y-severity-text" style="color:<?php echo esc_attr( $severity_colors[ $queue_prompt['severity'] ] ?? '#a7b4c9' ); ?>"><?php echo esc_html( strtoupper( $queue_prompt['severity'] ) ); ?></span>
									<?php if ( ! empty( $scan_permalink ) ) : ?>
										<a href="<?php echo esc_url( $scan_permalink ); ?>" class="button button-small">
											<?php esc_html_e( 'Open Scan', 'respira-for-wordpress' ); ?>
										</a>
									<?php endif; ?>
								</div>
							</div>
							<?php if ( ! empty( $queue_prompt['wcag'] ) ) : ?>
								<div class="respira-a11y-wcag-note"><?php echo esc_html( $queue_prompt['wcag'] ); ?></div>
							<?php endif; ?>
							<textarea id="<?php echo esc_attr( $queue_area_id ); ?>" readonly><?php echo esc_textarea( $queue_prompt['prompt'] ); ?></textarea>
							<div class="respira-a11y-prompt-actions">
								<button
									type="button"
									class="button button-secondary"
									data-respira-copy-target="<?php echo esc_attr( $queue_area_id ); ?>"
									data-copy-label="<?php echo esc_attr__( 'Copy Prompt', 'respira-for-wordpress' ); ?>"
									data-copied-label="<?php echo esc_attr__( 'Copied!', 'respira-for-wordpress' ); ?>"
								>
									<?php esc_html_e( 'Copy Prompt', 'respira-for-wordpress' ); ?>
								</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php endif; // end $addon_active ?>

	<!-- Disclaimer -->
	<div class="respira-a11y-disclaimer">
		<?php
		esc_html_e(
			'⚠️ Automated accessibility testing detects approximately 57% of WCAG violations. '
			. 'Full ADA compliance requires manual testing with assistive technologies (NVDA, JAWS, VoiceOver). '
			. 'This tool does NOT guarantee ADA compliance or legal protection.',
			'respira-for-wordpress'
		);
		?>
	</div>

</div>
<?php
if ( ! $respira_embed ) {
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
	require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
}
