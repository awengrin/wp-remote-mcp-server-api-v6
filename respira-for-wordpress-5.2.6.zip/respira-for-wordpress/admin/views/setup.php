<?php
/**
 * Setup IA page — guided stepper.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --- Step definitions -------------------------------------------------------

$steps = array(
	'license'      => array(
		'label' => __( 'License', 'respira-for-wordpress' ),
		'desc'  => __( 'Activate your license key', 'respira-for-wordpress' ),
		'time'  => __( '1 min', 'respira-for-wordpress' ),
	),
	'api-keys'     => array(
		'label' => __( 'API Keys', 'respira-for-wordpress' ),
		'desc'  => __( 'Generate an API key for MCP clients', 'respira-for-wordpress' ),
		'time'  => __( '30 sec', 'respira-for-wordpress' ),
	),
	'mcp'          => array(
		'label' => __( 'MCP Connection', 'respira-for-wordpress' ),
		'desc'  => __( 'Connect Cursor, Claude Code, or Codex', 'respira-for-wordpress' ),
		'time'  => __( '2 min', 'respira-for-wordpress' ),
	),
	'intelligence' => array(
		'label' => __( 'Builder Intelligence', 'respira-for-wordpress' ),
		'desc'  => __( 'Review detected builders and AI capabilities', 'respira-for-wordpress' ),
		'time'  => __( '1 min', 'respira-for-wordpress' ),
	),
	'prompts'      => array(
		'label' => __( 'Prompt Library', 'respira-for-wordpress' ),
		'desc'  => __( 'Browse ready-to-use prompts for your builder', 'respira-for-wordpress' ),
		'time'  => __( '2 min', 'respira-for-wordpress' ),
	),
	'permissions'  => array(
		'label' => __( 'Health & Permissions', 'respira-for-wordpress' ),
		'desc'  => __( 'Verify safety controls and site health', 'respira-for-wordpress' ),
		'time'  => __( '1 min', 'respira-for-wordpress' ),
	),
);

$step_slugs = array_keys( $steps );

$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'license';
if ( ! isset( $steps[ $active_tab ] ) ) {
	$active_tab = 'license';
}

$active_index = array_search( $active_tab, $step_slugs, true );

// --- Completion detection ---------------------------------------------------

$license_info = Respira_License::get_license_info();
$is_licensed  = ! empty( $license_info['is_pro'] ) || in_array( (string) ( $license_info['status'] ?? '' ), array( 'active', 'trial' ), true );
$user_keys    = Respira_Auth::get_user_keys( get_current_user_id() );
$has_keys     = ! empty( $user_keys );

$step_complete = array(
	'license'      => $is_licensed,
	'api-keys'     => $has_keys,
	'mcp'          => $is_licensed && $has_keys, // Both needed to connect.
	'intelligence' => true, // Read-only — always "done".
	'prompts'      => true, // Read-only — always "done".
	'permissions'  => true, // Read-only — always "done".
);

$completed_count = 0;
foreach ( $step_complete as $done ) {
	if ( $done ) {
		++$completed_count;
	}
}
$total_steps      = count( $steps );
$progress_percent = (int) round( ( $completed_count / $total_steps ) * 100 );

// --- Navigation helpers -----------------------------------------------------

$prev_slug = $active_index > 0 ? $step_slugs[ $active_index - 1 ] : null;
$next_slug = $active_index < $total_steps - 1 ? $step_slugs[ $active_index + 1 ] : null;

// --- Render -----------------------------------------------------------------

$respira_screen = 'respira-setup';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
?>
<div class="respira-page-body">
	<div class="respira-page-headline">
		<h2><?php esc_html_e( 'Setup', 'respira-for-wordpress' ); ?></h2>
		<p><?php esc_html_e( 'Configure connection, permissions, and AI-ready workflows.', 'respira-for-wordpress' ); ?>
			<span class="respira-setup-time-hint"><?php esc_html_e( 'Takes about 5-8 minutes.', 'respira-for-wordpress' ); ?></span>
		</p>
	</div>
	<?php settings_errors( 'respira_messages' ); ?>

	<!-- Progress bar -->
	<div class="respira-setup-progress">
		<div class="respira-setup-progress-header">
			<span class="respira-setup-progress-label">
				<?php
				printf(
					/* translators: 1: completed count, 2: total steps. */
					esc_html__( '%1$d of %2$d steps completed', 'respira-for-wordpress' ),
					$completed_count,
					$total_steps
				);
				?>
			</span>
			<span class="respira-setup-progress-pct"><?php echo esc_html( $progress_percent . '%' ); ?></span>
		</div>
		<div class="respira-setup-progress-track">
			<div class="respira-setup-progress-fill" style="width:<?php echo esc_attr( $progress_percent ); ?>%"></div>
		</div>
	</div>

	<!-- Step nav -->
	<nav class="respira-setup-stepper" aria-label="<?php esc_attr_e( 'Setup steps', 'respira-for-wordpress' ); ?>">
		<?php
		$step_num = 0;
		foreach ( $steps as $slug => $step ) :
			++$step_num;
			$is_current = ( $slug === $active_tab );
			$is_done    = $step_complete[ $slug ];

			$classes = 'respira-step';
			if ( $is_current ) {
				$classes .= ' is-current';
			}
			if ( $is_done ) {
				$classes .= ' is-done';
			}

			$href = admin_url( 'admin.php?page=respira-setup&tab=' . $slug );
			?>
			<a class="<?php echo esc_attr( $classes ); ?>" href="<?php echo esc_url( $href ); ?>" <?php echo $is_current ? 'aria-current="step"' : ''; ?>>
				<span class="respira-step-number">
					<?php if ( $is_done && ! $is_current ) : ?>
						<span class="dashicons dashicons-yes-alt"></span>
					<?php else : ?>
						<?php echo esc_html( (string) $step_num ); ?>
					<?php endif; ?>
				</span>
				<span class="respira-step-text">
					<span class="respira-step-label"><?php echo esc_html( $step['label'] ); ?></span>
					<span class="respira-step-desc"><?php echo esc_html( $step['desc'] ); ?></span>
				</span>
				<span class="respira-step-time"><?php echo esc_html( $step['time'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>

	<!-- Tab content -->
	<div class="respira-tab-panel" data-respira-tab="<?php echo esc_attr( $active_tab ); ?>">
		<?php
		switch ( $active_tab ) {
			case 'license':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/license.php';
				break;
			case 'api-keys':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/api-keys.php';
				break;
			case 'intelligence':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/intelligence.php';
				break;
			case 'prompts':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/prompts.php';
				break;
			case 'permissions':
				require RESPIRA_PLUGIN_DIR . 'admin/views/setup-permissions.php';
				break;
			case 'mcp':
			default:
				$context        = Respira_Context::get_site_info();
				$wordpress_url  = untrailingslashit( home_url() );
				$endpoint_v1    = rest_url( defined( 'RESPIRA_REST_NAMESPACE_V1' ) ? RESPIRA_REST_NAMESPACE_V1 : 'respira/v1' );
				$endpoint_v2    = rest_url( defined( 'RESPIRA_REST_NAMESPACE_V2' ) ? RESPIRA_REST_NAMESPACE_V2 : 'respira/v2' );
				$status_v2      = untrailingslashit( $endpoint_v2 ) . '/status';
				$api_key_notice = $is_licensed ? __( 'Generate an API key in the API Keys tab before connecting MCP clients.', 'respira-for-wordpress' ) : __( 'Activate your license and then generate an API key to connect MCP clients.', 'respira-for-wordpress' );
				?>
				<div class="respira-card">
					<h3><?php esc_html_e( 'MCP Connection', 'respira-for-wordpress' ); ?></h3>
					<p><?php esc_html_e( 'Use these values when connecting Cursor, Codex, Claude, or WebMCP clients.', 'respira-for-wordpress' ); ?></p>
					<div class="respira-stack">
						<div class="respira-inline-code"><code><?php echo esc_html( $wordpress_url ); ?></code><button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $wordpress_url ); ?>"><?php esc_html_e( 'Copy site URL', 'respira-for-wordpress' ); ?></button></div>
						<div class="respira-inline-code"><code><?php echo esc_html( $endpoint_v2 ); ?></code><button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $endpoint_v2 ); ?>"><?php esc_html_e( 'Copy API URL (v2)', 'respira-for-wordpress' ); ?></button></div>
						<div class="respira-inline-code"><code><?php echo esc_html( $endpoint_v1 ); ?></code><button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $endpoint_v1 ); ?>"><?php esc_html_e( 'Copy API URL (v1)', 'respira-for-wordpress' ); ?></button></div>
						<div class="respira-inline-code"><code><?php echo esc_html( $status_v2 ); ?></code><button type="button" class="button button-small respira-copy-btn" data-copy="<?php echo esc_attr( $status_v2 ); ?>"><?php esc_html_e( 'Copy v2 status URL', 'respira-for-wordpress' ); ?></button></div>
						<div class="respira-inline-code"><code>npx @respira/wordpress-mcp-server --setup</code><button type="button" class="button button-small respira-copy-btn" data-copy="npx @respira/wordpress-mcp-server --setup"><?php esc_html_e( 'Copy command', 'respira-for-wordpress' ); ?></button></div>
					</div>
					<p class="description"><?php esc_html_e( 'v2 is preferred. Current MCP clients auto-negotiate v2 and fall back to v1 when needed.', 'respira-for-wordpress' ); ?></p>
					<p class="description"><?php echo esc_html( $api_key_notice ); ?></p>
					<p>
						<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=api-keys' ) ); ?>"><?php esc_html_e( 'Open API Keys', 'respira-for-wordpress' ); ?></a>
						<a class="button button-secondary" href="https://respira.press/installation" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Installation guide', 'respira-for-wordpress' ); ?></a>
					</p>
				</div>
				<div class="respira-card">
					<h3><?php esc_html_e( 'Health Snapshot', 'respira-for-wordpress' ); ?></h3>
					<table class="widefat striped respira-table-lite">
						<tbody>
							<tr><th><?php esc_html_e( 'Site', 'respira-for-wordpress' ); ?></th><td><?php echo esc_html( (string) ( $context['site_name'] ?? get_bloginfo( 'name' ) ) ); ?></td></tr>
							<tr><th><?php esc_html_e( 'WordPress', 'respira-for-wordpress' ); ?></th><td><?php echo esc_html( (string) ( $context['wordpress_version'] ?? get_bloginfo( 'version' ) ) ); ?></td></tr>
							<tr><th><?php esc_html_e( 'PHP', 'respira-for-wordpress' ); ?></th><td><?php echo esc_html( (string) ( $context['php_version'] ?? PHP_VERSION ) ); ?></td></tr>
							<tr><th><?php esc_html_e( 'License', 'respira-for-wordpress' ); ?></th><td><?php echo esc_html( strtoupper( (string) ( $license_info['status'] ?? 'inactive' ) ) ); ?></td></tr>
						</tbody>
					</table>
				</div>
				<?php
				break;
		}
		?>
	</div>

	<!-- Step navigation (previous / next) -->
	<div class="respira-setup-nav">
		<?php if ( $prev_slug ) : ?>
			<a class="button button-secondary respira-setup-nav-prev" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=' . $prev_slug ) ); ?>">
				<span class="dashicons dashicons-arrow-left-alt2"></span>
				<?php echo esc_html( $steps[ $prev_slug ]['label'] ); ?>
			</a>
		<?php else : ?>
			<span></span>
		<?php endif; ?>

		<span class="respira-setup-nav-position">
			<?php
			printf(
				/* translators: 1: current step, 2: total steps. */
				esc_html__( 'Step %1$d of %2$d', 'respira-for-wordpress' ),
				$active_index + 1,
				$total_steps
			);
			?>
		</span>

		<?php if ( $next_slug ) : ?>
			<a class="button button-primary respira-setup-nav-next" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-setup&tab=' . $next_slug ) ); ?>">
				<?php echo esc_html( $steps[ $next_slug ]['label'] ); ?>
				<span class="dashicons dashicons-arrow-right-alt2"></span>
			</a>
		<?php else : ?>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-for-wordpress' ) ); ?>">
				<?php esc_html_e( 'Go to Dashboard', 'respira-for-wordpress' ); ?>
				<span class="dashicons dashicons-arrow-right-alt2"></span>
			</a>
		<?php endif; ?>
	</div>
</div>
<?php
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
