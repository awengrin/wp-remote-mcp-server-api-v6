<?php
/**
 * Reports IA page.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tabs = array(
	'accessibility' => __( 'Accessibility', 'respira-for-wordpress' ),
	'divi'          => __( 'Divi Migration', 'respira-for-wordpress' ),
	'intelligence'  => __( 'Intelligence Summary', 'respira-for-wordpress' ),
);

$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'accessibility';
if ( ! isset( $tabs[ $active_tab ] ) ) {
	$active_tab = 'accessibility';
}

$respira_screen = 'respira-reports';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-start.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/header.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-subnav.php';
?>
<div class="respira-page-body">
	<div class="respira-page-headline">
		<h2><?php esc_html_e( 'Reports', 'respira-for-wordpress' ); ?></h2>
		<p><?php esc_html_e( 'Audits, migration planning, and builder intelligence insights.', 'respira-for-wordpress' ); ?></p>
	</div>

	<nav class="respira-tabs" aria-label="<?php esc_attr_e( 'Reports tabs', 'respira-for-wordpress' ); ?>">
		<?php foreach ( $tabs as $slug => $label ) : ?>
			<a class="respira-tab-link<?php echo $slug === $active_tab ? ' is-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=respira-reports&tab=' . $slug ) ); ?>" <?php echo $slug === $active_tab ? 'aria-current="page"' : ''; ?>>
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<div class="respira-tab-panel" data-respira-tab="<?php echo esc_attr( $active_tab ); ?>">
		<?php
		switch ( $active_tab ) {
			case 'divi':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/divi-migration-copilot.php';
				break;
			case 'intelligence':
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/intelligence.php';
				break;
			case 'accessibility':
			default:
				$respira_embed = true;
				require RESPIRA_PLUGIN_DIR . 'admin/views/accessibility.php';
				break;
		}
		?>
	</div>
</div>
<?php
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/footer.php';
require RESPIRA_PLUGIN_DIR . 'admin/views/partials/admin-shell-end.php';
