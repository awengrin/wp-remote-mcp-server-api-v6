<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * @since 1.0.0
 */
class Respira_Admin {
	/**
	 * User meta key used to persist dismissal for the skills announcement.
	 *
	 * @since 4.0.9
	 * @var string
	 */
	private const SKILLS_NOTICE_DISMISSED_META_KEY = 'respira_skills_notice_dismissed_20260309';

	/**
	 * User meta key used to persist dismissal for the v5.2.0 What's New notice.
	 *
	 * @since 5.2.0
	 * @var string
	 */
	private const WHATS_NEW_520_DISMISSED_META_KEY = 'respira_dismissed_whats_new_520';

	/**
	 * User meta key for per-user approval count used by testimonial milestones.
	 *
	 * @since 4.0.12
	 * @var string
	 */
	private const TESTIMONIAL_APPROVAL_COUNT_META_KEY = 'respira_testimonial_approval_count';

	/**
	 * User meta key for milestones where testimonial prompt was already shown.
	 *
	 * @since 4.0.12
	 * @var string
	 */
	private const TESTIMONIAL_PROMPT_SHOWN_META_KEY = 'respira_testimonial_prompt_shown_milestones';

	/**
	 * User meta key that marks testimonial submission.
	 *
	 * @since 4.0.12
	 * @var string
	 */
	private const TESTIMONIAL_SUBMITTED_META_KEY = 'respira_testimonial_submitted_at';

	/**
	 * Approval milestones that should trigger testimonial prompt.
	 *
	 * @since 4.0.12
	 * @var array<int,int>
	 */
	private const TESTIMONIAL_PROMPT_MILESTONES = array( 3, 10 );


	/**
	 * The ID of this plugin.
	 *
	 * @since  1.0.0
	 * @access private
	 * @var    string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since  1.0.0
	 * @access private
	 * @var    string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 1.0.0
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version     The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/**
	 * Respira wp-admin pages managed by this plugin.
	 *
	 * @since 3.3.0
	 * @return array<int,string>
	 */
	private function get_respira_admin_pages() {
		return array(
			'respira-for-wordpress',
			'respira-setup',
			'respira-changes',
			'respira-reports',
			'respira-addons',
			'respira-audit-log',
			'respira-settings',
		);
	}

	/**
	 * Legacy page slug mapping to new IA pages.
	 *
	 * @since 3.3.0
	 * @return array<string,array<string,string>>
	 */
	private function get_legacy_page_redirect_map() {
		return array(
			'respira-license'               => array(
				'page' => 'respira-setup',
				'tab'  => 'license',
			),
			'respira-api-keys'              => array(
				'page' => 'respira-setup',
				'tab'  => 'api-keys',
			),
			'respira-intelligence'          => array(
				'page' => 'respira-setup',
				'tab'  => 'intelligence',
			),
			'respira-prompts'               => array(
				'page' => 'respira-setup',
				'tab'  => 'prompts',
			),
			'respira-divi-migration-copilot' => array(
				'page' => 'respira-reports',
				'tab'  => 'divi',
			),
			'respira-accessibility'         => array(
				'page' => 'respira-reports',
				'tab'  => 'accessibility',
			),
			'respira-approvals'             => array(
				'page' => 'respira-changes',
				'tab'  => '',
			),
			'respira-snapshots'             => array(
				'page' => 'respira-changes',
				'tab'  => '',
			),
		);
	}

	/**
	 * Redirect legacy menu slugs to IA routes.
	 *
	 * @since 3.3.0
	 * @return void
	 */
	public function maybe_redirect_legacy_admin_pages() {
		if ( ! is_admin() || wp_doing_ajax() ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( '' === $page ) {
			return;
		}

		$redirect_map = $this->get_legacy_page_redirect_map();
		if ( ! isset( $redirect_map[ $page ] ) ) {
			return;
		}

		$target = $redirect_map[ $page ];
		$args   = array(
			'page' => $target['page'],
			'tab'  => $target['tab'],
		);

		foreach ( array( 'action', 'scan_id', 'paged', 'post_type' ) as $query_key ) {
			if ( isset( $_GET[ $query_key ] ) ) {
				$args[ $query_key ] = sanitize_text_field( wp_unslash( $_GET[ $query_key ] ) );
			}
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Determine whether current wp-admin page belongs to Respira plugin.
	 *
	 * @since 2.3.0
	 * @return bool
	 */
	private function is_respira_admin_page() {
		return $this->is_respira_admin_screen();
	}

	/**
	 * Determine whether current wp-admin request is a Respira screen.
	 *
	 * @since 3.3.0
	 * @param string $hook_suffix Optional hook suffix from admin_enqueue_scripts.
	 * @return bool
	 */
	private function is_respira_admin_screen( $hook_suffix = '' ) {
		if ( ! is_admin() ) {
			return false;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( '' !== $page ) {
			$known_pages = array_merge(
				$this->get_respira_admin_pages(),
				array_keys( $this->get_legacy_page_redirect_map() )
			);
			if ( in_array( $page, $known_pages, true ) ) {
				return true;
			}
		}

		if ( ! empty( $hook_suffix ) && false !== strpos( (string) $hook_suffix, 'respira' ) ) {
			return true;
		}

		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen && ! empty( $screen->id ) && false !== strpos( (string) $screen->id, 'respira' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Remove third-party plugin notices from Respira admin pages.
	 *
	 * Keeps Respira-owned notices and WordPress core notices, while removing
	 * notices injected by other plugins that pollute the Respira header area.
	 *
	 * @since 2.0.18
	 * @return void
	 */
	public function suppress_third_party_admin_notices() {
		if ( ! $this->is_respira_admin_page() ) {
			return;
		}

		$this->filter_notice_hook_callbacks( 'admin_notices' );
		$this->filter_notice_hook_callbacks( 'all_admin_notices' );
		$this->filter_notice_hook_callbacks( 'network_admin_notices' );
	}

	/**
	 * Remove non-Respira plugin callbacks from a notice hook.
	 *
	 * @since 2.0.18
	 * @param string $hook_name Hook name to filter.
	 * @return void
	 */
	private function filter_notice_hook_callbacks( $hook_name ) {
		global $wp_filter;

		if ( ! isset( $wp_filter[ $hook_name ] ) || ! is_object( $wp_filter[ $hook_name ] ) ) {
			return;
		}

		$hook = $wp_filter[ $hook_name ];
		if ( empty( $hook->callbacks ) || ! is_array( $hook->callbacks ) ) {
			return;
		}

		foreach ( $hook->callbacks as $priority => $callbacks ) {
			if ( empty( $callbacks ) || ! is_array( $callbacks ) ) {
				continue;
			}

			foreach ( $callbacks as $callback_data ) {
				if ( empty( $callback_data['function'] ) ) {
					continue;
				}

				$callback = $callback_data['function'];
				if ( $this->should_remove_notice_callback( $callback ) ) {
					remove_action( $hook_name, $callback, $priority );
				}
			}
		}
	}

	/**
	 * Determine whether a notice callback should be removed.
	 *
	 * @since 2.0.18
	 * @param callable $callback Notice callback.
	 * @return bool True when callback belongs to a third-party plugin.
	 */
	private function should_remove_notice_callback( $callback ) {
		if ( $this->is_respira_callback( $callback ) ) {
			return false;
		}

		$callback_file = $this->resolve_callback_file( $callback );
		if ( empty( $callback_file ) ) {
			// If we cannot resolve origin, keep it to avoid removing core notices accidentally.
			return false;
		}

		$callback_file = wp_normalize_path( $callback_file );
		$respira_dir   = wp_normalize_path( RESPIRA_PLUGIN_DIR );

		// Always keep Respira notices.
		if ( 0 === strpos( $callback_file, $respira_dir ) ) {
			return false;
		}

		$plugin_dir = wp_normalize_path( WP_PLUGIN_DIR );
		if ( 0 === strpos( $callback_file, $plugin_dir . '/' ) ) {
			return true;
		}

		if ( defined( 'WPMU_PLUGIN_DIR' ) ) {
			$mu_plugin_dir = wp_normalize_path( WPMU_PLUGIN_DIR );
			if ( 0 === strpos( $callback_file, $mu_plugin_dir . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether callback belongs to Respira by name/class.
	 *
	 * @since 2.0.18
	 * @param callable $callback Notice callback.
	 * @return bool
	 */
	private function is_respira_callback( $callback ) {
		if ( is_string( $callback ) ) {
			return false !== stripos( $callback, 'respira' );
		}

		if ( is_array( $callback ) ) {
			$target = $callback[0] ?? null;
			$method = $callback[1] ?? '';

			if ( is_string( $method ) && false !== stripos( $method, 'respira' ) ) {
				return true;
			}

			if ( is_object( $target ) ) {
				return false !== stripos( get_class( $target ), 'respira' );
			}

			if ( is_string( $target ) ) {
				return false !== stripos( $target, 'respira' );
			}
		}

		return false;
	}

	/**
	 * Resolve callback source file path via reflection.
	 *
	 * @since 2.0.18
	 * @param callable $callback Callback to inspect.
	 * @return string Source file path or empty string.
	 */
	private function resolve_callback_file( $callback ) {
		try {
			if ( $callback instanceof Closure ) {
				$reflection = new ReflectionFunction( $callback );
				return (string) $reflection->getFileName();
			}

			if ( is_string( $callback ) && function_exists( $callback ) ) {
				$reflection = new ReflectionFunction( $callback );
				return (string) $reflection->getFileName();
			}

			if ( is_array( $callback ) && isset( $callback[0], $callback[1] ) ) {
				$target = $callback[0];
				$method = $callback[1];

				if ( is_object( $target ) && method_exists( $target, $method ) ) {
					$reflection = new ReflectionMethod( $target, $method );
					return (string) $reflection->getFileName();
				}

				if ( is_string( $target ) && method_exists( $target, $method ) ) {
					$reflection = new ReflectionMethod( $target, $method );
					return (string) $reflection->getFileName();
				}
			}
		} catch ( Exception $e ) {
			return '';
		}

		return '';
	}

	/**
	 * Hide default WordPress footer text on Respira admin pages.
	 *
	 * @since 2.3.0
	 * @param string $footer_text Existing footer text.
	 * @return string
	 */
	public function filter_admin_footer_text( $footer_text ) {
		if ( $this->is_respira_admin_page() ) {
			return '';
		}

		return $footer_text;
	}

	/**
	 * Hide default WordPress version footer on Respira admin pages.
	 *
	 * @since 2.3.0
	 * @param string $footer_text Existing footer text.
	 * @return string
	 */
	public function filter_update_footer( $footer_text ) {
		if ( $this->is_respira_admin_page() ) {
			return '';
		}

		return $footer_text;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_styles( $hook_suffix = '' ) {
		if ( ! $this->is_respira_admin_screen( (string) $hook_suffix ) ) {
			return;
		}

		$files = array(
			'base'       => RESPIRA_PLUGIN_DIR . 'admin/assets/css/respira-admin-base.css',
			'components' => RESPIRA_PLUGIN_DIR . 'admin/assets/css/respira-admin-components.css',
			'pages'      => RESPIRA_PLUGIN_DIR . 'admin/assets/css/respira-admin-pages.css',
		);

		$deps = array();
		wp_enqueue_style(
			$this->plugin_name . '-fonts',
			'https://fonts.googleapis.com/css2?family=Alan+Sans:wght@400;500;600;700&family=Baskervville:ital@0;1&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap',
			array(),
			null
		);
		$deps[] = $this->plugin_name . '-fonts';

		foreach ( $files as $key => $path ) {
			$handle  = $this->plugin_name . '-' . $key;
			$version = file_exists( $path ) ? (string) filemtime( $path ) : $this->version;
			wp_enqueue_style(
				$handle,
				RESPIRA_PLUGIN_URL . 'admin/assets/css/respira-admin-' . $key . '.css',
				$deps,
				$version,
				'all'
			);
			$deps[] = $handle;
		}
	}

	/**
	 * Register AJAX handlers (called on admin_init).
	 *
	 * @since 1.5.1
	 */
	public function register_ajax_handlers() {
		// One-time snapshot cleanup on version upgrade.
		$last_cleanup_ver = get_option( 'respira_snapshot_cleanup_version', '' );
		if ( $last_cleanup_ver !== RESPIRA_VERSION && class_exists( 'Respira_Snapshots' ) ) {
			Respira_Snapshots::get_instance()->cleanup_retention();
			update_option( 'respira_snapshot_cleanup_version', RESPIRA_VERSION, false );
		}

		// Register AJAX handlers - must be registered early, not in enqueue.
		add_action( 'wp_ajax_respira_approve_duplicate', array( $this, 'ajax_approve_duplicate' ) );
		add_action( 'wp_ajax_respira_bulk_approve_duplicates', array( $this, 'ajax_bulk_approve_duplicates' ) );
		add_action( 'wp_ajax_respira_reject_duplicate', array( $this, 'ajax_reject_duplicate' ) );
		add_action( 'wp_ajax_respira_submit_testimonial', array( $this, 'ajax_submit_testimonial' ) );
		add_action( 'wp_ajax_respira_update_plugin', array( $this, 'ajax_update_plugin' ) );
		add_action( 'wp_ajax_respira_dismiss_skills_notice', array( $this, 'ajax_dismiss_skills_notice' ) );
		add_action( 'wp_ajax_respira_dismiss_remote_notice', array( $this, 'ajax_dismiss_remote_notice' ) );
		add_action( 'wp_ajax_respira_install_skill', array( $this, 'ajax_install_skill' ) );

		// Changes page AJAX handlers.
		add_action( 'wp_ajax_respira_changes_list_posts', array( $this, 'ajax_changes_list_posts' ) );
		add_action( 'wp_ajax_respira_changes_post_detail', array( $this, 'ajax_changes_post_detail' ) );

		// Snapshots AJAX handlers (used by Changes page).
		add_action( 'wp_ajax_respira_list_snapshots', array( $this, 'ajax_list_snapshots' ) );
		add_action( 'wp_ajax_respira_preview_snapshot', array( $this, 'ajax_preview_snapshot' ) );
		add_action( 'wp_ajax_respira_visual_preview_snapshot', array( $this, 'ajax_visual_preview_snapshot' ) );
		add_action( 'wp_ajax_respira_restore_snapshot', array( $this, 'ajax_restore_snapshot' ) );
		add_action( 'wp_ajax_respira_pin_snapshot', array( $this, 'ajax_pin_snapshot' ) );
		add_action( 'wp_ajax_respira_snapshot_storage_stats', array( $this, 'ajax_snapshot_storage_stats' ) );
		add_action( 'wp_ajax_respira_purge_old_snapshots', array( $this, 'ajax_purge_old_snapshots' ) );
		add_action( 'wp_ajax_respira_delete_snapshots', array( $this, 'ajax_delete_snapshots' ) );
		add_action( 'wp_ajax_respira_delete_post_snapshots', array( $this, 'ajax_delete_post_snapshots' ) );
		add_action( 'wp_ajax_respira_purge_all_snapshots', array( $this, 'ajax_purge_all_snapshots' ) );
		add_action( 'wp_ajax_respira_search_posts', array( $this, 'ajax_search_posts' ) );
		add_action( 'wp_ajax_respira_dismiss_v5_notice', array( $this, 'ajax_dismiss_v5_notice' ) );
		add_action( 'wp_ajax_respira_dismiss_whats_new_520', array( $this, 'ajax_dismiss_whats_new_520' ) );
		add_action( 'wp_ajax_respira_save_setting', array( $this, 'ajax_save_setting' ) );
	}

	/**
	 * Render a one-time notification for newly published skills.
	 *
	 * @since 4.0.9
	 * @return void
	 */
	public function maybe_render_skills_published_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->is_respira_admin_page() ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		$is_dismissed = get_user_meta( $user_id, self::SKILLS_NOTICE_DISMISSED_META_KEY, true );
		if ( ! empty( $is_dismissed ) ) {
			return;
		}

		$skills_url = 'https://www.respira.press/skills';
		?>
		<div class="notice notice-success is-dismissible respira-skills-published-notice">
			<p><strong><?php esc_html_e( 'New: Respira WordPress Skills are live.', 'respira-for-wordpress' ); ?></strong></p>
			<p><?php esc_html_e( 'We published ready-to-run skills for audits, SEO/AEO, and image optimization. Open the skills directory to install and use them in your AI workflows.', 'respira-for-wordpress' ); ?></p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( $skills_url ); ?>" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Browse Skills', 'respira-for-wordpress' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Persist dismissal for the skills announcement notice.
	 *
	 * @since 4.0.9
	 * @return void
	 */
	public function ajax_dismiss_skills_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ),
				),
				403
			);
		}

		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'User context not found.', 'respira-for-wordpress' ),
				),
				400
			);
		}

		update_user_meta( $user_id, self::SKILLS_NOTICE_DISMISSED_META_KEY, gmdate( 'Y-m-d H:i:s' ) );
		wp_send_json_success(
			array(
				'message' => __( 'Notice dismissed.', 'respira-for-wordpress' ),
			)
		);
	}

	/**
	 * Persist dismissal for a remote plugin-header notice.
	 *
	 * @since 4.2.2
	 * @return void
	 */
	public function ajax_dismiss_remote_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ),
				),
				403
			);
		}

		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		$notice_key = isset( $_POST['notice'] ) ? sanitize_text_field( wp_unslash( $_POST['notice'] ) ) : '';
		if ( '' === $notice_key ) {
			wp_send_json_error(
				array(
					'message' => __( 'Notification not found.', 'respira-for-wordpress' ),
				),
				400
			);
		}

		if ( ! class_exists( 'Respira_Remote_Notifications' ) || ! Respira_Remote_Notifications::dismiss_notice_for_current_user( $notice_key ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Failed to dismiss notification.', 'respira-for-wordpress' ),
				),
				500
			);
		}

		wp_send_json_success(
			array(
				'message' => __( 'Notification dismissed.', 'respira-for-wordpress' ),
			)
		);
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts( $hook_suffix = '' ) {
		if ( ! $this->is_respira_admin_screen( (string) $hook_suffix ) ) {
			return;
		}

		$js_file  = RESPIRA_PLUGIN_DIR . 'admin/assets/js/respira-admin.js';
		$version  = file_exists( $js_file ) ? (string) filemtime( $js_file ) : $this->version;
		wp_enqueue_script(
			$this->plugin_name,
			RESPIRA_PLUGIN_URL . 'admin/assets/js/respira-admin.js',
			array( 'jquery' ),
			$version,
			true
		);

		// Localize script for AJAX.
		wp_localize_script(
			$this->plugin_name,
			'respira_admin',
			array(
				'ajax_url'    => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'respira_admin_nonce' ),
				'updates_url' => self_admin_url( 'update-core.php?force-check=1' ),
				'i18n'        => array(
					'copied'             => __( 'Copied!', 'respira-for-wordpress' ),
					'copy_manual'        => __( 'Select and copy manually', 'respira-for-wordpress' ),
					'approving'          => __( 'Approving...', 'respira-for-wordpress' ),
						'approve'            => __( 'Approve', 'respira-for-wordpress' ),
						'approve_selected'   => __( 'Approve selected', 'respira-for-wordpress' ),
						'approving_selected' => __( 'Approving selected...', 'respira-for-wordpress' ),
						'rejecting'          => __( 'Rejecting...', 'respira-for-wordpress' ),
						'reject'             => __( 'Reject', 'respira-for-wordpress' ),
					'network_error'      => __( 'Network error. Please try again.', 'respira-for-wordpress' ),
					'generic_error'      => __( 'An error occurred.', 'respira-for-wordpress' ),
					'reject_confirm'     => __( 'Are you sure you want to reject and permanently delete this duplicate? This action cannot be undone.', 'respira-for-wordpress' ),
						'force_confirm'      => __( 'The original has changed since this duplicate was created. Force approval will replace a newer live version. Do you want to force approve?', 'respira-for-wordpress' ),
						'bulk_none_selected' => __( 'Select at least one duplicate to approve.', 'respira-for-wordpress' ),
						'bulk_confirm'       => __( 'Approve selected duplicates? This applies all selected AI changes to live content.', 'respira-for-wordpress' ),
						'bulk_summary'       => __( 'Bulk approval complete.', 'respira-for-wordpress' ),
						'scan_starting'      => __( 'Starting…', 'respira-for-wordpress' ),
					'scan_refreshing'    => __( 'Refreshing…', 'respira-for-wordpress' ),
					'scan_failed'        => __( 'Request failed. Try again.', 'respira-for-wordpress' ),
					'request_failed'     => __( 'Request failed.', 'respira-for-wordpress' ),
					'get_extension'      => __( 'Get Chrome extension', 'respira-for-wordpress' ),
					'testimonial_rating' => __( 'Please select a rating.', 'respira-for-wordpress' ),
					'testimonial_send'   => __( 'Submitting...', 'respira-for-wordpress' ),
					'setting_updated'    => __( 'Setting updated', 'respira-for-wordpress' ),
					'setting_undo'       => __( 'Undo', 'respira-for-wordpress' ),
					'setting_undone'     => __( 'Reverted', 'respira-for-wordpress' ),
					'setting_save_error' => __( 'Failed to save setting.', 'respira-for-wordpress' ),
					'confirm_direct_edit_title'   => __( 'Enable Direct Editing?', 'respira-for-wordpress' ),
					'confirm_direct_edit_message' => __( 'Enabling direct editing allows AI to modify live content without creating a duplicate first. Changes go live immediately. Snapshots provide a safety net, but there is no automatic undo.', 'respira-for-wordpress' ),
					'confirm_plugin_mgmt_title'   => __( 'Enable Plugin Management?', 'respira-for-wordpress' ),
					'confirm_plugin_mgmt_message' => __( 'Enabling plugin management allows AI to install, activate, deactivate, and delete plugins on your site. All actions are logged, but changes may be hard to reverse.', 'respira-for-wordpress' ),
				),
			)
		);
	}

	/**
	 * Show one-click installer notice when WooCommerce is active and add-on is missing.
	 *
	 * @since 2.1.0
	 */
	public function maybe_render_woocommerce_addon_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->is_woocommerce_active() || $this->is_woocommerce_addon_active() ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return;
		}

		$allowed_screens = array(
			'plugins',
		);
		if ( ! in_array( $screen->id, $allowed_screens, true ) ) {
			return;
		}

		$status = isset( $_GET['respira_woo_addon_status'] ) ? sanitize_text_field( wp_unslash( $_GET['respira_woo_addon_status'] ) ) : '';
		if ( 'installed' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>';
			echo esc_html__( 'Respira WooCommerce Add-on installed and activated successfully.', 'respira-for-wordpress' );
			echo '</p></div>';
			return;
		}
		if ( 'failed' === $status ) {
			$message = isset( $_GET['respira_woo_addon_message'] ) ? sanitize_text_field( wp_unslash( $_GET['respira_woo_addon_message'] ) ) : __( 'Installation failed.', 'respira-for-wordpress' );
			echo '<div class="notice notice-error is-dismissible"><p>';
			echo esc_html( $message );
			echo '</p></div>';
		}

		$action_url = admin_url( 'admin-post.php' );
		$redirect   = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : admin_url( 'admin.php?page=respira-for-wordpress' );
		?>
		<div class="notice notice-info">
			<p><strong><?php esc_html_e( 'WooCommerce detected', 'respira-for-wordpress' ); ?></strong></p>
			<p><?php esc_html_e( 'Install the Respira WooCommerce Add-on to manage products, orders, and inventory from your AI workflow.', 'respira-for-wordpress' ); ?></p>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>" style="margin-top: 8px;">
				<?php wp_nonce_field( 'respira_install_activate_woo_addon' ); ?>
				<input type="hidden" name="action" value="respira_install_activate_woo_addon">
				<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect ); ?>">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Install & Activate WooCommerce Add-on', 'respira-for-wordpress' ); ?></button>
			</form>
		</div>
		<?php
	}

	/**
	 * Install and activate the WooCommerce add-on plugin.
	 *
	 * @since 2.1.0
	 */
	public function handle_install_activate_woo_addon() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'respira-for-wordpress' ) );
		}

		check_admin_referer( 'respira_install_activate_woo_addon' );

		$redirect_to = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : admin_url( 'admin.php?page=respira-for-wordpress' );
		$redirect_to = $this->normalize_admin_redirect( $redirect_to );

		if ( ! $this->is_woocommerce_active() ) {
			$this->redirect_with_woo_addon_status( $redirect_to, 'failed', __( 'WooCommerce must be active before installing the add-on.', 'respira-for-wordpress' ) );
		}

		$addon_file = 'respira-woocommerce-addon/respira-woocommerce-addon.php';

		if ( file_exists( WP_PLUGIN_DIR . '/' . $addon_file ) ) {
			$activation_result = activate_plugin( $addon_file );
			if ( is_wp_error( $activation_result ) ) {
				$this->redirect_with_woo_addon_status( $redirect_to, 'failed', $activation_result->get_error_message() );
			}
			$this->redirect_with_woo_addon_status( $redirect_to, 'installed', '' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';

		$package_url = apply_filters(
			'respira_woo_addon_package_url',
			'https://respira.press/api/plugin-updates/respira-woocommerce-addon/download'
		);

		$base_license_key = get_option( 'respira_license_key', '' );
		if ( ! empty( $base_license_key ) ) {
			$package_url = add_query_arg(
				array(
					'license_key' => sanitize_text_field( (string) $base_license_key ),
					'source'      => 'wp_one_click_installer',
				),
				$package_url
			);
		}

		if ( empty( $package_url ) ) {
			$this->redirect_with_woo_addon_status( $redirect_to, 'failed', __( 'WooCommerce add-on package URL is not configured.', 'respira-for-wordpress' ) );
		}

		$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $package_url );
		if ( is_wp_error( $result ) ) {
			$this->redirect_with_woo_addon_status( $redirect_to, 'failed', $result->get_error_message() );
		}
		if ( ! $result ) {
			$this->redirect_with_woo_addon_status( $redirect_to, 'failed', __( 'WordPress could not install the WooCommerce add-on package.', 'respira-for-wordpress' ) );
		}

		$installed_plugin = $upgrader->plugin_info();
		if ( empty( $installed_plugin ) ) {
			$installed_plugin = $addon_file;
		}

		$activation_result = activate_plugin( $installed_plugin );
		if ( is_wp_error( $activation_result ) ) {
			$this->redirect_with_woo_addon_status( $redirect_to, 'failed', $activation_result->get_error_message() );
		}

		$this->redirect_with_woo_addon_status( $redirect_to, 'installed', '' );
	}

	/**
	 * Redirect helper for add-on status UI.
	 *
	 * @since 2.1.0
	 * @param string $redirect_to Admin URL to redirect to.
	 * @param string $status Status slug.
	 * @param string $message Optional error message.
	 */
	private function redirect_with_woo_addon_status( $redirect_to, $status, $message = '' ) {
		$args = array(
			'respira_woo_addon_status' => sanitize_key( $status ),
		);

		if ( ! empty( $message ) ) {
			$args['respira_woo_addon_message'] = $message;
		}

		wp_safe_redirect( add_query_arg( $args, $redirect_to ) );
		exit;
	}

	/**
	 * Ensure redirect targets admin URLs only.
	 *
	 * @since 2.1.0
	 * @param string $url Requested redirect.
	 * @return string
	 */
	private function normalize_admin_redirect( $url ) {
		$fallback  = admin_url( 'admin.php?page=respira-for-wordpress' );
		$validated = wp_validate_redirect( $url, $fallback );
		if ( empty( $validated ) || 0 !== strpos( $validated, admin_url() ) ) {
			return $fallback;
		}

		return $validated;
	}

	/**
	 * Check WooCommerce plugin state.
	 *
	 * @since 2.1.0
	 * @return bool
	 */
	private function is_woocommerce_active() {
		if ( class_exists( 'WooCommerce' ) ) {
			return true;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'woocommerce/woocommerce.php' );
	}

	/**
	 * Check whether Respira WooCommerce add-on is active.
	 *
	 * @since 2.1.0
	 * @return bool
	 */
	private function is_woocommerce_addon_active() {
		if ( class_exists( '\Respira_WooCommerce\Plugin_Core' ) ) {
			return true;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'respira-woocommerce-addon/respira-woocommerce-addon.php' );
	}

	/**
	 * Add plugin admin menu.
	 *
	 * @since 1.0.0
	 */
	public function add_plugin_admin_menu() {
		// Respira favicon at 20x20 for crisp display in wp-admin sidebar (matches WP menu icon size).
		$icon_url = RESPIRA_PLUGIN_URL . 'admin/assets/images/respira-icon-20.png';

		// Main menu page - uses dashboard as callback.
		add_menu_page(
			__( 'Respira for WordPress', 'respira-for-wordpress' ),
			__( 'Respira', 'respira-for-wordpress' ),
			'manage_options',
			'respira-for-wordpress',
			array( $this, 'display_dashboard_page' ),
			$icon_url,
			30
		);
		

		// Dashboard - override the auto-generated submenu item.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Overview', 'respira-for-wordpress' ),
			__( 'Overview', 'respira-for-wordpress' ),
			'manage_options',
			'respira-for-wordpress',
			array( $this, 'display_dashboard_page' )
		);

		// Setup (grouped IA page).
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Setup', 'respira-for-wordpress' ),
			__( 'Setup', 'respira-for-wordpress' ),
			'manage_options',
			'respira-setup',
			array( $this, 'display_setup_page' )
		);

		// Changes (unified approvals + version history).
		$pending_count = $this->get_pending_duplicate_count();
		$badge         = $pending_count > 0
			? ' <span class="awaiting-mod count-' . (int) $pending_count . '"><span class="pending-count">' . (int) $pending_count . '</span></span>'
			: '';
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Approvals & Undo', 'respira-for-wordpress' ),
			__( 'Approvals & Undo', 'respira-for-wordpress' ) . $badge,
			'manage_options',
			'respira-changes',
			array( $this, 'display_changes_page' )
		);

		// Reports.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Reports', 'respira-for-wordpress' ),
			__( 'Reports', 'respira-for-wordpress' ),
			'manage_options',
			'respira-reports',
			array( $this, 'display_reports_page' )
		);

		// Add-ons.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Add-ons', 'respira-for-wordpress' ),
			__( 'Add-ons', 'respira-for-wordpress' ),
			'manage_options',
			'respira-addons',
			array( $this, 'display_addons_page' )
		);

		// Skills.
		$skills_label = __( 'Skills', 'respira-for-wordpress' );
		$user_id      = get_current_user_id();
		if ( $user_id > 0 && ! get_user_meta( $user_id, 'respira_skills_page_visited', true ) ) {
			$skills_label .= ' <span class="awaiting-mod" style="background:#10b981;">NEW</span>';
		}
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Skills', 'respira-for-wordpress' ),
			$skills_label,
			'manage_options',
			'respira-skills',
			array( $this, 'display_skills_page' )
		);

		// Governance.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Tool Governance', 'respira-for-wordpress' ),
			__( 'Governance', 'respira-for-wordpress' ),
			'manage_options',
			'respira-governance',
			array( $this, 'display_governance_page' )
		);

		// Logs.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Audit Log', 'respira-for-wordpress' ),
			__( 'Logs', 'respira-for-wordpress' ),
			'manage_options',
			'respira-audit-log',
			array( $this, 'display_audit_log_page' )
		);

		// Settings.
		add_submenu_page(
			'respira-for-wordpress',
			__( 'Settings', 'respira-for-wordpress' ),
			__( 'Settings', 'respira-for-wordpress' ),
			'manage_options',
			'respira-settings',
			array( $this, 'display_settings_page' )
		);

		// What's New page.
		add_submenu_page(
			'respira-for-wordpress',
			__( "What's New", 'respira-for-wordpress' ),
			__( "What's New", 'respira-for-wordpress' ),
			'manage_options',
			'respira-whats-new',
			array( $this, 'display_whats_new_page' )
		);

		// Remove the duplicate submenu item that WordPress auto-creates.
		global $submenu;
		if ( isset( $submenu['respira-for-wordpress'] ) ) {
			// Remove the first item if it's a duplicate (same slug as parent).
			foreach ( $submenu['respira-for-wordpress'] as $key => $item ) {
				if ( 'respira-for-wordpress' === $item[2] && 0 !== $key ) {
					unset( $submenu['respira-for-wordpress'][ $key ] );
					break;
				}
			}
		}
	}

	/**
	 * Handle license form submissions used by dashboard/license pages.
	 *
	 * @since 2.3.1
	 */
	private function handle_license_form_submission() {
		if ( isset( $_POST['respira_activate_license'] ) && check_admin_referer( 'respira_activate_license' ) ) {
			$license_key   = sanitize_text_field( wp_unslash( $_POST['license_key'] ?? '' ) );
			$agree_privacy = isset( $_POST['agree_privacy'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['agree_privacy'] ) );
			$agree_terms   = isset( $_POST['agree_terms'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['agree_terms'] ) );

			if ( ! $agree_privacy || ! $agree_terms ) {
				add_settings_error( 'respira_messages', 'respira_error', __( 'You must confirm that you have read and agree to both the Privacy Policy and Terms of Service before activating your license.', 'respira-for-wordpress' ), 'error' );
			} elseif ( empty( $license_key ) ) {
				add_settings_error( 'respira_messages', 'respira_error', __( 'Please enter a license key.', 'respira-for-wordpress' ), 'error' );
			} elseif ( preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $license_key ) ) {
				add_settings_error(
					'respira_messages',
					'respira_lemonsqueezy_key',
					sprintf(
						/* translators: %s: link to respira.press dashboard */
						__( 'That looks like a LemonSqueezy order key — it won\'t work here. Your Respira license key starts with "respira_" and can be found in your %s.', 'respira-for-wordpress' ),
						'<a href="https://respira.press/dashboard" target="_blank">respira.press dashboard</a>'
					),
					'error'
				);
			} else {
				$result = Respira_License::activate_license( $license_key );
				if ( is_wp_error( $result ) ) {
					add_settings_error( 'respira_messages', 'respira_error', $result->get_error_message(), 'error' );
				} else {
					add_settings_error( 'respira_messages', 'respira_success', __( 'License activated successfully!', 'respira-for-wordpress' ), 'success' );
				}
			}
		}

		if ( isset( $_POST['respira_deactivate_license'] ) && check_admin_referer( 'respira_deactivate_license' ) ) {
			$result = Respira_License::deactivate_license();
			if ( is_wp_error( $result ) ) {
				add_settings_error( 'respira_messages', 'respira_error', $result->get_error_message(), 'error' );
			} else {
				add_settings_error( 'respira_messages', 'respira_success', __( 'License deactivated successfully.', 'respira-for-wordpress' ), 'success' );
			}
		}
	}

	/**
	 * Handle API key create/revoke submissions used by dashboard/API key pages.
	 *
	 * @since 2.3.1
	 */
	private function handle_api_key_form_submission() {
		if ( isset( $_POST['respira_generate_key'] ) && check_admin_referer( 'respira_generate_key' ) ) {
			$name    = sanitize_text_field( wp_unslash( $_POST['key_name'] ?? '' ) );
			$user_id = get_current_user_id();

			// Resolve allowed tools from profile + custom selections.
			$profile = isset( $_POST['respira_access_profile'] ) ? sanitize_key( wp_unslash( $_POST['respira_access_profile'] ) ) : 'full_access';
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-tool-governance.php';
			if ( 'full_access' === $profile ) {
				$allowed_tools = array( '*' ); // Wildcard = all tools.
			} else {
				$allowed_tools = Respira_Tool_Governance::get_profile_tools( $profile );
				// If custom tools were submitted, merge any individually checked tools.
				if ( ! empty( $_POST['respira_allowed_tools'] ) ) {
					$custom_tools  = array_map( 'sanitize_key', (array) wp_unslash( $_POST['respira_allowed_tools'] ) );
					$allowed_tools = array_unique( array_merge( $allowed_tools, $custom_tools ) );
				}
			}

			// Build permissions: keep legacy scopes + add allowed_tools.
			$permissions_with_tools = array(
				'scopes'        => array( 'read_basic', 'read_fidelity', 'write' ),
				'profile'       => $profile,
				'allowed_tools' => array_values( $allowed_tools ),
			);

			$api_key = Respira_Auth::generate_api_key( $user_id, $name, $permissions_with_tools );

			if ( is_wp_error( $api_key ) ) {
				add_settings_error( 'respira_messages', 'respira_error', $api_key->get_error_message(), 'error' );
			} else {
				update_user_meta( $user_id, 'respira_new_api_key', $api_key );
				add_settings_error( 'respira_messages', 'respira_success', __( 'API key generated successfully! Copy it below before leaving this page.', 'respira-for-wordpress' ), 'success' );
			}
		}

		$revoke_requested = isset( $_POST['respira_revoke_key'] ) || ( isset( $_POST['respira_action'] ) && 'revoke_key' === sanitize_text_field( wp_unslash( $_POST['respira_action'] ) ) );
		if ( $revoke_requested && check_admin_referer( 'respira_revoke_key' ) ) {
			$key_id = isset( $_POST['key_id'] ) ? absint( wp_unslash( $_POST['key_id'] ) ) : 0;
			$result = Respira_Auth::revoke_api_key( $key_id, get_current_user_id() );

			if ( is_wp_error( $result ) ) {
				add_settings_error( 'respira_messages', 'respira_error', $result->get_error_message(), 'error' );
			} else {
				add_settings_error( 'respira_messages', 'respira_success', __( 'API key revoked successfully!', 'respira-for-wordpress' ), 'success' );
			}
		}
	}

	/**
	 * Display license page.
	 *
	 * @since 1.5.3
	 */
	public function display_license_page() {
		$this->handle_license_form_submission();

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/license.php';
	}

	/**
	 * Display add-ons page.
	 *
	 * @since 2.2.0
	 */
	public function display_addons_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/addons.php';
	}

	/**
	 * Display intelligence page.
	 *
	 * @since 2.0.17
	 */
	public function display_intelligence_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/intelligence.php';
	}

	/**
	 * Handle builder cache refresh redirect on admin_init (before output).
	 *
	 * Moved out of display callbacks to avoid "headers already sent" when
	 * wp_safe_redirect() fires after admin header output.
	 *
	 * @since 5.2.6
	 */
	public function maybe_refresh_builders_redirect() {
		if ( ! isset( $_GET['respira_refresh_builders'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		delete_transient( 'respira_builder_info' );
		delete_transient( 'respira_detected_builders' );
		delete_transient( 'respira_theme_info' );
		delete_transient( 'respira_site_context' );

		wp_safe_redirect( remove_query_arg( 'respira_refresh_builders' ) );
		exit;
	}

	/**
	 * Display dashboard page.
	 *
	 * @since 1.0.0
	 */
	public function display_dashboard_page() {
		$this->handle_license_form_submission();
		$this->handle_api_key_form_submission();
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/dashboard.php';
	}

	/**
	 * Display setup IA page with tabbed sections.
	 *
	 * @since 3.3.0
	 * @return void
	 */
	public function display_setup_page() {
		// Keep existing submit handlers unchanged.
		$this->handle_license_form_submission();
		$this->handle_api_key_form_submission();
		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'license';

		// Settings tab reuses existing settings variables and submit handling.
		$webmcp_tool_groups             = $this->get_webmcp_tool_groups();
		$webmcp_selected_groups         = $this->get_selected_webmcp_groups();

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/setup.php';
	}

	/**
	 * Display API keys page.
	 *
	 * @since 1.0.0
	 */
	public function display_api_keys_page() {
		// Check if license is active first.
		$license_status = get_option( 'respira_license_status', 'inactive' );
		if ( 'active' !== $license_status && 'trial' !== $license_status ) {
			add_settings_error( 'respira_messages', 'respira_error', __( 'Please activate your license first before generating API keys.', 'respira-for-wordpress' ), 'error' );
		}
		$this->handle_api_key_form_submission();

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/api-keys.php';
	}

	/**
	 * Display prompts page.
	 *
	 * @since 2.3.1
	 */
	public function display_prompts_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/prompts.php';
	}

	/**
	 * Display settings page.
	 *
	 * @since 1.0.0
	 */
	public function display_settings_page() {
		$plugin_management_availability = Respira_Plugin_Manager::get_availability();
		$plugin_management_available    = ! empty( $plugin_management_availability['available'] );
		$plugin_management_reason       = isset( $plugin_management_availability['reason'] ) ? (string) $plugin_management_availability['reason'] : '';
		$webmcp_available              = $this->is_webmcp_available();
		$webmcp_unavailable_reason     = $webmcp_available ? '' : $this->get_webmcp_unavailable_reason();
		$webmcp_tool_groups            = $this->get_webmcp_tool_groups();
		$webmcp_selected_groups        = $this->get_selected_webmcp_groups();
		$angie_active                  = (bool) apply_filters( 'respira_angie_is_active', false );
		$angie_enabled                 = 1 === (int) get_option( 'respira_enable_angie_integration', $angie_active ? 1 : 0 );

		// Handle settings update.
		if ( isset( $_POST['respira_update_settings'] ) && check_admin_referer( 'respira_update_settings' ) ) {
				update_option( 'respira_auto_duplicate', isset( $_POST['auto_duplicate'] ) ? 1 : 0 );
				update_option( 'respira_security_checks', isset( $_POST['security_checks'] ) ? 1 : 0 );
				update_option( 'respira_audit_logging', isset( $_POST['audit_logging'] ) ? 1 : 0 );
				update_option( 'respira_allow_direct_edit', isset( $_POST['allow_direct_edit'] ) ? 1 : 0 );
				update_option( 'respira_preserve_product_ids_on_approve', isset( $_POST['preserve_product_ids_on_approve'] ) ? 1 : 0 );
				update_option( 'respira_enable_bulk_approvals', isset( $_POST['enable_bulk_approvals'] ) ? 1 : 0 );
				update_option( 'respira_enable_angie_integration', isset( $_POST['respira_enable_angie_integration'] ) ? 1 : 0 );
				$raw_preserve_cpt_slugs = isset( $_POST['preserve_id_cpt_slugs'] ) ? wp_unslash( $_POST['preserve_id_cpt_slugs'] ) : '';
				if ( is_array( $raw_preserve_cpt_slugs ) ) {
					$preserve_cpt_slugs = array_filter( array_map( 'sanitize_key', $raw_preserve_cpt_slugs ) );
				} else {
					$preserve_cpt_slugs = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', (string) $raw_preserve_cpt_slugs ) ) ) );
				}
				update_option( 'respira_preserve_id_cpt_slugs', implode( ',', $preserve_cpt_slugs ) );
				$plugin_management_requested = isset( $_POST['enable_plugin_management'] ) ? 1 : 0;
			if ( $plugin_management_requested && ! $plugin_management_available ) {
				update_option( 'respira_enable_plugin_management', 0 );
				add_settings_error(
					'respira_messages',
					'respira_plugin_management_unavailable',
					sprintf(
						/* translators: %s: reason plugin-management feature cannot be enabled. */
						__( 'Plugin management was not enabled: %s', 'respira-for-wordpress' ),
						$plugin_management_reason
					),
					'error'
				);
			} else {
				// Server-side sanitize callback on the option enforces availability too.
				update_option( 'respira_enable_plugin_management', $plugin_management_requested );
			}
			update_option( 'respira_rate_limit', absint( $_POST['rate_limit'] ?? 100 ) );

			$raw_webmcp_selected = isset( $_POST['respira_webmcp_tools'] ) ? (array) wp_unslash( $_POST['respira_webmcp_tools'] ) : array( 'all' );
			$webmcp_selected_groups = $this->sanitize_webmcp_selected_groups( $raw_webmcp_selected );
			update_option( 'respira_webmcp_tools', $webmcp_selected_groups );
			$this->sync_webmcp_exposed_tools( $webmcp_selected_groups );
			$angie_enabled = isset( $_POST['respira_enable_angie_integration'] );

			$errors = get_settings_errors( 'respira_messages' );
			$has_error = false;
			foreach ( $errors as $error ) {
				if ( isset( $error['type'] ) && 'error' === $error['type'] ) {
					$has_error = true;
					break;
				}
			}

			if ( ! $has_error ) {
				add_settings_error( 'respira_messages', 'respira_success', __( 'Settings saved successfully!', 'respira-for-wordpress' ), 'success' );
			}
		}

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/settings.php';
	}

	/**
	 * Check whether bundled WebMCP support is available on this site.
	 *
	 * @since 2.0.19
	 * @return bool
	 */
	private function is_webmcp_available() {
		return class_exists( 'Respira\\WebMCP\\Plugin' ) && class_exists( 'Respira_WebMCP_Integration' ) && function_exists( 'wp_register_ability' );
	}

	/**
	 * Get unavailable reason for bundled WebMCP support.
	 *
	 * @since 3.0.2
	 * @return string
	 */
	private function get_webmcp_unavailable_reason() {
		if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
			return sprintf(
				/* translators: 1: current PHP version, 2: required PHP version. */
				__( 'Bundled Browser AI (WebMCP) requires PHP %2$s+; current site runtime is PHP %1$s.', 'respira-for-wordpress' ),
				PHP_VERSION,
				'8.1'
			);
		}

		if ( ! function_exists( 'wp_register_ability' ) ) {
			return __( 'WordPress Abilities API support is required (WordPress 6.9+).', 'respira-for-wordpress' );
		}

		if ( ! class_exists( 'Respira\\WebMCP\\Plugin' ) ) {
			return __( 'Bundled WebMCP bridge class did not load. Check plugin files and PHP error logs.', 'respira-for-wordpress' );
		}

		if ( ! class_exists( 'Respira_WebMCP_Integration' ) ) {
			return __( 'Respira WebMCP integration did not load. Check plugin files and PHP error logs.', 'respira-for-wordpress' );
		}

		return __( 'WebMCP is currently unavailable due to initialization failure.', 'respira-for-wordpress' );
	}

	/**
	 * Get configurable WebMCP tool-group labels.
	 *
	 * @since 2.0.19
	 * @return array<string,string>
	 */
	private function get_webmcp_group_labels() {
		return array(
			'site_context'      => __( 'Site / Context Tools', 'respira-for-wordpress' ),
			'builder'           => __( 'Page Builder Tools', 'respira-for-wordpress' ),
			'pages'             => __( 'Page Tools', 'respira-for-wordpress' ),
			'posts'             => __( 'Post Tools', 'respira-for-wordpress' ),
			'duplication'       => __( 'Duplication Tools', 'respira-for-wordpress' ),
			'media'             => __( 'Media Tools', 'respira-for-wordpress' ),
			'security'          => __( 'Security Tools', 'respira-for-wordpress' ),
			'performance_seo'   => __( 'Performance / SEO / AEO Tools', 'respira-for-wordpress' ),
			'plugins'           => __( 'Plugin Management Tools', 'respira-for-wordpress' ),
			'users'             => __( 'User Management Tools', 'respira-for-wordpress' ),
			'comments'          => __( 'Comment Tools', 'respira-for-wordpress' ),
			'taxonomies'        => __( 'Taxonomy / Term Tools', 'respira-for-wordpress' ),
			'custom_post_types' => __( 'Custom Post Type Tools', 'respira-for-wordpress' ),
			'options'           => __( 'Option Tools', 'respira-for-wordpress' ),
			'menus'             => __( 'Menu Tools', 'respira-for-wordpress' ),
			'woocommerce'       => __( 'WooCommerce Tools', 'respira-for-wordpress' ),
		);
	}

	/**
	 * Build tool groups and counts from the Respira ability registry.
	 *
	 * @since 2.0.19
	 * @return array<string,array<string,mixed>>
	 */
	private function get_webmcp_tool_groups() {
		$groups = array();
		foreach ( $this->get_webmcp_group_labels() as $slug => $label ) {
			$groups[ $slug ] = array(
				'label'       => $label,
				'count'       => 0,
				'ability_ids' => array(),
			);
		}

		if ( ! class_exists( 'Respira_WebMCP_Integration' ) || ! method_exists( 'Respira_WebMCP_Integration', 'get_tool_registry' ) ) {
			return $groups;
		}

		$registry = Respira_WebMCP_Integration::get_tool_registry();
		foreach ( $registry as $entry ) {
			if ( empty( $entry['tool'] ) || empty( $entry['ability_id'] ) ) {
				continue;
			}

			$slug = $this->map_webmcp_tool_group( (string) $entry['tool'] );
			if ( ! isset( $groups[ $slug ] ) ) {
				continue;
			}

			$groups[ $slug ]['count']++;
			$groups[ $slug ]['ability_ids'][] = (string) $entry['ability_id'];
		}

		return $groups;
	}

	/**
	 * Map a Respira MCP tool to a settings group slug.
	 *
	 * @since 2.0.19
	 * @param string $tool Tool name.
	 * @return string
	 */
	private function map_webmcp_tool_group( $tool ) {
		if ( 0 === strpos( $tool, 'woocommerce_' ) ) {
			return 'woocommerce';
		}

		$group_map = array(
			'site_context' => array(
				'wordpress_get_site_context',
				'wordpress_get_theme_docs',
				'wordpress_switch_site',
			),
			'builder' => array(
				'wordpress_get_builder_info',
				'wordpress_detect_page_builder',
				'wordpress_extract_builder_content',
				'wordpress_inject_builder_content',
				'wordpress_update_module',
			),
			'pages' => array(
				'wordpress_list_pages',
				'wordpress_read_page',
				'wordpress_update_page',
				'wordpress_delete_page',
			),
			'posts' => array(
				'wordpress_list_posts',
				'wordpress_read_post',
				'wordpress_update_post',
				'wordpress_delete_post',
			),
			'duplication' => array(
				'wordpress_create_page_duplicate',
				'wordpress_create_post_duplicate',
				'wordpress_approve_duplicate',
				'wordpress_reject_duplicate',
			),
			'media' => array(
				'wordpress_list_media',
				'wordpress_get_media',
				'wordpress_upload_media',
				'wordpress_update_media',
				'wordpress_delete_media',
			),
			'security' => array(
				'wordpress_validate_security',
			),
			'performance_seo' => array(
				'wordpress_analyze_performance',
				'wordpress_get_core_web_vitals',
				'wordpress_analyze_images',
				'wordpress_analyze_seo',
				'wordpress_check_seo_issues',
				'wordpress_analyze_readability',
				'wordpress_analyze_aeo',
				'wordpress_check_structured_data',
			),
			'plugins' => array(
				'wordpress_list_plugins',
				'wordpress_install_plugin',
				'wordpress_activate_plugin',
				'wordpress_deactivate_plugin',
				'wordpress_update_plugin',
				'wordpress_delete_plugin',
			),
			'users' => array(
				'wordpress_list_users',
				'wordpress_get_user',
				'wordpress_create_user',
				'wordpress_update_user',
				'wordpress_delete_user',
			),
			'comments' => array(
				'wordpress_list_comments',
				'wordpress_get_comment',
				'wordpress_create_comment',
				'wordpress_update_comment',
				'wordpress_delete_comment',
			),
			'taxonomies' => array(
				'wordpress_list_taxonomies',
				'wordpress_get_taxonomy',
				'wordpress_list_terms',
				'wordpress_get_term',
				'wordpress_create_term',
				'wordpress_update_term',
				'wordpress_delete_term',
			),
			'custom_post_types' => array(
				'wordpress_list_post_types',
				'wordpress_get_post_type',
				'wordpress_list_custom_posts',
				'wordpress_get_custom_post',
				'wordpress_create_custom_post',
				'wordpress_update_custom_post',
				'wordpress_delete_custom_post',
			),
			'options' => array(
				'wordpress_list_options',
				'wordpress_get_option',
				'wordpress_update_option',
				'wordpress_delete_option',
			),
			'menus' => array(
				'wordpress_list_menus',
				'wordpress_get_menu',
				'wordpress_create_menu',
				'wordpress_update_menu',
				'wordpress_delete_menu',
				'wordpress_list_menu_locations',
				'wordpress_assign_menu_location',
				'wordpress_list_menu_items',
				'wordpress_create_menu_item',
				'wordpress_get_menu_item',
				'wordpress_update_menu_item',
				'wordpress_delete_menu_item',
			),
		);

		foreach ( $group_map as $slug => $tools ) {
			if ( in_array( $tool, $tools, true ) ) {
				return $slug;
			}
		}

		return 'site_context';
	}

	/**
	 * Get selected WebMCP settings groups from options.
	 *
	 * @since 2.0.19
	 * @return array<int,string>
	 */
	private function get_selected_webmcp_groups() {
		$value = get_option( 'respira_webmcp_tools', array( 'all' ) );
		return $this->sanitize_webmcp_selected_groups( $value );
	}

	/**
	 * Sanitize WebMCP group selection.
	 *
	 * @since 2.0.19
	 * @param mixed $raw Raw option or request payload.
	 * @return array<int,string>
	 */
	private function sanitize_webmcp_selected_groups( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array( 'all' );
		}

		$allowed = array_keys( $this->get_webmcp_group_labels() );
		$allowed[] = 'all';

		$selected = array();
		foreach ( $raw as $item ) {
			$slug = sanitize_key( (string) $item );
			if ( in_array( $slug, $allowed, true ) ) {
				$selected[] = $slug;
			}
		}

		$selected = array_values( array_unique( $selected ) );
		if ( in_array( 'all', $selected, true ) ) {
			return array( 'all' );
		}

		return empty( $selected ) ? array( 'all' ) : $selected;
	}

	/**
	 * Sync WebMCP plugin allowlist option with Respira settings selection.
	 *
	 * @since 2.0.19
	 * @param array<int,string> $selected_groups Selected group slugs.
	 * @return void
	 */
	private function sync_webmcp_exposed_tools( $selected_groups ) {
		$groups = $this->get_webmcp_tool_groups();
		$ability_ids = array();
		$woo_available = class_exists( 'Respira_WebMCP_Integration' ) && method_exists( 'Respira_WebMCP_Integration', 'is_woocommerce_addon_available' )
			? (bool) Respira_WebMCP_Integration::is_woocommerce_addon_available()
			: false;

		if ( in_array( 'all', $selected_groups, true ) ) {
			foreach ( $groups as $slug => $group ) {
				if ( 'woocommerce' === $slug && ! $woo_available ) {
					continue;
				}
				if ( empty( $group['ability_ids'] ) || ! is_array( $group['ability_ids'] ) ) {
					continue;
				}
				$ability_ids = array_merge( $ability_ids, $group['ability_ids'] );
			}
		} else {
			foreach ( $selected_groups as $slug ) {
				if ( ! isset( $groups[ $slug ] ) ) {
					continue;
				}
				if ( 'woocommerce' === $slug && ! $woo_available ) {
					continue;
				}
				if ( empty( $groups[ $slug ]['ability_ids'] ) || ! is_array( $groups[ $slug ]['ability_ids'] ) ) {
					continue;
				}
				$ability_ids = array_merge( $ability_ids, $groups[ $slug ]['ability_ids'] );
			}
		}

		$ability_ids = array_values( array_unique( array_map( 'sanitize_text_field', $ability_ids ) ) );
		update_option( 'wmcp_exposed_tools', $ability_ids );
		update_option( 'wmcp_enabled', 1 );

		if ( function_exists( 'wp_cache_flush_group' ) ) {
			wp_cache_flush_group( 'wmcp_bridge' );
		}
	}

	/**
	 * Display unified Changes page (replaces Approvals + Snapshots).
	 *
	 * @since 5.0.0
	 */
	public function display_changes_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/changes.php';
	}

	/**
	 * Count pending duplicates for the admin menu badge.
	 *
	 * @since 5.0.0
	 * @return int
	 */
	public function get_pending_duplicate_count() {
		global $wpdb;

		$count = $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID)
			 FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pm1 ON pm1.post_id = p.ID AND pm1.meta_key = '_respira_duplicate' AND pm1.meta_value = '1'
			 INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = p.ID AND pm2.meta_key = '_respira_original_id'
			 WHERE p.post_status IN ('draft','pending')"
		);

		return (int) $count;
	}

	/**
	 * Display reports IA page with tabbed sections.
	 *
	 * @since 3.3.0
	 * @return void
	 */
	public function display_reports_page() {
		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'accessibility';
		if ( 'divi' === $active_tab ) {
			$user_id = get_current_user_id();
			$report  = Respira_Divi_Migration_Copilot::get_cached_report( $user_id );
			$prompts = is_array( $report ) ? Respira_Divi_Migration_Copilot::build_prompt_pack( $report ) : array();

			if ( isset( $_POST['respira_generate_migration_report'] ) && check_admin_referer( 'respira_generate_migration_report' ) ) {
				$report = Respira_Divi_Migration_Copilot::generate_readiness_report();
				Respira_Divi_Migration_Copilot::cache_report( $user_id, $report );
				$prompts = Respira_Divi_Migration_Copilot::build_prompt_pack( $report );
				add_settings_error(
					'respira_messages',
					'respira_migration_report_generated',
					__( 'Migration readiness report generated.', 'respira-for-wordpress' ),
					'success'
				);
			}

			if ( isset( $_POST['respira_export_migration_report_json'] ) && check_admin_referer( 'respira_export_migration_report_json' ) ) {
				if ( empty( $report ) ) {
					wp_die( esc_html__( 'Generate a report first before exporting JSON.', 'respira-for-wordpress' ) );
				}
				nocache_headers();
				header( 'Content-Type: application/json; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename=respira-divi5-readiness-report.json' );
				echo wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
				exit;
			}

			if ( isset( $_POST['respira_export_prompt_pack_md'] ) && check_admin_referer( 'respira_export_prompt_pack_md' ) ) {
				if ( empty( $report ) ) {
					wp_die( esc_html__( 'Generate a report first before exporting prompts.', 'respira-for-wordpress' ) );
				}
				$markdown = Respira_Divi_Migration_Copilot::export_prompt_pack_markdown( $prompts, $report );
				nocache_headers();
				header( 'Content-Type: text/markdown; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename=respira-divi5-prompt-pack.md' );
				echo $markdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				exit;
			}
		}

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/reports.php';
	}

	/**
	 * Display Divi 5 Migration Copilot page.
	 *
	 * @since 2.0.7
	 */
	public function display_divi_migration_copilot_page() {
		$user_id = get_current_user_id();
		$report  = Respira_Divi_Migration_Copilot::get_cached_report( $user_id );
		$prompts = is_array( $report ) ? Respira_Divi_Migration_Copilot::build_prompt_pack( $report ) : array();

		if ( isset( $_POST['respira_generate_migration_report'] ) && check_admin_referer( 'respira_generate_migration_report' ) ) {
			$report = Respira_Divi_Migration_Copilot::generate_readiness_report();
			Respira_Divi_Migration_Copilot::cache_report( $user_id, $report );
			$prompts = Respira_Divi_Migration_Copilot::build_prompt_pack( $report );
			add_settings_error(
				'respira_messages',
				'respira_migration_report_generated',
				__( 'Migration readiness report generated.', 'respira-for-wordpress' ),
				'success'
			);
		}

		if ( isset( $_POST['respira_export_migration_report_json'] ) && check_admin_referer( 'respira_export_migration_report_json' ) ) {
			if ( empty( $report ) ) {
				wp_die( esc_html__( 'Generate a report first before exporting JSON.', 'respira-for-wordpress' ) );
			}
			nocache_headers();
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=respira-divi5-readiness-report.json' );
			echo wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
			exit;
		}

		if ( isset( $_POST['respira_export_prompt_pack_md'] ) && check_admin_referer( 'respira_export_prompt_pack_md' ) ) {
			if ( empty( $report ) ) {
				wp_die( esc_html__( 'Generate a report first before exporting prompts.', 'respira-for-wordpress' ) );
			}
			$markdown = Respira_Divi_Migration_Copilot::export_prompt_pack_markdown( $prompts, $report );
			nocache_headers();
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=respira-divi5-prompt-pack.md' );
			echo $markdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			exit;
		}

		require_once RESPIRA_PLUGIN_DIR . 'admin/views/divi-migration-copilot.php';
	}

	/**
	 * Display audit log page.
	 *
	 * @since 1.0.0
	 */
	public function display_audit_log_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/audit-log.php';
	}

	/**
	 * Display the Accessibility tab page.
	 *
	 * @since 2.2.0
	 */
	public function display_accessibility_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/accessibility.php';
	}

	/**
	 * Display Skills marketplace page.
	 *
	 * @since 4.1.0
	 */
	public function display_skills_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/skills.php';
	}

	/**
	 * Display Tool Governance page.
	 *
	 * @since 5.2.0
	 */
	public function display_governance_page() {
		// Handle form submission.
		if ( isset( $_POST['respira_update_governance'] ) && check_admin_referer( 'respira_update_governance' ) ) {
			$all_tools   = array();
			$categories  = Respira_Tool_Governance::get_tool_categories();
			foreach ( $categories as $tools ) {
				$all_tools = array_merge( $all_tools, $tools );
			}

			$enabled_tools  = isset( $_POST['respira_enabled_tools'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['respira_enabled_tools'] ) ) : array();
			$disabled_tools = array_diff( $all_tools, $enabled_tools );

			Respira_Tool_Governance::set_disabled_tools( array_values( $disabled_tools ) );

			add_settings_error( 'respira_governance_messages', 'respira_governance_success', __( 'Governance rules saved successfully!', 'respira-for-wordpress' ), 'success' );
		}

		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-tool-governance.php';
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/tool-governance.php';
	}

	/**
	 * Display the What's New page.
	 *
	 * @since 5.2.0
	 */
	public function display_whats_new_page() {
		require_once RESPIRA_PLUGIN_DIR . 'admin/views/whats-new.php';
	}

	/**
	 * Redirect to What's New page after plugin update (once).
	 *
	 * @since 5.2.0
	 */
	public function maybe_redirect_whats_new() {
		$transient = get_transient( 'respira_show_whats_new' );
		if ( ! $transient ) {
			return;
		}

		// Only redirect once.
		delete_transient( 'respira_show_whats_new' );

		// Don't redirect during AJAX, bulk activations, or if not admin.
		if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Don't redirect if activating multiple plugins.
		if ( isset( $_GET['activate-multi'] ) ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=respira-whats-new' ) );
		exit;
	}

	/**
	 * Fetch the skills catalog from GitHub.
	 *
	 * Cached via a transient for 6 hours.
	 *
	 * @since 4.1.0
	 * @return array Skills catalog data with 'skills' key, or 'error' key on failure.
	 */
	public static function fetch_skills_catalog() {
		$cache_key = 'respira_skills_catalog';
		$cached    = get_transient( $cache_key );

		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}

		$url      = 'https://raw.githubusercontent.com/webmyc/claude-skills-wordpress/main/skills.json';
		$response = wp_remote_get( $url, array( 'timeout' => 15 ) );

		if ( is_wp_error( $response ) ) {
			return array(
				'skills' => array(),
				'error'  => sprintf(
					/* translators: %s: error message */
					__( 'Could not fetch skills catalog: %s', 'respira-for-wordpress' ),
					$response->get_error_message()
				),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return array(
				'skills' => array(),
				'error'  => sprintf(
					/* translators: %d: HTTP status code */
					__( 'Could not fetch skills catalog (HTTP %d).', 'respira-for-wordpress' ),
					$code
				),
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || ! isset( $data['skills'] ) ) {
			return array(
				'skills' => array(),
				'error'  => __( 'Invalid skills catalog format.', 'respira-for-wordpress' ),
			);
		}

		set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );

		return $data;
	}

	/**
	 * AJAX handler for approving duplicates.
	 *
	 * @since 1.2.0
	 */
	public function ajax_approve_duplicate() {
		// Verify nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		// Get duplicate ID.
		$duplicate_id = isset( $_POST['duplicate_id'] ) ? absint( $_POST['duplicate_id'] ) : 0;
		if ( ! $duplicate_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid duplicate ID.', 'respira-for-wordpress' ) ) );
		}

		$force = ! empty( $_POST['force'] ) && '1' === (string) sanitize_text_field( wp_unslash( $_POST['force'] ) );

		// Approve the duplicate.
		$result = Respira_Approver::approve_duplicate(
			$duplicate_id,
			array(
				'force'       => $force,
				'allow_force' => current_user_can( 'manage_options' ),
			)
		);

		if ( is_wp_error( $result ) ) {
			$error_data = $result->get_error_data();
			if ( ! is_array( $error_data ) ) {
				$error_data = array();
			}

			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code'    => $result->get_error_code(),
					'data'    => $error_data,
				)
			);
		}

		$approval_mode = is_array( $result ) && ! empty( $result['approval_mode'] ) ? (string) $result['approval_mode'] : 'swap_duplicate_live';
		$message       = __( 'Duplicate approved successfully. The original is now private and the duplicate is live.', 'respira-for-wordpress' );
		if ( 'merge_into_original_id' === $approval_mode ) {
			$message = __( 'Duplicate approved successfully. Changes were merged into the original item to preserve its live ID, and the duplicate was kept as a private backup.', 'respira-for-wordpress' );
		}

		$tracking = $this->track_approval_and_testimonial_prompt( get_current_user_id() );

		wp_send_json_success(
			array(
				'message'                => $message,
				'approval_mode'          => $approval_mode,
				'result'                 => $result,
				'approval_count'         => $tracking['approval_count'],
				'show_testimonial_modal' => $tracking['show_testimonial_modal'],
			)
		);
	}

	/**
	 * AJAX handler for bulk-approving duplicates.
	 *
	 * @since 4.0.11
	 * @return void
	 */
	public function ajax_bulk_approve_duplicates() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		if ( 1 !== (int) get_option( 'respira_enable_bulk_approvals', 0 ) ) {
			wp_send_json_error( array( 'message' => __( 'Bulk approvals are disabled in settings.', 'respira-for-wordpress' ) ) );
		}

		$duplicate_ids_raw = isset( $_POST['duplicate_ids'] ) ? (array) wp_unslash( $_POST['duplicate_ids'] ) : array();
		$duplicate_ids     = array_values( array_unique( array_filter( array_map( 'absint', $duplicate_ids_raw ) ) ) );

		if ( empty( $duplicate_ids ) ) {
			wp_send_json_error( array( 'message' => __( 'No duplicates selected.', 'respira-for-wordpress' ) ) );
		}

		$results                          = array();
		$summary                          = array(
			'total'    => count( $duplicate_ids ),
			'approved' => 0,
			'failed'   => 0,
		);
		$current_user_id                  = get_current_user_id();
		$show_testimonial_modal           = false;
		$testimonial_prompt_approval_count = 0;

		foreach ( $duplicate_ids as $duplicate_id ) {
			$result = Respira_Approver::approve_duplicate(
				$duplicate_id,
				array(
					'force'       => false,
					'allow_force' => current_user_can( 'manage_options' ),
				)
			);

			if ( is_wp_error( $result ) ) {
				$summary['failed']++;
				$results[] = array(
					'duplicate_id' => $duplicate_id,
					'success'      => false,
					'code'         => $result->get_error_code(),
					'message'      => $result->get_error_message(),
					'data'         => $result->get_error_data(),
				);
				continue;
			}

			$summary['approved']++;
			$tracking = $this->track_approval_and_testimonial_prompt( $current_user_id );
			if ( ! $show_testimonial_modal && ! empty( $tracking['show_testimonial_modal'] ) ) {
				$show_testimonial_modal            = true;
				$testimonial_prompt_approval_count = (int) $tracking['approval_count'];
			}
			$results[] = array(
				'duplicate_id'   => $duplicate_id,
				'success'        => true,
				'approval_mode'  => is_array( $result ) && ! empty( $result['approval_mode'] ) ? (string) $result['approval_mode'] : 'swap_duplicate_live',
				'approval_count' => (int) $tracking['approval_count'],
				'result'         => $result,
			);
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: approved count, 2: failed count, 3: total count */
					__( 'Bulk approval finished: %1$d approved, %2$d failed, out of %3$d selected.', 'respira-for-wordpress' ),
					$summary['approved'],
					$summary['failed'],
					$summary['total']
				),
				'summary'                          => $summary,
				'results'                          => $results,
				'show_testimonial_modal'           => $show_testimonial_modal,
				'testimonial_prompt_approval_count' => $testimonial_prompt_approval_count,
			)
		);
	}

	/**
	 * AJAX handler for rejecting duplicates.
	 *
	 * @since 1.4.2
	 */
	public function ajax_reject_duplicate() {
		// Verify nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		// Get duplicate ID.
		$duplicate_id = isset( $_POST['duplicate_id'] ) ? absint( $_POST['duplicate_id'] ) : 0;
		if ( ! $duplicate_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid duplicate ID.', 'respira-for-wordpress' ) ) );
		}

		// Reject the duplicate.
		$result = Respira_Approver::reject_duplicate( $duplicate_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Duplicate rejected and deleted successfully.', 'respira-for-wordpress' ),
			)
		);
	}

	/**
	 * AJAX handler for submitting testimonials.
	 *
	 * @since 1.8.0
	 */
	public function ajax_submit_testimonial() {
		// Verify nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		// Get form data.
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$testimonial = isset( $_POST['testimonial'] ) ? sanitize_textarea_field( wp_unslash( $_POST['testimonial'] ) ) : '';
		$rating = isset( $_POST['rating'] ) ? absint( $_POST['rating'] ) : 0;
		$anonymous_name = isset( $_POST['anonymous_name'] ) && '1' === $_POST['anonymous_name'];
		$anonymous_website = isset( $_POST['anonymous_website'] ) && '1' === $_POST['anonymous_website'];
		$website_url = isset( $_POST['website_url'] ) ? esc_url_raw( wp_unslash( $_POST['website_url'] ) ) : '';

		// Validate required fields.
		if ( empty( $name ) || empty( $testimonial ) || empty( $rating ) || $rating < 1 || $rating > 5 ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in all required fields.', 'respira-for-wordpress' ) ) );
		}

		// Submit testimonial to Supabase via API
		$api_url = 'https://respira.press/api/reviews/submit-from-plugin';
		$response = wp_remote_post(
			$api_url,
			array(
				'timeout' => 15,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'name'             => $name,
						'testimonial'      => $testimonial,
						'rating'           => $rating,
						'anonymous_name'   => $anonymous_name ? '1' : '0',
						'anonymous_website' => $anonymous_website ? '1' : '0',
						'website_url'      => $website_url,
					)
				),
			)
		);

		// Check for API errors
		if ( is_wp_error( $response ) ) {
			// API call failed - fallback to local storage
			$testimonials = get_option( 'respira_testimonials_pending', array() );
			$testimonials[] = array(
				'name'            => $name,
				'testimonial'     => $testimonial,
				'rating'          => $rating,
				'anonymous_name'  => $anonymous_name,
				'anonymous_website' => $anonymous_website,
				'website_url'     => $website_url,
				'submitted_at'    => current_time( 'mysql' ),
				'submitted_by'    => get_current_user_id(),
				'sync_error'      => $response->get_error_message(),
			);
			update_option( 'respira_testimonials_pending', $testimonials );
			$this->mark_user_testimonial_submitted( get_current_user_id() );

			wp_send_json_success(
				array(
					'message' => __( 'Testimonial saved locally. There was an issue syncing to our server, but it will be reviewed.', 'respira-for-wordpress' ),
				)
			);
			return;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( 200 !== $response_code || ! isset( $response_data['success'] ) || ! $response_data['success'] ) {
			// API call failed - fallback to local storage
			$error_message = isset( $response_data['error'] ) ? $response_data['error'] : __( 'Unknown error', 'respira-for-wordpress' );
			$testimonials = get_option( 'respira_testimonials_pending', array() );
			$testimonials[] = array(
				'name'            => $name,
				'testimonial'     => $testimonial,
				'rating'          => $rating,
				'anonymous_name'  => $anonymous_name,
				'anonymous_website' => $anonymous_website,
				'website_url'     => $website_url,
				'submitted_at'    => current_time( 'mysql' ),
				'submitted_by'    => get_current_user_id(),
				'sync_error'      => $error_message,
			);
			update_option( 'respira_testimonials_pending', $testimonials );
			$this->mark_user_testimonial_submitted( get_current_user_id() );

			wp_send_json_success(
				array(
					'message' => __( 'Testimonial saved locally. There was an issue syncing to our server, but it will be reviewed.', 'respira-for-wordpress' ),
				)
			);
			return;
		}

		// Successfully submitted to Supabase
		$this->mark_user_testimonial_submitted( get_current_user_id() );
		wp_send_json_success(
			array(
				'message' => __( 'Testimonial submitted successfully! It will be reviewed by our team.', 'respira-for-wordpress' ),
			)
		);
	}

	/**
	 * Increment approval count and determine whether testimonial prompt should show.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return array{approval_count:int,show_testimonial_modal:bool}
	 */
	private function track_approval_and_testimonial_prompt( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return array(
				'approval_count'         => 0,
				'show_testimonial_modal' => false,
			);
		}

		$approval_count = $this->increment_user_approval_count( $user_id );

		return array(
			'approval_count'         => $approval_count,
			'show_testimonial_modal' => $this->should_show_testimonial_prompt_for_approval( $user_id, $approval_count ),
		);
	}

	/**
	 * Increment and persist per-user approval count.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return int
	 */
	private function increment_user_approval_count( $user_id ) {
		$current_count = $this->get_user_approval_count( $user_id );
		$next_count    = $current_count + 1;
		update_user_meta( $user_id, self::TESTIMONIAL_APPROVAL_COUNT_META_KEY, $next_count );

		return $next_count;
	}

	/**
	 * Get per-user approval count and bootstrap from historical approvals.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return int
	 */
	private function get_user_approval_count( $user_id ) {
		$stored_count = get_user_meta( $user_id, self::TESTIMONIAL_APPROVAL_COUNT_META_KEY, true );
		if ( '' !== $stored_count && null !== $stored_count ) {
			return max( 0, (int) $stored_count );
		}

		$historical_query = new WP_Query(
			array(
				'post_type'      => 'any',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_respira_approved_by',
						'value'   => (string) $user_id,
						'compare' => '=',
					),
				),
			)
		);
		$historical_count = (int) $historical_query->found_posts;
		wp_reset_postdata();

		update_user_meta( $user_id, self::TESTIMONIAL_APPROVAL_COUNT_META_KEY, $historical_count );

		return $historical_count;
	}

	/**
	 * Decide whether testimonial prompt should be shown for this approval count.
	 *
	 * @since 4.0.12
	 * @param int $user_id        Current user ID.
	 * @param int $approval_count Approval count after current action.
	 * @return bool
	 */
	private function should_show_testimonial_prompt_for_approval( $user_id, $approval_count ) {
		if ( $this->has_user_submitted_testimonial( $user_id ) ) {
			return false;
		}

		if ( ! in_array( (int) $approval_count, self::TESTIMONIAL_PROMPT_MILESTONES, true ) ) {
			return false;
		}

		$shown_milestones = $this->get_user_testimonial_prompt_shown_milestones( $user_id );
		if ( in_array( (int) $approval_count, $shown_milestones, true ) ) {
			return false;
		}

		$shown_milestones[] = (int) $approval_count;
		sort( $shown_milestones, SORT_NUMERIC );
		update_user_meta( $user_id, self::TESTIMONIAL_PROMPT_SHOWN_META_KEY, array_values( array_unique( $shown_milestones ) ) );

		return true;
	}

	/**
	 * Read stored approval milestones where prompt was already shown.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return array<int,int>
	 */
	private function get_user_testimonial_prompt_shown_milestones( $user_id ) {
		$stored = get_user_meta( $user_id, self::TESTIMONIAL_PROMPT_SHOWN_META_KEY, true );
		if ( empty( $stored ) ) {
			return array();
		}

		if ( ! is_array( $stored ) ) {
			$stored = array( $stored );
		}

		$milestones = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', $stored )
				)
			)
		);
		sort( $milestones, SORT_NUMERIC );

		return $milestones;
	}

	/**
	 * Mark testimonial as submitted for this user.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return void
	 */
	private function mark_user_testimonial_submitted( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return;
		}

		update_user_meta( $user_id, self::TESTIMONIAL_SUBMITTED_META_KEY, current_time( 'mysql' ) );
	}

	/**
	 * Check if the user already submitted testimonial from this plugin.
	 *
	 * @since 4.0.12
	 * @param int $user_id Current user ID.
	 * @return bool
	 */
	private function has_user_submitted_testimonial( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		$submitted_at = get_user_meta( $user_id, self::TESTIMONIAL_SUBMITTED_META_KEY, true );
		if ( ! empty( $submitted_at ) ) {
			return true;
		}

		$pending = get_option( 'respira_testimonials_pending', array() );
		if ( ! is_array( $pending ) || empty( $pending ) ) {
			return false;
		}

		foreach ( $pending as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$submitted_by = isset( $entry['submitted_by'] ) ? absint( $entry['submitted_by'] ) : 0;
			if ( $submitted_by === $user_id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * AJAX handler for updating the plugin.
	 *
	 * @since 1.8.7
	 */
	public function ajax_update_plugin() {
		// Verify nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		// Check if update is available.
		$update_info = Respira_Updater::check_update_available();
		if ( ! $update_info || ! $update_info['available'] ) {
			wp_send_json_error( array( 'message' => __( 'No update available.', 'respira-for-wordpress' ) ) );
		}

		// Include required WordPress files.
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
			if ( file_exists( ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php' ) ) {
				require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
			}
			if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) && file_exists( ABSPATH . 'wp-admin/includes/class-wp-upgrader-skin.php' ) ) {
				require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader-skin.php';
			}
		}
		if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
			wp_send_json_error(
				array(
					'message'           => __( 'Update UI is unavailable on this WordPress version. Please update from WordPress Updates page.', 'respira-for-wordpress' ),
					'manual_update_url' => self_admin_url( 'update-core.php?force-check=1' ),
				)
			);
		}

		// Get the plugin basename.
		$plugin_basename = RESPIRA_PLUGIN_BASENAME;
		$was_active      = is_plugin_active( $plugin_basename );

		// Get download URL from update server.
		$updater = new Respira_Updater();
		$release_info = $updater->get_latest_release();
		
		if ( is_wp_error( $release_info ) || ! isset( $release_info['download_url'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Failed to get update package URL.', 'respira-for-wordpress' ) ) );
		}

		$download_url = $release_info['download_url'];
		
		// If it's a GitHub URL, use proxy endpoint.
		if ( strpos( $download_url, 'github.com/repos' ) !== false || strpos( $download_url, 'githubusercontent.com' ) !== false ) {
			$download_url = add_query_arg(
				array( 'version' => $release_info['version'] ),
				'https://respira.press/api/plugin-updates/download'
			);
		}

		$skin = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );

		// Perform the update using the package URL.
		ob_start();
		$result = $upgrader->run(
			array(
				'package'                     => $download_url,
				'destination'                 => WP_PLUGIN_DIR,
				'clear_destination'           => true,
				'clear_working'               => true,
				'hook_extra'                  => array(
					'plugin' => $plugin_basename,
					'type'   => 'plugin',
					'action' => 'update',
					),
				)
		);
		$upgrader_output = trim( (string) ob_get_clean() );

		if ( is_wp_error( $result ) ) {
			$message = $result->get_error_message();
			if ( empty( $message ) ) {
				$message = __( 'Update failed. Please try again or update manually.', 'respira-for-wordpress' );
			}
			wp_send_json_error(
				array(
					'message'           => $message,
					'manual_update_url' => self_admin_url( 'update-core.php?force-check=1' ),
				)
			);
		}

		if ( false === $result ) {
			$errors = $skin->get_errors();
			$error_message = '';

			if ( is_wp_error( $errors ) ) {
				$error_message = implode(
					' ',
					array_filter(
						array_map(
							'trim',
							(array) $errors->get_error_messages()
						)
					)
				);
			} elseif ( is_array( $errors ) ) {
				$error_message = implode( ' ', array_filter( array_map( 'trim', $errors ) ) );
			} elseif ( is_string( $errors ) ) {
				$error_message = trim( $errors );
			}

			if ( empty( $error_message ) && ! empty( $upgrader_output ) ) {
				$error_message = trim( wp_strip_all_tags( $upgrader_output ) );
			}
			if ( empty( $error_message ) ) {
				$error_message = __( 'Update failed. Please try again or update manually.', 'respira-for-wordpress' );
			}

			wp_send_json_error(
				array(
					'message'           => $error_message,
					'manual_update_url' => self_admin_url( 'update-core.php?force-check=1' ),
				)
			);
		}

		// Clear update cache.
		Respira_Updater::clear_cache();
		delete_site_transient( 'update_plugins' );
		wp_clean_plugins_cache( true );

		// Activate the plugin if it was active before.
		if ( $was_active ) {
			$activation_result = activate_plugin( $plugin_basename );
			if ( is_wp_error( $activation_result ) ) {
				wp_send_json_success(
					array(
						'message' => __( 'Plugin updated, but activation requires confirmation on the Plugins page.', 'respira-for-wordpress' ),
					)
				);
			}
		}

		wp_send_json_success( array( 'message' => __( 'Plugin updated successfully!', 'respira-for-wordpress' ) ) );
	}

	/**
	 * AJAX handler: install a skill by downloading SKILL.md from GitHub.
	 *
	 * Downloads the raw SKILL.md for the given slug and saves it to
	 * .claude/commands/{slug}.md relative to ABSPATH.
	 *
	 * @since 4.3.0
	 * @return void
	 */
	public function ajax_install_skill() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'respira_admin_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'respira-for-wordpress' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ) );
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_file_name( wp_unslash( $_POST['slug'] ) ) : '';
		if ( empty( $slug ) ) {
			wp_send_json_error( array( 'message' => __( 'Skill slug is required.', 'respira-for-wordpress' ) ) );
		}

		$raw_url  = 'https://raw.githubusercontent.com/webmyc/claude-skills-wordpress/main/skills/' . $slug . '/SKILL.md';
		$response = wp_remote_get( $raw_url, array( 'timeout' => 20 ) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: error message */
						__( 'Failed to download skill: %s', 'respira-for-wordpress' ),
						$response->get_error_message()
					),
				)
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %d: HTTP status code */
						__( 'Failed to download skill (HTTP %d).', 'respira-for-wordpress' ),
						$code
					),
				)
			);
		}

		$content = wp_remote_retrieve_body( $response );
		if ( empty( $content ) ) {
			wp_send_json_error( array( 'message' => __( 'Downloaded skill file is empty.', 'respira-for-wordpress' ) ) );
		}

		// Determine the target directory.
		$commands_dir = ABSPATH . '.claude/commands';

		// Create directory if it doesn't exist.
		if ( ! is_dir( $commands_dir ) ) {
			if ( ! wp_mkdir_p( $commands_dir ) ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: directory path */
							__( 'Could not create directory: %s. Check file permissions.', 'respira-for-wordpress' ),
							$commands_dir
						),
					)
				);
			}
		}

		$target_file = $commands_dir . '/' . $slug . '.md';

		// Write the file.
		$written = file_put_contents( $target_file, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( false === $written ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: file path */
						__( 'Could not write skill file to %s. Check file permissions.', 'respira-for-wordpress' ),
						$target_file
					),
				)
			);
		}

		// Track skill installation (non-blocking, best-effort).
		try {
			if ( ! class_exists( 'Respira_Usage_Tracker' ) ) {
				require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-usage-tracker.php';
			}
			Respira_Usage_Tracker::track( 'install_skill', $slug, 0 );
		} catch ( \Exception $e ) {
			// Tracking is non-critical — never block the install response.
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %s: file path */
					__( 'Skill installed to %s', 'respira-for-wordpress' ),
					'.claude/commands/' . $slug . '.md'
				),
				'path'    => '.claude/commands/' . $slug . '.md',
			)
		);
	}

	// ──────────────────────────────────────────────────────────
	// Changes page AJAX handlers
	// ──────────────────────────────────────────────────────────

	/**
	 * AJAX: list posts with Respira activity (for Changes page).
	 *
	 * Returns posts that have snapshots or pending duplicates,
	 * ordered by most recent activity.
	 *
	 * @since 5.0.0
	 */
	public function ajax_changes_list_posts() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		global $wpdb;

		$per_page  = min( 50, max( 1, absint( $_GET['per_page'] ?? 20 ) ) );
		$cursor    = ! empty( $_GET['cursor'] ) ? sanitize_text_field( wp_unslash( $_GET['cursor'] ) ) : '';
		$search    = ! empty( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
		$post_type = ! empty( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '';

		$table = ( class_exists( 'Respira_Snapshots' ) )
			? Respira_Snapshots::get_instance()->table_name()
			: $wpdb->prefix . 'respira_snapshots';

		// Build WHERE clauses.
		$where_parts  = array();
		$where_values = array();

		if ( $search ) {
			$where_parts[]  = 'p.post_title LIKE %s';
			$where_values[] = '%' . $wpdb->esc_like( $search ) . '%';
		}
		if ( $post_type ) {
			$where_parts[]  = 'p.post_type = %s';
			$where_values[] = $post_type;
		}
		if ( $cursor ) {
			$where_parts[]  = 'latest_activity <= %s';
			$where_values[] = $cursor;
		}

		$where_sql = $where_parts ? 'WHERE ' . implode( ' AND ', $where_parts ) : '';

		// Posts with snapshots (exclude Respira duplicates — they show nested under originals).
		$sql = "SELECT p.ID AS post_id, p.post_title AS title, p.post_type AS type, p.post_status AS status,
		               MAX(s.created_at_gmt) AS latest_snapshot,
		               COUNT(s.id) AS version_count
		        FROM {$wpdb->posts} p
		        INNER JOIN {$table} s ON s.post_id = p.ID
		        LEFT JOIN {$wpdb->postmeta} dup_meta ON dup_meta.post_id = p.ID AND dup_meta.meta_key = '_respira_duplicate' AND dup_meta.meta_value = '1'
		        WHERE p.post_status IN ('publish','draft','private','pending')
		          AND dup_meta.meta_id IS NULL
		        GROUP BY p.ID";

		// Posts with pending duplicates (may not have snapshots yet).
		// Uses (meta_value + 0) for implicit integer cast — works on both MySQL and SQLite.
		$dup_sql = "SELECT orig.ID AS post_id, orig.post_title AS title, orig.post_type AS type, orig.post_status AS status,
		                   dup.post_date_gmt AS latest_snapshot,
		                   0 AS version_count
		            FROM {$wpdb->posts} dup
		            INNER JOIN {$wpdb->postmeta} pm1 ON pm1.post_id = dup.ID AND pm1.meta_key = '_respira_duplicate' AND pm1.meta_value = '1'
		            INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = dup.ID AND pm2.meta_key = '_respira_original_id'
		            INNER JOIN {$wpdb->posts} orig ON orig.ID = (pm2.meta_value + 0)
		            WHERE dup.post_status IN ('draft','pending','publish')";

		// Wrap in a subquery to merge and deduplicate.
		// Uses unparenthesized UNION ALL for SQLite compatibility.
		$combined = "SELECT sub.post_id, MAX(sub.title) AS title, MAX(sub.type) AS type, MAX(sub.status) AS status,
		                    MAX(sub.latest_snapshot) AS latest_activity,
		                    MAX(sub.version_count) AS version_count
		             FROM ( {$sql} UNION ALL {$dup_sql} ) AS sub
		             GROUP BY sub.post_id";

		// Apply outer filters.
		$outer_where = array();
		$outer_vals  = array();
		if ( $search ) {
			$outer_where[] = 'title LIKE %s';
			$outer_vals[]  = '%' . $wpdb->esc_like( $search ) . '%';
		}
		if ( $post_type ) {
			$outer_where[] = 'type = %s';
			$outer_vals[]  = $post_type;
		}
		if ( $cursor ) {
			$outer_where[] = 'latest_activity <= %s';
			$outer_vals[]  = $cursor;
		}

		$outer_where_sql = $outer_where ? 'WHERE ' . implode( ' AND ', $outer_where ) : '';

		$final = "SELECT * FROM ({$combined}) AS combined {$outer_where_sql} ORDER BY latest_activity DESC LIMIT %d";
		$outer_vals[] = $per_page + 1;

		if ( ! empty( $outer_vals ) ) {
			$final = $wpdb->prepare( $final, ...$outer_vals ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$rows = $wpdb->get_results( $final, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$has_more = count( $rows ) > $per_page;
		if ( $has_more ) {
			array_pop( $rows );
		}

		// Enrich each post with pending duplicate info.
		$posts = array();
		foreach ( $rows as $row ) {
			$post_id = (int) $row['post_id'];

			// Check for pending duplicate.
			$duplicate = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT dup.ID, dup.post_title, dup.post_status, dup.post_date_gmt
					 FROM {$wpdb->posts} dup
					 INNER JOIN {$wpdb->postmeta} pm1 ON pm1.post_id = dup.ID AND pm1.meta_key = '_respira_duplicate' AND pm1.meta_value = '1'
					 INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = dup.ID AND pm2.meta_key = '_respira_original_id' AND pm2.meta_value = %s
					 WHERE dup.post_status IN ('draft','pending')
					 ORDER BY dup.post_date DESC
					 LIMIT 1",
					(string) $post_id
				),
				ARRAY_A
			);

			$posts[] = array(
				'post_id'                => $post_id,
				'title'                  => $row['title'],
				'type'                   => $row['type'],
				'status'                 => $row['status'],
				'has_pending_duplicate'  => ! empty( $duplicate ),
				'duplicate_id'           => $duplicate ? (int) $duplicate['ID'] : null,
				'duplicate_title'        => $duplicate ? $duplicate['post_title'] : null,
				'duplicate_status'       => $duplicate ? $duplicate['post_status'] : null,
				'duplicate_created'      => $duplicate ? $duplicate['post_date_gmt'] : null,
				'latest_activity'        => $row['latest_activity'],
				'version_count'          => (int) $row['version_count'],
			);
		}

		$next_cursor = $has_more && ! empty( $rows ) ? end( $rows )['latest_activity'] : null;

		wp_send_json_success( array(
			'posts'       => $posts,
			'has_more'    => $has_more,
			'next_cursor' => $next_cursor,
		) );
	}

	/**
	 * AJAX: get post detail (versions + duplicate info) for Changes page.
	 *
	 * @since 5.0.0
	 */
	public function ajax_changes_post_detail() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$post_id = absint( $_GET['post_id'] ?? 0 );
		if ( ! $post_id ) {
			wp_send_json_error( 'Missing post_id' );
		}

		$per_page = min( 50, max( 1, absint( $_GET['versions_per_page'] ?? 10 ) ) );
		$cursor   = ! empty( $_GET['versions_cursor'] ) ? sanitize_text_field( wp_unslash( $_GET['versions_cursor'] ) ) : '';

		$data = array(
			'post_id'              => $post_id,
			'permalink'            => get_permalink( $post_id ),
			'versions'             => array(),
			'versions_has_more'    => false,
			'duplicate'            => null,
			'duplicate_versions'   => array(),
		);

		// Get versions (snapshots) for this post.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snapshots = Respira_Snapshots::get_instance();
			$args      = array(
				'post_id' => $post_id,
				'limit'   => $per_page,
			);
			if ( $cursor ) {
				$args['cursor'] = $cursor;
			}
			$result = $snapshots->list_snapshots( $args );

			global $wpdb;
			$table = $snapshots->table_name();
			$items = $result['items'] ?? array();

			// Enrich with pinned status.
			$uuids = array_filter( array_map( function ( $s ) {
				return $s['snapshot_uuid'] ?? '';
			}, $items ) );

			$pinned_map = array();
			if ( ! empty( $uuids ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $uuids ), '%s' ) );
				$pinned_rows  = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT snapshot_uuid, pinned FROM {$table} WHERE snapshot_uuid IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
						...$uuids
					),
					ARRAY_A
				);
				foreach ( (array) $pinned_rows as $pr ) {
					$pinned_map[ $pr['snapshot_uuid'] ] = (int) $pr['pinned'];
				}
			}

			foreach ( $items as $item ) {
				$data['versions'][] = array(
					'uuid'          => $item['snapshot_uuid'] ?? '',
					'kind'          => $item['kind'] ?? '',
					'created_at'    => $item['created_at_gmt'] ?? '',
					'payload_bytes' => (int) ( $item['payload_bytes'] ?? 0 ),
					'pinned'        => (bool) ( $pinned_map[ $item['snapshot_uuid'] ?? '' ] ?? 0 ),
					'builder'       => $item['builder'] ?? '',
					'actor'         => $item['actor'] ?? '',
					'label'         => $item['label'] ?? '',
				);
			}

			$data['versions_has_more'] = ! empty( $result['next_cursor'] );
		}

		// Check for pending duplicate.
		global $wpdb;
		$duplicate = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT dup.ID, dup.post_title, dup.post_status, dup.post_date_gmt
				 FROM {$wpdb->posts} dup
				 INNER JOIN {$wpdb->postmeta} pm1 ON pm1.post_id = dup.ID AND pm1.meta_key = '_respira_duplicate' AND pm1.meta_value = '1'
				 INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = dup.ID AND pm2.meta_key = '_respira_original_id' AND pm2.meta_value = %s
				 WHERE dup.post_status IN ('draft','pending')
				 ORDER BY dup.post_date DESC
				 LIMIT 1",
				(string) $post_id
			),
			ARRAY_A
		);

		if ( $duplicate ) {
			$dup_id = (int) $duplicate['ID'];
			$data['duplicate'] = array(
				'id'            => $dup_id,
				'title'         => $duplicate['post_title'],
				'status'        => $duplicate['post_status'],
				'created_at'    => $duplicate['post_date_gmt'],
				'original_id'   => $post_id,
				'original_url'  => get_permalink( $post_id ),
				'duplicate_url' => get_preview_post_link( $dup_id ) ?: get_permalink( $dup_id ),
			);

			// Get duplicate's snapshots.
			if ( class_exists( 'Respira_Snapshots' ) ) {
				$dup_result = $snapshots->list_snapshots( array(
					'post_id' => (int) $duplicate['ID'],
					'limit'   => 10,
				) );

				foreach ( ( $dup_result['items'] ?? array() ) as $ds ) {
					$data['duplicate_versions'][] = array(
						'uuid'          => $ds['snapshot_uuid'] ?? '',
						'kind'          => $ds['kind'] ?? '',
						'created_at'    => $ds['created_at_gmt'] ?? '',
						'payload_bytes' => (int) ( $ds['payload_bytes'] ?? 0 ),
						'pinned'        => false,
						'builder'       => $ds['builder'] ?? '',
						'label'         => $ds['label'] ?? '',
					);
				}
			}
		}

		wp_send_json_success( $data );
	}

	/**
	 * AJAX: list snapshots (paginated, filterable).
	 *
	 * @since 5.0.0
	 */
	public function ajax_list_snapshots() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		if ( ! class_exists( 'Respira_Snapshots' ) ) {
			wp_send_json_error( 'Snapshots not available' );
		}

		$args = array(
			'limit' => min( 50, max( 1, absint( $_GET['per_page'] ?? 20 ) ) ),
		);

		if ( ! empty( $_GET['post_id'] ) ) {
			$args['post_id'] = absint( $_GET['post_id'] );
		}
		if ( ! empty( $_GET['kind'] ) ) {
			$args['kind'] = sanitize_key( $_GET['kind'] );
		}
		if ( ! empty( $_GET['cursor'] ) ) {
			$args['cursor'] = sanitize_text_field( wp_unslash( $_GET['cursor'] ) );
		}

		$snapshots = Respira_Snapshots::get_instance();
		$result    = $snapshots->list_snapshots( $args );

		// Enrich with post titles and pinned status.
		global $wpdb;
		$table = $snapshots->table_name();
		$items = $result['items'] ?? array();

		$post_ids = array_unique( array_filter( array_map( function ( $s ) {
			return (int) ( $s['post_id'] ?? 0 );
		}, $items ) ) );

		$titles_map = array();
		if ( ! empty( $post_ids ) ) {
			$ids_sql    = implode( ',', array_map( 'absint', $post_ids ) );
			$posts_data = $wpdb->get_results( "SELECT ID, post_title, post_type FROM {$wpdb->posts} WHERE ID IN ({$ids_sql})", ARRAY_A );
			foreach ( (array) $posts_data as $p ) {
				$titles_map[ (int) $p['ID'] ] = array(
					'title' => $p['post_title'],
					'type'  => $p['post_type'],
				);
			}
		}

		// Get pinned status for these snapshots.
		$uuids = array_filter( array_map( function ( $s ) {
			return $s['snapshot_uuid'] ?? '';
		}, $items ) );

		$pinned_map = array();
		if ( ! empty( $uuids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $uuids ), '%s' ) );
			$pinned_rows  = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT snapshot_uuid, pinned FROM {$table} WHERE snapshot_uuid IN ({$placeholders})",
					...$uuids
				),
				ARRAY_A
			);
			foreach ( (array) $pinned_rows as $pr ) {
				$pinned_map[ $pr['snapshot_uuid'] ] = (int) $pr['pinned'];
			}
		}

		foreach ( $items as &$item ) {
			$pid = (int) ( $item['post_id'] ?? 0 );
			$item['post_title'] = $titles_map[ $pid ]['title'] ?? '(deleted)';
			$item['post_type_label'] = $titles_map[ $pid ]['type'] ?? 'unknown';
			$item['pinned'] = $pinned_map[ $item['snapshot_uuid'] ?? '' ] ?? 0;
		}
		unset( $item );

		wp_send_json_success( array(
			'snapshots'   => $items,
			'has_more'    => ! empty( $result['next_cursor'] ),
			'next_cursor' => $result['next_cursor'] ?? null,
		) );
	}

	/**
	 * AJAX: preview a snapshot (full payload + diff).
	 *
	 * @since 5.0.0
	 */
	public function ajax_preview_snapshot() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$uuid = sanitize_text_field( wp_unslash( $_GET['snapshot_uuid'] ?? '' ) );
		if ( empty( $uuid ) ) {
			wp_send_json_error( 'Missing snapshot_uuid' );
		}

		$snapshots = Respira_Snapshots::get_instance();
		$snapshot  = $snapshots->get_snapshot( $uuid, true );
		if ( is_wp_error( $snapshot ) ) {
			wp_send_json_error( $snapshot->get_error_message() );
		}

		wp_send_json_success( $snapshot );
	}

	/**
	 * AJAX: visual preview — create a temporary draft and return its preview URL.
	 *
	 * @since 5.0.2
	 */
	public function ajax_visual_preview_snapshot() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$uuid = sanitize_text_field( wp_unslash( $_POST['snapshot_uuid'] ?? '' ) );
		if ( empty( $uuid ) ) {
			wp_send_json_error( 'Missing snapshot_uuid' );
		}

		$snapshots = Respira_Snapshots::get_instance();
		$result    = $snapshots->create_preview_draft( $uuid );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: restore a snapshot.
	 *
	 * @since 5.0.0
	 */
	public function ajax_restore_snapshot() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$uuid = sanitize_text_field( wp_unslash( $_POST['snapshot_uuid'] ?? '' ) );
		if ( empty( $uuid ) ) {
			wp_send_json_error( 'Missing snapshot_uuid' );
		}

		$snapshots = Respira_Snapshots::get_instance();
		$result    = $snapshots->restore_snapshot( $uuid );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: pin or unpin a snapshot.
	 *
	 * @since 5.0.0
	 */
	public function ajax_pin_snapshot() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$uuid   = sanitize_text_field( wp_unslash( $_POST['snapshot_uuid'] ?? '' ) );
		$pinned = (int) ( $_POST['pinned'] ?? 0 );
		if ( empty( $uuid ) ) {
			wp_send_json_error( 'Missing snapshot_uuid' );
		}

		$snapshots = Respira_Snapshots::get_instance();
		$ok        = $snapshots->set_pinned( $uuid, (bool) $pinned );
		if ( ! $ok ) {
			wp_send_json_error( 'Failed to update pin status' );
		}

		wp_send_json_success( array( 'pinned' => $pinned ) );
	}

	/**
	 * AJAX: get storage stats.
	 *
	 * @since 5.0.0
	 */
	public function ajax_snapshot_storage_stats() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$snapshots = Respira_Snapshots::get_instance();
		wp_send_json_success( $snapshots->get_storage_stats() );
	}

	/**
	 * AJAX: purge old unpinned snapshots.
	 *
	 * @since 5.0.0
	 */
	public function ajax_purge_old_snapshots() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$age_days  = max( 1, absint( $_POST['age_days'] ?? 30 ) );
		$snapshots = Respira_Snapshots::get_instance();
		wp_send_json_success( $snapshots->purge_old_snapshots( $age_days ) );
	}

	/**
	 * AJAX: delete specific snapshots by UUID.
	 *
	 * @since 5.0.0
	 */
	public function ajax_delete_snapshots() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$raw_uuids = $_POST['uuids'] ?? array();
		if ( ! is_array( $raw_uuids ) || empty( $raw_uuids ) ) {
			wp_send_json_error( 'No snapshots selected' );
		}

		$uuids     = array_map( 'sanitize_text_field', $raw_uuids );
		$snapshots = Respira_Snapshots::get_instance();
		wp_send_json_success( $snapshots->delete_snapshots( $uuids ) );
	}

	/**
	 * AJAX: delete all unpinned snapshots for a specific post.
	 *
	 * @since 5.0.5
	 */
	public function ajax_delete_post_snapshots() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$post_id = absint( $_POST['post_id'] ?? 0 );
		if ( ! $post_id ) {
			wp_send_json_error( 'Missing post_id' );
		}

		$snapshots = Respira_Snapshots::get_instance();
		wp_send_json_success( $snapshots->delete_post_snapshots( $post_id ) );
	}

	/**
	 * AJAX: purge ALL unpinned snapshots (regardless of age).
	 *
	 * @since 5.0.5
	 */
	public function ajax_purge_all_snapshots() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$snapshots = Respira_Snapshots::get_instance();
		// Pass age_days=0 to delete all unpinned snapshots.
		wp_send_json_success( $snapshots->purge_old_snapshots( 0 ) );
	}

	/**
	 * AJAX: search posts by title for the snapshot filter dropdown.
	 *
	 * @since 5.0.0
	 */
	public function ajax_search_posts() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$q = sanitize_text_field( wp_unslash( $_GET['q'] ?? '' ) );
		if ( strlen( $q ) < 2 ) {
			wp_send_json_success( array() );
		}

		$posts = get_posts( array(
			's'              => $q,
			'post_type'      => 'any',
			'post_status'    => array( 'publish', 'draft', 'private', 'pending' ),
			'posts_per_page' => 20,
			'orderby'        => 'relevance',
		) );

		$results = array();
		foreach ( $posts as $post ) {
			$results[] = array(
				'id'    => $post->ID,
				'title' => $post->post_title ?: '(no title)',
				'type'  => $post->post_type,
			);
		}

		wp_send_json_success( $results );
	}

	/**
	 * AJAX: dismiss v5 upgrade notice.
	 *
	 * @since 5.0.0
	 */
	public function ajax_dismiss_v5_notice() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );
		update_option( 'respira_last_seen_version', RESPIRA_VERSION );
		wp_send_json_success();
	}

	/**
	 * Render v5 upgrade admin notice.
	 *
	 * @since 5.0.0
	 */
	public function maybe_render_v5_upgrade_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$last_seen = (string) get_option( 'respira_last_seen_version', '' );
		if ( version_compare( $last_seen, '5.0.0', '>=' ) ) {
			return;
		}

		$changes_url = admin_url( 'admin.php?page=respira-changes' );
		$release_url = 'https://www.respira.press/releases/5.0.0';
		$nonce       = wp_create_nonce( 'respira_admin_nonce' );
		?>
		<div class="notice notice-info is-dismissible respira-v5-notice" data-nonce="<?php echo esc_attr( $nonce ); ?>">
			<p><strong>Respira 5.0 Haven</strong> — every AI edit now has an undo button.</p>
			<p>Every edit automatically creates a full-fidelity snapshot — post content, builder data, metadata. Browse, diff, and one-click restore from the new <a href="<?php echo esc_url( $changes_url ); ?>">Changes page</a>. Pending duplicates and version history in a single post-centric timeline.</p>
			<p>⚠️ <strong>Behavior change:</strong> Approving a duplicate now merges into the original, preserving your URLs and menu links. Disable this in <a href="<?php echo esc_url( admin_url( 'admin.php?page=respira-settings' ) ); ?>">Settings → Merge Mode</a> to restore the old swap behavior.</p>
			<p>
				<a href="<?php echo esc_url( $changes_url ); ?>" class="button button-primary">View Changes</a>
				<a href="<?php echo esc_url( $release_url ); ?>" class="button" target="_blank" rel="noopener">Read release notes</a>
			</p>
		</div>
		<script>
		jQuery(function($) {
			$('.respira-v5-notice').on('click', '.notice-dismiss', function() {
				$.post(ajaxurl, {
					action: 'respira_dismiss_v5_notice',
					nonce: $(this).closest('.respira-v5-notice').data('nonce')
				});
			});
		});
		</script>
		<?php
	}

	/**
	 * Render the v5.2.0 "What's New" admin notice.
	 *
	 * Displayed for 7 days after update, dismissed permanently via user_meta.
	 *
	 * @since 5.2.0
	 * @return void
	 */
	public function maybe_render_whats_new_520_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->is_respira_admin_page() ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		// Already dismissed by this user.
		$is_dismissed = get_user_meta( $user_id, self::WHATS_NEW_520_DISMISSED_META_KEY, true );
		if ( ! empty( $is_dismissed ) ) {
			return;
		}

		// Only show for 7 days after the plugin was updated to 5.2.0+.
		$updated_at = get_option( 'respira_updated_at_520', '' );
		if ( empty( $updated_at ) ) {
			// First time rendering — record the timestamp.
			$updated_at = gmdate( 'U' );
			update_option( 'respira_updated_at_520', $updated_at, false );
		}
		if ( ( time() - (int) $updated_at ) > 7 * DAY_IN_SECONDS ) {
			return;
		}

		$whats_new_url = admin_url( 'admin.php?page=respira-whats-new' );
		$nonce         = wp_create_nonce( 'respira_admin_nonce' );
		?>
		<div class="notice notice-info is-dismissible respira-whats-new-520-notice" data-nonce="<?php echo esc_attr( $nonce ); ?>">
			<p>
				<strong><?php esc_html_e( 'Respira v5.2.0 Elemental is here', 'respira-for-wordpress' ); ?></strong>
				&mdash;
				<?php
				printf(
					/* translators: %s: link to What's New page. */
					wp_kses(
						__( '65 new tools including element editing, build_page, HTML conversion, and stock images. <a href="%s">See What\'s New &rarr;</a>', 'respira-for-wordpress' ),
						array( 'a' => array( 'href' => array() ) )
					),
					esc_url( $whats_new_url )
				);
				?>
			</p>
		</div>
		<script>
		jQuery(function($) {
			$('.respira-whats-new-520-notice').on('click', '.notice-dismiss', function() {
				$.post(ajaxurl, {
					action: 'respira_dismiss_whats_new_520',
					nonce: $(this).closest('.respira-whats-new-520-notice').data('nonce')
				});
			});
		});
		</script>
		<?php
	}

	/**
	 * AJAX: dismiss v5.2.0 What's New notice (stored in user_meta).
	 *
	 * @since 5.2.0
	 * @return void
	 */
	public function ajax_dismiss_whats_new_520() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ),
				),
				403
			);
		}

		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'User context not found.', 'respira-for-wordpress' ),
				),
				400
			);
		}

		update_user_meta( $user_id, self::WHATS_NEW_520_DISMISSED_META_KEY, gmdate( 'Y-m-d H:i:s' ) );
		wp_send_json_success(
			array(
				'message' => __( 'Notice dismissed.', 'respira-for-wordpress' ),
			)
		);
	}

	/**
	 * AJAX handler for auto-saving individual settings.
	 *
	 * Accepts: option (string), value (mixed), type (checkbox|number|tags).
	 *
	 * @since 5.2.0
	 */
	public function ajax_save_setting() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ), 403 );
		}

		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		$option = isset( $_POST['option'] ) ? sanitize_key( $_POST['option'] ) : '';
		$type   = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'checkbox';
		$value  = isset( $_POST['value'] ) ? wp_unslash( $_POST['value'] ) : '';

		// Allowlist of options that can be saved via AJAX.
		$allowed = array(
			'respira_auto_duplicate',
			'respira_security_checks',
			'respira_audit_logging',
			'respira_allow_direct_edit',
			'respira_preserve_product_ids_on_approve',
			'respira_enable_bulk_approvals',
			'respira_enable_plugin_management',
			'respira_rate_limit',
			'respira_preserve_id_cpt_slugs',
		);

		if ( ! in_array( $option, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid option.', 'respira-for-wordpress' ) ), 400 );
		}

		// Plugin management availability check.
		if ( 'respira_enable_plugin_management' === $option ) {
			$pm = Respira_Plugin_Manager::get_availability();
			if ( empty( $pm['available'] ) && '1' === (string) $value ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: reason plugin-management feature cannot be enabled. */
							__( 'Plugin management was not enabled: %s', 'respira-for-wordpress' ),
							isset( $pm['reason'] ) ? (string) $pm['reason'] : ''
						),
					),
					400
				);
			}
		}

		$old_value = get_option( $option );

		switch ( $type ) {
			case 'number':
				$value = absint( $value );
				if ( 'respira_rate_limit' === $option ) {
					$value = max( 1, min( 1000, $value ) );
				}
				update_option( $option, $value );
				break;

			case 'tags':
				if ( is_array( $value ) ) {
					$slugs = array_filter( array_map( 'sanitize_key', $value ) );
				} else {
					$slugs = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', (string) $value ) ) ) );
				}
				update_option( $option, implode( ',', $slugs ) );
				break;

			default: // checkbox
				$value = '1' === (string) $value ? 1 : 0;
				update_option( $option, $value );
				break;
		}

		wp_send_json_success(
			array(
				'message'   => __( 'Setting updated.', 'respira-for-wordpress' ),
				'option'    => $option,
				'old_value' => $old_value,
			)
		);
	}
}
