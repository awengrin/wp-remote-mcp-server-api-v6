/**
 * Respira for WordPress - Scoped admin interactions.
 */

(function($) {
	'use strict';

	function getI18n(key, fallback) {
		if (window.respira_admin && window.respira_admin.i18n && window.respira_admin.i18n[key]) {
			return window.respira_admin.i18n[key];
		}
		return fallback;
	}

	function announce(message) {
		var $announcer = $('.respira-admin .respira-admin-announcer').first();
		if (!$announcer.length) {
			return;
		}
		$announcer.text(message || '');
	}

	function copyText(text, onSuccess, onError) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(onSuccess).catch(onError);
			return;
		}

		var $temp = $('<textarea aria-hidden="true">').css({
			position: 'absolute',
			left: '-9999px',
			top: '0'
		}).val(text);
		$('body').append($temp);
		$temp[0].focus();
		$temp[0].select();
		try {
			document.execCommand('copy');
			onSuccess();
		} catch (err) {
			onError(err);
		}
		$temp.remove();
	}

	function withButtonFeedback($btn, label, resetMs) {
		var original = $btn.data('original-label');
		if (!original) {
			original = $btn.text();
			$btn.data('original-label', original);
		}
		$btn.text(label);
		setTimeout(function() {
			$btn.text(original);
		}, resetMs || 1800);
	}

	function setupCopyButtons() {
		$('.respira-admin').on('click', '.respira-copy-btn', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var text = $btn.data('copy');
			if (typeof text === 'object' && text !== null) {
				text = JSON.stringify(text, null, 2);
			}
			if (typeof text !== 'string' || !text.length) {
				return;
			}

			copyText(
				text,
				function() {
					withButtonFeedback($btn, getI18n('copied', 'Copied!'));
					announce(getI18n('copied', 'Copied!'));
				},
				function() {
					withButtonFeedback($btn, getI18n('copy_manual', 'Select and copy manually'));
				}
			);
		});

		$('.respira-admin').on('click', '[data-respira-copy-target]', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var targetId = $btn.attr('data-respira-copy-target');
			var target = targetId ? document.getElementById(targetId) : null;
			if (!target) {
				return;
			}
			var text = target.value || target.textContent || '';
			var copiedLabel = $btn.attr('data-copied-label') || getI18n('copied', 'Copied!');

			copyText(
				text,
				function() {
					withButtonFeedback($btn, copiedLabel);
					announce(copiedLabel);
				},
				function() {
					target.focus();
					if (typeof target.select === 'function') {
						target.select();
					}
				}
			);
		});
	}

	function setupLicenseCheckboxGuards() {
		var forms = [
			{ form: '#respira-dashboard-license-form', btn: '#respira-dash-activate-submit', privacy: '#respira_dash_agree_privacy', terms: '#respira_dash_agree_terms' },
			{ form: '#respira-activate-license-form', btn: '#respira-activate-submit', privacy: '#agree_privacy', terms: '#agree_terms' }
		];

		forms.forEach(function(config) {
			var $form = $(config.form);
			if (!$form.length) {
				return;
			}
			var $btn = $(config.btn);
			var $privacy = $(config.privacy);
			var $terms = $(config.terms);
			var updateState = function() {
				var allowed = $privacy.is(':checked') && $terms.is(':checked');
				$btn.prop('disabled', !allowed);
			};
			$privacy.on('change', updateState);
			$terms.on('change', updateState);
			$form.on('submit', function(ev) {
				if (!($privacy.is(':checked') && $terms.is(':checked'))) {
					ev.preventDefault();
				}
			});
			updateState();
		});
	}

	function setupTabsKeyboardSupport() {
		$('.respira-admin .respira-tabs').each(function() {
			var $tabs = $(this).find('.respira-tab-link');
			$tabs.on('keydown', function(e) {
				if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') {
					return;
				}
				e.preventDefault();
				var index = $tabs.index(this);
				var next = e.key === 'ArrowRight' ? index + 1 : index - 1;
				if (next < 0) {
					next = $tabs.length - 1;
				}
				if (next >= $tabs.length) {
					next = 0;
				}
				$tabs.eq(next).focus();
			});
		});
	}

	function setupPluginUpdates() {
		$('.respira-admin').on('click', '.respira-update-now-button', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $notice = $btn.closest('.respira-update-notification');
			var original = $btn.text();

			$btn.prop('disabled', true).text('Updating...');
			$notice.addClass('is-updating');

			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_update_plugin',
					nonce: $btn.data('nonce')
				}
			}).done(function(response) {
				if (response && response.success) {
					$btn.text('Updated');
					announce('Plugin updated');
					setTimeout(function() { window.location.reload(); }, 1200);
					return;
				}
				$btn.prop('disabled', false).text(original);
				$notice.removeClass('is-updating');
				window.alert((response && response.data && response.data.message) ? response.data.message : getI18n('generic_error', 'An error occurred.'));
			}).fail(function() {
				$btn.prop('disabled', false).text(original);
				$notice.removeClass('is-updating');
				window.alert(getI18n('generic_error', 'An error occurred.'));
			});
		});
	}

	function setupSkillsNoticeDismiss() {
		$(document).on('click', '.respira-skills-published-notice .notice-dismiss', function() {
			var $notice = $(this).closest('.respira-skills-published-notice');
			if ($notice.data('dismissed')) {
				return;
			}
			$notice.data('dismissed', true);

			if (!window.respira_admin || !respira_admin.ajax_url || !respira_admin.nonce) {
				return;
			}

			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_dismiss_skills_notice',
					nonce: respira_admin.nonce
				}
			});
		});
	}

	function setupRemoteNoticeDismiss() {
		$('.respira-admin').on('click', '.respira-remote-notice-dismiss', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $notice = $btn.closest('[data-respira-remote-notice]');
			var noticeKey = ($btn.data('notice') || '').toString();

			if (!noticeKey || !window.respira_admin || !respira_admin.ajax_url || !respira_admin.nonce) {
				return;
			}

			$btn.prop('disabled', true);

			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_dismiss_remote_notice',
					nonce: respira_admin.nonce,
					notice: noticeKey
				}
			}).done(function(response) {
				if (response && response.success) {
					$notice.slideUp(160, function() {
						$notice.remove();
					});
					return;
				}
				$btn.prop('disabled', false);
			}).fail(function() {
				$btn.prop('disabled', false);
			});
		});
	}

	function setupChangesPage() {
		if (!$('#respira-changes-list').length) return;

		var nonce = window.respira_admin ? window.respira_admin.nonce : '';
		var nextCursor = null;
		var currentSearch = '';
		var currentType = '';

		// ── Utility functions ──

		function formatBytes(bytes) {
			if (bytes === 0) return '0 B';
			var k = 1024;
			var sizes = ['B', 'KB', 'MB', 'GB'];
			var i = Math.floor(Math.log(bytes) / Math.log(k));
			return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
		}

		function timeAgo(dateStr) {
			if (!dateStr) return '—';
			var diff = (Date.now() - new Date(dateStr + 'Z').getTime()) / 1000;
			if (diff < 60) return 'just now';
			if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
			if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
			return Math.floor(diff / 86400) + 'd ago';
		}

		function kindBadge(kind) {
			var map = {
				'before_live_edit': { label: 'Before edit', cls: 'amber' },
				'after_live_edit':  { label: 'After edit', cls: 'green' },
				'before_edit':      { label: 'Before patch', cls: 'amber' },
				'after_edit':       { label: 'After patch', cls: 'green' },
				'before_restore':   { label: 'Before restore', cls: 'red' },
				'after_restore':    { label: 'After restore', cls: 'green' },
				'before_approve':   { label: 'Before approve', cls: 'amber' },
				'base':             { label: 'Base', cls: 'blue' },
				'manual':           { label: 'Manual', cls: 'gray' }
			};
			var m = map[kind] || { label: kind, cls: 'gray' };
			return '<span class="respira-badge respira-badge-' + m.cls + '">' + m.label + '</span>';
		}

		function showToast(msg) {
			$('#respira-snapshot-toast').text(msg).fadeIn(200);
			setTimeout(function() { $('#respira-snapshot-toast').fadeOut(400); }, 3000);
		}

		function showModal(title, body, onConfirm) {
			$('#respira-confirm-title').text(title);
			$('#respira-confirm-body').html(body);
			$('#respira-confirm-modal').show();
			$('#respira-confirm-ok').off('click').on('click', function() {
				$('#respira-confirm-modal').hide();
				onConfirm();
			});
		}

		var trapModalFocus = function($modal) {
			var selector = 'a[href],button:not([disabled]),textarea,input,select,[tabindex]:not([tabindex=\"-1\"])';
			var $focusable = $modal.find(selector).filter(':visible');
			if (!$focusable.length) {
				return;
			}
			var first = $focusable.first();
			var last = $focusable.last();
			first.trigger('focus');

			$modal.off('keydown.respiraTrap').on('keydown.respiraTrap', function(event) {
				if (event.key === 'Escape') {
					event.preventDefault();
					$modal.hide().attr('aria-hidden', 'true');
					return;
				}
				if (event.key !== 'Tab') {
					return;
				}
				if (event.shiftKey && document.activeElement === first[0]) {
					event.preventDefault();
					last.trigger('focus');
				} else if (!event.shiftKey && document.activeElement === last[0]) {
					event.preventDefault();
					first.trigger('focus');
				}
			});
		};

		// ── Render helpers ──

		function renderPostCard(post) {
			var pendingBadge = post.has_pending_duplicate
				? '<span class="respira-badge respira-badge-amber">Duplicate pending review</span>'
				: '';
			return '<div class="respira-post-card" data-post-id="' + post.post_id + '">' +
				'<div class="respira-post-card-header">' +
					'<div class="respira-post-card-info">' +
						'<h3 class="respira-post-card-title">' + $('<span>').text(post.title).html() + '</h3>' +
						'<span class="respira-badge respira-badge-cyan">' + post.type + '</span>' +
						pendingBadge +
						'<span class="respira-post-card-meta">' + post.version_count + ' version' + (post.version_count !== 1 ? 's' : '') + ' · ' + timeAgo(post.latest_activity) + '</span>' +
					'</div>' +
					'<button type="button" class="respira-expand-btn" aria-expanded="false">▾</button>' +
				'</div>' +
				'<div class="respira-post-detail" style="display:none;"></div>' +
			'</div>';
		}

		function renderTimeline(versions, hasMore, postId, permalink) {
			if (!versions || !versions.length) return '<p class="respira-no-versions">No versions yet.</p>';
			var html = '';
			if (permalink) {
				html += '<p style="margin:0 0 10px;"><a href="' + $('<span>').text(permalink).html() + '" target="_blank" rel="noopener" class="button" style="text-decoration:none;">View live page ↗</a></p>';
			}
			html += '<div class="respira-timeline-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">' +
				'<span style="font-size:12px; color:#9ca3af;">' + versions.length + ' version' + (versions.length !== 1 ? 's' : '') + '</span>' +
				'<button type="button" class="button respira-delete-all-versions-btn" data-post-id="' + postId + '" style="font-size:11px; padding:2px 8px; color:#fca5a5; border-color:rgba(239,68,68,0.3);">Delete all</button>' +
			'</div>';
			html += '<div class="respira-timeline">';
			versions.forEach(function(v, i) {
				var pinnedClass = v.pinned ? ' is-pinned' : '';
				var pinIcon = v.pinned ? '★' : '☆';
				var num = 'v' + (versions.length - i);
				var labelHtml = v.label ? '<span class="respira-version-label">' + $('<span>').text(v.label).html() + '</span>' : '';
				html += '<div class="respira-version-row' + pinnedClass + '" data-uuid="' + v.uuid + '">' +
					'<span class="respira-version-num">' + num + '</span>' +
					kindBadge(v.kind) +
					labelHtml +
					'<span class="respira-version-meta">' + timeAgo(v.created_at) + '</span>' +
					'<span class="respira-version-meta">' + formatBytes(v.payload_bytes) + '</span>' +
					(v.actor ? '<span class="respira-version-meta respira-version-actor">' + $('<span>').text(v.actor).html() + '</span>' : '') +
					'<div class="respira-version-actions">' +
						'<button type="button" class="respira-pin-btn' + pinnedClass + '" data-uuid="' + v.uuid + '" data-pinned="' + (v.pinned ? 1 : 0) + '" title="' + (v.pinned ? 'Unpin — allow this version to be purged during cleanup' : 'Pin — protect this version from cleanup and purge') + '">' + pinIcon + '</button>' +
						'<button type="button" class="button respira-visual-preview-btn" data-uuid="' + v.uuid + '" style="background:rgba(16,185,129,0.12); border-color:rgba(16,185,129,0.35); color:#6ee7b7;" title="Preview this version — opens the rendered page in a new tab as it looked at this point">Preview ↗</button>' +
						'<button type="button" class="button button-primary respira-restore-btn" data-uuid="' + v.uuid + '" title="Restore this version — replaces current content with this snapshot (current state is saved first)">Revert</button>' +
						'<button type="button" class="respira-delete-version-btn" data-uuid="' + v.uuid + '" title="Delete this version permanently — cannot be undone" style="background:none; border:none; color:#6b7280; cursor:pointer; padding:2px 4px; font-size:14px;">×</button>' +
					'</div>' +
				'</div>';
			});
			if (hasMore) {
				html += '<div class="respira-timeline-loadmore"><button type="button" class="button respira-load-versions-btn" data-post-id="' + postId + '">Load more versions</button></div>';
			}
			html += '</div>';
			return html;
		}

		function renderDuplicateSection(dup, dupVersions) {
			var html = '<div class="respira-duplicate-section" style="border:1px solid rgba(245,158,11,0.3); border-radius:10px; padding:16px; background:linear-gradient(135deg, rgba(245,158,11,0.08), transparent);">' +
				'<h4 style="margin:0 0 8px;"><span class="dashicons dashicons-admin-page" style="color:#f59e0b;"></span> Duplicate — pending review</h4>' +
				'<p style="margin:0 0 12px; color:#b0c4b8;">Compare the original and duplicate pages side by side, then approve or discard.</p>' +
				'<div class="respira-duplicate-info" style="margin-bottom:12px;">' +
					'<span>"' + $('<span>').text(dup.title).html() + '" (' + dup.status + ')</span>' +
					'<span class="respira-version-meta">Created ' + timeAgo(dup.created_at) + '</span>' +
				'</div>' +
				'<div class="respira-duplicate-actions" style="display:flex; gap:8px; flex-wrap:wrap;">' +
					(dup.original_url ? '<a href="' + $('<span>').text(dup.original_url).html() + '" target="_blank" rel="noopener" class="button" style="text-decoration:none;" title="Open the original live page in a new tab to compare">View Original ↗</a>' : '') +
					(dup.duplicate_url ? '<a href="' + $('<span>').text(dup.duplicate_url).html() + '" target="_blank" rel="noopener" class="button" style="text-decoration:none;" title="Open the duplicate draft in a new tab to review changes">View Duplicate ↗</a>' : '') +
					'<button type="button" class="button button-primary respira-apply-btn" data-duplicate-id="' + dup.id + '" data-original-id="' + dup.original_id + '" title="Merge duplicate content into the original post — preserving its URL, ID, and menu links">Approve & Apply</button>' +
					'<button type="button" class="button respira-discard-btn" data-duplicate-id="' + dup.id + '" style="color:#fca5a5; border-color:rgba(239,68,68,0.4);" title="Delete the duplicate permanently — the original page stays unchanged">Discard</button>' +
				'</div>' +
				'<div class="respira-duplicate-message" style="display:none;"></div>';

			if (dupVersions && dupVersions.length) {
				html += '<div class="respira-duplicate-versions" style="margin-top:14px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.08);">' +
					'<h5 style="margin:0 0 8px; color:#b0c4b8;">Duplicate edit history</h5>' +
					renderTimeline(dupVersions, false, dup.id, dup.duplicate_url || '') +
				'</div>';
			}

			html += '</div>';
			return html;
		}

		// ── Core data functions ──

		function loadPosts(append) {
			var params = {
				action: 'respira_changes_list_posts',
				nonce: nonce,
				per_page: 20
			};
			if (currentSearch) params.search = currentSearch;
			if (currentType) params.post_type = currentType;
			if (append && nextCursor) params.cursor = nextCursor;

			if (!append) {
				$('#respira-changes-list').html('<div class="respira-empty-state" id="respira-changes-loading"><span class="spinner is-active" style="float:none;"></span> Loading...</div>');
			}

			$.get(ajaxurl, params, function(res) {
				$('#respira-changes-loading').remove();
				if (!res.success) return;

				var posts = res.data.posts || [];
				if (!append) {
					$('#respira-changes-list').empty();
				}

				if (posts.length === 0 && !append) {
					$('#respira-changes-list').html('<div class="respira-empty-state">No posts with changes found.</div>');
					$('#respira-loadmore-btn').hide();
					return;
				}

				posts.forEach(function(post) {
					$('#respira-changes-list').append(renderPostCard(post));
				});

				nextCursor = res.data.next_cursor || null;
				$('#respira-loadmore-btn').toggle(!!res.data.has_more);
			});
		}

		function expandPost(postId, $card) {
			var $detail = $card.find('.respira-post-detail');
			$detail.html('<span class="spinner is-active" style="float:none;"></span> Loading...');

			$.get(ajaxurl, {
				action: 'respira_changes_post_detail',
				nonce: nonce,
				post_id: postId,
				versions_per_page: 10
			}, function(res) {
				if (!res.success) {
					$detail.html('<p style="color:#ef4444;">Failed to load details.</p>');
					return;
				}

				var html = '';
				var d = res.data;

				// Duplicate section (show first — this is the pending work)
				if (d.duplicate) {
					html += renderDuplicateSection(d.duplicate, d.duplicate_versions || []);
				}

				// Original version history
				html += '<div class="respira-post-versions">';
				if (d.duplicate) {
					html += '<h4 style="margin-top:16px; padding-top:16px; border-top:1px solid rgba(255,255,255,0.08);">Original page — version history</h4>';
				} else {
					html += '<h4>Version history</h4>';
				}
				html += renderTimeline(d.versions || [], d.versions_has_more || false, postId, d.permalink || '');
				html += '</div>';

				$detail.html(html);
			});
		}

		function loadStats() {
			$.get(ajaxurl, { action: 'respira_snapshot_storage_stats', nonce: nonce }, function(res) {
				if (res.success) {
					$('#respira-stat-count').text(res.data.total_count);
					$('#respira-stat-size').text(formatBytes(res.data.total_bytes));
					$('#respira-stat-oldest').text(res.data.oldest_date ? timeAgo(res.data.oldest_date) : 'None');
				}
			});
		}

		// ── Event handlers ──

		// 1. Expand/collapse post — clicking anywhere on the header row
		$(document).on('click', '.respira-post-card-header', function() {
			var $card = $(this).closest('.respira-post-card');
			var $btn = $card.find('.respira-expand-btn');
			var $detail = $card.find('.respira-post-detail');
			var expanded = $btn.attr('aria-expanded') === 'true';

			if (expanded) {
				$detail.slideUp(200);
				$btn.attr('aria-expanded', 'false').text('▾');
			} else {
				$detail.slideDown(200);
				$btn.attr('aria-expanded', 'true').text('▴');
				if (!$detail.children().length) {
					expandPost($card.data('post-id'), $card);
				}
			}
		});

		// 2. Apply duplicate
		$(document).on('click', '.respira-apply-btn', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var duplicateId = $btn.data('duplicate-id');
			var originalId = $btn.data('original-id');
			var $section = $btn.closest('.respira-duplicate-section');
			var $message = $section.find('.respira-duplicate-message');
			var $card = $btn.closest('.respira-post-card');

			var submitApproval = function(forceApproval) {
				$btn.prop('disabled', true).text(getI18n('approving', 'Applying...'));
				$.ajax({
					url: respira_admin.ajax_url,
					type: 'POST',
					dataType: 'json',
					data: {
						action: 'respira_approve_duplicate',
						nonce: nonce,
						duplicate_id: duplicateId,
						original_id: originalId,
						force: forceApproval ? '1' : '0'
					}
				}).done(function(response) {
					if (response && response.success) {
						showToast(response.data.message || 'Duplicate applied.');
						$section.slideUp(200, function() { $section.remove(); });
						// Refresh the post detail
						expandPost($card.data('post-id'), $card);
						// Show testimonial modal if needed
						var shouldShowTestimonialModal = !!(response.data && response.data.show_testimonial_modal);
						if (shouldShowTestimonialModal) {
							var $modal = $('#respira-testimonial-modal');
							if ($modal.length) {
								$modal.show().attr('aria-hidden', 'false');
								trapModalFocus($modal);
							}
						}
						announce(response.data.message || 'Applied');
						return;
					}

					var code = response && response.data ? response.data.code : '';
					if (code === 'respira_stale_base' && window.confirm(getI18n('force_confirm', 'Force approve?'))) {
						submitApproval(true);
						return;
					}

					$message.removeClass('success').addClass('error').html('<span class="dashicons dashicons-warning" aria-hidden="true"></span> ' + ((response && response.data && response.data.message) ? response.data.message : getI18n('generic_error', 'An error occurred.'))).show();
					$btn.prop('disabled', false).text('Apply ✓');
				}).fail(function() {
					$message.removeClass('success').addClass('error').html('<span class="dashicons dashicons-warning" aria-hidden="true"></span> ' + getI18n('network_error', 'Network error. Please try again.')).show();
					$btn.prop('disabled', false).text('Apply ✓');
				});
			};

			submitApproval(false);
		});

		// 3. Discard duplicate
		$(document).on('click', '.respira-discard-btn', function(e) {
			e.preventDefault();
			if (!window.confirm(getI18n('reject_confirm', 'Discard this duplicate? This cannot be undone.'))) {
				return;
			}
			var $btn = $(this);
			var duplicateId = $btn.data('duplicate-id');
			var $section = $btn.closest('.respira-duplicate-section');
			var $message = $section.find('.respira-duplicate-message');

			$btn.prop('disabled', true).text(getI18n('rejecting', 'Discarding...'));
			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_reject_duplicate',
					nonce: nonce,
					duplicate_id: duplicateId
				}
			}).done(function(response) {
				if (response && response.success) {
					showToast(response.data.message || 'Duplicate discarded.');
					$section.slideUp(200, function() { $section.remove(); });
					announce(response.data.message || 'Discarded');
					return;
				}
				$message.removeClass('success').addClass('error').html('<span class="dashicons dashicons-warning" aria-hidden="true"></span> ' + ((response && response.data && response.data.message) ? response.data.message : getI18n('generic_error', 'An error occurred.'))).show();
				$btn.prop('disabled', false).text('Discard ✗');
			}).fail(function() {
				$message.removeClass('success').addClass('error').html('<span class="dashicons dashicons-warning" aria-hidden="true"></span> ' + getI18n('network_error', 'Network error. Please try again.')).show();
				$btn.prop('disabled', false).text('Discard ✗');
			});
		});

		// 4. View Diff (duplicate)
		$(document).on('click', '.respira-view-diff-btn', function() {
			var duplicateId = $(this).data('duplicate-id');
			$('#respira-preview-body').html('<span class="spinner is-active" style="float:none;"></span> Loading...');
			$('#respira-preview-modal').show();

			$.get(ajaxurl, { action: 'respira_preview_snapshot', nonce: nonce, duplicate_id: duplicateId }, function(res) {
				if (!res.success) {
					$('#respira-preview-body').html('<p style="color:#ef4444;">Failed to load diff</p>');
					return;
				}
				var d = res.data;
				var payload = d.payload || {};
				var post = payload.post || {};
				var html = '';

				html += '<div class="respira-diff-section"><h4>Post</h4>';
				html += '<div class="respira-diff-content">';
				html += 'Title: ' + $('<span>').text(post.title || '').html() + '\n';
				html += 'Status: ' + (post.status || '') + '\n';
				html += 'Slug: ' + (post.slug || '') + '\n';
				html += 'Modified: ' + (post.modified_gmt || '') + '\n';
				html += '</div></div>';

				if (payload.builder && payload.builder.name) {
					html += '<div class="respira-diff-section"><h4>Builder: ' + payload.builder.name + '</h4>';
					var bp = payload.builder.payload;
					var bpStr = typeof bp === 'string' ? bp : JSON.stringify(bp, null, 2);
					if (bpStr && bpStr.length > 2000) bpStr = bpStr.substring(0, 2000) + '\n...(truncated)';
					html += '<div class="respira-diff-content">' + $('<span>').text(bpStr || '(empty)').html() + '</div></div>';
				}

				if (payload.meta_allowlisted && Object.keys(payload.meta_allowlisted).length) {
					html += '<div class="respira-diff-section"><h4>Meta (' + Object.keys(payload.meta_allowlisted).length + ' keys)</h4>';
					html += '<div class="respira-diff-content">';
					Object.keys(payload.meta_allowlisted).forEach(function(k) {
						var v = payload.meta_allowlisted[k];
						var vStr = typeof v === 'string' ? v : JSON.stringify(v);
						if (vStr && vStr.length > 200) vStr = vStr.substring(0, 200) + '...';
						html += k + ': ' + $('<span>').text(vStr).html() + '\n';
					});
					html += '</div></div>';
				}

				$('#respira-preview-body').html(html);
			});
		});

		// 5. Preview version
		$(document).on('click', '.respira-preview-btn', function() {
			var uuid = $(this).data('uuid');
			$('#respira-preview-body').html('<span class="spinner is-active" style="float:none;"></span> Loading...');
			$('#respira-preview-modal').show();

			$.get(ajaxurl, { action: 'respira_preview_snapshot', nonce: nonce, snapshot_uuid: uuid }, function(res) {
				if (!res.success) {
					$('#respira-preview-body').html('<p style="color:#ef4444;">Failed to load snapshot</p>');
					return;
				}
				var d = res.data;
				var payload = d.payload || {};
				var post = payload.post || {};
				var html = '';

				html += '<div class="respira-diff-section"><h4>Post</h4>';
				html += '<div class="respira-diff-content">';
				html += 'Title: ' + $('<span>').text(post.title || '').html() + '\n';
				html += 'Status: ' + (post.status || '') + '\n';
				html += 'Slug: ' + (post.slug || '') + '\n';
				html += 'Modified: ' + (post.modified_gmt || '') + '\n';
				html += '</div></div>';

				if (payload.builder && payload.builder.name) {
					html += '<div class="respira-diff-section"><h4>Builder: ' + payload.builder.name + '</h4>';
					var bp = payload.builder.payload;
					var bpStr = typeof bp === 'string' ? bp : JSON.stringify(bp, null, 2);
					if (bpStr && bpStr.length > 2000) bpStr = bpStr.substring(0, 2000) + '\n...(truncated)';
					html += '<div class="respira-diff-content">' + $('<span>').text(bpStr || '(empty)').html() + '</div></div>';
				}

				if (payload.meta_allowlisted && Object.keys(payload.meta_allowlisted).length) {
					html += '<div class="respira-diff-section"><h4>Meta (' + Object.keys(payload.meta_allowlisted).length + ' keys)</h4>';
					html += '<div class="respira-diff-content">';
					Object.keys(payload.meta_allowlisted).forEach(function(k) {
						var v = payload.meta_allowlisted[k];
						var vStr = typeof v === 'string' ? v : JSON.stringify(v);
						if (vStr && vStr.length > 200) vStr = vStr.substring(0, 200) + '...';
						html += k + ': ' + $('<span>').text(vStr).html() + '\n';
					});
					html += '</div></div>';
				}

				$('#respira-preview-body').html(html);
			});
		});

		// 6a. Visual preview — opens rendered page in new tab
		$(document).on('click', '.respira-visual-preview-btn', function() {
			var $btn = $(this);
			var uuid = $btn.data('uuid');
			$btn.prop('disabled', true).text('Loading...');
			$.post(ajaxurl, {
				action: 'respira_visual_preview_snapshot',
				nonce: nonce,
				snapshot_uuid: uuid
			}, function(res) {
				$btn.prop('disabled', false).text('Preview ↗');
				if (res.success && res.data.preview_url) {
					window.open(res.data.preview_url, '_blank');
				} else {
					showToast('Preview failed: ' + ((res.data && res.data.message) || 'Unknown error'));
				}
			}).fail(function() {
				$btn.prop('disabled', false).text('Preview ↗');
				showToast('Preview request failed');
			});
		});

		// 6b. Revert version
		$(document).on('click', '.respira-restore-btn', function() {
			var uuid = $(this).data('uuid');
			var $card = $(this).closest('.respira-post-card');
			showModal(
				'Revert to this version?',
				'The current state will be saved as a "before restore" snapshot automatically.',
				function() {
					$.post(ajaxurl, {
						action: 'respira_restore_snapshot',
						nonce: nonce,
						snapshot_uuid: uuid
					}, function(res) {
						if (res.success) {
							showToast('Version restored successfully');
							if ($card.length) {
								expandPost($card.data('post-id'), $card);
							}
							loadStats();
						} else {
							showToast('Restore failed: ' + ((res.data && res.data.message) || 'Unknown error'));
						}
					});
				}
			);
		});

		// 6c. Delete single version
		$(document).on('click', '.respira-delete-version-btn', function() {
			var uuid = $(this).data('uuid');
			var $card = $(this).closest('.respira-post-card');
			showModal(
				'Delete this version?',
				'This cannot be undone. Pinned versions cannot be deleted.',
				function() {
					$.post(ajaxurl, {
						action: 'respira_delete_snapshots',
						nonce: nonce,
						uuids: [uuid]
					}, function(res) {
						if (res.success) {
							showToast('Deleted ' + res.data.deleted_count + ' version, freed ' + formatBytes(res.data.freed_bytes));
							if ($card.length) {
								expandPost($card.data('post-id'), $card);
							}
							loadStats();
						} else {
							showToast('Delete failed: ' + ((res.data && res.data.message) || 'Unknown error'));
						}
					});
				}
			);
		});

		// 6d. Delete all versions for a post
		$(document).on('click', '.respira-delete-all-versions-btn', function() {
			var postId = $(this).data('post-id');
			var $card = $(this).closest('.respira-post-card');
			showModal(
				'Delete ALL versions for this page?',
				'All unpinned versions will be permanently deleted. Pinned versions will be kept. This cannot be undone.',
				function() {
					$.post(ajaxurl, {
						action: 'respira_delete_post_snapshots',
						nonce: nonce,
						post_id: postId
					}, function(res) {
						if (res.success) {
							showToast('Deleted ' + res.data.deleted_count + ' versions, freed ' + formatBytes(res.data.freed_bytes));
							if ($card.length) {
								expandPost(postId, $card);
							}
							loadStats();
						} else {
							showToast('Delete failed: ' + ((res.data && res.data.message) || 'Unknown error'));
						}
					});
				}
			);
		});

		// 7. Pin/unpin
		$(document).on('click', '.respira-pin-btn', function() {
			var $btn = $(this);
			var uuid = $btn.data('uuid');
			var newPinned = $btn.data('pinned') ? 0 : 1;
			$.post(ajaxurl, {
				action: 'respira_pin_snapshot',
				nonce: nonce,
				snapshot_uuid: uuid,
				pinned: newPinned
			}, function(res) {
				if (res.success) {
					$btn.data('pinned', newPinned);
					$btn.toggleClass('is-pinned', !!newPinned);
					$btn.text(newPinned ? '★' : '☆');
					$btn.closest('.respira-version-row').toggleClass('is-pinned', !!newPinned);
					showToast(newPinned ? 'Version pinned' : 'Version unpinned');
				}
			});
		});

		// 8. Search posts (debounced)
		var searchTimer;
		$('#respira-changes-search').on('input', function() {
			var q = $(this).val();
			clearTimeout(searchTimer);

			if (q.length === 0) {
				$('#respira-post-search-results').hide();
				currentSearch = '';
				nextCursor = null;
				loadPosts(false);
				return;
			}

			if (q.length < 2) {
				$('#respira-post-search-results').hide();
				return;
			}

			searchTimer = setTimeout(function() {
				$.get(ajaxurl, { action: 'respira_search_posts', nonce: nonce, q: q }, function(res) {
					if (!res.success) return;
					var $dd = $('#respira-post-search-results').empty();
					if (res.data.length === 0) {
						$dd.append('<div class="respira-search-item" style="color:#6b7280;">No results</div>');
					} else {
						res.data.forEach(function(p) {
							$dd.append('<div class="respira-search-item" data-id="' + p.id + '">' + $('<span>').text(p.title).html() + ' <small style="color:#6b7280;">(' + p.type + ')</small></div>');
						});
					}
					$dd.show();
				});
			}, 300);
		});

		$(document).on('click', '#respira-post-search-results .respira-search-item', function() {
			var id = $(this).data('id');
			if (!id) return;
			$('#respira-changes-search').val($(this).text().trim());
			$('#respira-post-search-results').hide();
			currentSearch = $(this).text().trim();
			nextCursor = null;
			loadPosts(false);
		});

		$(document).on('click', function(e) {
			if (!$(e.target).closest('.respira-changes-filters').length) {
				$('#respira-post-search-results').hide();
			}
		});

		// 9. Type filter
		$('#respira-changes-type-filter').on('change', function() {
			currentType = $(this).val() || '';
			nextCursor = null;
			loadPosts(false);
		});

		// 10. Load more posts
		$('#respira-loadmore-btn').on('click', function() {
			loadPosts(true);
		});

		// 11. Load more versions
		$(document).on('click', '.respira-load-versions-btn', function() {
			var $btn = $(this);
			var postId = $btn.data('post-id');
			var $timeline = $btn.closest('.respira-timeline');
			var existingCount = $timeline.find('.respira-version-row').length;

			$btn.prop('disabled', true).text('Loading...');

			$.get(ajaxurl, {
				action: 'respira_changes_post_detail',
				nonce: nonce,
				post_id: postId,
				versions_per_page: 10,
				versions_offset: existingCount
			}, function(res) {
				if (!res.success) {
					$btn.prop('disabled', false).text('Load more versions');
					return;
				}
				var versions = res.data.versions || [];
				var $loadmoreContainer = $btn.closest('.respira-timeline-loadmore');
				versions.forEach(function(v, i) {
					var pinnedClass = v.pinned ? ' is-pinned' : '';
					var pinIcon = v.pinned ? '★' : '☆';
					var num = 'v' + (existingCount + versions.length - i);
					var rowHtml = '<div class="respira-version-row' + pinnedClass + '" data-uuid="' + v.uuid + '">' +
						'<span class="respira-version-num">' + num + '</span>' +
						kindBadge(v.kind) +
						(v.label ? '<span class="respira-version-label">' + $('<span>').text(v.label).html() + '</span>' : '') +
						'<span class="respira-version-meta">' + timeAgo(v.created_at) + '</span>' +
						'<span class="respira-version-meta">' + formatBytes(v.payload_bytes) + '</span>' +
						(v.actor ? '<span class="respira-version-meta respira-version-actor">' + $('<span>').text(v.actor).html() + '</span>' : '') +
						'<div class="respira-version-actions">' +
							'<button type="button" class="respira-pin-btn' + pinnedClass + '" data-uuid="' + v.uuid + '" data-pinned="' + (v.pinned ? 1 : 0) + '" title="' + (v.pinned ? 'Unpin — allow this version to be purged during cleanup' : 'Pin — protect this version from cleanup and purge') + '">' + pinIcon + '</button>' +
							'<button type="button" class="button respira-visual-preview-btn" data-uuid="' + v.uuid + '" style="background:rgba(16,185,129,0.12); border-color:rgba(16,185,129,0.35); color:#6ee7b7;" title="Preview this version — opens the rendered page in a new tab as it looked at this point">Preview ↗</button>' +
							'<button type="button" class="button button-primary respira-restore-btn" data-uuid="' + v.uuid + '" title="Restore this version — replaces current content with this snapshot (current state is saved first)">Revert</button>' +
							'<button type="button" class="respira-delete-version-btn" data-uuid="' + v.uuid + '" title="Delete this version permanently — cannot be undone" style="background:none; border:none; color:#6b7280; cursor:pointer; padding:2px 4px; font-size:14px;">×</button>' +
						'</div>' +
					'</div>';
					$loadmoreContainer.before(rowHtml);
				});

				if (!res.data.versions_has_more) {
					$loadmoreContainer.remove();
				} else {
					$btn.prop('disabled', false).text('Load more versions');
				}
			});
		});

		// 12. Storage stats loaded on init (see bottom)

		// 13. Purge
		$('#respira-purge-btn').on('click', function() {
			showModal(
				'Purge old snapshots?',
				'Delete all unpinned snapshots older than 30 days. Pinned snapshots will be kept.',
				function() {
					$.post(ajaxurl, {
						action: 'respira_purge_old_snapshots',
						nonce: nonce,
						age_days: 30
					}, function(res) {
						if (res.success) {
							showToast('Freed ' + formatBytes(res.data.freed_bytes) + ', deleted ' + res.data.deleted_count + ' snapshots');
							nextCursor = null;
							loadPosts(false);
							loadStats();
						}
					});
				}
			);
		});

		// 13b. Purge ALL versions (regardless of age)
		$('#respira-purge-all-btn').on('click', function() {
			showModal(
				'Delete ALL versions?',
				'This will permanently delete every unpinned version across all pages. Pinned versions will be kept. This cannot be undone.',
				function() {
					$.post(ajaxurl, {
						action: 'respira_purge_all_snapshots',
						nonce: nonce
					}, function(res) {
						if (res.success) {
							showToast('Deleted ' + res.data.deleted_count + ' versions, freed ' + formatBytes(res.data.freed_bytes));
							nextCursor = null;
							loadPosts(false);
							loadStats();
						}
					});
				}
			);
		});

		// 14. Modal close handlers
		$('#respira-preview-close, #respira-preview-modal .respira-modal-backdrop').on('click', function() {
			$('#respira-preview-modal').hide();
		});

		$('#respira-confirm-cancel, #respira-confirm-modal .respira-modal-backdrop').on('click', function() {
			$('#respira-confirm-modal').hide();
		});

		// Testimonial modal handlers (from approvals)
		$('.respira-admin').on('click', '.respira-modal-close, .respira-modal-overlay', function(e) {
			e.preventDefault();
			$('#respira-testimonial-modal').hide().attr('aria-hidden', 'true').off('keydown.respiraTrap');
		});

		$('.respira-admin').on('click', '.respira-star-btn', function(e) {
			e.preventDefault();
			var rating = Number($(this).data('rating'));
			$('#testimonial-rating').val(rating);
			$('.respira-star-btn').each(function() {
				var $icon = $(this).find('.dashicons');
				if (Number($(this).data('rating')) <= rating) {
					$icon.removeClass('dashicons-star-empty').addClass('dashicons-star-filled').css('color', '#f59e0b');
				} else {
					$icon.removeClass('dashicons-star-filled').addClass('dashicons-star-empty').css('color', '#78716c');
				}
			});
		});

		$('.respira-admin').on('submit', '#respira-testimonial-form', function(e) {
			e.preventDefault();
			var $form = $(this);
			var rating = $('#testimonial-rating').val();
			var $message = $('#respira-testimonial-message');
			var $btn = $form.find('button[type="submit"]');

			if (!rating) {
				$message.removeClass('success').addClass('error').text(getI18n('testimonial_rating', 'Please select a rating.')).show();
				return;
			}

			$btn.prop('disabled', true).text(getI18n('testimonial_send', 'Submitting...'));
			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_submit_testimonial',
					nonce: respira_admin.nonce,
					name: $('#testimonial-name').val(),
					testimonial: $('#testimonial-text').val(),
					rating: rating,
					anonymous_name: $form.find('input[name="anonymous_name"]').is(':checked') ? 1 : 0,
					anonymous_website: $form.find('input[name="anonymous_website"]').is(':checked') ? 1 : 0,
					website_url: $form.find('input[name="website_url"]').val()
				}
			}).done(function(response) {
				if (response && response.success) {
					$message.removeClass('error').addClass('success').text((response.data && response.data.message) ? response.data.message : 'Thank you.').show();
					setTimeout(function() {
						$('#respira-testimonial-modal').hide();
					}, 1000);
					return;
				}
				$message.removeClass('success').addClass('error').text((response && response.data && response.data.message) ? response.data.message : getI18n('generic_error', 'An error occurred.')).show();
				$btn.prop('disabled', false).text('Submit Testimonial');
			}).fail(function() {
				$message.removeClass('success').addClass('error').text(getI18n('network_error', 'Network error. Please try again.')).show();
				$btn.prop('disabled', false).text('Submit Testimonial');
			});
		});

		// ── Init ──
		loadStats();
		loadPosts(false);
	}

	function setupAccessibilityScan() {
		var $btn = $('#respira-scan-now-btn');
		if (!$btn.length) {
			return;
		}
		var $feedback = $('#respira-scan-now-feedback');
		var ajaxUrl = $btn.attr('data-ajax-url') || (window.respira_admin ? window.respira_admin.ajax_url : '');

		var runScan = function() {
			if (!ajaxUrl) {
				return;
			}
			$feedback.show().css('color', '#57534e').text(getI18n('scan_starting', 'Starting…'));
			var formData = new FormData();
			formData.append('action', 'respira_run_accessibility_scan');
			formData.append('nonce', $btn.attr('data-nonce') || '');
			formData.append('url', $btn.attr('data-home-url') || '');

			fetch(ajaxUrl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin'
			}).then(function(response) {
				if (!response.ok) {
					throw new Error('Request failed');
				}
				return response.json();
			}).then(function(data) {
				if (!data || !data.success) {
					$feedback.css('color', '#b91c1c').text((data && data.data && data.data.message) ? data.data.message : getI18n('request_failed', 'Request failed.'));
					return;
				}
				var message = (data.data && data.data.message) ? data.data.message : '';
				if (data.data && data.data.reload) {
					$feedback.css('color', '#047857').text(message + ' ' + getI18n('scan_refreshing', 'Refreshing…'));
					window.location.reload();
					return;
				}
				$feedback.css('color', '#047857').text(message);
			}).catch(function() {
				$feedback.css('color', '#b91c1c').text(getI18n('scan_failed', 'Request failed. Try again.'));
			});
		};

		$btn.on('click', function(e) {
			e.preventDefault();
			runScan();
		});

		if ($btn.attr('data-auto-run') === '1') {
			runScan();
		}
	}

	function setupSkillsPage() {
		var $page = $('.respira-skills-page');
		if (!$page.length) {
			return;
		}

		var $cards = $page.find('.respira-skill-card');
		var $search = $('#respira-skills-search');
		var $tabs = $page.find('.respira-skills-tab');
		var activeCategory = 'all';

		function filterCards() {
			var query = ($search.val() || '').toLowerCase();

			$cards.each(function() {
				var $card = $(this);
				var category = ($card.attr('data-category') || '').toLowerCase();
				var name = $card.attr('data-name') || '';
				var description = $card.attr('data-description') || '';

				var matchesCategory = activeCategory === 'all' || category === activeCategory;
				var matchesSearch = !query || name.indexOf(query) !== -1 || description.indexOf(query) !== -1;

				if (matchesCategory && matchesSearch) {
					$card.removeAttr('hidden');
				} else {
					$card.attr('hidden', '');
				}
			});
		}

		$tabs.on('click', function() {
			$tabs.removeClass('is-active').attr('aria-selected', 'false');
			$(this).addClass('is-active').attr('aria-selected', 'true');
			activeCategory = ($(this).attr('data-category') || 'all').toLowerCase();
			filterCards();
		});

		$search.on('input', filterCards);

		// One-click install handler.
		$page.on('click', '.respira-skill-one-click-install', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var slug = $btn.data('skill-slug');
			var name = $btn.data('skill-name');

			if (!slug || !window.respira_admin || !respira_admin.ajax_url || !respira_admin.nonce) {
				return;
			}

			$btn.prop('disabled', true);
			var $icon = $btn.find('.dashicons');
			$icon.removeClass('dashicons-download').addClass('dashicons-update dashicons-spin');
			$btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Installing...');

			$.ajax({
				url: respira_admin.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'respira_install_skill',
					nonce: respira_admin.nonce,
					slug: slug
				}
			}).done(function(response) {
				$icon.removeClass('dashicons-update dashicons-spin');
				if (response && response.success) {
					$icon.addClass('dashicons-yes-alt');
					$btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Installed');
					$btn.css('color', '#10b981');
					announce('Skill ' + name + ' installed.');
				} else {
					$icon.addClass('dashicons-download');
					$btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Install');
					$btn.prop('disabled', false);
					var msg = (response && response.data && response.data.message) ? response.data.message : getI18n('generic_error', 'An error occurred.');
					window.alert(msg);
				}
			}).fail(function() {
				$icon.removeClass('dashicons-update dashicons-spin').addClass('dashicons-download');
				$btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Install');
				$btn.prop('disabled', false);
				window.alert(getI18n('network_error', 'Network error. Please try again.'));
			});
		});
	}

	/* ══════════════════════════════════════════
	   Settings auto-save, toast, tooltips, confirm
	   ══════════════════════════════════════════ */

	function showToast(message, undoCallback) {
		var $container = $('#respira-toast-container');
		if (!$container.length) return;

		var $toast = $('<div class="respira-toast"></div>').text(message);

		if (typeof undoCallback === 'function') {
			var $undo = $('<button type="button" class="respira-toast-undo"></button>')
				.text(getI18n('setting_undo', 'Undo'))
				.on('click', function() {
					undoCallback();
					$toast.remove();
				});
			$toast.append($undo);
		}

		$container.append($toast);

		setTimeout(function() {
			$toast.addClass('is-leaving');
			setTimeout(function() { $toast.remove(); }, 200);
		}, 5000);
	}

	function saveSetting(option, value, type, onDone) {
		if (!window.respira_admin || !respira_admin.ajax_url) return;

		var data = {
			action: 'respira_save_setting',
			nonce: respira_admin.nonce,
			option: option,
			type: type || 'checkbox',
			value: value
		};

		$.ajax({
			url: respira_admin.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: data
		}).done(function(response) {
			if (response && response.success) {
				if (typeof onDone === 'function') onDone(response.data);
			} else {
				showToast(getI18n('setting_save_error', 'Failed to save setting.'));
			}
		}).fail(function() {
			showToast(getI18n('setting_save_error', 'Failed to save setting.'));
		});
	}

	function showConfirmDialog(title, message) {
		return new Promise(function(resolve) {
			var $dialog = $('#respira-confirm-dialog');
			if (!$dialog.length) { resolve(false); return; }

			$('#respira-confirm-title').text(title);
			$('#respira-confirm-message').text(message);
			$dialog.removeAttr('hidden');

			function cleanup(result) {
				$dialog.attr('hidden', '');
				$dialog.off('.respira-confirm');
				resolve(result);
			}

			$dialog.on('click.respira-confirm', '.respira-confirm-cancel, .respira-confirm-dialog-backdrop', function() {
				cleanup(false);
			});
			$dialog.on('click.respira-confirm', '.respira-confirm-proceed', function() {
				cleanup(true);
			});
			$dialog.on('keydown.respira-confirm', function(e) {
				if (e.key === 'Escape') cleanup(false);
			});
		});
	}

	function updateSafetyBanner() {
		var $banner = $('.respira-safety-banner');
		if (!$banner.length) return;

		var issues = [];

		$('.respira-settings-zone').each(function() {
			$(this).find('.respira-setting-row[data-option]').each(function() {
				var $row = $(this);
				var option = $row.data('option');
				var def = String($row.data('default'));
				var $input = $row.find('input').first();
				var val;

				if ($row.data('type') === 'number') {
					val = $input.val();
				} else if ($row.data('type') === 'tags') {
					return; // skip tags for safety banner
				} else {
					val = $input.is(':checked') ? '1' : '0';
				}

				// Check for safety-relevant deviations
				if (option === 'respira_auto_duplicate' && val === '0') {
					issues.push('Auto Duplicate is OFF');
				}
				if (option === 'respira_security_checks' && val === '0') {
					issues.push('Security Checks are OFF');
				}
				if (option === 'respira_allow_direct_edit' && val === '1') {
					issues.push('Direct Editing is ON');
				}
				if (option === 'respira_enable_plugin_management' && val === '1') {
					issues.push('Plugin Management is ON');
				}
			});
		});

		if (issues.length === 0) {
			$banner.removeClass('is-warning').addClass('is-safe');
			$banner.find('.respira-safety-icon').html('&#10003;');
			$banner.find('.respira-safety-copy strong').text(getI18n('site_protected', 'Your site is protected.'));
			$banner.find('.respira-safety-copy').contents().filter(function() {
				return this.nodeType === 3;
			}).remove();
			$banner.find('.respira-safety-details').remove();
		} else {
			$banner.removeClass('is-safe').addClass('is-warning');
			$banner.find('.respira-safety-icon').html('&#9888;');
			$banner.find('.respira-safety-copy strong').text(
				issues.length + ' safety setting' + (issues.length > 1 ? 's' : '') + ' changed from recommended defaults.'
			);
			var $details = $banner.find('.respira-safety-details');
			if (!$details.length) {
				$details = $('<span class="respira-safety-details"></span>');
				$banner.find('.respira-safety-copy').append($details);
			}
			$details.text(issues.join(' \u00b7 '));
		}
	}

	function setupSettingsAutoSave() {
		if (!$('.respira-settings-zone').length) return;

		// Toggle auto-save
		$('.respira-settings-zone').on('change', '.respira-setting-row[data-option] input[type="checkbox"]', function() {
			var $row = $(this).closest('.respira-setting-row');
			var option = $row.data('option');
			var type = $row.data('type') || 'checkbox';
			if (type === 'tags') return; // handled separately

			var checked = $(this).is(':checked');
			var value = checked ? '1' : '0';
			var $input = $(this);

			// Confirmation for red zone
			if ($row.data('confirm') === 'red' && checked) {
				var titleKey = option === 'respira_allow_direct_edit' ? 'confirm_direct_edit_title' : 'confirm_plugin_mgmt_title';
				var msgKey = option === 'respira_allow_direct_edit' ? 'confirm_direct_edit_message' : 'confirm_plugin_mgmt_message';
				var title = getI18n(titleKey, 'Are you sure?');
				var msg = getI18n(msgKey, 'This setting affects live content safety.');

				showConfirmDialog(title, msg).then(function(confirmed) {
					if (!confirmed) {
						$input.prop('checked', false);
						return;
					}
					doSave(option, '1', type, $row);
				});
				return;
			}

			doSave(option, value, type, $row);
		});

		// Rate limit auto-save (debounced)
		var rateTimer;
		$('.respira-settings-zone').on('input', '.respira-setting-row[data-type="number"] input[type="number"]', function() {
			var $input = $(this);
			var $row = $input.closest('.respira-setting-row');
			clearTimeout(rateTimer);
			rateTimer = setTimeout(function() {
				var option = $row.data('option');
				var value = $input.val();
				doSave(option, value, 'number', $row);
			}, 800);
		});

		// Tag pills auto-save
		$('.respira-settings-zone').on('change', '.respira-setting-row[data-type="tags"] input[type="checkbox"]', function() {
			var $row = $(this).closest('.respira-setting-row');
			var option = $row.data('option');
			var selected = [];
			$row.find('.respira-tag input:checked').each(function() {
				selected.push($(this).val());
			});

			// Update is-active class
			$row.find('.respira-tag').each(function() {
				$(this).toggleClass('is-active', $(this).find('input').is(':checked'));
			});

			saveSetting(option, selected, 'tags', function() {
				showToast(getI18n('setting_updated', 'Setting updated'));
			});
		});

		function doSave(option, value, type, $row) {
			saveSetting(option, value, type, function(data) {
				showToast(getI18n('setting_updated', 'Setting updated'), function() {
					// Undo: restore old value
					var oldValue = data.old_value;
					if (type === 'checkbox') {
						var wasChecked = String(oldValue) === '1';
						$row.find('input[type="checkbox"]').first().prop('checked', wasChecked);
					} else if (type === 'number') {
						$row.find('input[type="number"]').first().val(oldValue);
					}
					saveSetting(option, oldValue, type, function() {
						showToast(getI18n('setting_undone', 'Reverted'));
						updateSafetyBanner();
					});
				});
				updateSafetyBanner();
			});
		}
	}

	function setupSettingsHelpTooltips() {
		$('.respira-admin').on('click', '.respira-help-btn', function(e) {
			e.preventDefault();
			e.stopPropagation();
			var $btn = $(this);
			var $row = $btn.closest('.respira-setting-row');
			var $tooltip = $row.find('.respira-help-tooltip');

			var isOpen = !$tooltip.attr('hidden');

			// Close all other tooltips
			$('.respira-help-tooltip').attr('hidden', '');
			$('.respira-help-btn').removeClass('is-active');

			if (!isOpen) {
				$tooltip.removeAttr('hidden');
				$btn.addClass('is-active');
			}
		});

		// Close tooltip when clicking outside
		$(document).on('click', function(e) {
			if (!$(e.target).closest('.respira-help-btn, .respira-help-tooltip').length) {
				$('.respira-help-tooltip').attr('hidden', '');
				$('.respira-help-btn').removeClass('is-active');
			}
		});
	}

	$(document).ready(function() {
		if (!$('.respira-admin').length) {
			return;
		}
		setupCopyButtons();
		setupLicenseCheckboxGuards();
		setupTabsKeyboardSupport();
		setupPluginUpdates();
		setupSkillsNoticeDismiss();
		setupRemoteNoticeDismiss();
		setupChangesPage();
		setupAccessibilityScan();
		setupSkillsPage();
		setupSettingsAutoSave();
		setupSettingsHelpTooltips();
	});


})(jQuery);
