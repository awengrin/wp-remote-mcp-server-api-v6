=== Respira for WordPress ===
Contributors: respira
Tags: ai, mcp, cursor, claude, page-builder, automation
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 5.2.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Vibe code your WordPress site. No SSH required. Connect AI coding assistants like Cursor and Claude Code to edit your WordPress site.

== Description ==

**Respira for WordPress** enables AI coding assistants (Cursor, Claude Code, Codex, Windsurf, and more) to remotely edit your WordPress site without requiring SSH access. Built on the Model Context Protocol (MCP), it provides a secure REST API bridge for AI-powered WordPress development.

= Key Features =

* **Safe Editing**: Always creates duplicate pages before making changes
* **Respira API v2 Fidelity**: Include-gated content contracts, canonical builder payloads, snapshots, diff/restore, and builder patch operations
* **Security First**: Built-in validation for XSS, SQL injection, and other vulnerabilities
* **No SSH Required**: Works with any WordPress hosting, even shared hosts
* **Context-Aware AI**: Provides comprehensive site information to AI assistants
* **Page Builder Support**: Works with Gutenberg, Divi, Elementor, Oxygen, Bricks, and more
* **Audit Logging**: Complete activity log of all AI actions
* **Rate Limiting**: Configurable request limits for security
* **Multi-Site Support**: Manage multiple WordPress sites from one AI assistant
* **Browser AI (WebMCP) Built In**: Includes bundled WebMCP bridge + 85/106 Respira abilities directly in Chrome 146+
* **WordPress AI Stack Ready**: Registers Respira tools as WordPress Abilities and supports both the official MCP Adapter default server and a dedicated Respira MCP Adapter server
* **Elementor Angie Integration**: Optional browser-auth bridge lets Elementor Angie use a curated Respira toolset inside logged-in wp-admin

= Supported Page Builders =

* Gutenberg (Block Editor) ✅
* Divi ✅
* Elementor ✅
* Oxygen ✅
* Bricks ✅
* Uncode (WPBakery) ✅
* Beaver Builder ✅
* Thrive Architect ✅
* Brizy ✅
* Visual Composer ✅

= Supported AI Tools =

* Cursor ✅
* Claude Desktop ✅
* Codex ✅
* Windsurf ✅
* Cline ✅
* Continue.dev ✅

= How It Works =

1. Install the plugin on your WordPress site
2. Generate an API key from the plugin dashboard
3. Download the MCP server for your local machine
4. Configure your AI coding assistant (Cursor, Claude Code, etc.)
5. Start vibe coding your WordPress site!

= Use Cases =

* Edit WordPress pages with natural language instructions
* Create new content and layouts without leaving your code editor
* Automate content updates across multiple pages
* Quickly prototype designs and features
* Manage client sites more efficiently

= Security & Safety =

* **Duplicate-First Approach**: Never modifies original pages without explicit confirmation
* **Catalog-Safe Woo Approvals**: WooCommerce products keep original live IDs on approval by default to avoid Meta/Google catalog desync
* **Content Validation**: Scans all content for security issues before saving
* **WordPress Standards**: Validates code against WordPress Coding Standards
* **Audit Trail**: Complete log of all API activity
* **Rate Limiting**: Prevents abuse with configurable request limits
* **Encrypted API Keys**: Securely stored with WordPress password hashing

== Installation ==

= Automatic Installation =

1. Log in to your WordPress admin panel
2. Go to Plugins > Add New
3. Search for "Respira for WordPress"
4. Click "Install Now" and then "Activate"

= Manual Installation =

1. Download the plugin ZIP file
2. Go to Plugins > Add New > Upload Plugin
3. Choose the ZIP file and click "Install Now"
4. Activate the plugin

= Configuration =

1. Go to Respira > API Keys in your WordPress admin
2. Click "Generate API Key" and give it a name
3. Copy and save the API key securely (it won't be shown again)
4. Download the MCP server from respira.press
5. Configure your AI coding assistant with the API key and WordPress URL
6. If you manage multiple client sites, open https://www.respira.press/dashboard/mcp for the dedicated account-wide MCP Setup page

== Frequently Asked Questions ==

= Do I need SSH access to use this plugin? =

No! That's the whole point. Respira works entirely through WordPress's REST API, so it works with any hosting provider, including shared hosting.

= Is it safe to let AI edit my WordPress site? =

Yes! Respira always creates duplicate pages before making changes, so your original content is never touched. You can review changes before publishing, and all actions are logged in the audit trail.

= Which page builders are supported? =

Respira supports Gutenberg, Divi, Elementor, Oxygen, Bricks, Uncode, Beaver Builder, Thrive Architect, Brizy, Visual Composer, and more.

= Can I use this with multiple WordPress sites? =

Yes! The MCP server supports multi-site configuration. You can manage multiple client sites from one AI assistant.

= Which AI coding assistants work with this? =

Any AI assistant that supports the Model Context Protocol (MCP), including Cursor, Claude Desktop, Codex, Windsurf, Cline, and Continue.dev.

= Does Respira include BrowserMCP / WebMCP support? =

Yes. Respira 4.2.2 bundles WebMCP Abilities directly in the plugin. No separate WebMCP plugin install is required.

= Does this work with the official WordPress MCP Adapter and Abilities API? =

Yes. Respira registers its tools as WordPress Abilities when the Abilities API is available, keeps its dedicated Respira MCP Adapter server, and can also expose a safe read-only subset on the adapter's default public server.

= Do I need a newer PHP version for Browser AI (WebMCP)? =

WebMCP bridge components are enabled on PHP 8.1+ due upstream bundled code requirements. Core Respira functionality continues to run on the plugin minimum PHP version.

= Can I use Respira with Elementor Angie? =

Yes. Respira 4.2.2 includes an optional Elementor Angie integration that runs in logged-in wp-admin, uses WordPress cookies + REST nonces for auth, and exposes a curated duplicate-first tool allowlist instead of the full MCP registry.

= Does this work with WordPress multisite? =

Yes! Respira is fully compatible with WordPress multisite networks.

= What happens if the AI makes a mistake? =

Since Respira always creates duplicates, your original content is safe. You can review the duplicate, and if you don't like the changes, simply delete it and start over.

= Is there a limit on API requests? =

Yes, for security. The default is 100 requests per hour per API key, but you can configure this in the settings.

== Credits ==

Respira includes WebMCP integration based on the WebMCP Abilities plugin by Code Atlantic:
https://github.com/code-atlantic/webmcp-abilities

Licensed under GPL v2.

== Screenshots ==

1. Dashboard - Quick start guide and site information
2. API Keys - Generate and manage API keys
3. Settings - Configure security and preferences
4. Audit Log - Complete activity history

== Changelog ==

= 5.0.1 =
* FIXED: Settings label renamed from "Preserve Product IDs" to "Preserve IDs on Approval" — now explicitly mentions pages, posts, and products.
* FIXED: CPT exclusion list now correctly connected to the approver logic.
* FIXED: Admin v5 notice links to Settings page instead of showing code snippet.
* ADDED: Descriptive tooltips on all Changes page action buttons.

= 5.0 =
* NEW: **Changes page** — unified version history and duplicate review in one place (replaces separate Approvals and Snapshots pages).
* NEW: **Snapshots admin** — automatic before/after snapshots for every API edit, with version timeline, pin, preview, revert, and delete.
* NEW: **Visual preview** — "Preview ↗" button opens a fully rendered page preview in a new tab (creates a temporary draft with full snapshot content, meta, and builder data).
* NEW: **Duplicate approval flow** — side-by-side "View Original ↗" and "View Duplicate ↗" buttons, plus "Approve & Apply" and "Discard" actions. Duplicates appear nested under their original page.
* NEW: **Version labels** — each version row shows a mini changelog of what the AI editor changed (e.g. "Updated content, SEO", "Injected builder content", "Restored from snapshot").
* NEW: **Delete versions** — × button per version, "Delete all" per post, and global "Delete all versions" purge (regardless of age). Pinned versions are always preserved.
* NEW: **Merge mode default** — duplicate-first editing is the default. Live editing requires explicit opt-in in Settings + per-request MCP confirmation.
* NEW: **Auto revisions** — Respira captures WordPress revisions before each API edit for builder-agnostic rollback.
* IMPROVED: **Snapshot deduplication** — consecutive edits within 2 minutes collapse into a single before/after pair instead of creating hundreds of snapshots.
* IMPROVED: **Retention** — max 50 snapshots per post enforced on every cleanup cycle, with automatic pruning on upgrade.
* IMPROVED: **Storage panel** — expanded by default, shows total size, version count, and oldest snapshot with design-system styling.
* FIXED: **Divi 5 content integrity** — all write paths (pages, posts, custom posts, media, snapshots, duplicates, previews) now use `wp_slash()` before `wp_update_post()` to preserve backslashes in Divi 5 `\u003c` Unicode escapes.
* FIXED: **MCP guidance** — tool descriptions now reference "Respira → Changes" (not the old "Approvals" page). Duplicate creation responses include `approval_url` and explicit guidance text.

= 4.2.2 =
* ADDED: Remote plugin-header notifications sourced from respira.press, with per-user dismissal and cached delivery.
* ADDED: Push-style release announcement support for plugin users via the shared site notification feed (`channel=plugin`), so future notices do not require another plugin code change.

= 4.2.1 =
* FIXED: Content-save exceptions thrown by WordPress save hooks, cache plugins, or builder integrations are now returned as structured Respira errors instead of generic critical-error pages.
* FIXED: Usage tracking is now fully non-blocking across create/update/delete flows for pages, posts, and custom posts.
* CHANGED: Divi builder info now advertises a conservative safe-default subset of native Divi 5 blocks and reports registered-vs-safe block diagnostics to reduce blank-page risk on unstable runtimes.

= 4.2.0 =
* ADDED: Explicit live-edit preflight responses for original pages/posts/CPTs and builder mutation flows, requiring `editTarget` confirmation before modifying a live original when direct editing is enabled.
* ADDED: Dashboard-issued `respira_site_...` site tokens for hosted agency MCP exports, plus wp-admin handoff to the dedicated hosted MCP Setup page.
* CHANGED: Confirmation-only preflight no longer creates a duplicate until the duplicate path is actually chosen.
* IMPROVED: Live-edit responses now point users to WordPress revisions and Respira snapshots for rollback.

= 4.1.7 =
* FIXED: Elementor extraction now retries additional unslash/decode passes for heavily escaped `_elementor_data` payloads before failing.
* FIXED: When raw `_elementor_data` decoding fails but Elementor can still read the document internally, Respira now falls back to Elementor's document API and normalizes stored meta to canonical JSON.
* IMPROVED: Added richer Elementor decode diagnostics in debug logs (payload length and leading-byte signature) to speed up edge-case troubleshooting.

= 4.1.6 =
* FIXED: Testimonial modal prompt now appears only when a user reaches approval milestone #3 and #10, and does not show on other approvals.
* FIXED: After a user submits a testimonial from the plugin, testimonial modal prompts are permanently suppressed for that user.

= 4.1.5 =
* FIXED: Angie bridge now declares MCP tool capability at server construction time before registering `tools/list` and `tools/call` handlers, preventing "Server does not support tools" errors in Elementor Angie.
* CHANGED: Rebuilt the Angie bridge browser bundle so the distributed asset matches the fixed MCP server initialization path.

= 4.1.4 =
* FIXED: Elementor extraction now unwraps additional malformed `_elementor_data` storage variants, including serialized wrappers and UTF-8 BOM-prefixed JSON.
* FIXED: Elementor inject flow now checks method visibility before calling internal document save APIs, avoiding protected-method exceptions on newer Elementor versions and falling back cleanly.
* ADDED: Regression coverage for serialized-wrapper and BOM-prefixed Elementor meta decoding.

= 4.1.3 =
* CHANGED: Respira ability registrations now use official WordPress ability metadata (`show_in_rest`, `annotations`, `mcp.public`) while preserving WebMCP compatibility shims.
* CHANGED: Added safe default-server MCP exposure for low-risk read-only abilities while keeping the dedicated Respira MCP Adapter server for the full registry.
* CHANGED: Added a registry parity check so the standalone MCP server and WordPress ability registry do not silently drift.

= 4.1.2 =
* ADDED: Optional Angie integration that registers Respira inside Elementor's Angie assistant without any local MCP setup.
* ADDED: Curated browser-auth Angie tool bridge for page discovery, duplicate workflows, builder detection, and WooCommerce product operations.
* ADDED: Settings toggle and dormant-by-default Angie loading path so non-Angie sites carry no frontend or admin bloat.

= 4.1.1 =
* FIXED: Restored broad PHP compatibility in packaged dependencies by pinning Composer resolution to PHP 7.4-safe dependency versions.
* FIXED: Removed unintended PHP 8.2 runtime hard requirement from release artifacts (`vendor/composer/platform_check.php` now requires PHP 7.4+).
* ADDED: Early runtime guard before Composer autoload to prevent site-crashing fatals if a future release is built with incompatible vendor constraints.

= 4.1.0 =
* ADDED: ID-preserving approvals for WooCommerce products by default (`respira_preserve_product_ids_on_approve`), so approved changes keep the original live product ID.
* ADDED: Optional CSV setting for additional CPTs that should preserve IDs during approval (`respira_preserve_id_cpt_slugs`).
* ADDED: Setting-gated bulk approvals (`respira_enable_bulk_approvals`, off by default) with per-item success/failure reporting.
* CHANGED: Product/CPT approvals can now merge duplicate changes back into the original ID while retaining the duplicate as a private backup artifact.
* CHANGED: Direct edit contract is now explicit and single-step: direct live edits/deletes require `force=true` + `confirm_live_edit=true` when direct editing is enabled.
* FIXED: `update_custom_post` and `delete_custom_post` now follow duplicate-first safety parity with page/post routes and no longer bypass guardrails.

= 4.0.10 =
* FIXED: Duplicate creation no longer appends technical `_duplicate_*` suffixes to customer-facing titles
* FIXED: Approval now strips legacy `_duplicate_*` title suffixes before publishing, preventing storefront product title pollution
* IMPROVED: Added `_respira_duplicate_suffix` meta marker to support deterministic legacy-title normalization

= 4.0.9 =
* ADDED: New dismissible skills announcement notice on Respira admin pages to highlight newly published WordPress skills
* ADDED: Persistent per-user dismissal for the skills announcement notice

= 4.0.8 =
* FIXED: Approvals queue now includes Respira duplicates across all supported post types (pages, posts, products, and custom post types) instead of only pages/posts
* FIXED: Approvals empty-state copy now reflects all supported content types
* IMPROVED: Approvals cards now show the actual post type label for each original item (for example, Product, Case Study, Event)

= 4.0.7 =
* FIXED: Elementor URL validation now safely handles link-control arrays (`url`, `is_external`, `nofollow`) to prevent `esc_url_raw()` type fatal errors
* FIXED: Elementor fallback save path now invalidates `_elementor_element_cache` to prevent stale frontend renders after fallback writes
* ADDED: Regression test coverage for Elementor URL-array validation, root-only wrapping recursion, depth-guard limits, and throwable-safe fallback saves

= 4.0.6 =
* ADDED: Agent telemetry headers support (`X-Respira-Agent-*`) for MCP client attribution (Cursor, Claude Code, Codex, Windsurf, etc.)
* ADDED: Audit log request metadata enrichment with MCP version + agent telemetry for AI request diagnostics
* ADDED: Usage telemetry payload now includes agent client/version/transport for live stats aggregation
* ADDED: Setup permission callback now captures agent telemetry in request context for downstream tracking
* CHANGED: MCP desktop client now emits normalized agent signature headers on WordPress API calls
* CHANGED: Homepage Live Stats and Admin Platform dashboard now show AI-agent usage distribution and per-site primary agent

= 4.0.5 =
* FIXED: Normalized Elementor `_elementor_data` REST meta writes to prevent nested/double-serialized payload corruption
* FIXED: Hardened Elementor decode path to unwrap nested JSON-string wrappers and preserve valid element arrays
* FIXED: Added coercion guards in Elementor module updates to prevent array-to-scalar sanitizer crashes (`ltrim()` type errors)

= 4.0.4 =
* ADDED: WooCommerce taxonomy operations in the add-on flow (`categories` + `tags`) with create/read/update/delete routes and MCP tool parity
* ADDED: WebMCP tool registry now exposes WooCommerce category/tag operations for browser AI flows
* CHANGED: Browser AI inventory copy updated to 85 WordPress tools + 21 conditional WooCommerce tools (106 total when add-on is active)
* FIXED: Admin layout footer containment and dark-surface readability polish across setup/intelligence/report states

= 4.0.3 =
* FIXED: Hardened Elementor write operations (`inject_builder_content` and `update_module`) to avoid critical 500 errors and return structured diagnostics for MCP clients
* FIXED: Replaced hard `mb_strlen()` dependency in module update flow with safe byte-length fallback on hosts without mbstring
* FIXED: Improved dark-mode admin readability for labels/tables/notices/prompt textareas/footer links and removed duplicate intelligence status badge in builder cards
* FIXED: Removed header Documentation button and corrected wrapper nesting causing footer/layout spill on some admin pages

= 4.0.2 =
* FIXED: Improved heading contrast on Respira admin pages so titles/section headings remain readable on dark brand backgrounds
* FIXED: Builder Intelligence cards now use status pills for intelligence state (Active/Available/Not available) instead of inline status text
* CHANGED: Setup -> Health & Permissions is now read-only summary + Open Settings CTA; editing settings is consolidated in Respira -> Settings

= 4.0.1 =
* FIXED: Hardened Elementor builder inject flow to catch fatal throwables and safely fall back to meta persistence when Elementor API calls fail
* FIXED: Added structured REST error payload for builder inject server exceptions to improve MCP diagnostics instead of generic WordPress critical-error output
* FIXED: Updated plugin admin footer documentation link to `https://www.respira.press/docs`

= 4.0.0 =
* CHANGED: Major admin UX refresh aligned to Respira brand system, fully isolated under `.respira-admin` so no other wp-admin screens are affected
* CHANGED: New plugin admin IA (Overview, Setup, Approvals, Reports, Add-ons, Logs, Settings) with legacy slug redirects preserved
* CHANGED: Unified scoped admin component system for cards, tables, notices, diff blocks, and calmer safety-first workflows
* CHANGED: Improved approvals/readability UX and setup clarity while preserving all existing settings/forms/actions/AJAX contracts

= 3.3.1 =
* FIXED: Updated official WordPress MCP Adapter registration to modern `mcp_adapter_init` lifecycle with backward-compatible legacy fallback
* FIXED: Added compatibility handling for modern MCP Adapter `create_server()` signature (transport class + handlers + permission callback), with legacy fallback support
* CHANGED: Composer dependency target for `wordpress/mcp-adapter` is now `^0.4`
* CHANGED: Composer dependency target for `wordpress/abilities-api` now supports `^0.4 || ^1.0` for forward compatibility
* CHANGED: Added Composer `allow-plugins` configuration for `automattic/jetpack-autoloader` to keep release installs deterministic

= 3.3.0 =
* ADDED: New `respira/v2` fidelity model with include-gated read contracts and canonical builder payload/hash metadata
* ADDED: Snapshot lifecycle support (capture, list, diff, restore) with retention defaults (90 days + latest 50 per post)
* ADDED: Builder patch endpoint (`/respira/v2/builder/{builder}/patch/{post_id}`) with `id` and deterministic `path` targeting
* CHANGED: v2 writes enforce duplicate-before-edit for pages, posts, and custom post types
* CHANGED: Approval flow now blocks stale-base approvals by default with explicit force override authorization
* CHANGED: MCP/WebMCP now negotiate v2 automatically and fall back to v1 when unavailable

= 3.0.5 =
* ADDED: Respira API / Webhook URL now prominently displayed with copy button on dashboard (MCP clients connect to /wp-json/respira/v1/, not /wp-json/wp/v2)
* IMPROVED: Dashboard install section now recommends `npx @respira/wordpress-mcp-server --setup` first, with clearer setup flow
* IMPROVED: Clarified that MCP clients use the Respira endpoint, not the default WordPress REST API

= 3.0.4 =
* FIXED: Bricks inject now normalizes MCP payload variants (`elements` wrappers, simplified `type` payloads, and section/row/module wrappers) before save validation, resolving "Content validation failed" errors
* ADDED: Bricks now supports `wordpress_update_module` for module-level updates (admin label, path, and type/content matching)
* FIXED: Oxygen and Beaver Builder inject flows now normalize incoming MCP payload shapes and validate native saved structures, preventing false validation failures
* FIXED: Visual Composer inject now validates native element arrays (in addition to shortcode strings), preventing false validation failures on array payloads

= 3.0.3 =
* FIXED: Elementor inject no longer triggers recursive wrapping crashes in `complexify_structure()` when handling nested container `elements`
* FIXED: Elementor inject now normalizes `{sections:[...]}`, `{elements:[...]}`, and raw `elType` payloads before validation to avoid false "Each item must have a type" errors
* FIXED: Reduced non-actionable Sentry browser noise on Respira admin pages for Firefox unhandled rejection pattern "Object captured as promise rejection with keys: code, message" when no Respira frame is present

= 3.0.2 =
* FIXED: Dashboard MCP config now sets `WORDPRESS_URL` to the WordPress site root URL instead of the REST endpoint path, preventing duplicated `/wp-json/respira/v1` request URLs
* FIXED: Updated setup language and copy button labels from "Webhook URL" to "Site URL" and clarified the derived Respira API endpoint

= 3.0.1 =
* FIXED: Prevented multisite/WP-CLI bootstrap fatals caused by early REST URL resolution during WebMCP ability initialization
* FIXED: Deferred WebMCP exposed-tool option sync until `init` so permalink/REST globals are initialized before ability context checks
* FIXED: Hardened WooCommerce add-on context endpoint URL generation with bootstrap-safe REST URL fallback
* FIXED: Improved Respira context resilience by catching Woo add-on context errors during early lifecycle execution
* FIXED: Reduced Sentry admin noise by filtering third-party tracking breadcrumb errors and non-Respira `localeCompare`/`pointer` JavaScript exceptions

= 3.0.0 =
* ADDED: Bundled WebMCP bridge from Code Atlantic directly into Respira (GPL), including browser discovery/execution endpoints and frontend bridge assets
* ADDED: Complete Respira Browser AI ability inventory exposed via WordPress Abilities (77 WordPress tools + 11 conditional WooCommerce tools)
* ADDED: Respira Settings now include Browser AI (WebMCP) controls with "Enable all tools" and granular category allowlist
* ADDED: Dynamic MCP Adapter exposure now follows the same 77/88 registry contract used by bundled WebMCP
* CHANGED: Ability IDs rebased to MCP-aligned format `respira/{tool-name}` (no legacy aliases)
* CHANGED: Respira now ships as a unified one-plugin install for MCP + BrowserMCP tool exposure
* CHANGED: Bundled WebMCP upstream built-in starter tools are disabled so Respira-only tool registry is exposed
* DOCS: Added bundled WebMCP credits and integration notes

= 2.0.18 =
* FIXED: Divi code-module schema no longer instructs AI to force base64 content; prompts now preserve extracted encoding style
* FIXED: MCP Divi inject flow now rejects unknown/mixed Divi payload formats before save, preventing broken hybrid layouts

= 2.0.17 =
* ADDED: New Respira > Intelligence page with builder/theme detection restored in dedicated UI
* ADDED: Builder-aware intelligence panel now adapts capabilities and prompt examples to the active detected builder and site pages

= 2.0.16 =
* FIXED: Plugin header "Update Now" flow no longer crashes on failed upgrader responses and now returns actionable error messages
* FIXED: Accessibility page now renders in-plugin scan details and MCP fixing prompts (including queue view) instead of only refreshing

= 2.0.15 =
* CHANGED: Accessibility scanner now defaults to plugin-local scanning as the primary mode, with optional cloud/hybrid modes
* ADDED: Builder-aware MCP-first AI fix prompts generated directly in plugin scan payloads (Respira plugin + MCP required)
* ADDED: Prompt enrichment fallback in scan storage to regenerate legacy/non-MCP prompts into executable Respira workflows

= 2.0.14 =
* FIXED: Meta-only update flows now skip wp_update_post/save_post, preventing Elementor container CSS from being invalidated on duplicated drafts
* FIXED: Preserved JSON backslashes in post meta writes/copies to avoid _elementor_data unicode escape corruption on Cyrillic content
* IMPROVED: Added Elementor _elementor_data repair logic for malformed bare unicode escapes in API/builder read paths

= 2.0.13 =
* RELEASE: Packaging and distribution refresh for latest dashboard/accessibility rollout

= 2.0.12 =
* ADDED: Per-site usage stats on dashboard (lines changed, pages/posts edited/created, last activity)
* FIXED: Usage tracking now includes generic custom post create/update/delete endpoints

= 2.0.11 =
* FIXED: Prevented versioned GitHub release assets from being overwritten on reruns (versioned releases are now immutable)
* CHANGED: WooCommerce install notice no longer appears as a global Respira admin header notice
* CHANGED: Accessibility page now uses the shared Respira admin header/footer partials
* IMPROVED: Header focused on license/update context and removed extra account CTA clutter
* IMPROVED: Restored expanded Prompt Library with multi-section prompt packs

= 2.0.10 =
* FIXED: Prevented full/lite constant collisions when both plugins exist on the same site
* FIXED: Full plugin constants are now guarded to avoid redeclare notices in mixed-load environments
* FIXED: Eliminated path resolution conflicts that could cause fatal include errors during bootstrap

= 2.0.9 =
* FIXED: Ignore browser-extension noise in Sentry admin widget reporting (e.g. "Extension context invalidated")
* IMPROVED: Filter extension-originated stack traces/URLs from plugin Sentry telemetry

= 2.0.8 =
* FIXED: Approve flow now makes replaced originals private (instead of draft)
* FIXED: Removed overlapping WordPress footer/version text on Respira admin pages
* FIXED: Usage tracking lines now records content length reliably for page/post updates
* FIXED: API key screen clarifies prefix copy and supports full-key copy for newly generated recoverable keys
* FIXED: API key revoke flow hardened and made more reliable
* FIXED: Plugin metadata "Requires at least" corrected for broader WordPress compatibility

= 2.0.7 =
* ADDED: Divi 5 support (block-based layouts) while preserving Divi 4 shortcode support
* ADDED: Divi 5 Migration Copilot admin toolkit with readiness report and 5-prompt pack
* CHANGED: Divi inject now requires explicit format confirmation (`diviVersion`: 4 or 5) in MCP flows
* CHANGED: Added approvals URL guidance in MCP responses to review changes at `/wp-admin/admin.php?page=respira-approvals`
* NOTE: Respira helps plan and validate Divi 5 migration; Divi’s Migrator performs conversion

= 2.0.5 =
* IMPROVED: Cloud scanner now uses Google PageSpeed Insights API for reliable server-side scans on Vercel
* COMPATIBLE: Works with updated respira.press accessibility scan endpoint

= 2.0.4 =
* ADDED: Full server-side accessibility scanning via respira.press (Puppeteer + axe-core)
* ADDED: Dashboard header uses Respira brand logo (respira-logo-favicon.png)
* IMPROVED: Scan Now runs plugin scan for public URLs, stores results and reloads

= 2.0.3 =
* ADDED: Cloud scanner endpoint (https://respira.press/api/accessibility/scan-page) for server-side accessibility scans
* ADDED: 20x20 favicon for sidebar menu (respira-icon-20.png)
* IMPROVED: Scan Now tries plugin server-side scan first, falls back to extension with clear messaging
* IMPROVED: Non-2xx scanner responses handled correctly

= 2.0.2 =
* ADDED: Add-ons page in wp-admin (Respira → Add-ons) with WooCommerce and Accessibility add-on status
* ADDED: Real Respira brand logo in wp-admin sidebar menu (replaces simple R SVG)
* IMPROVED: Scan Now on Accessibility page now opens site in new tab for Chrome extension scanning
* IMPROVED: Dashboard Add-ons section links to dedicated Add-ons page

= 2.0.1 =
* Release 2.0.1 (release workflow and packaging)

= 2.0 =
* ADDED: Breakdance Builder support - 11th page builder with full detection, extraction, CSS injection, and AI documentation
* ADDED: Robust multi-fallback builder detection for Oxygen, Elementor, Divi, Bricks, Beaver Builder, Thrive, Brizy, Visual Composer, WPBakery
* ADDED: "Refresh detection" link in Builder & Theme Detection section

= 1.9.3 =
* FIXED: Robust builder detection - multi-fallback for all page builders (Oxygen, Elementor, Divi, Bricks, Beaver, Thrive, Brizy, Visual Composer, WPBakery)
* Each builder now checks multiple constants/classes/functions for different versions and load orders
* FIXED: "Refresh detection" link in Builder & Theme Detection - clears cache so newly activated builders show

= 1.9.2 =
* FIXED: API key display - newly generated API keys now reliably show with copy functionality
* Switched from transients to user meta for storage (more reliable)
* Prominent display with selectable input and copy-to-clipboard button

= 1.8.39 =
* IMPROVED: License revalidation now happens immediately when status is not active/trial
* This allows licenses updated server-side to work without waiting for 7-day auto-validation
* API key generation will now force revalidation if license status is inactive, enabling immediate access after license activation

= 1.8.38 =
* ADDED: Custom CSS support for posts (matching pages functionality)
* Custom CSS can now be set via custom_css parameter for both pages and posts
* Supports Divi Builder _et_pb_custom_css meta field with proper sanitization

= 1.8.37 =
* FIXED: Usage statistics tracking now works even when license key option is not set locally in WordPress
* IMPROVED: Tracker now uses license key from API key data when available
* This fixes empty stats dashboard issue where pages updated, posts updated, and lines of code showed as 0

= 1.8.18 =
* FIXED: Usage stats tracking now works for all users (not just PRO)
* IMPROVED: Better error logging for usage tracking diagnostics
* IMPROVED: Stats dashboard will now collect data from all users with license keys
* This enables comprehensive usage analytics for marketing and development insights

= 1.8.16 =
* Improved diagnostics extraction - Always include basic diagnostics when content extraction returns empty results
* Enhanced error reporting for page builder extraction failures

= 1.8.6 =
* FIXED: Sidebar icon now uses the official 20×20 SVG so it renders exactly like other WordPress menu items
* CHANGED: Start Here workflow rebuilt with a responsive 2-column grid and better hierarchy for steps 1-7
* CHANGED: Personal Onboarding card redesigned in dark mode with improved contrast, typography, and CTA

= 1.8.5 =
* CHANGED: Start Here page grid - improved step boxes layout with proportional sizing based on content
* CHANGED: Onboarding section - enhanced contrast and readability with better colors and typography
* CHANGED: Full-width layout - all plugin pages now use full width with left-aligned content
* CHANGED: Auto-update check interval - changed from 12 hours to 4 hours for faster update availability
* FIXED: Footer links - fixed 404 errors for "Add More Sites" and "Become an Affiliate" (changed from /account to /dashboard)

= 1.8.4 =
* ADDED: Privacy Policy and Terms of Service agreement requirement on license activation
* ADDED: Usage tracking for inject_builder_content API endpoint (page builder content injections)
* ADDED: Automatic page builder detection during license activation (Divi, Elementor, Gutenberg, etc.)
* CHANGED: License activation flow now requires explicit agreement to Privacy Policy and Terms
* CHANGED: Enhanced usage statistics tracking including builder content injections
* IMPROVED: Privacy disclosures throughout plugin settings and documentation

= 1.8.3 =
* CHANGED: Complete design system overhaul - professional redesign of entire admin interface
* CHANGED: New comprehensive design system inspired by respira.press
* CHANGED: Activation-state color theming: Red theme for unlicensed, Green theme for licensed
* CHANGED: Complete CSS refactoring with organized design tokens and component library
* IMPROVED: Typography system with consistent type scale and font families
* IMPROVED: Unified spacing system based on 8px base unit
* IMPROVED: Consistent border radius values across all components
* IMPROVED: Professional component library with reusable styles for buttons, badges, cards, sections, and tables
* IMPROVED: Enhanced visual hierarchy and readability
* IMPROVED: Better organized and maintainable CSS structure
* ADDED: Design system documentation (DESIGN-SYSTEM.md)

= 1.7.1 =
* FIXED: Admin styling - centered all Respira wp-admin screens with consistent dark canvas background
* FIXED: Removed grey seams at page edges when scrolling
* FIXED: Simplified page padding using single CSS variable for consistency
* IMPROVED: Updated sidebar icon to use official Respira logo with refined styling (rounded edges, branded drop shadow)
* IMPROVED: Typography spacing and readability across all admin pages (License, API Keys, Settings, Approvals, Audit Log)

= 1.7.0 =
* ADDED: Page Speed Analysis - comprehensive performance analysis tools
* ADDED: SEO Analysis - complete SEO optimization tools
* ADDED: AI Engine Optimization (AEO) - optimize content for AI search engines
* ADDED: Plugin Management (Experimental) - manage WordPress plugins via API (opt-in feature)
* NEW REST API Endpoints for analysis and plugin management

= 1.6.3 =
* ADDED: Personal Onboarding product integration in dashboard and Start Here pages
* IMPROVED: Added super admin functionality for enhanced account management
* IMPROVED: Updated admin panel access controls

= 1.6.2 =
* IMPROVED: Comprehensive UI/UX improvements for all plugin admin pages
* IMPROVED: Full-page dark background for better visual consistency
* IMPROVED: Audit Log page with white alternative rows for better readability
* IMPROVED: Approvals page with word count, character count, and improved button layout
* IMPROVED: Settings page with full dark background
* IMPROVED: API Keys page with better license notice integration
* IMPROVED: Start Here page with 3-column layout and newsletter subscription
* IMPROVED: Dashboard layout with improved Quick Links section
* IMPROVED: Dynamic header styling (red hues until license activated, then green)
* IMPROVED: Better page builder detection in dashboard footer
* FIXED: Duplicate step 5 in Start Here page
* FIXED: Page builder detection issues in Site Information card

= 1.6.4 =
* IMPROVED: Polished dashboard boxes with centered content and improved button styles
* IMPROVED: Enhanced typography and spacing throughout dashboard
* IMPROVED: Better button hover effects with gradients and shadows
* IMPROVED: FAQ column expansion fixed - items stay fixed when others open
* IMPROVED: Replaced emoji icons with Material Symbols icons in FAQ
* IMPROVED: Added spacing between version badge and license notice in header
* FIXED: All plugin pages now have consistent #1A1F2E dark background
* FIXED: Super admin dashboard now shows all sites and licenses properly
* FIXED: Super admin can add sites even with expired/cancelled licenses
* FIXED: Better error messages when adding duplicate sites
* FIXED: Improved add-site functionality for all users

= 1.6.5 =
* FIXED: Comprehensive dark mode fixes - all plugin pages now have consistent #1A1F2E background
* FIXED: Sidebar Respira logo now visible in wp-admin menu with proper styling
* FIXED: All text readability issues resolved - proper contrast on all pages
* FIXED: Dashboard card overlapping issues resolved with proper grid layout
* FIXED: Button text readability - all buttons now have white text with proper contrast
* FIXED: API endpoint and MCP settings hidden until license is activated
* FIXED: Footer text updated to "Respira for WordPress v1.6.5"
* IMPROVED: Ultra-aggressive CSS overrides to ensure dark background everywhere
* IMPROVED: Enhanced sidebar menu icon visibility and styling
* IMPROVED: Comprehensive text color fixes for headings, paragraphs, labels, and all elements

= 1.6.1 =
* CRITICAL FIX: Fixed fatal error "Class 'Respira_License' not found" in dashboard
* Fixed missing class loading for Respira_License in core plugin initialization

= 1.6.0 =
* Updated pricing to 1-year licenses (yearly payment only)
* Changed Agency plan from unlimited to 20 WordPress sites
* Added upgrade account banner in plugin dashboard
* Updated all upgrade links to point to /dashboard/billing
* Improved license messaging and upgrade prompts
* Updated plugin readme with new pricing structure

= 1.5.4 =

= 1.2.0 =
* NEW: Approval system - AI can only edit duplicates by default, not original pages
* NEW: Page Approvals admin page with two-column layout showing originals and duplicates
* NEW: Approve button to replace original pages with AI-enhanced duplicates
* NEW: "Allow Direct Editing" setting (disabled by default) to control force parameter behavior
* NEW: Enhanced error messages with step-by-step instructions and helpful links
* NEW: Modern toggle switches in settings page replacing checkboxes
* NEW: Post update and delete endpoints (previously only pages)
* IMPROVED: MCP server error handling now formats errors with actionable instructions
* IMPROVED: Tool descriptions updated to reflect new default behavior
* IMPROVED: Better user guidance when trying to edit original pages
* SECURITY: Direct editing of original pages disabled by default for safety

= 1.1.4 =
* CRITICAL FIX: Fixed PHP parse error in dashboard.php - missing endif statement
* FIXED: Dashboard page now loads correctly without syntax errors

= 1.1.3 =
* FIXED: Admin menu structure - removed duplicate Respira page causing errors
* FIXED: Main Respira menu item now properly displays dashboard
* IMPROVED: Clean menu structure with proper submenu ordering
* UPDATED: All links changed from respira.love to respira.press
* NEW: Created documentation pages on product website (documentation, installation, configuration, api-reference, support)

= 1.1.2 =
* NEW: Version badge displayed in dashboard header
* IMPROVED: Better visual hierarchy with styled version indicator
* IMPROVED: Version badge also shown on Start Here page

= 1.1.1 =
* NEW: Auto-update system with GitHub releases integration
* NEW: Custom update server endpoint for private repos
* NEW: Multi-tool dashboard with instructions for Cursor, Claude Code, and Codex
* NEW: Tabbed interface for easy switching between AI tools
* IMPROVED: Enhanced dashboard with platform-specific configuration paths
* IMPROVED: Better user experience with tool-specific setup instructions
* FIXED: Update server URL now points to respira.press

= 1.1.0 =
* NEW: Divi Intelligence - Comprehensive Divi Builder support
* NEW: Dynamic detection of all 200+ Divi modules
* NEW: Complete module schemas with attribute definitions
* NEW: Layout validation before content injection
* NEW: Global module support and resolution
* NEW: Layout pattern library for common Divi structures
* NEW: Enhanced AI context with Divi-specific prompts
* NEW: Improved shortcode parsing with WordPress native functions
* NEW: Performance monitoring for extract/inject operations
* IMPROVED: Divi support upgraded from 45% to 95%+
* IMPROVED: Better handling of complex nested layouts
* IMPROVED: Support for specialty sections and advanced features
* FIXED: Dynamic builder version detection (no longer hardcoded)
* NOTE: Divi Intelligence is a modular addon that can be sold separately

= 1.0.8 =
* CRITICAL FIX: Ultra-aggressive entity decoding now catches Divi's re-encoding during module render
* NEW: Added et_pb_module_content filter to decode entities RIGHT when Divi renders modules
* IMPROVED: Changed final cleanup priority from 99 to 9999 to run after ALL other filters
* IMPROVED: 5-iteration decoding loop (up from 3) to handle deeply nested encoding
* IMPROVED: Added hexadecimal entity support (&#x26;, &#x27;, &#x22;)
* IMPROVED: Automatic removal of <br /> and <p> tags around script tags via regex
* FIXED: Entities that were being re-encoded by Divi during shortcode processing
* FIXED: Script tags now properly decode even when Divi re-encodes them
* OPTIMIZED: Case-insensitive search (stripos) for better detection of encoded scripts

= 1.0.7 =
* CRITICAL FIX: Resolved HTML entity encoding breaking JavaScript execution (&#038; → &, &#8221; → ")
* CRITICAL FIX: Prevented wpautop from adding unwanted <br /> tags around script tags
* IMPROVED: Aggressive entity decoding with explicit str_replace for common WordPress entities
* IMPROVED: Priority 8 filter prevents wpautop interference (runs before wpautop at priority 10)
* IMPROVED: Script tag placeholder protection system to bypass wpautop processing
* FIXED: Logical operators (&&, ||) now render correctly instead of &#038;&#038;
* FIXED: Smart quotes (", ", ', ') decode properly from &#8220;, &#8221;, &#8216;, &#8217;
* FIXED: JavaScript in et_pb_html_content blocks now executes without entity encoding issues
* TESTED: Parallax scroll effects and Cal.com embeds confirmed working on mihai.love/vibe

= 1.0.6 =
* CRITICAL FIX: JavaScript now executes correctly on frontend pages
* NEW: Added frontend rendering filters to preserve scripts during page display
* IMPROVED: Early-priority filter (priority 5) decodes HTML entities before Divi processes shortcodes
* IMPROVED: Hook into Divi's module attribute processing to preserve scripts
* IMPROVED: Post-processing filter (priority 99) decodes any remaining encoded scripts
* FIXED: Script tags in et_pb_html_content blocks now execute on page load
* FIXED: Script tags in et_pb_code blocks now execute on page load
* FIXED: Triple-encoded HTML entities are properly decoded on frontend

= 1.0.5 =
* IMPROVED: Updated branding with official Respira logo from respira.cafe
* IMPROVED: Changed dashboard page title to "Respira for WordPress"
* IMPROVED: Added custom SVG icon to WordPress admin sidebar menu
* IMPROVED: Enhanced header layout with better logo display and responsiveness
* FIXED: Logo now properly loads and displays at optimal size (180px)

= 1.0.4 =
* CRITICAL FIX: Prevent WordPress from stripping script tags during API save operations
* NEW: Comprehensive content filter system for modern web features preservation
* IMPROVED: Enhanced script tag preservation in Divi et_pb_html_content modules
* IMPROVED: Enhanced script tag preservation in Divi et_pb_code modules
* IMPROVED: Multiple-pass HTML entity decoding to handle triple-encoded content
* IMPROVED: API update context tracking to preserve scripts only during authenticated API requests
* IMPROVED: Removal of all WordPress content sanitization filters during API updates (safely)
* FIXED: Third-party embeds (Cal.com, Google Analytics, etc.) now work correctly
* FIXED: Parallax and modern JavaScript animations no longer break
* FIXED: JavaScript wrapped in <p> tags issue resolved
* SECURITY: Maintained security by using custom wp_kses whitelist with script tag support
* SECURITY: Script preservation only enabled for authenticated API requests

= 1.0.3 =
* Added JavaScript and modern web technology support
* Enhanced content sanitization with script tag preservation
* Added data-* attribute support for modern frameworks
* Fixed script tags being stripped in Divi modules

= 1.0.2 =
* Fixed custom CSS output on frontend
* Improved CSS sanitization

= 1.0.1 =
* Added custom CSS support for Divi Builder
* Added SEO meta field support (Yoast, Rank Math, All in One SEO)
* Added featured image management
* Improved content extraction for page builders

= 1.0.0 =
* Initial release
* Gutenberg, Divi, Elementor, Oxygen, Bricks, Uncode support
* REST API with authentication
* Security validation
* Audit logging
* Multi-site support
* Rate limiting

== Upgrade Notice ==

= 1.1.0 =
MAJOR UPDATE: Introduces Divi Intelligence with comprehensive Divi Builder support. All 200+ Divi modules now fully supported with schemas, validation, and AI intelligence. Divi Intelligence is included in this release but can be sold as a separate addon in the future.

= 1.0.8 =
CRITICAL UPDATE: Fixes Divi re-encoding issue with ultra-aggressive decoding. If scripts STILL have &#038; entities after v1.0.7, update NOW!

= 1.0.7 =
CRITICAL UPDATE: Fixes HTML entity encoding (&#038;) and wpautop issues that break JavaScript. Update immediately if scripts aren't executing!

= 1.0.6 =
CRITICAL UPDATE: Fixes JavaScript execution on frontend. If your scripts aren't running on pages, update immediately!

= 1.0.5 =
Branding update with official Respira logo and improved dashboard UI.

= 1.0.4 =
CRITICAL UPDATE: Fixes script tags being stripped during save. If you use third-party embeds or JavaScript, update immediately!

= 1.0.3 =
Adds JavaScript and modern web technology support for Divi Builder.

= 1.0.0 =
Initial release. Install and start vibe coding your WordPress site!

== Privacy Policy ==

Respira for WordPress respects your privacy. We collect only anonymous usage statistics to improve the product.

**What We Collect:**
* Anonymous usage statistics (page/post update counts, approximate line counts)
* Detected page builders (for analytics and insights)
* License activation information

**What We Do NOT Collect:**
* Your actual WordPress content, code, or data
* Personal information or user data
* Database queries or configuration
* Any sensitive or confidential information

**What We Store Locally:**
* API keys (encrypted, in your WordPress database)
* Audit logs (on your WordPress site)
* Plugin settings (on your WordPress site)

**Usage Statistics:**
We collect anonymous aggregate statistics (e.g., "50 pages updated", "1000 lines of code") to understand usage patterns and improve the product. Your actual content, code, and data remain entirely on your server and are never transmitted to or stored on our servers.

All API communication happens directly between your local machine and your WordPress site. Usage statistics are sent asynchronously and do not impact plugin performance.

== Support ==

* Documentation: https://respira.press/documentation
* Installation Guide: https://respira.press/installation
* Configuration Guide: https://respira.press/configuration
* API Reference: https://respira.press/api-reference
* Support: https://respira.press/support
* Support Forum: https://wordpress.org/support/plugin/respira-for-wordpress/
* GitHub Issues: https://github.com/webmyc/respira-wordpress/issues
