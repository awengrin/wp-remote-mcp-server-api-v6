#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CSS_DIR="$ROOT_DIR/admin/assets/css"

printf "[Respira QA] Checking admin CSS selector scope...\n"
if rg -n '^[^{]*\{' "$CSS_DIR"/respira-admin*.css | awk -F: '{print $3}' | rg -v '^\s*\.respira-admin' >/tmp/respira-admin-scope-violations.txt; then
  printf "[Respira QA] FAIL: non-scoped selectors found in respira-admin*.css\n"
  cat /tmp/respira-admin-scope-violations.txt
  exit 1
fi

printf "[Respira QA] PASS: all selectors in respira-admin*.css are scoped to .respira-admin\n"
printf "[Respira QA] Manual checks:\n"
printf "  1) Visit Posts/Pages/Plugins/Settings and verify visuals are unchanged.\n"
printf "  2) Visit another plugin page (WooCommerce/Elementor) and verify visuals are unchanged.\n"
printf "  3) Confirm Respira CSS/JS are not loaded on non-Respira screens in devtools.\n"
