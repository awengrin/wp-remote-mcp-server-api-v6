<?php
/**
 * Tool Governance — per-tool enable/disable with audit logging.
 *
 * Single governance chokepoint called in BOTH the REST API permission
 * callback and the Abilities API handler. Fail-open on corrupt options.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Tool governance class.
 *
 * @since 5.2.0
 */
class Respira_Tool_Governance {

	/**
	 * Option name for the disabled tools list.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'respira_tool_governance_disabled';

	/**
	 * Check if a tool is allowed (not disabled by admin).
	 *
	 * Fail-open: if option is missing or corrupt, allow all tools.
	 *
	 * @since 5.2.0
	 * @param string $tool_name Tool name (any variant: respira_*, wordpress_*, or canonical).
	 * @return bool True if allowed, false if disabled.
	 */
	public static function is_tool_allowed( $tool_name ) {
		$canonical = self::canonicalize( $tool_name );
		$disabled  = self::get_disabled_tools();

		$allowed = ! in_array( $canonical, $disabled, true );

		// Log if denied.
		if ( ! $allowed && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( sprintf( 'Respira: Tool "%s" (canonical: "%s") blocked by governance.', $tool_name, $canonical ) );
		}

		return $allowed;
	}

	/**
	 * Get the list of disabled tools.
	 *
	 * @since 5.2.0
	 * @return array Array of canonical tool names that are disabled.
	 */
	public static function get_disabled_tools() {
		$raw = get_option( self::OPTION_KEY, '[]' );

		if ( is_array( $raw ) ) {
			return $raw;
		}

		$decoded = json_decode( $raw, true );

		if ( ! is_array( $decoded ) ) {
			// Corrupt option — fail-open.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira: Tool governance option is corrupt. Failing open (all tools allowed).' );
			}
			return array();
		}

		return $decoded;
	}

	/**
	 * Set the list of disabled tools.
	 *
	 * @since 5.2.0
	 * @param array $tools Array of canonical tool names to disable.
	 * @return bool True on success.
	 */
	public static function set_disabled_tools( $tools ) {
		if ( ! is_array( $tools ) ) {
			return false;
		}

		// Canonicalize all tool names.
		$tools = array_map( array( __CLASS__, 'canonicalize' ), $tools );
		$tools = array_unique( array_filter( $tools ) );

		return update_option( self::OPTION_KEY, wp_json_encode( array_values( $tools ) ) );
	}

	/**
	 * Canonicalize a tool name by stripping prefix.
	 *
	 * Both 'respira_update_page' and 'wordpress_update_page' → 'update_page'.
	 *
	 * @since 5.2.0
	 * @param string $tool_name Tool name.
	 * @return string Canonical name (without prefix).
	 */
	public static function canonicalize( $tool_name ) {
		$tool_name = strtolower( trim( $tool_name ) );

		// Strip known prefixes.
		$prefixes = array( 'respira_', 'wordpress_' );
		foreach ( $prefixes as $prefix ) {
			if ( strpos( $tool_name, $prefix ) === 0 ) {
				return substr( $tool_name, strlen( $prefix ) );
			}
		}

		return $tool_name;
	}

	/**
	 * Log a governance decision to the audit log.
	 *
	 * @since 5.2.0
	 * @param string $tool_name   Tool name as called.
	 * @param bool   $allowed     Whether the tool was allowed.
	 * @param int    $api_key_id  API key ID (0 if unknown).
	 */
	public static function log_decision( $tool_name, $allowed, $api_key_id = 0 ) {
		if ( ! class_exists( 'Respira_Auth' ) ) {
			return;
		}

		Respira_Auth::log_action(
			$api_key_id,
			0,
			$allowed ? 'governance_allow' : 'governance_deny',
			'tool_governance',
			null,
			array( 'tool' => $tool_name )
		);
	}

	/**
	 * Get tool categories for admin UI.
	 *
	 * @since 5.2.0
	 * @return array Category => tool names.
	 */
	public static function get_tool_categories() {
		return array(
			'pages'     => array(
				'list_pages', 'read_page', 'update_page', 'delete_page',
				'create_page_duplicate',
			),
			'posts'     => array(
				'list_posts', 'read_post', 'update_post', 'delete_post',
				'create_post_duplicate',
			),
			'media'     => array(
				'list_media', 'get_media', 'upload_media', 'update_media', 'delete_media',
			),
			'builder'   => array(
				'extract_builder_content', 'inject_builder_content',
				'find_element', 'update_element', 'move_element',
				'duplicate_element', 'remove_element', 'batch_update',
				'reorder_elements', 'build_page',
				'find_builder_targets', 'apply_builder_patch', 'update_module',
			),
			'analysis'  => array(
				'analyze_seo', 'analyze_performance', 'analyze_readability',
				'analyze_images', 'check_seo_issues', 'check_structured_data',
				'analyze_aeo', 'get_core_web_vitals', 'validate_security',
			),
			'stock'     => array(
				'search_stock_images', 'sideload_image',
			),
			'context'   => array(
				'get_site_context', 'get_builder_info', 'get_theme_docs',
			),
			'menus'     => array(
				'list_menus', 'get_menu', 'create_menu', 'update_menu', 'delete_menu',
				'list_menu_items', 'get_menu_item', 'create_menu_item',
				'update_menu_item', 'delete_menu_item',
				'list_menu_locations', 'assign_menu_location',
			),
			'snapshots' => array(
				'list_snapshots', 'get_snapshot', 'restore_snapshot', 'diff_snapshots',
			),
			'plugins'   => array(
				'list_plugins', 'install_plugin', 'activate_plugin',
				'deactivate_plugin', 'update_plugin', 'delete_plugin',
			),
			'users'     => array(
				'list_users', 'get_user', 'create_user', 'update_user', 'delete_user',
			),
		);
	}

	/**
	 * Get access profiles for API key generation.
	 *
	 * Each profile defines which tool categories are included.
	 * Governance is still the global kill switch — profiles only scope
	 * what a key *could* access if governance allows it.
	 *
	 * @since 5.2.0
	 * @return array Profile definitions keyed by slug.
	 */
	public static function get_access_profiles() {
		return array(
			'full_access'    => array(
				'label'       => __( 'Full Access', 'respira-for-wordpress' ),
				'description' => __( 'All tools, respects governance rules.', 'respira-for-wordpress' ),
				'categories'  => array_keys( self::get_tool_categories() ),
			),
			'read_only'      => array(
				'label'       => __( 'Read Only', 'respira-for-wordpress' ),
				'description' => __( 'Read pages, posts, context, and analysis. No writes.', 'respira-for-wordpress' ),
				'categories'  => array( 'context', 'analysis', 'snapshots' ),
				'extra_tools' => array( 'list_pages', 'read_page', 'list_posts', 'read_post', 'list_media', 'get_media', 'get_builder_info', 'extract_builder_content' ),
			),
			'content_editor' => array(
				'label'       => __( 'Content Editor', 'respira-for-wordpress' ),
				'description' => __( 'Read and write pages, posts, and media. No plugins, users, or settings.', 'respira-for-wordpress' ),
				'categories'  => array( 'pages', 'posts', 'media', 'context', 'analysis', 'snapshots', 'stock' ),
			),
			'builder_only'   => array(
				'label'       => __( 'Builder', 'respira-for-wordpress' ),
				'description' => __( 'Content editing plus all builder operations. No plugins or users.', 'respira-for-wordpress' ),
				'categories'  => array( 'pages', 'posts', 'media', 'builder', 'context', 'analysis', 'snapshots', 'stock' ),
			),
		);
	}

	/**
	 * Get all canonical tool names for a given access profile.
	 *
	 * @since 5.2.0
	 * @param string $profile_key Profile slug.
	 * @return array Array of canonical tool names.
	 */
	public static function get_profile_tools( $profile_key ) {
		$profiles = self::get_access_profiles();
		if ( ! isset( $profiles[ $profile_key ] ) ) {
			return array(); // Unknown profile = no tools.
		}
		$profile    = $profiles[ $profile_key ];
		$categories = self::get_tool_categories();
		$tools      = array();
		foreach ( $profile['categories'] as $cat ) {
			if ( isset( $categories[ $cat ] ) ) {
				$tools = array_merge( $tools, $categories[ $cat ] );
			}
		}
		if ( ! empty( $profile['extra_tools'] ) ) {
			$tools = array_merge( $tools, $profile['extra_tools'] );
		}
		return array_unique( $tools );
	}

	/**
	 * Check if a specific tool is allowed for a key's allowed_tools list.
	 *
	 * @since 5.2.0
	 * @param string $tool_name     Tool name (any variant).
	 * @param array  $allowed_tools Array of canonical tool names from the key.
	 * @return bool True if allowed.
	 */
	public static function is_tool_allowed_for_key( $tool_name, $allowed_tools ) {
		if ( empty( $allowed_tools ) || in_array( '*', $allowed_tools, true ) ) {
			return true; // Full access or legacy key.
		}
		$canonical = self::canonicalize( $tool_name );
		return in_array( $canonical, $allowed_tools, true );
	}
}
