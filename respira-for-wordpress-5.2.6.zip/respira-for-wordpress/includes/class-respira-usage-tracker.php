<?php
/**
 * Usage Statistics Tracker
 *
 * Tracks plugin usage and sends stats to Supabase for admin dashboard.
 * 
 * IMPORTANT: This only tracks general usage metrics (page/post counts, content length).
 * NO personal data, code content, or sensitive information is collected or stored.
 * All tracking is anonymous and aggregated to help improve the product.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * Usage Statistics Tracker class.
 * 
 * Privacy: Tracks only aggregate statistics. No code content, personal data,
 * or sensitive information is collected or transmitted.
 *
 * @since 1.8.3
 */
class Respira_Usage_Tracker {

	/**
	 * Usage API endpoint.
	 *
	 * @var string
	 */
	const USAGE_API_ENDPOINT = 'https://respira.press/api/usage/track';

	/**
	 * Sanitize version strings before sending telemetry.
	 *
	 * @param mixed $version Raw version value.
	 * @return string|null
	 */
	private static function sanitize_version( $version ) {
		if ( ! is_string( $version ) ) {
			return null;
		}

		$version = trim( $version );
		if ( '' === $version ) {
			return null;
		}

		$version = preg_replace( '/[^a-zA-Z0-9\.\-\+_]/', '', $version );
		if ( empty( $version ) ) {
			return null;
		}

		return substr( $version, 0, 64 );
	}

	/**
	 * Resolve MCP client version from request context, if available.
	 *
	 * @return string|null
	 */
	private static function get_mcp_version_from_context() {
		$mcp_version = null;

		global $wp;
		if ( isset( $wp->query_vars['_respira_key_data']['mcp_version'] ) ) {
			$mcp_version = self::sanitize_version( $wp->query_vars['_respira_key_data']['mcp_version'] );
		}

		if ( empty( $mcp_version ) && isset( $_SERVER['HTTP_X_RESPIRA_MCP_VERSION'] ) ) {
			$mcp_version = self::sanitize_version( wp_unslash( $_SERVER['HTTP_X_RESPIRA_MCP_VERSION'] ) );
		}

		return $mcp_version;
	}

	/**
	 * Sanitize agent telemetry values.
	 *
	 * @param mixed  $value Raw value.
	 * @param string $pattern Strip pattern.
	 * @return string|null
	 */
	private static function sanitize_agent_token( $value, $pattern = '/[^a-zA-Z0-9\.\-\+_\/]/' ) {
		if ( ! is_string( $value ) ) {
			return null;
		}

		$value = trim( $value );
		if ( '' === $value ) {
			return null;
		}

		$value = preg_replace( $pattern, '', $value );
		if ( empty( $value ) ) {
			return null;
		}

		return substr( strtolower( (string) $value ), 0, 64 );
	}

	/**
	 * Infer agent client from HTTP user agent when explicit telemetry headers are absent.
	 *
	 * @return string|null
	 */
	private static function infer_agent_from_user_agent() {
		if ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
			return null;
		}

		$user_agent = strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) );
		if ( false !== strpos( $user_agent, 'cursor' ) ) {
			return 'cursor';
		}
		if ( false !== strpos( $user_agent, 'claude' ) ) {
			return 'claude-code';
		}
		if ( false !== strpos( $user_agent, 'codex' ) ) {
			return 'codex';
		}
		if ( false !== strpos( $user_agent, 'windsurf' ) || false !== strpos( $user_agent, 'codeium' ) ) {
			return 'windsurf';
		}
		if ( false !== strpos( $user_agent, 'copilot' ) ) {
			return 'copilot';
		}

		return null;
	}

	/**
	 * Resolve agent telemetry from request context.
	 *
	 * @return array{client:string|null,version:string|null,transport:string|null}
	 */
	private static function get_agent_telemetry_from_context() {
		$client    = null;
		$version   = null;
		$transport = null;

		global $wp;
		if ( isset( $wp->query_vars['_respira_key_data'] ) && is_array( $wp->query_vars['_respira_key_data'] ) ) {
			$key_data  = $wp->query_vars['_respira_key_data'];
			$client    = self::sanitize_agent_token( $key_data['agent_client'] ?? null );
			$version   = self::sanitize_agent_token( $key_data['agent_version'] ?? null, '/[^a-zA-Z0-9\.\-\+_]/' );
			$transport = self::sanitize_agent_token( $key_data['agent_transport'] ?? null, '/[^a-zA-Z0-9\.\-\+_]/' );
		}

		if ( empty( $client ) && isset( $_SERVER['HTTP_X_RESPIRA_AGENT_CLIENT'] ) ) {
			$client = self::sanitize_agent_token( wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_CLIENT'] ) );
		}
		if ( empty( $version ) && isset( $_SERVER['HTTP_X_RESPIRA_AGENT_VERSION'] ) ) {
			$version = self::sanitize_agent_token( wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_VERSION'] ), '/[^a-zA-Z0-9\.\-\+_]/' );
		}
		if ( empty( $transport ) && isset( $_SERVER['HTTP_X_RESPIRA_AGENT_TRANSPORT'] ) ) {
			$transport = self::sanitize_agent_token( wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_TRANSPORT'] ), '/[^a-zA-Z0-9\.\-\+_]/' );
		}

		if ( empty( $client ) ) {
			$client = self::infer_agent_from_user_agent();
		}

		return array(
			'client'    => $client,
			'version'   => $version,
			'transport' => $transport,
		);
	}

	/**
	 * Resolve MCP tool name from request header.
	 *
	 * The MCP server sends X-Respira-Tool-Name on every REST call.
	 *
	 * @return string|null
	 */
	private static function get_tool_name_from_context() {
		if ( isset( $_SERVER['HTTP_X_RESPIRA_TOOL_NAME'] ) ) {
			$raw = wp_unslash( $_SERVER['HTTP_X_RESPIRA_TOOL_NAME'] );
			$sanitized = preg_replace( '/[^a-zA-Z0-9_\-]/', '', $raw );
			return ! empty( $sanitized ) ? substr( $sanitized, 0, 80 ) : null;
		}
		return null;
	}

	/**
	 * Track usage stat.
	 *
	 * Sends usage statistics to Supabase for tracking across all sites.
	 * 
	 * PRIVACY: Only tracks aggregate metrics:
	 * - Action type (update_page, update_post, etc.)
	 * - Resource type (page/post)
	 * - Resource ID (internal WordPress ID)
	 * - Content length estimate (line count, NOT actual content)
	 * 
	 * NO CODE CONTENT, personal data, or sensitive information is collected.
	 *
	 * @since 1.8.3
	 * @param string $action_type      Action type: 'update_page', 'update_post', 'inject_builder_content'.
	 * @param string $resource_type    Resource type: 'page' or 'post'.
	 * @param int    $resource_id      Resource ID.
	 * @param mixed  $content          Content being updated (for calculating lines of code ONLY - content itself is NOT sent).
	 * @param string $license_key      Optional. License key to use. If not provided, will try to get from options or API key data.
	 * @param array  $extra            Optional. Extra tracking fields: 'tool_name' (MCP tool), 'response_status' (HTTP status code).
	 * @return void
	 */
	public static function track( $action_type, $resource_type, $resource_id, $content = null, $license_key = null, $extra = array() ) {
		// Track usage for all users with a license key (not just PRO).
		// This helps us understand usage patterns across all tiers.
		
		// Try to get license key from parameter, then from options, then from API key data
		if ( empty( $license_key ) ) {
			$license_key = get_option( 'respira_license_key' );
		}
		
		// If still empty, try to get from API key data (if available in request context)
		if ( empty( $license_key ) ) {
			// Try to get from current request's API key data
			// This works when tracker is called from API endpoints that have validated the API key
			global $wp;
			if ( isset( $wp->query_vars['_respira_key_data'] ) && ! empty( $wp->query_vars['_respira_key_data']['license_key'] ) ) {
				$license_key = $wp->query_vars['_respira_key_data']['license_key'];
			}
		}
		
		if ( empty( $license_key ) ) {
			// Log for debugging but don't fail - tracking is non-critical
			error_log( 'Respira Usage Tracker: No license key found. Tracking skipped.' );
			return;
		}

		$site_url = get_site_url();
		$plugin_version = self::sanitize_version( defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '' );
		$mcp_version    = self::get_mcp_version_from_context();
		$agent_telemetry = self::get_agent_telemetry_from_context();

		// Calculate content length (lines of code/content).
		$content_length = 0;
		if ( ! empty( $content ) ) {
			if ( is_string( $content ) ) {
				// Count lines in content.
				$content_length = substr_count( $content, "\n" ) + 1;
				// Also approximate based on content length (average 80 chars per line).
				$content_length = max( $content_length, ceil( strlen( $content ) / 80 ) );
			} elseif ( is_array( $content ) ) {
				// For builder content, estimate from array structure.
				$content_str = wp_json_encode( $content );
				$content_length = ceil( strlen( $content_str ) / 80 );
			}
		}

		// Optionally detect and include page builders (for real-time updates).
		// Use transient cache to avoid checking on every call (check every 5 minutes).
		$detected_builders = null;
		$cache_key = 'respira_detected_builders';
		$cached_builders = get_transient( $cache_key );
		
		if ( false === $cached_builders ) {
			// Load Respira_Context if available (for builder detection).
			if ( ! class_exists( 'Respira_Context' ) ) {
				require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-context.php';
			}
			
			if ( class_exists( 'Respira_Context' ) ) {
				$builder_info = Respira_Context::get_builder_info();
				if ( isset( $builder_info['builders'] ) && is_array( $builder_info['builders'] ) ) {
					$detected_builders = array();
					foreach ( $builder_info['builders'] as $builder_name => $builder_data ) {
						if ( isset( $builder_data['detected'] ) && $builder_data['detected'] ) {
							$detected_builders[] = $builder_name;
						}
					}
					// Cache the result for 5 minutes (300 seconds).
					set_transient( $cache_key, $detected_builders, 300 );
				} else {
					// Cache empty result to avoid repeated checks.
					set_transient( $cache_key, array(), 300 );
				}
			}
		} else {
			$detected_builders = $cached_builders;
		}
		
		// Only include if we found builders (avoid sending empty array).
		if ( empty( $detected_builders ) || ! is_array( $detected_builders ) ) {
			$detected_builders = null;
		}

		// Prepare request data.
		$request_data = array(
			'license_key'   => $license_key,
			'site_url'      => $site_url,
			'action_type'   => $action_type,
			'resource_type' => $resource_type,
			'resource_id'   => $resource_id,
			'content_length' => $content_length,
		);

		if ( ! empty( $plugin_version ) ) {
			$request_data['plugin_version'] = $plugin_version;
		}

		if ( ! empty( $mcp_version ) ) {
			$request_data['mcp_version'] = $mcp_version;
		}

		if ( ! empty( $agent_telemetry['client'] ) ) {
			$request_data['agent_client'] = $agent_telemetry['client'];
		}

		if ( ! empty( $agent_telemetry['version'] ) ) {
			$request_data['agent_version'] = $agent_telemetry['version'];
		}

		if ( ! empty( $agent_telemetry['transport'] ) ) {
			$request_data['agent_transport'] = $agent_telemetry['transport'];
		}
		
		// Add detected builders if available (optional field).
		if ( ! empty( $detected_builders ) && is_array( $detected_builders ) ) {
			$request_data['detected_builders'] = $detected_builders;
		}

		// Add tool tracking fields — prefer explicit extra, fall back to request header.
		$tool_name = ! empty( $extra['tool_name'] ) ? sanitize_text_field( $extra['tool_name'] ) : self::get_tool_name_from_context();
		if ( ! empty( $tool_name ) ) {
			$request_data['tool_name'] = $tool_name;
		}
		if ( isset( $extra['response_status'] ) && is_numeric( $extra['response_status'] ) ) {
			$request_data['response_status'] = (int) $extra['response_status'];
		}

		/**
		 * PRIVACY: Transmission to Our Servers
		 *
		 * This is a blocking request with a short 2-second timeout.
		 * Non-blocking requests fail silently on most WordPress hosts.
		 *
		 * TRANSMITTED DATA (reminder):
		 * - License key, site URL, action type, resource type, resource ID
		 * - Approximate line count (NOT actual content)
		 * - Detected page builders (optional, only sent occasionally)
		 *
		 * NOT TRANSMITTED:
		 * - Actual page/post content
		 * - Code, scripts, or any sensitive data
		 * - Personal information or user data
		 *
		 * The short timeout minimizes performance impact.
		 * If the request fails, it's silently ignored (tracking is non-critical).
		 */
		$response = wp_remote_post(
			self::USAGE_API_ENDPOINT,
			array(
				'timeout'  => 2, // Short timeout to minimize performance impact
				'blocking' => true, // Must be blocking to actually send the request - non-blocking fails silently on most hosts
				'headers'  => array(
					'Content-Type' => 'application/json',
				),
				'body'     => wp_json_encode( $request_data ), // Only aggregate metrics, NO content
			)
		);

		// Log errors for debugging (even without WP_DEBUG to help diagnose tracking issues).
		// Don't wait for response or handle errors - tracking is non-critical.
		// Your content remains safely on your server.
		if ( is_wp_error( $response ) ) {
			error_log( 'Respira Usage Tracker Error: ' . $response->get_error_message() );
			error_log( 'Respira Usage Tracker Request Data: ' . wp_json_encode( array(
				'action_type' => $action_type,
				'resource_type' => $resource_type,
				'resource_id' => $resource_id,
				'site_url' => $site_url,
				'has_license' => ! empty( $license_key ),
			) ) );
		} else {
			// Log request details for debugging (helps identify if requests are being sent)
			error_log( 'Respira Usage Tracker: Request queued for ' . $action_type . ' (non-blocking)' );
			
			// In debug mode, also log the full request
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira Usage Tracker Request: ' . wp_json_encode( array(
					'endpoint' => self::USAGE_API_ENDPOINT,
					'action_type' => $action_type,
					'resource_type' => $resource_type,
					'resource_id' => $resource_id,
					'site_url' => $site_url,
					'content_length' => $content_length,
				) ) );
			}
		}
	}
}
