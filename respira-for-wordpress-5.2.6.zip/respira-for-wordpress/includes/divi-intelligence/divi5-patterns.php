<?php
/**
 * Divi 5 Layout Patterns.
 *
 * Real-world page patterns using Divi 5's block-based architecture.
 * Includes flexbox system, responsive breakpoints, and card patterns.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/divi-intelligence
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Get the Divi 5 flex fraction system.
 *
 * Divi 5 uses a 24-unit fraction system for column widths via flexColumnStructure
 * on the row and flexType on each column.
 *
 * @since 5.2.0
 * @return array Fraction name => CSS percentage width.
 */
function respira_get_divi5_flex_fractions() {
	return array(
		'24_24' => '100%',
		'18_24' => '75%',
		'16_24' => '66.667%',
		'12_24' => '50%',
		'8_24'  => '33.333%',
		'6_24'  => '25%',
		'4_24'  => '16.667%',
	);
}

/**
 * Get Divi 5 responsive breakpoints.
 *
 * Desktop is always required. Other breakpoints are optional overrides.
 *
 * @since 5.2.0
 * @return array Breakpoint name => min-width in pixels.
 */
function respira_get_divi5_breakpoints() {
	return array(
		'desktop'   => 981,  // >= 981px (always required).
		'tablet'    => 768,  // 768–980px.
		'phoneWide' => 480,  // 480–767px.
		'phone'     => 0,    // < 480px.
	);
}

/**
 * Get the Divi 5 card pattern decision tree.
 *
 * Three approaches for card-like layouts in Divi 5:
 * - column-as-card: entire column is one card (bg/border/padding on column)
 * - row-as-card: full-width card with inner layout (bg/border/padding on row)
 * - group-as-card: multiple cards stacked in one column (divi/group per card)
 *
 * @since 5.2.0
 * @return array Card pattern definitions.
 */
function respira_get_divi5_card_patterns() {
	return array(
		'column-as-card' => array(
			'description' => 'Whole column is one card. Apply bg, border, padding on the column.',
			'when'        => 'One card per column in a multi-column row.',
			'decoration'  => array(
				'background' => array(
					'desktop' => array(
						'value' => array(
							'color' => '#ffffff',
						),
					),
				),
				'border'     => array(
					'desktop' => array(
						'value' => array(
							'radius' => array(
								'topLeft'     => '12px',
								'topRight'    => '12px',
								'bottomLeft'  => '12px',
								'bottomRight' => '12px',
							),
						),
					),
				),
				'spacing'    => array(
					'desktop' => array(
						'value' => array(
							'padding' => array(
								'top'    => '24px',
								'right'  => '24px',
								'bottom' => '24px',
								'left'   => '24px',
							),
						),
					),
				),
				'boxShadow'  => array(
					'desktop' => array(
						'value' => array(
							'horizontal' => '0px',
							'vertical'   => '4px',
							'blur'       => '16px',
							'spread'     => '0px',
							'color'      => 'rgba(0,0,0,0.08)',
						),
					),
				),
			),
		),
		'row-as-card'    => array(
			'description' => 'Full-width card with inner rows. Apply bg/border/padding on the row.',
			'when'        => 'Single wide card spanning multiple columns inside.',
		),
		'group-as-card'  => array(
			'description' => 'Multiple cards stacked in one column. Each card is a divi/group.',
			'when'        => 'Multiple cards in a single column that each need independent styling.',
			'note'        => 'Only use divi/group when needed for multiple cards. A column already acts as a card on its own.',
		),
	);
}

/**
 * Get Divi 5 self-closing vs container module registry.
 *
 * Self-closing modules end with ` /-->` (space + slash). Container modules
 * require a matching close tag `<!-- /divi/module-name -->`.
 *
 * @since 5.2.0
 * @return array Keys: 'self_closing', 'container'.
 */
function respira_get_divi5_module_types() {
	return array(
		'self_closing' => array(
			'divi/text',
			'divi/heading',
			'divi/button',
			'divi/image',
			'divi/blurb',
			'divi/call-to-action',
			'divi/testimonial',
			'divi/video',
			'divi/code',
			'divi/divider',
			'divi/icon',
			'divi/link',
			'divi/team-member',
			'divi/number-counter',
			'divi/circle-counter',
			'divi/gallery',
			'divi/lottie',
			'divi/audio',
			'divi/before-after-image',
			'divi/countdown-timer',
			'divi/map',
			'divi/menu',
			'divi/search',
			'divi/sidebar',
			'divi/login',
			'divi/blog',
			'divi/post-title',
			'divi/comments',
			'divi/post-navigation',
			'divi/shop',
		),
		'container'    => array(
			'divi/section',
			'divi/row',
			'divi/column',
			'divi/group',
			'divi/group-carousel',
			'divi/accordion',
			'divi/tabs',
			'divi/contact-form',
			'divi/counters',
			'divi/pricing-tables',
			'divi/social-media-follow',
			'divi/icon-list',
			'divi/slider',
			'divi/video-slider',
		),
	);
}

/**
 * Get Divi 5 nesting hierarchy rules.
 *
 * Enforced rules:
 * - Section -> Row -> Column -> Module(s) — never skip levels.
 * - Rows CAN nest inside columns (for complex layouts).
 * - Sections CANNOT nest inside columns.
 * - Modules CANNOT be placed directly in section or row.
 *
 * @since 5.2.0
 * @return array Valid parent => allowed children mapping.
 */
function respira_get_divi5_nesting_rules() {
	return array(
		'root'         => array( 'divi/section' ),
		'divi/section' => array( 'divi/row' ),
		'divi/row'     => array( 'divi/column' ),
		'divi/column'  => array( '*modules', 'divi/row', 'divi/group' ),
		'divi/group'   => array( '*modules' ),
	);
}

/**
 * Get Divi 5 page layout patterns.
 *
 * Seven real-world patterns used as build_page templates.
 * Each pattern uses the Divi 5 block comment syntax and flexColumnStructure system.
 *
 * @since 5.2.0
 * @return array Pattern definitions keyed by name.
 */
function respira_get_divi5_patterns() {
	return array(

		'single_column_centered' => array(
			'name'        => 'Single-Column Centred Content',
			'description' => 'Section headers, CTAs, or simple centred content rows.',
			'use_cases'   => array( 'section headers', 'CTAs', 'single-column content' ),
			'structure'   => array(
				'section' => array(
					'row' => array(
						'flexColumnStructure' => '1',
						'columns'             => array(
							array(
								'flexType'  => '24_24',
								'textAlign' => 'center',
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone'     => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
				'phoneWide' => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
			),
		),

		'three_feature_cards' => array(
			'name'        => 'Three-Feature Card Row',
			'description' => 'Three equal columns with blurbs, commonly used for features or services.',
			'use_cases'   => array( 'features', 'services', 'benefits' ),
			'structure'   => array(
				'section' => array(
					'row' => array(
						'flexColumnStructure' => '3',
						'columns'             => array(
							array( 'flexType' => '8_24' ),
							array( 'flexType' => '8_24' ),
							array( 'flexType' => '8_24' ),
						),
					),
				),
			),
			'responsive'  => array(
				'phone'     => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
				'phoneWide' => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
				'tablet'    => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '12_24',
				),
			),
		),

		'hero_two_column' => array(
			'name'        => 'Hero Two-Column (Text + Image)',
			'description' => 'Hero section with text on left, image on right. Column-reverse on mobile.',
			'use_cases'   => array( 'hero', 'landing page header', 'above the fold' ),
			'structure'   => array(
				'section' => array(
					'row' => array(
						'flexColumnStructure' => '2',
						'columns'             => array(
							array(
								'flexType'       => '12_24',
								'content_hint'   => 'heading + text + button',
								'verticalAlign'  => 'center',
							),
							array(
								'flexType'     => '12_24',
								'content_hint' => 'image',
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone'     => array(
					'row_flexWrap'      => 'wrap',
					'column_flexType'   => '24_24',
					'row_flexDirection'  => 'column-reverse',
				),
				'phoneWide' => array(
					'row_flexWrap'      => 'wrap',
					'column_flexType'   => '24_24',
					'row_flexDirection'  => 'column-reverse',
				),
			),
		),

		'testimonials' => array(
			'name'        => 'Testimonials Section',
			'description' => 'Header row with centred heading, then a 3-column card row for testimonials.',
			'use_cases'   => array( 'testimonials', 'reviews', 'social proof' ),
			'structure'   => array(
				'section' => array(
					'rows' => array(
						array(
							'purpose'             => 'section header',
							'flexColumnStructure' => '1',
							'columns'             => array(
								array(
									'flexType'  => '24_24',
									'textAlign' => 'center',
								),
							),
						),
						array(
							'purpose'             => 'testimonial cards',
							'flexColumnStructure' => '3',
							'columns'             => array(
								array( 'flexType' => '8_24' ),
								array( 'flexType' => '8_24' ),
								array( 'flexType' => '8_24' ),
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone'     => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
				'phoneWide' => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
			),
		),

		'cta_section' => array(
			'name'        => 'CTA Section',
			'description' => 'Accent background, centred heading + text + button.',
			'use_cases'   => array( 'call to action', 'signup prompt', 'conversion section' ),
			'structure'   => array(
				'section' => array(
					'background' => 'accent color',
					'row'        => array(
						'flexColumnStructure' => '1',
						'columns'             => array(
							array(
								'flexType'  => '24_24',
								'textAlign' => 'center',
								'modules'   => array( 'heading', 'text', 'button' ),
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone'     => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
			),
		),

		'stats_bar' => array(
			'name'        => 'Stats Bar',
			'description' => 'Three-column number counters for statistics display.',
			'use_cases'   => array( 'stats', 'metrics', 'numbers' ),
			'structure'   => array(
				'section' => array(
					'row' => array(
						'flexColumnStructure' => '3',
						'columns'             => array(
							array(
								'flexType' => '8_24',
								'module'   => 'divi/number-counter',
							),
							array(
								'flexType' => '8_24',
								'module'   => 'divi/number-counter',
							),
							array(
								'flexType' => '8_24',
								'module'   => 'divi/number-counter',
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone' => array(
					'row_flexWrap'    => 'wrap',
					'column_flexType' => '24_24',
				),
			),
		),

		'animated_bg_orbs' => array(
			'name'        => 'Animated Background Orbs',
			'description' => 'Section with divi/code module containing CSS animation for floating background orbs.',
			'use_cases'   => array( 'hero background', 'decorative', 'visual interest' ),
			'structure'   => array(
				'section' => array(
					'overflow' => 'hidden',
					'position' => 'relative',
					'row'      => array(
						'flexColumnStructure' => '1',
						'columns'             => array(
							array(
								'flexType' => '24_24',
								'module'   => 'divi/code',
								'note'     => 'Contains CSS keyframes and absolute-positioned divs for floating orb animation.',
							),
						),
					),
				),
			),
			'responsive'  => array(
				'phone' => array(
					'note' => 'Consider hiding or reducing animation on mobile for performance.',
				),
			),
		),
	);
}

/**
 * Get Divi 5 side-by-side button pattern.
 *
 * To place buttons side-by-side, set flexDirection to "row" on the parent column.
 *
 * @since 5.2.0
 * @return array Pattern definition.
 */
function respira_get_divi5_side_by_side_buttons() {
	return array(
		'description'      => 'Place multiple buttons horizontally by setting flexDirection on parent column.',
		'column_decoration' => array(
			'layout' => array(
				'desktop' => array(
					'value' => array(
						'flexDirection' => 'row',
						'gap'           => '16px',
					),
				),
			),
		),
	);
}
