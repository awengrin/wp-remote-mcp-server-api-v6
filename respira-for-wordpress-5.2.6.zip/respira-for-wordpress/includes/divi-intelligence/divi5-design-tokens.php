<?php
/**
 * Divi 5 Design Tokens & Variable Reference System.
 *
 * Handles Divi 5's variable syntax for global colors, fonts, and content variables.
 * Used by the validator, build_page, and HTML-to-builder conversion pipeline.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/divi-intelligence
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Build a Divi 5 color variable reference string.
 *
 * Format: $variable({"type":"color","value":{"name":"gcid-ID","settings":{}}})$
 * CRITICAL: always include "settings":{} — omitting breaks the reference.
 *
 * @since 5.2.0
 * @param string $gcid The global color ID (e.g., "gcid-abc123def456").
 * @return string The variable reference string.
 */
function respira_divi5_color_variable( $gcid ) {
	return '$variable({"type":"color","value":{"name":"' . esc_attr( $gcid ) . '","settings":{}}})$';
}

/**
 * Build a Divi 5 content/font variable reference string.
 *
 * Format: $variable({"type":"content","value":{"name":"gvid-ID","settings":{}}})$
 *
 * @since 5.2.0
 * @param string $gvid The global variable ID (e.g., "gvid-abc123def456").
 * @return string The variable reference string.
 */
function respira_divi5_content_variable( $gvid ) {
	return '$variable({"type":"content","value":{"name":"' . esc_attr( $gvid ) . '","settings":{}}})$';
}

/**
 * Parse a Divi 5 variable reference string into its components.
 *
 * @since 5.2.0
 * @param string $reference The full variable reference string.
 * @return array|null Parsed components: {type, name, settings} or null if invalid.
 */
function respira_divi5_parse_variable( $reference ) {
	if ( ! is_string( $reference ) ) {
		return null;
	}

	// Match the $variable(...)$ pattern.
	if ( ! preg_match( '/^\$variable\((.+)\)\$$/', $reference, $matches ) ) {
		return null;
	}

	$json = $matches[1];
	$data = json_decode( $json, true );

	if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
		return null;
	}

	$type = $data['type'] ?? null;
	$name = $data['value']['name'] ?? null;
	$settings = $data['value']['settings'] ?? null;

	if ( ! $type || ! $name ) {
		return null;
	}

	// Warn if settings is missing (a common mistake).
	if ( null === $settings ) {
		return null;
	}

	return array(
		'type'     => $type,
		'name'     => $name,
		'settings' => $settings,
	);
}

/**
 * Validate a Divi 5 variable reference string.
 *
 * @since 5.2.0
 * @param string $reference The variable reference to validate.
 * @return array {valid: bool, error: string|null}
 */
function respira_divi5_validate_variable( $reference ) {
	if ( ! is_string( $reference ) ) {
		return array(
			'valid' => false,
			'error' => 'Variable reference must be a string.',
		);
	}

	if ( strpos( $reference, '$variable(' ) === false ) {
		return array(
			'valid' => true,
			'error' => null,
		);
	}

	$parsed = respira_divi5_parse_variable( $reference );

	if ( null === $parsed ) {
		// Try to provide a specific error message.
		if ( ! preg_match( '/^\$variable\((.+)\)\$$/', $reference, $matches ) ) {
			return array(
				'valid' => false,
				'error' => 'Variable reference must match $variable({...})$ format.',
			);
		}

		$json = $matches[1];
		$data = json_decode( $json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return array(
				'valid' => false,
				'error' => 'Variable JSON is malformed: ' . json_last_error_msg(),
			);
		}

		if ( ! isset( $data['value']['settings'] ) ) {
			return array(
				'valid' => false,
				'error' => "Variable reference missing 'settings:{}'. This will break the reference.",
			);
		}

		return array(
			'valid' => false,
			'error' => 'Variable reference is missing required fields (type or value.name).',
		);
	}

	return array(
		'valid' => true,
		'error' => null,
	);
}

/**
 * Get the format specification for Divi 5 global_colors.
 *
 * global_colors is an array of [id, {color, status, label}] tuples stored
 * in the Divi theme options / global settings.
 *
 * @since 5.2.0
 * @return array Format specification with example.
 */
function respira_get_divi5_global_colors_format() {
	return array(
		'description' => 'Array of [id, {color, status, label}] tuples.',
		'storage'     => 'Divi theme options (et_divi global_colors)',
		'example'     => array(
			array(
				'gcid-abc123def456',
				array(
					'color'  => '#4ecece',
					'status' => 'active',
					'label'  => 'Primary',
				),
			),
			array(
				'gcid-789xyz012345',
				array(
					'color'  => '#1a1a2e',
					'status' => 'active',
					'label'  => 'Dark Background',
				),
			),
		),
		'usage'       => 'Reference in module attributes via respira_divi5_color_variable($gcid)',
	);
}

/**
 * Get the format specification for Divi 5 global_variables.
 *
 * global_variables is an array of objects with id, label, value, status,
 * lastUpdated, order, and type. Used for fonts, content strings, and other
 * reusable values.
 *
 * @since 5.2.0
 * @return array Format specification with example.
 */
function respira_get_divi5_global_variables_format() {
	return array(
		'description' => 'Array of {id, label, value, status, lastUpdated, order, type} objects.',
		'storage'     => 'Divi theme options (et_divi global_variables)',
		'example'     => array(
			array(
				'id'          => 'gvid-font-heading-001',
				'label'       => 'Heading Font',
				'value'       => 'Sora',
				'status'      => 'active',
				'lastUpdated' => '2026-03-01T00:00:00Z',
				'order'       => 0,
				'type'        => 'font',
			),
			array(
				'id'          => 'gvid-font-body-001',
				'label'       => 'Body Font',
				'value'       => 'Inter',
				'status'      => 'active',
				'lastUpdated' => '2026-03-01T00:00:00Z',
				'order'       => 1,
				'type'        => 'font',
			),
		),
		'usage'       => 'Reference in module attributes via respira_divi5_content_variable($gvid)',
	);
}

/**
 * Get Divi 5 global font CSS custom property names.
 *
 * These can be used as fallbacks or for reference in CSS-based operations.
 *
 * @since 5.2.0
 * @return array Property name => description.
 */
function respira_get_divi5_global_font_properties() {
	return array(
		'--et_global_heading_font' => 'Global heading font family.',
		'--et_global_body_font'    => 'Global body text font family.',
	);
}

/**
 * Escape a Divi 5 variable reference for use within a JSON string context.
 *
 * Inner quotes must use \" when the variable reference is embedded inside
 * a JSON string value.
 *
 * @since 5.2.0
 * @param string $variable_ref The variable reference string.
 * @return string JSON-safe variable reference.
 */
function respira_divi5_escape_variable_for_json( $variable_ref ) {
	// The variable reference contains JSON internally.
	// When embedding inside another JSON string, inner quotes must be escaped.
	return str_replace( '"', '\\"', $variable_ref );
}

/**
 * Check if a string value contains a Divi 5 variable reference.
 *
 * @since 5.2.0
 * @param string $value The value to check.
 * @return bool True if the value contains a variable reference.
 */
function respira_divi5_is_variable_reference( $value ) {
	if ( ! is_string( $value ) ) {
		return false;
	}
	return strpos( $value, '$variable(' ) !== false && strpos( $value, ')$' ) !== false;
}

/**
 * Get the Divi 5 builder version string.
 *
 * Every module in Divi 5 content must include this builderVersion.
 *
 * @since 5.2.0
 * @return string The builder version.
 */
function respira_get_divi5_builder_version() {
	return '5.0.1';
}
