<?php
/**
 * Divi Intelligence - Layout Validator.
 *
 * Validates Divi module structures and attributes before injection.
 * Supports both Divi 4 (et_pb_* shortcodes) and Divi 5 (divi/* blocks).
 *
 * Divi 5 validation implements a 13-point checklist with 16 common mistake
 * patterns that return actionable error messages.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/divi-intelligence
 * @since      1.0.0
 */

/**
 * Divi validator class.
 *
 * @since 1.0.0
 */
class Respira_Divi_Validator {

	/**
	 * Validate module structure (Divi 4 legacy).
	 *
	 * Checks for required parent modules and proper nesting.
	 *
	 * @since 1.0.0
	 * @param array  $modules     Array of modules to validate.
	 * @param string $parent_type Parent module type for nesting checks.
	 * @return array Array with 'valid' (bool) and 'errors' (array).
	 */
	public static function validate_structure( $modules, $parent_type = '' ) {
		$errors = array();

		foreach ( $modules as $index => $module ) {
			$module_type = $module['type'] ?? '';

			// Validate module type.
			if ( empty( $module_type ) || ( strpos( $module_type, 'et_pb_' ) !== 0 && strpos( $module_type, 'divi/' ) !== 0 && strpos( $module_type, '/' ) === false ) ) {
				$errors[] = sprintf(
					/* translators: %d: module index */
					__( 'Module at index %d has invalid type.', 'respira-for-wordpress' ),
					$index
				);
				continue;
			}

			// Check nesting rules.
			$nesting_errors = self::validate_nesting( $module, $index, $parent_type );
			$errors         = array_merge( $errors, $nesting_errors );

			// Validate children recursively.
			if ( ! empty( $module['children'] ) ) {
				$child_result = self::validate_structure( $module['children'], $module_type );
				if ( ! $child_result['valid'] ) {
					$errors = array_merge( $errors, $child_result['errors'] );
				}
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}

	/**
	 * Validate module nesting rules.
	 *
	 * @since 1.0.0
	 * @param array  $module      Module to validate.
	 * @param int    $index       Module index.
	 * @param string $parent_type Parent module type.
	 * @return array Array of error messages.
	 */
	private static function validate_nesting( $module, $index, $parent_type = '' ) {
		$errors = array();
		$type   = $module['type'] ?? '';

		// Divi 5 sections should stay top-level.
		if ( strpos( $type, 'divi/section' ) === 0 && ! empty( $parent_type ) ) {
			$errors[] = sprintf(
				/* translators: %d: module index */
				__( 'Divi 5 section at index %d must be top-level.', 'respira-for-wordpress' ),
				$index
			);
		}

		// Divi 5 rows should be nested inside sections.
		if ( strpos( $type, 'divi/row' ) === 0 && ! empty( $parent_type ) && strpos( $parent_type, 'divi/section' ) !== 0 && strpos( $parent_type, 'divi/column' ) !== 0 ) {
			$errors[] = sprintf(
				/* translators: %d: module index */
				__( 'Divi 5 row at index %d should be inside a Divi section or column.', 'respira-for-wordpress' ),
				$index
			);
		}

		// Columns should be inside rows.
		if ( strpos( $type, 'divi/column' ) === 0 && ! empty( $parent_type ) && strpos( $parent_type, 'divi/row' ) !== 0 ) {
			$errors[] = sprintf(
				/* translators: %d: module index */
				__( 'Divi 5 column at index %d should be inside a Divi row.', 'respira-for-wordpress' ),
				$index
			);
		}

		// Modules cannot be placed directly in section or row (must be in column).
		if ( self::is_divi5_leaf_module( $type ) && ! empty( $parent_type ) ) {
			if ( strpos( $parent_type, 'divi/section' ) === 0 || strpos( $parent_type, 'divi/row' ) === 0 ) {
				$errors[] = sprintf(
					"Module '%s' placed directly in %s. Must be inside a column.",
					$type,
					$parent_type
				);
			}
		}

		// Group/container-like nodes should stay inside layout containers.
		if ( self::is_divi5_group_node( $type ) && ! empty( $parent_type ) && ! self::is_divi5_layout_parent( $parent_type ) ) {
			$errors[] = sprintf(
				/* translators: %d: module index */
				__( 'Divi 5 group/container at index %d has an invalid parent.', 'respira-for-wordpress' ),
				$index
			);
		}

		// Legacy/shortcode wrapper blocks should be treated as opaque.
		if ( self::is_legacy_wrapper_block( $type, $module ) && ! empty( $module['children'] ) ) {
			$errors[] = sprintf(
				/* translators: %d: module index */
				__( 'Legacy block at index %d must remain opaque (no nested edits).', 'respira-for-wordpress' ),
				$index
			);
		}

		// Check for maximum nesting depth (prevent infinite recursion).
		$depth = self::calculate_depth( $module );
		if ( $depth > 10 ) {
			$errors[] = sprintf(
				/* translators: 1: module type, 2: depth */
				__( 'Module %1$s at index %2$d exceeds maximum nesting depth.', 'respira-for-wordpress' ),
				$type,
				$index
			);
		}

		return $errors;
	}

	/**
	 * Detect if a block represents a legacy shortcode wrapper.
	 *
	 * @since 1.9.2
	 * @param string $type   Module/block type.
	 * @param array  $module Module data.
	 * @return bool True if legacy wrapper.
	 */
	private static function is_legacy_wrapper_block( $type, $module ) {
		if ( 'core/shortcode' === $type ) {
			return true;
		}

		if ( strpos( $type, 'legacy' ) !== false || strpos( $type, 'shortcode' ) !== false ) {
			return true;
		}

		$content = $module['content'] ?? '';
		return is_string( $content ) && strpos( $content, '[et_pb_' ) !== false;
	}

	/**
	 * Detect Divi 5 group/container nodes.
	 *
	 * @since 1.9.2
	 * @param string $type Module/block type.
	 * @return bool
	 */
	private static function is_divi5_group_node( $type ) {
		return strpos( $type, 'divi/group' ) === 0 || strpos( $type, 'divi/container' ) === 0;
	}

	/**
	 * Detect valid Divi 5 layout parents.
	 *
	 * @since 1.9.2
	 * @param string $type Module/block type.
	 * @return bool
	 */
	private static function is_divi5_layout_parent( $type ) {
		return strpos( $type, 'divi/section' ) === 0 ||
			strpos( $type, 'divi/row' ) === 0 ||
			strpos( $type, 'divi/column' ) === 0 ||
			self::is_divi5_group_node( $type );
	}

	/**
	 * Detect if a Divi 5 module type is a leaf (non-container) module.
	 *
	 * @since 5.2.0
	 * @param string $type Module/block type.
	 * @return bool True if this is a content/leaf module.
	 */
	private static function is_divi5_leaf_module( $type ) {
		if ( strpos( $type, 'divi/' ) !== 0 ) {
			return false;
		}

		$layout_types = array(
			'divi/section', 'divi/row', 'divi/column',
			'divi/group', 'divi/group-carousel', 'divi/container',
		);

		foreach ( $layout_types as $layout_type ) {
			if ( strpos( $type, $layout_type ) === 0 ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Calculate nesting depth of a module.
	 *
	 * @since 1.0.0
	 * @param array $module        Module to check.
	 * @param int   $current_depth Current recursion depth.
	 * @return int Nesting depth.
	 */
	private static function calculate_depth( $module, $current_depth = 0 ) {
		if ( $current_depth > 10 ) {
			return $current_depth; // Prevent infinite recursion.
		}

		if ( empty( $module['children'] ) ) {
			return $current_depth;
		}

		$max_child_depth = $current_depth;
		foreach ( $module['children'] as $child ) {
			$child_depth = self::calculate_depth( $child, $current_depth + 1 );
			if ( $child_depth > $max_child_depth ) {
				$max_child_depth = $child_depth;
			}
		}

		return $max_child_depth;
	}

	/**
	 * Validate module attributes against schema.
	 *
	 * @since 1.0.0
	 * @param string $module_name Module name (e.g., 'et_pb_text').
	 * @param array  $attributes   Attributes to validate.
	 * @return array Array with 'valid' (bool) and 'errors' (array).
	 */
	public static function validate_attributes( $module_name, $attributes ) {
		$errors = array();

		if ( ! class_exists( 'Respira_Divi_Module_Schema' ) ) {
			// Can't validate without schema.
			return array(
				'valid'  => true,
				'errors' => array(),
			);
		}

		$schema = Respira_Divi_Module_Schema::get_module_schema( $module_name );
		if ( ! $schema ) {
			// No schema available, skip validation.
			return array(
				'valid'  => true,
				'errors' => array(),
			);
		}

		$schema_attrs = $schema['attributes'] ?? array();

		// Check required attributes.
		foreach ( $schema_attrs as $attr_name => $attr_def ) {
			if ( ! empty( $attr_def['required'] ) && ! isset( $attributes[ $attr_name ] ) ) {
				$errors[] = sprintf(
					/* translators: 1: attribute name, 2: module name */
					__( 'Required attribute "%1$s" missing for module %2$s.', 'respira-for-wordpress' ),
					$attr_name,
					$module_name
				);
			}
		}

		// Validate attribute formats.
		foreach ( $attributes as $attr_name => $attr_value ) {
			if ( ! isset( $schema_attrs[ $attr_name ] ) ) {
				// Unknown attribute - allow it (Divi has many dynamic attributes).
				continue;
			}

			$attr_def = $schema_attrs[ $attr_name ];
			$format   = $attr_def['format'] ?? '';

			// Validate color format.
			if ( 'color' === $attr_def['type'] && 'hex' === $format ) {
				if ( ! preg_match( '/^#[0-9A-Fa-f]{6}$/', $attr_value ) ) {
					$errors[] = sprintf(
						/* translators: 1: attribute name, 2: module name */
						__( 'Attribute "%1$s" for module %2$s must be a valid hex color (e.g., #000000).', 'respira-for-wordpress' ),
						$attr_name,
						$module_name
					);
				}
			}

			// Validate URL format.
			if ( 'url' === $format && ! empty( $attr_value ) ) {
				if ( ! filter_var( $attr_value, FILTER_VALIDATE_URL ) ) {
					$errors[] = sprintf(
						/* translators: 1: attribute name, 2: module name */
						__( 'Attribute "%1$s" for module %2$s must be a valid URL.', 'respira-for-wordpress' ),
						$attr_name,
						$module_name
					);
				}
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}

	/**
	 * Validate complete layout before injection.
	 *
	 * @since 1.0.0
	 * @param array $modules Array of modules to validate.
	 * @return array Array with 'valid' (bool) and 'errors' (array).
	 */
	public static function validate_layout( $modules ) {
		$errors = array();

		// Validate structure.
		$structure_result = self::validate_structure( $modules );
		if ( ! $structure_result['valid'] ) {
			$errors = array_merge( $errors, $structure_result['errors'] );
		}

		// Validate attributes for each module.
		foreach ( $modules as $module ) {
			$module_type = $module['type'] ?? '';
			$attributes  = $module['attributes'] ?? ( $module['attrs'] ?? array() );

			// The simplified structure stores 'content' as a top-level key,
			// but the schema marks it as a required attribute. Merge it in
			// so validation passes for both input formats.
			if ( isset( $module['content'] ) && ! isset( $attributes['content'] ) ) {
				$attributes['content'] = $module['content'];
			}

			if ( ! empty( $module_type ) ) {
				$attr_result = self::validate_attributes( $module_type, $attributes );
				if ( ! $attr_result['valid'] ) {
					$errors = array_merge( $errors, $attr_result['errors'] );
				}
			}

			// Validate children recursively.
			if ( ! empty( $module['children'] ) ) {
				$child_result = self::validate_layout( $module['children'] );
				if ( ! $child_result['valid'] ) {
					$errors = array_merge( $errors, $child_result['errors'] );
				}
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}

	// =========================================================================
	// Divi 5 Block Content Validation (13-point checklist)
	// =========================================================================

	/**
	 * Validate a full Divi 5 save payload (the JSON sent to WordPress).
	 *
	 * Implements the 13-point checklist for Divi 5 block-based content.
	 * Returns actionable error messages for 16 common mistakes.
	 *
	 * @since 5.2.0
	 * @param array $payload The full save payload (decoded JSON).
	 * @return array {valid: bool, errors: string[], warnings: string[]}
	 */
	public static function validate_divi5_payload( $payload ) {
		$errors   = array();
		$warnings = array();

		// Step 0: Ensure payload is valid.
		if ( ! is_array( $payload ) ) {
			$errors[] = 'Payload must be a JSON object. If parsing failed: ' . json_last_error_msg();
			return array(
				'valid'    => false,
				'errors'   => $errors,
				'warnings' => $warnings,
			);
		}

		// --- Root structure checks ---

		// Check 1: "context": "et_builder" is present.
		if ( ! isset( $payload['context'] ) || 'et_builder' !== $payload['context'] ) {
			$errors[] = 'Missing or incorrect "context" field. Must be "et_builder".';
		}

		// Check 2: "data" has exactly one key (integer string).
		if ( ! isset( $payload['data'] ) || ! is_array( $payload['data'] ) ) {
			$errors[] = 'Missing "data" field or "data" is not an object.';
		} else {
			$data_keys = array_keys( $payload['data'] );
			if ( count( $data_keys ) !== 1 ) {
				$errors[] = 'The "data" object must have exactly one key (the post ID as a string).';
			} else {
				$post_key  = $data_keys[0];
				$data_value = $payload['data'][ $post_key ];

				// Check 3: data value is a plain string (NOT nested object with post_content/post_title).
				if ( ! is_string( $data_value ) ) {
					$errors[] = "data value must be a string, not an object. Remove post_content/post_title nesting.";
				} else {
					// --- Content string checks ---
					$content = $data_value;

					// Check 4: Starts with wp:divi/placeholder.
					if ( strpos( $content, '<!-- wp:divi/placeholder -->' ) !== 0 ) {
						$errors[] = 'Content must be wrapped in <!-- wp:divi/placeholder -->.';
					}

					// Check 5: Ends with wp:divi/placeholder close.
					$trimmed = rtrim( $content );
					if ( substr( $trimmed, -strlen( '<!-- /wp:divi/placeholder -->' ) ) !== '<!-- /wp:divi/placeholder -->' ) {
						$errors[] = 'Content must end with <!-- /wp:divi/placeholder -->.';
					}

					// Check 6-8: Validate nesting within the content string.
					$nesting_result = self::validate_divi5_content_nesting( $content );
					$errors         = array_merge( $errors, $nesting_result['errors'] );
					$warnings       = array_merge( $warnings, $nesting_result['warnings'] );

					// Check 9-16: Validate module-level rules.
					$module_result = self::validate_divi5_modules_in_content( $content );
					$errors        = array_merge( $errors, $module_result['errors'] );
					$warnings      = array_merge( $warnings, $module_result['warnings'] );
				}
			}
		}

		return array(
			'valid'    => empty( $errors ),
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Validate nesting rules within Divi 5 block content string.
	 *
	 * Checks:
	 * - Every section has at least one row (Check 6)
	 * - Every row has at least one column (Check 7)
	 * - No module placed directly in section or row (Check 8)
	 *
	 * @since 5.2.0
	 * @param string $content The block content string.
	 * @return array {errors: string[], warnings: string[]}
	 */
	private static function validate_divi5_content_nesting( $content ) {
		$errors   = array();
		$warnings = array();

		// Extract all opening block comments.
		preg_match_all( '/<!-- wp:(divi\/[\w-]+)\s+(\{[^}]*\})\s*(?:\/)?-->/', $content, $matches, PREG_SET_ORDER );

		$module_types = function_exists( 'respira_get_divi5_module_types' )
			? respira_get_divi5_module_types()
			: array( 'self_closing' => array(), 'container' => array() );

		$self_closing = $module_types['self_closing'] ?? array();

		// Build a simple stack to track nesting.
		$stack = array();
		// Use a line-by-line approach for nesting validation.
		preg_match_all( '/<!-- (?:wp:)?(divi\/[\w-]+)\s|<!-- \/(divi\/[\w-]+)\s/', $content, $tag_matches, PREG_SET_ORDER );

		$section_has_row    = array();
		$row_has_column     = array();
		$section_count      = 0;
		$row_count          = 0;

		foreach ( $tag_matches as $match ) {
			if ( ! empty( $match[1] ) ) {
				// Opening tag.
				$tag_type = $match[1];
				$stack[]  = $tag_type;

				$parent = count( $stack ) > 1 ? $stack[ count( $stack ) - 2 ] : 'root';

				if ( 'divi/section' === $tag_type ) {
					$section_count++;
					$section_has_row[ $section_count ] = false;
				}

				if ( 'divi/row' === $tag_type ) {
					$row_count++;
					$row_has_column[ $row_count ] = false;
					if ( $section_count > 0 ) {
						$section_has_row[ $section_count ] = true;
					}
				}

				if ( 'divi/column' === $tag_type && $row_count > 0 ) {
					$row_has_column[ $row_count ] = true;
				}

				// Check 8: Leaf modules not directly in section or row.
				if ( in_array( $tag_type, $self_closing, true ) ) {
					if ( 'divi/section' === $parent || 'divi/row' === $parent ) {
						$errors[] = sprintf(
							"Module '%s' placed directly in %s. Must be inside a column.",
							$tag_type,
							$parent
						);
					}
				}
			} elseif ( ! empty( $match[2] ) ) {
				// Closing tag.
				array_pop( $stack );
			}
		}

		// Check 6: Every section has at least one row.
		foreach ( $section_has_row as $idx => $has_row ) {
			if ( ! $has_row ) {
				$errors[] = sprintf( 'Section #%d has no row children. Every section needs at least one row.', $idx );
			}
		}

		// Check 7: Every row has at least one column.
		foreach ( $row_has_column as $idx => $has_col ) {
			if ( ! $has_col ) {
				$errors[] = sprintf( 'Row #%d has no column children. Every row needs at least one column.', $idx );
			}
		}

		return array(
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Validate module-level rules in Divi 5 content.
	 *
	 * Checks (9-13) and common mistakes (16 patterns):
	 * - builderVersion on every module (Check 9)
	 * - Non-self-closing modules have matching close tags (Check 10)
	 * - Self-closing modules end with ` /-->` (Check 11)
	 * - flexColumnStructure count matches column count (Check 12)
	 * - Mobile breakpoints set for columns (Check 13)
	 * - 16 common mistake patterns with actionable errors
	 *
	 * @since 5.2.0
	 * @param string $content The block content string.
	 * @return array {errors: string[], warnings: string[]}
	 */
	private static function validate_divi5_modules_in_content( $content ) {
		$errors   = array();
		$warnings = array();

		$module_types = function_exists( 'respira_get_divi5_module_types' )
			? respira_get_divi5_module_types()
			: array( 'self_closing' => array(), 'container' => array() );

		$self_closing_types = $module_types['self_closing'] ?? array();
		$container_types    = $module_types['container'] ?? array();

		$builder_version = function_exists( 'respira_get_divi5_builder_version' )
			? respira_get_divi5_builder_version()
			: '5.0.1';

		// Extract all module blocks with their JSON attributes.
		preg_match_all(
			'/<!-- wp:(divi\/[\w-]+)\s+(\{.*?\})\s*(\/)?-->/s',
			$content,
			$module_matches,
			PREG_SET_ORDER | PREG_OFFSET_CAPTURE
		);

		$open_containers = array();

		foreach ( $module_matches as $idx => $match ) {
			$module_type = $match[1][0];
			$json_str    = $match[2][0];
			$is_self_close_syntax = ! empty( $match[3][0] );
			$position    = $idx + 1;

			// Parse JSON.
			$attrs = json_decode( $json_str, true );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				$errors[] = sprintf(
					"Module '%s' at position %d has malformed JSON: %s",
					$module_type,
					$position,
					json_last_error_msg()
				);
				continue;
			}

			// Check 9: builderVersion present.
			if ( ! isset( $attrs['builderVersion'] ) ) {
				$errors[] = sprintf(
					"Module '%s' at position %d missing builderVersion. Add \"builderVersion\": \"%s\".",
					$module_type,
					$position,
					$builder_version
				);
			}

			// Check 11: Self-closing syntax.
			$is_self_closing_type = in_array( $module_type, $self_closing_types, true );
			if ( $is_self_closing_type && ! $is_self_close_syntax ) {
				$errors[] = sprintf(
					"Module '%s' is self-closing but missing ' /-->' ending.",
					$module_type
				);
			}

			// Track containers for close tag matching (Check 10).
			$is_container_type = in_array( $module_type, $container_types, true );
			if ( $is_container_type && ! $is_self_close_syntax ) {
				$open_containers[] = $module_type;
			}

			// --- Common mistake checks ---

			// Mistake 3: Row flex not working (CSS display:flex instead of flexColumnStructure).
			if ( 'divi/row' === $module_type ) {
				$decoration = $attrs['module']['decoration'] ?? array();
				$display    = $decoration['display']['desktop']['value'] ?? '';
				if ( 'flex' === $display ) {
					$warnings[] = "Row has display:flex but Divi uses flexColumnStructure. Set module.advanced.flexColumnStructure instead.";
				}

				// Check 12: flexColumnStructure count matches actual columns.
				$flex_structure = $attrs['module']['advanced']['flexColumnStructure'] ?? null;
				if ( null !== $flex_structure ) {
					$declared_count = (int) $flex_structure;
					// Count column children in content after this row.
					$row_offset = $match[0][1];
					$actual_columns = self::count_direct_children_of_type( $content, $row_offset, 'divi/column', 'divi/row' );
					if ( $actual_columns > 0 && $declared_count !== $actual_columns ) {
						$errors[] = sprintf(
							"Row declares %d columns but contains %d divi/column children.",
							$declared_count,
							$actual_columns
						);
					}
				}
			}

			// Mistake 4: HTML in heading title.
			if ( 'divi/heading' === $module_type ) {
				$title_content = $attrs['module']['advanced']['title']['innerContent'] ?? '';
				if ( is_string( $title_content ) && preg_match( '/<[a-zA-Z][^>]*>/', $title_content ) ) {
					$errors[] = "Heading contains HTML tags. Use plain text and set headingLevel in font decoration.";
				}
			}

			// Mistake 9: Wrong button attributes (Divi 4 vs 5).
			if ( 'divi/button' === $module_type ) {
				if ( isset( $attrs['url'] ) || isset( $attrs['module']['advanced']['url'] ) ) {
					$errors[] = "Button uses 'url' — Divi 5 uses 'linkUrl'. Also: 'newWindow' → 'linkTarget'.";
				}
			}

			// Mistake 11: Wrong blurb title format.
			if ( 'divi/blurb' === $module_type ) {
				$blurb_title = $attrs['module']['advanced']['title'] ?? null;
				if ( is_string( $blurb_title ) ) {
					$errors[] = 'Blurb title must be {"text": "..."} object, not a plain string.';
				}
			}

			// Mistake 10: Variable references missing settings.
			$variable_errors = self::check_variable_references( $attrs, $module_type, $position );
			$errors          = array_merge( $errors, $variable_errors );

			// Mistake 16: syncVertical/syncHorizontal booleans instead of strings.
			$sync_errors = self::check_sync_values( $attrs, $module_type );
			$errors      = array_merge( $errors, $sync_errors );

			// Mistake 13: Over-wrapping with group.
			if ( 'divi/group' === $module_type ) {
				$warnings[] = "Column already acts as a card. divi/group is only needed for multiple cards in one column.";
			}

			// Mistake 15: Separate form submit button.
			if ( 'divi/contact-form' === $module_type ) {
				// Check if a divi/button follows this contact form (common mistake).
				if ( isset( $module_matches[ $idx + 1 ] ) && 'divi/button' === $module_matches[ $idx + 1 ][1][0] ) {
					$warnings[] = "Contact form submit uses the 'button' key on contact-form, not a separate divi/button.";
				}
			}

			// Check for groupPreset keys (site-specific, won't port).
			if ( isset( $attrs['groupPreset'] ) ) {
				$warnings[] = sprintf(
					"Module '%s' at position %d has a 'groupPreset' key. These are site-specific and won't port to other sites.",
					$module_type,
					$position
				);
			}
		}

		// Check 10: Verify all containers have close tags.
		foreach ( $open_containers as $container_type ) {
			$close_tag = '<!-- /wp:' . $container_type . ' -->';
			if ( strpos( $content, $close_tag ) === false ) {
				$errors[] = sprintf(
					"Container module '%s' has no matching close tag.",
					$container_type
				);
			}
		}

		return array(
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Count direct children of a specific type within a container in block content.
	 *
	 * @since 5.2.0
	 * @param string $content     Full content string.
	 * @param int    $start_offset Byte offset of the container opening tag.
	 * @param string $child_type  The child block type to count (e.g., 'divi/column').
	 * @param string $parent_type The parent block type (e.g., 'divi/row').
	 * @return int Number of direct children of the specified type.
	 */
	private static function count_direct_children_of_type( $content, $start_offset, $child_type, $parent_type ) {
		// Find the closing tag of the parent.
		$close_tag = '<!-- /wp:' . $parent_type . ' -->';
		$close_pos = strpos( $content, $close_tag, $start_offset );
		if ( false === $close_pos ) {
			return 0;
		}

		$inner = substr( $content, $start_offset, $close_pos - $start_offset );

		// Count opening tags of the child type at depth 1.
		$depth = 0;
		$count = 0;
		$open_pattern  = '<!-- wp:' . preg_quote( $parent_type, '/' ) . '\s';
		$close_pattern = preg_quote( $close_tag, '/' );
		$child_pattern = '<!-- wp:' . preg_quote( $child_type, '/' ) . '\s';

		// Simple approach: count child_type opening tags that aren't nested in another parent_type.
		preg_match_all( '/<!-- wp:' . preg_quote( $child_type, '/' ) . '\s/', $inner, $child_matches );
		return count( $child_matches[0] );
	}

	/**
	 * Check variable references in module attributes for missing settings.
	 *
	 * @since 5.2.0
	 * @param array  $attrs       Module attributes.
	 * @param string $module_type Module type name.
	 * @param int    $position    Module position in content.
	 * @return array Error messages.
	 */
	private static function check_variable_references( $attrs, $module_type, $position ) {
		$errors    = array();
		$json_str  = wp_json_encode( $attrs );

		if ( false === $json_str ) {
			return $errors;
		}

		// Find all $variable(...) patterns.
		if ( preg_match_all( '/\$variable\((\{.*?\})\)\$/', $json_str, $var_matches ) ) {
			foreach ( $var_matches[1] as $var_json ) {
				// Unescape JSON-within-JSON.
				$var_json_clean = stripslashes( $var_json );
				$var_data       = json_decode( $var_json_clean, true );

				if ( null === $var_data ) {
					$errors[] = sprintf(
						"Variable reference in '%s' at position %d has malformed JSON.",
						$module_type,
						$position
					);
					continue;
				}

				if ( ! isset( $var_data['value']['settings'] ) ) {
					$errors[] = "Variable reference missing 'settings:{}'. This will break the reference.";
				}
			}
		}

		return $errors;
	}

	/**
	 * Check syncVertical/syncHorizontal values are strings, not booleans.
	 *
	 * @since 5.2.0
	 * @param array  $attrs       Module attributes.
	 * @param string $module_type Module type name.
	 * @return array Error messages.
	 */
	private static function check_sync_values( $attrs, $module_type ) {
		$errors   = array();
		$json_str = wp_json_encode( $attrs );

		if ( false === $json_str ) {
			return $errors;
		}

		// Look for syncVertical or syncHorizontal with boolean values.
		if ( preg_match( '/"sync(?:Vertical|Horizontal)"\s*:\s*(true|false)/', $json_str ) ) {
			$errors[] = "syncVertical/syncHorizontal must be 'on'/'off' strings, not true/false.";
		}

		return $errors;
	}
}
