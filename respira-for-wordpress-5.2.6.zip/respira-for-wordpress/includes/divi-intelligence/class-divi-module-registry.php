<?php
/**
 * Divi Intelligence - Module Registry.
 *
 * Dynamically detects and catalogs all available Divi modules.
 * Part of Divi Intelligence addon for Respira for WordPress.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/divi-intelligence
 */

/**
 * Divi module registry class.
 *
 * @since 1.0.0
 */
class Respira_Divi_Module_Registry {

	/**
	 * Cache key for module list.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	const CACHE_KEY = 'respira_divi_modules';

	/**
	 * Cache expiration (24 hours).
	 *
	 * @since 1.0.0
	 * @var int
	 */
	const CACHE_EXPIRATION = 86400;

	/**
	 * Conservative allowlist of Divi 5 blocks that are safe to advertise by default.
	 *
	 * Some Divi runtimes register many native `divi/*` blocks before their
	 * save/render pipeline can safely round-trip them. Keep the default AI-facing
	 * allowlist narrow and let advanced sites opt in via filters.
	 *
	 * @since 4.2.1
	 * @var array
	 */
	const AI_SAFE_BLOCK_ALLOWLIST = array(
		'divi/placeholder',
		'divi/section',
		'divi/row',
		'divi/column',
		'divi/group',
		'divi/container',
		'divi/code',
		'divi/layout',
		'divi/shortcode-module',
	);

	/**
	 * Get all registered Divi modules.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	public static function get_all_modules() {
		// Try cache first.
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return $cached;
		}

		$modules = self::detect_modules();

		// Cache for 24 hours.
		set_transient( self::CACHE_KEY, $modules, self::CACHE_EXPIRATION );

		return $modules;
	}

	/**
	 * Get all registered Divi 5 block modules.
	 *
	 * @since 4.2.1
	 * @return array
	 */
	public static function get_block_modules() {
		return self::filter_modules_by_prefix( self::get_all_modules(), 'divi/' );
	}

	/**
	 * Get AI-safe Divi modules for documentation and builder capability output.
	 *
	 * Divi 4 shortcode modules remain available. Divi 5 native blocks are reduced
	 * to a conservative allowlist unless the site owner extends it via filters.
	 *
	 * @since 4.2.1
	 * @return array
	 */
	public static function get_ai_safe_modules() {
		$all_modules = self::get_all_modules();
		$allowlist   = self::get_ai_safe_block_allowlist();
		$safe        = array();

		foreach ( $all_modules as $module ) {
			$name = isset( $module['name'] ) ? (string) $module['name'] : '';
			if ( '' === $name ) {
				continue;
			}

			if ( 0 === strpos( $name, 'divi/' ) && ! in_array( $name, $allowlist, true ) ) {
				continue;
			}

			$safe[] = $module;
		}

		/**
		 * Filter AI-safe Divi modules.
		 *
		 * @since 4.2.1
		 * @param array $safe      Modules currently considered safe for AI defaults.
		 * @param array $all       All registered modules.
		 * @param array $allowlist Safe Divi 5 block allowlist.
		 */
		$filtered = apply_filters( 'respira_divi_ai_safe_modules', $safe, $all_modules, $allowlist );

		return is_array( $filtered ) ? array_values( $filtered ) : $safe;
	}

	/**
	 * Get AI-safe Divi 5 blocks.
	 *
	 * @since 4.2.1
	 * @return array
	 */
	public static function get_ai_safe_block_modules() {
		$safe_blocks = array();
		$allowlist   = self::get_ai_safe_block_allowlist();

		foreach ( self::get_block_modules() as $module ) {
			$name = isset( $module['name'] ) ? (string) $module['name'] : '';
			if ( '' !== $name && in_array( $name, $allowlist, true ) ) {
				$safe_blocks[] = $module;
			}
		}

		return $safe_blocks;
	}

	/**
	 * Get registered Divi 5 blocks that are intentionally not advertised by default.
	 *
	 * @since 4.2.1
	 * @return array
	 */
	public static function get_ai_restricted_block_modules() {
		$restricted = array();
		$allowlist  = self::get_ai_safe_block_allowlist();

		foreach ( self::get_block_modules() as $module ) {
			$name = isset( $module['name'] ) ? (string) $module['name'] : '';
			if ( '' !== $name && ! in_array( $name, $allowlist, true ) ) {
				$restricted[] = $module;
			}
		}

		return $restricted;
	}

	/**
	 * Detect all Divi modules.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	private static function detect_modules() {
		$modules = array();

		// Strategy 1: Try to use Divi's module registry if available.
		if ( class_exists( 'ET_Builder_Module' ) ) {
			$modules = self::merge_module_lists( $modules, self::detect_from_divi_registry() );
		}

		// Strategy 2: Scan WordPress shortcode registry.
		$modules = self::merge_module_lists( $modules, self::detect_from_shortcode_registry() );

		// Strategy 3: Detect Divi 5 block modules from block registry.
		$modules = self::merge_module_lists( $modules, self::detect_from_block_registry() );

		// Strategy 4: Fallback to comprehensive static list.
		if ( empty( $modules ) ) {
			$modules = self::get_static_module_list();
		}

		return $modules;
	}

	/**
	 * Get AI-safe Divi 5 block allowlist.
	 *
	 * @since 4.2.1
	 * @return array
	 */
	private static function get_ai_safe_block_allowlist() {
		$allowlist = apply_filters( 'respira_divi_ai_safe_block_allowlist', self::AI_SAFE_BLOCK_ALLOWLIST );
		if ( ! is_array( $allowlist ) ) {
			return self::AI_SAFE_BLOCK_ALLOWLIST;
		}

		$normalized = array();
		foreach ( $allowlist as $module_name ) {
			if ( ! is_string( $module_name ) ) {
				continue;
			}

			$module_name = trim( $module_name );
			if ( '' === $module_name ) {
				continue;
			}

			$normalized[ $module_name ] = $module_name;
		}

		return array_values( $normalized );
	}

	/**
	 * Filter modules by a name prefix.
	 *
	 * @since 4.2.1
	 * @param array  $modules Module list.
	 * @param string $prefix  Prefix to match.
	 * @return array
	 */
	private static function filter_modules_by_prefix( $modules, $prefix ) {
		$filtered = array();

		foreach ( $modules as $module ) {
			$name = isset( $module['name'] ) ? (string) $module['name'] : '';
			if ( '' !== $name && 0 === strpos( $name, $prefix ) ) {
				$filtered[] = $module;
			}
		}

		return $filtered;
	}

	/**
	 * Detect modules from Divi's internal registry.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	private static function detect_from_divi_registry() {
		$modules = array();

		// Check if ET_Builder_Module has a registry method.
		if ( class_exists( 'ET_Builder_Module' ) && method_exists( 'ET_Builder_Module', 'get_modules' ) ) {
			$divi_modules = ET_Builder_Module::get_modules();
			foreach ( $divi_modules as $module_name => $module_class ) {
				if ( strpos( $module_name, 'et_pb_' ) === 0 ) {
					$modules[] = array(
						'name'        => $module_name,
						'title'       => self::get_module_title( $module_name ),
						'description' => self::get_module_description( $module_name ),
						'category'    => self::get_module_category( $module_name ),
					);
				}
			}
		}

		return $modules;
	}

	/**
	 * Detect modules from WordPress shortcode registry.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	private static function detect_from_shortcode_registry() {
		global $shortcode_tags;
		$modules = array();

		if ( ! empty( $shortcode_tags ) ) {
			foreach ( $shortcode_tags as $tag => $callback ) {
				if ( strpos( $tag, 'et_pb_' ) === 0 ) {
					$modules[] = array(
						'name'        => $tag,
						'title'       => self::get_module_title( $tag ),
						'description' => self::get_module_description( $tag ),
						'category'    => self::get_module_category( $tag ),
					);
				}
			}
		}

		return $modules;
	}

	/**
	 * Detect Divi 5 modules from block registry.
	 *
	 * @since 1.9.2
	 * @return array Array of module definitions.
	 */
	private static function detect_from_block_registry() {
		$modules = array();

		if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
			return $modules;
		}

		$registry  = WP_Block_Type_Registry::get_instance();
		$all_types = $registry->get_all_registered();

		foreach ( $all_types as $name => $block_type ) {
			if ( strpos( $name, 'divi/' ) !== 0 ) {
				continue;
			}

			$title = $block_type->title ? $block_type->title : self::get_module_title( $name );
			$description = $block_type->description ? $block_type->description : sprintf(
				/* translators: %s: module name */
				__( 'Divi 5 %s block', 'respira-for-wordpress' ),
				$title
			);

			$modules[] = array(
				'name'        => $name,
				'title'       => $title,
				'description' => $description,
				'category'    => 'block',
				'attributes'  => is_array( $block_type->attributes ) ? $block_type->attributes : array(),
				'format'      => 'block',
			);
		}

		return $modules;
	}

	/**
	 * Merge module lists without duplicate names.
	 *
	 * @since 1.9.2
	 * @param array $base Base list.
	 * @param array $incoming Incoming list.
	 * @return array Merged list.
	 */
	private static function merge_module_lists( $base, $incoming ) {
		$merged = array();

		foreach ( $base as $module ) {
			if ( isset( $module['name'] ) ) {
				$merged[ $module['name'] ] = $module;
			}
		}

		foreach ( $incoming as $module ) {
			if ( isset( $module['name'] ) ) {
				$merged[ $module['name'] ] = array_merge( $merged[ $module['name'] ] ?? array(), $module );
			}
		}

		return array_values( $merged );
	}

	/**
	 * Get comprehensive static list of all known Divi modules.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	private static function get_static_module_list() {
		// Load module definitions from data file.
		$module_file = RESPIRA_PLUGIN_DIR . 'includes/divi-intelligence/divi-modules.php';
		if ( file_exists( $module_file ) ) {
			require_once $module_file;
			if ( function_exists( 'respira_get_divi_module_definitions' ) ) {
				return respira_get_divi_module_definitions();
			}
		}

		// Fallback: Try to detect from Divi's internal structure.
		return self::detect_from_divi_internal();
	}

	/**
	 * Detect modules from Divi's internal structure.
	 *
	 * @since 1.0.0
	 * @return array Array of module definitions.
	 */
	private static function detect_from_divi_internal() {
		$modules = array();

		// Try to use Divi's module loader if available.
		if ( class_exists( 'ET_Builder_Module' ) ) {
			// Use reflection to get all module classes.
			$builder_dir = '';
			if ( defined( 'ET_BUILDER_DIR' ) ) {
				$builder_dir = ET_BUILDER_DIR . 'modules/';
			} elseif ( defined( 'ET_CORE_PATH' ) ) {
				$builder_dir = ET_CORE_PATH . 'app/models/builder/module/';
			}

			if ( ! empty( $builder_dir ) && is_dir( $builder_dir ) ) {
				$module_files = glob( $builder_dir . '*.php' );
				foreach ( $module_files as $file ) {
					$module_name = basename( $file, '.php' );
					if ( strpos( $module_name, 'et_pb_' ) === 0 ) {
						$modules[] = array(
							'name'        => $module_name,
							'title'       => self::get_module_title( $module_name ),
							'description' => self::get_module_description( $module_name ),
							'category'    => self::get_module_category( $module_name ),
						);
					}
				}
			}
		}

		// If still empty, return comprehensive list from data file.
		if ( empty( $modules ) ) {
			$module_file = RESPIRA_PLUGIN_DIR . 'includes/divi-intelligence/divi-modules.php';
			if ( file_exists( $module_file ) ) {
				require_once $module_file;
				if ( function_exists( 'respira_get_divi_module_definitions' ) ) {
					$modules = respira_get_divi_module_definitions();
					// Remove tier from all modules.
					foreach ( $modules as &$module ) {
						unset( $module['tier'] );
					}
				}
			}
		}

		return $modules;
	}

	/**
	 * Get module title.
	 *
	 * @since 1.0.0
	 * @param string $module_name Module name.
	 * @return string Module title.
	 */
	private static function get_module_title( $module_name ) {
		// Remove et_pb_ prefix and format.
		$title = str_replace( 'et_pb_', '', $module_name );
		$title = str_replace( 'divi/', '', $title );
		$title = str_replace( '_', ' ', $title );
		$title = str_replace( '-', ' ', $title );
		return ucwords( $title );
	}

	/**
	 * Get module description.
	 *
	 * @since 1.0.0
	 * @param string $module_name Module name.
	 * @return string Module description.
	 */
	private static function get_module_description( $module_name ) {
		// Default description - can be enhanced with lookup table.
		return sprintf(
			/* translators: %s: module name */
			__( 'Divi %s module', 'respira-for-wordpress' ),
			self::get_module_title( $module_name )
		);
	}

	/**
	 * Get module category.
	 *
	 * @since 1.0.0
	 * @param string $module_name Module name.
	 * @return string Module category.
	 */
	private static function get_module_category( $module_name ) {
		// Categorize based on module name patterns.
		if ( strpos( $module_name, 'section' ) !== false || strpos( $module_name, 'row' ) !== false ) {
			return 'layout';
		}
		if ( strpos( $module_name, 'image' ) !== false || strpos( $module_name, 'video' ) !== false || strpos( $module_name, 'gallery' ) !== false ) {
			return 'media';
		}
		if ( strpos( $module_name, 'form' ) !== false || strpos( $module_name, 'contact' ) !== false ) {
			return 'form';
		}
		return 'content';
	}

	/**
	 * Get module tier (deprecated - all modules are now equal priority).
	 *
	 * @since 1.0.0
	 * @param string $module_name Module name.
	 * @return int Always returns 1 (all modules equal priority).
	 */
	private static function get_module_tier( $module_name ) {
		// All modules are now equal priority - full support for all.
		return 1;
	}

	/**
	 * Get modules by tier (deprecated - kept for backward compatibility).
	 *
	 * @since 1.0.0
	 * @param int $tier Tier number (1, 2, or 3).
	 * @return array Array of module definitions.
	 */
	public static function get_modules_by_tier( $tier ) {
		// Return all modules regardless of tier - full support.
		return self::get_all_modules();
	}

	/**
	 * Clear module cache.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_cache() {
		delete_transient( self::CACHE_KEY );
	}
}
