<?php
/**
 * Divi 5 Module Definitions.
 *
 * Complete module definitions for Divi 5's block-based architecture.
 * Sourced from the Divi 5 Skill File v0.2.1 (Beta).
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/divi-intelligence
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Get Divi 5 module definitions with full attribute schemas.
 *
 * Modules are categorized as self-closing (no children) or container (has children).
 * Every module uses the `divi/*` block namespace in post_content.
 *
 * @since 5.2.0
 * @return array Module definitions keyed by block name.
 */
function respira_get_divi5_module_definitions() {
	return array(

		// === LAYOUT CONTAINERS ===

		'divi/section'   => array(
			'title'       => 'Section',
			'type'        => 'container',
			'description' => 'Top-level layout container. All content must be inside a section.',
			'children'    => array( 'divi/row', 'divi/group', 'divi/container' ),
			'attributes'  => array(
				'fullwidth'              => array( 'type' => 'bool', 'default' => false ),
				'specialty'              => array( 'type' => 'bool', 'default' => false ),
				'inner_shadow'           => array( 'type' => 'bool', 'default' => false ),
				'parallax'               => array( 'type' => 'bool', 'default' => false ),
				'parallax_method'        => array( 'type' => 'enum', 'values' => array( 'on', 'off' ), 'default' => 'on' ),
				'module'                 => array( 'type' => 'object', 'description' => 'Decoration and responsive styles' ),
			),
		),

		'divi/row'       => array(
			'title'       => 'Row',
			'type'        => 'container',
			'description' => 'Column layout container inside sections. Uses flexColumnStructure for column widths.',
			'children'    => array( 'divi/column' ),
			'attributes'  => array(
				'flexColumnStructure'    => array(
					'type'        => 'string',
					'description' => 'Column width fractions using N_24 system. E.g. "12_24,12_24" = two equal columns, "16_24,8_24" = 2/3 + 1/3.',
				),
				'flexType'               => array( 'type' => 'string', 'default' => 'row' ),
				'column_structure'       => array( 'type' => 'string', 'description' => 'Legacy Divi 4 format, e.g. "4_4_4". Deprecated in Divi 5.' ),
				'module'                 => array( 'type' => 'object' ),
			),
		),

		'divi/column'    => array(
			'title'       => 'Column',
			'type'        => 'container',
			'description' => 'Column inside a row. Width determined by parent row flexColumnStructure.',
			'children'    => array( '*' ), // Any module.
			'attributes'  => array(
				'module' => array( 'type' => 'object' ),
			),
		),

		'divi/group'     => array(
			'title'       => 'Group',
			'type'        => 'container',
			'description' => 'Generic container for grouping modules. Can be nested inside sections or columns.',
			'children'    => array( '*' ),
			'attributes'  => array(
				'module' => array( 'type' => 'object' ),
			),
		),

		'divi/container' => array(
			'title'       => 'Container',
			'type'        => 'container',
			'description' => 'Max-width wrapper for content alignment.',
			'children'    => array( '*' ),
			'attributes'  => array(
				'module' => array( 'type' => 'object' ),
			),
		),

		// === CONTENT MODULES (self-closing) ===

		'divi/text'          => array(
			'title'       => 'Text',
			'type'        => 'self-closing',
			'description' => 'Rich text content. Supports HTML inside content.',
			'attributes'  => array(
				'content'           => array( 'type' => 'string', 'required' => true ),
				'text_orientation'  => array( 'type' => 'enum', 'values' => array( 'left', 'center', 'right', 'justified' ) ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/heading'       => array(
			'title'       => 'Heading',
			'type'        => 'self-closing',
			'description' => 'Heading module with configurable level (h1-h6).',
			'attributes'  => array(
				'title'             => array( 'type' => 'string', 'required' => true ),
				'header_level'      => array( 'type' => 'enum', 'values' => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), 'default' => 'h2' ),
				'text_orientation'  => array( 'type' => 'enum', 'values' => array( 'left', 'center', 'right' ) ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/image'         => array(
			'title'       => 'Image',
			'type'        => 'self-closing',
			'description' => 'Image display module.',
			'attributes'  => array(
				'src'               => array( 'type' => 'string', 'required' => true ),
				'alt'               => array( 'type' => 'string' ),
				'title_text'        => array( 'type' => 'string' ),
				'url'               => array( 'type' => 'string', 'description' => 'Link URL when image is clicked' ),
				'align'             => array( 'type' => 'enum', 'values' => array( 'left', 'center', 'right' ) ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/button'        => array(
			'title'       => 'Button',
			'type'        => 'self-closing',
			'description' => 'Button with link.',
			'attributes'  => array(
				'button_text'       => array( 'type' => 'string', 'required' => true ),
				'button_url'        => array( 'type' => 'string' ),
				'button_alignment'  => array( 'type' => 'enum', 'values' => array( 'left', 'center', 'right' ) ),
				'url_new_window'    => array( 'type' => 'bool', 'default' => false ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/blurb'         => array(
			'title'       => 'Blurb',
			'type'        => 'self-closing',
			'description' => 'Icon/image + title + description combination.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string' ),
				'content'           => array( 'type' => 'string' ),
				'image'             => array( 'type' => 'string', 'description' => 'Image URL or icon name' ),
				'url'               => array( 'type' => 'string' ),
				'use_icon'          => array( 'type' => 'bool', 'default' => false ),
				'font_icon'         => array( 'type' => 'string' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/cta'           => array(
			'title'       => 'Call to Action',
			'type'        => 'self-closing',
			'description' => 'Heading + text + button combination.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string' ),
				'content'           => array( 'type' => 'string' ),
				'button_text'       => array( 'type' => 'string' ),
				'button_url'        => array( 'type' => 'string' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/video'         => array(
			'title'       => 'Video',
			'type'        => 'self-closing',
			'description' => 'Video embed or self-hosted.',
			'attributes'  => array(
				'src'               => array( 'type' => 'string', 'required' => true ),
				'image_src'         => array( 'type' => 'string', 'description' => 'Poster image URL' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/divider'       => array(
			'title'       => 'Divider',
			'type'        => 'self-closing',
			'description' => 'Horizontal line or space divider.',
			'attributes'  => array(
				'show_divider'      => array( 'type' => 'bool', 'default' => true ),
				'divider_style'     => array( 'type' => 'enum', 'values' => array( 'solid', 'dotted', 'dashed', 'double', 'groove', 'ridge' ) ),
				'divider_weight'    => array( 'type' => 'string', 'description' => 'CSS width, e.g. "2px"' ),
				'color'             => array( 'type' => 'string', 'description' => 'Hex color' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/icon'          => array(
			'title'       => 'Icon',
			'type'        => 'self-closing',
			'description' => 'Single icon from Divi icon library.',
			'attributes'  => array(
				'font_icon'         => array( 'type' => 'string', 'required' => true ),
				'icon_color'        => array( 'type' => 'string' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/icon-list'     => array(
			'title'       => 'Icon List',
			'type'        => 'self-closing',
			'description' => 'List with custom icons per item.',
			'attributes'  => array(
				'content'           => array( 'type' => 'string', 'required' => true, 'description' => 'HTML list items' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/social-follow' => array(
			'title'       => 'Social Follow',
			'type'        => 'self-closing',
			'description' => 'Social media icon links.',
			'attributes'  => array(
				'content'           => array( 'type' => 'string', 'description' => 'Social network items' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/testimonial'   => array(
			'title'       => 'Testimonial',
			'type'        => 'self-closing',
			'description' => 'Testimonial with author info.',
			'attributes'  => array(
				'author'            => array( 'type' => 'string' ),
				'job_title'         => array( 'type' => 'string' ),
				'company_name'      => array( 'type' => 'string' ),
				'url'               => array( 'type' => 'string' ),
				'portrait_url'      => array( 'type' => 'string' ),
				'content'           => array( 'type' => 'string', 'required' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/tabs'          => array(
			'title'       => 'Tabs',
			'type'        => 'container',
			'description' => 'Tabbed content container.',
			'children'    => array( 'divi/tab' ),
			'attributes'  => array(
				'active_tab_background_color'   => array( 'type' => 'string' ),
				'inactive_tab_background_color' => array( 'type' => 'string' ),
				'module'                        => array( 'type' => 'object' ),
			),
		),

		'divi/tab'           => array(
			'title'       => 'Tab',
			'type'        => 'self-closing',
			'description' => 'Individual tab inside tabs module.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string', 'required' => true ),
				'content'           => array( 'type' => 'string', 'required' => true ),
			),
		),

		'divi/accordion'     => array(
			'title'       => 'Accordion',
			'type'        => 'container',
			'description' => 'Collapsible accordion container.',
			'children'    => array( 'divi/accordion-item' ),
			'attributes'  => array(
				'module' => array( 'type' => 'object' ),
			),
		),

		'divi/accordion-item' => array(
			'title'       => 'Accordion Item',
			'type'        => 'self-closing',
			'description' => 'Individual accordion panel.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string', 'required' => true ),
				'content'           => array( 'type' => 'string', 'required' => true ),
				'open'              => array( 'type' => 'bool', 'default' => false ),
			),
		),

		'divi/toggle'        => array(
			'title'       => 'Toggle',
			'type'        => 'self-closing',
			'description' => 'Collapsible toggle (standalone, not inside accordion).',
			'attributes'  => array(
				'title'             => array( 'type' => 'string', 'required' => true ),
				'content'           => array( 'type' => 'string', 'required' => true ),
				'open'              => array( 'type' => 'bool', 'default' => false ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/counter'       => array(
			'title'       => 'Number Counter',
			'type'        => 'self-closing',
			'description' => 'Animated number counter.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string' ),
				'number'            => array( 'type' => 'string', 'required' => true ),
				'percent_sign'      => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/bar-counter'   => array(
			'title'       => 'Bar Counter',
			'type'        => 'self-closing',
			'description' => 'Animated horizontal bar counter.',
			'attributes'  => array(
				'content'           => array( 'type' => 'string', 'required' => true, 'description' => 'Label text' ),
				'percent'           => array( 'type' => 'string', 'required' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/map'           => array(
			'title'       => 'Map',
			'type'        => 'self-closing',
			'description' => 'Google Maps embed.',
			'attributes'  => array(
				'address_lat'       => array( 'type' => 'string', 'required' => true ),
				'address_lng'       => array( 'type' => 'string', 'required' => true ),
				'zoom_level'        => array( 'type' => 'string', 'default' => '12' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/contact-form'  => array(
			'title'       => 'Contact Form',
			'type'        => 'container',
			'description' => 'Contact form with configurable fields.',
			'children'    => array( 'divi/contact-field' ),
			'attributes'  => array(
				'email'             => array( 'type' => 'string', 'description' => 'Recipient email' ),
				'title'             => array( 'type' => 'string' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/contact-field' => array(
			'title'       => 'Contact Field',
			'type'        => 'self-closing',
			'description' => 'Individual form field.',
			'attributes'  => array(
				'field_id'          => array( 'type' => 'string', 'required' => true ),
				'field_title'       => array( 'type' => 'string', 'required' => true ),
				'field_type'        => array( 'type' => 'enum', 'values' => array( 'input', 'email', 'text', 'select', 'checkbox', 'radio' ) ),
				'required_mark'     => array( 'type' => 'bool', 'default' => true ),
			),
		),

		'divi/gallery'       => array(
			'title'       => 'Gallery',
			'type'        => 'self-closing',
			'description' => 'Image gallery grid.',
			'attributes'  => array(
				'gallery_ids'       => array( 'type' => 'string', 'required' => true, 'description' => 'Comma-separated attachment IDs' ),
				'posts_number'      => array( 'type' => 'string' ),
				'show_title_and_caption' => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/slider'        => array(
			'title'       => 'Slider',
			'type'        => 'container',
			'description' => 'Content slider with multiple slides.',
			'children'    => array( 'divi/slide' ),
			'attributes'  => array(
				'show_arrows'       => array( 'type' => 'bool', 'default' => true ),
				'show_pagination'   => array( 'type' => 'bool', 'default' => true ),
				'auto'              => array( 'type' => 'bool', 'default' => false ),
				'auto_speed'        => array( 'type' => 'string', 'default' => '7000' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/slide'         => array(
			'title'       => 'Slide',
			'type'        => 'self-closing',
			'description' => 'Individual slide in a slider.',
			'attributes'  => array(
				'heading'           => array( 'type' => 'string' ),
				'content'           => array( 'type' => 'string' ),
				'button_text'       => array( 'type' => 'string' ),
				'button_link'       => array( 'type' => 'string' ),
				'background_image'  => array( 'type' => 'string' ),
			),
		),

		'divi/pricing-table' => array(
			'title'       => 'Pricing Table',
			'type'        => 'self-closing',
			'description' => 'Pricing plan card.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string', 'required' => true ),
				'subtitle'          => array( 'type' => 'string' ),
				'currency'          => array( 'type' => 'string', 'default' => '$' ),
				'per'               => array( 'type' => 'string' ),
				'sum'               => array( 'type' => 'string', 'required' => true ),
				'button_text'       => array( 'type' => 'string' ),
				'button_url'        => array( 'type' => 'string' ),
				'content'           => array( 'type' => 'string', 'description' => 'Feature list as HTML' ),
				'featured'          => array( 'type' => 'bool', 'default' => false ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/code'          => array(
			'title'       => 'Code',
			'type'        => 'self-closing',
			'description' => 'Custom HTML/CSS/JS code block. Content must be base64 encoded in Divi 5.',
			'attributes'  => array(
				'content'           => array( 'type' => 'string', 'required' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/sidebar'       => array(
			'title'       => 'Sidebar',
			'type'        => 'self-closing',
			'description' => 'WordPress widget area.',
			'attributes'  => array(
				'area'              => array( 'type' => 'string', 'description' => 'Widget area ID' ),
				'orientation'       => array( 'type' => 'enum', 'values' => array( 'left', 'right' ) ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/menu'          => array(
			'title'       => 'Menu',
			'type'        => 'self-closing',
			'description' => 'WordPress navigation menu.',
			'attributes'  => array(
				'menu_id'           => array( 'type' => 'string', 'description' => 'WordPress menu ID or slug' ),
				'menu_style'        => array( 'type' => 'enum', 'values' => array( 'centered', 'left_aligned', 'upward', 'inline_centered_logo' ) ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/search'        => array(
			'title'       => 'Search',
			'type'        => 'self-closing',
			'description' => 'Search form.',
			'attributes'  => array(
				'placeholder'       => array( 'type' => 'string', 'default' => 'Search...' ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/login'         => array(
			'title'       => 'Login Form',
			'type'        => 'self-closing',
			'description' => 'WordPress login form.',
			'attributes'  => array(
				'title'             => array( 'type' => 'string' ),
				'current_page_redirect' => array( 'type' => 'bool', 'default' => false ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/blog'          => array(
			'title'       => 'Blog',
			'type'        => 'self-closing',
			'description' => 'Blog post listing.',
			'attributes'  => array(
				'posts_number'      => array( 'type' => 'string', 'default' => '10' ),
				'fullwidth'         => array( 'type' => 'bool', 'default' => true ),
				'include_categories' => array( 'type' => 'string' ),
				'show_thumbnail'    => array( 'type' => 'bool', 'default' => true ),
				'show_author'       => array( 'type' => 'bool', 'default' => true ),
				'show_date'         => array( 'type' => 'bool', 'default' => true ),
				'show_pagination'   => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/post-title'    => array(
			'title'       => 'Post Title',
			'type'        => 'self-closing',
			'description' => 'Dynamic post/page title display.',
			'attributes'  => array(
				'title'             => array( 'type' => 'bool', 'default' => true ),
				'meta'              => array( 'type' => 'bool', 'default' => true ),
				'featured_image'    => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/comments'      => array(
			'title'       => 'Comments',
			'type'        => 'self-closing',
			'description' => 'WordPress comments section.',
			'attributes'  => array(
				'show_count'        => array( 'type' => 'bool', 'default' => true ),
				'show_reply'        => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		'divi/post-navigation' => array(
			'title'       => 'Post Navigation',
			'type'        => 'self-closing',
			'description' => 'Previous/next post links.',
			'attributes'  => array(
				'show_prev'         => array( 'type' => 'bool', 'default' => true ),
				'show_next'         => array( 'type' => 'bool', 'default' => true ),
				'module'            => array( 'type' => 'object' ),
			),
		),

		// WooCommerce modules (available when Woo is active).
		'divi/shop'          => array(
			'title'       => 'Shop',
			'type'        => 'self-closing',
			'description' => 'WooCommerce product grid.',
			'requires'    => 'woocommerce',
			'attributes'  => array(
				'type'              => array( 'type' => 'enum', 'values' => array( 'latest', 'featured', 'sale', 'best_selling', 'top_rated' ) ),
				'posts_number'      => array( 'type' => 'string', 'default' => '12' ),
				'columns_number'    => array( 'type' => 'string', 'default' => '4' ),
				'module'            => array( 'type' => 'object' ),
			),
		),
	);
}
