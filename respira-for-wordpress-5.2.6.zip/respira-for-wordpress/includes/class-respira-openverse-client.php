<?php
/**
 * Openverse API client for stock image search and sideload.
 *
 * Searches Openverse (open-source image catalog), sideloads images to
 * the Media Library with CC attribution, and includes SSRF protection.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Openverse client class.
 *
 * @since 5.2.0
 */
class Respira_Openverse_Client {

	/**
	 * Openverse API base URL.
	 *
	 * @var string
	 */
	const API_BASE = 'https://api.openverse.org/v1/images/';

	/**
	 * Search cache TTL in seconds (1 hour).
	 *
	 * @var int
	 */
	const CACHE_TTL = 3600;

	/**
	 * HTTP request timeout in seconds.
	 *
	 * @var int
	 */
	const TIMEOUT = 5;

	/**
	 * Maximum file size for sideload (10 MB).
	 *
	 * @var int
	 */
	const MAX_FILE_SIZE = 10485760;

	/**
	 * Maximum redirects to follow during sideload.
	 *
	 * @var int
	 */
	const MAX_REDIRECTS = 3;

	/**
	 * Allowed MIME types for sideloaded images.
	 *
	 * @var array
	 */
	const ALLOWED_MIME_TYPES = array(
		'image/jpeg',
		'image/png',
		'image/gif',
		'image/webp',
		'image/svg+xml',
	);

	/**
	 * Search Openverse for images.
	 *
	 * @since 5.2.0
	 * @param string $query   Search query.
	 * @param array  $filters Optional. Search filters (license_type, source, aspect_ratio, size, category).
	 * @return array|WP_Error Array of image results or WP_Error.
	 */
	public static function search( $query, $filters = array() ) {
		if ( empty( $query ) ) {
			return new WP_Error(
				'respira_empty_query',
				__( 'Search query cannot be empty.', 'respira-for-wordpress' )
			);
		}

		// Build cache key.
		$cache_key = 'respira_openverse_' . md5( $query . wp_json_encode( $filters ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			// Return cached result, mark if stale.
			return $cached;
		}

		// Build query parameters.
		$params = array(
			'q'        => sanitize_text_field( $query ),
			'page_size' => 20,
		);

		$valid_filters = array( 'license_type', 'source', 'aspect_ratio', 'size', 'category' );
		foreach ( $valid_filters as $filter_key ) {
			if ( ! empty( $filters[ $filter_key ] ) ) {
				$params[ $filter_key ] = sanitize_text_field( $filters[ $filter_key ] );
			}
		}

		$url = add_query_arg( $params, self::API_BASE );

		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'     => self::TIMEOUT,
				'redirection' => 3,
				'user-agent'  => 'Respira-for-WordPress/' . ( defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '5.2.0' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			// Try to return stale cache if available.
			$stale = get_transient( $cache_key . '_stale' );
			if ( false !== $stale ) {
				$stale['_stale'] = true;
				return $stale;
			}

			return new WP_Error(
				'respira_openverse_unavailable',
				__( 'Openverse API unavailable. Try again later or provide a direct image URL.', 'respira-for-wordpress' )
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		// Handle rate limiting.
		if ( 429 === $status_code ) {
			$retry_after = wp_remote_retrieve_header( $response, 'Retry-After' );
			$message     = __( 'Openverse API rate limit reached.', 'respira-for-wordpress' );
			if ( $retry_after ) {
				$message .= sprintf(
					/* translators: %s: seconds */
					__( ' Retry after %s seconds.', 'respira-for-wordpress' ),
					$retry_after
				);
			}
			return new WP_Error( 'respira_openverse_rate_limit', $message );
		}

		if ( 200 !== $status_code ) {
			return new WP_Error(
				'respira_openverse_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Openverse API returned HTTP %d.', 'respira-for-wordpress' ),
					$status_code
				)
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( null === $body || json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error(
				'respira_openverse_parse_error',
				__( 'Failed to parse Openverse response.', 'respira-for-wordpress' )
			);
		}

		// Normalize results.
		$results = array();
		foreach ( ( $body['results'] ?? array() ) as $item ) {
			$results[] = array(
				'url'        => $item['url'] ?? '',
				'title'      => $item['title'] ?? '',
				'author'     => $item['creator'] ?? '',
				'license'    => $item['license'] ?? '',
				'source'     => $item['source'] ?? '',
				'dimensions' => array(
					'width'  => $item['width'] ?? 0,
					'height' => $item['height'] ?? 0,
				),
			);
		}

		$result_data = array(
			'total'   => $body['result_count'] ?? count( $results ),
			'results' => $results,
		);

		// Cache both fresh and stale versions.
		set_transient( $cache_key, $result_data, self::CACHE_TTL );
		set_transient( $cache_key . '_stale', $result_data, self::CACHE_TTL * 2 );

		return $result_data;
	}

	/**
	 * Sideload an image from an allowed domain into the Media Library.
	 *
	 * @since 5.2.0
	 * @param string $url   Image URL to sideload.
	 * @param array  $meta  Optional. Additional metadata (title, caption, alt).
	 * @return array|WP_Error {media_id: int, url: string, caption: string} or WP_Error.
	 */
	public static function sideload( $url, $meta = array() ) {
		// Validate URL scheme.
		if ( strpos( $url, 'https://' ) !== 0 ) {
			return new WP_Error(
				'respira_https_required',
				__( 'Only HTTPS URLs are allowed for image sideloading.', 'respira-for-wordpress' )
			);
		}

		// Validate domain against allowlist.
		$domain = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! self::is_domain_allowed( $domain ) ) {
			return new WP_Error(
				'respira_domain_not_allowed',
				sprintf(
					/* translators: %s: domain name */
					__( 'Domain "%s" is not in the allowed list for image sideloading.', 'respira-for-wordpress' ),
					$domain
				)
			);
		}

		// Check for existing attachment by source URL (deduplication).
		$existing = self::find_existing_attachment( $url );
		if ( $existing ) {
			return $existing;
		}

		// HEAD request to check Content-Length before downloading.
		$head_response = wp_safe_remote_head(
			$url,
			array(
				'timeout'     => self::TIMEOUT,
				'redirection' => 0,
			)
		);

		if ( ! is_wp_error( $head_response ) ) {
			$status_code = wp_remote_retrieve_response_code( $head_response );

			// Handle redirects manually (SSRF protection: re-check domain).
			if ( in_array( $status_code, array( 301, 302, 307, 308 ), true ) ) {
				$redirect_url = self::follow_redirect_safely( $head_response, 0 );
				if ( is_wp_error( $redirect_url ) ) {
					return $redirect_url;
				}
				$url = $redirect_url;
			}

			$content_length = (int) wp_remote_retrieve_header( $head_response, 'Content-Length' );
			if ( $content_length > self::MAX_FILE_SIZE ) {
				return new WP_Error(
					'respira_file_too_large',
					sprintf(
						/* translators: %s: max size */
						__( 'Image exceeds maximum file size of %s.', 'respira-for-wordpress' ),
						size_format( self::MAX_FILE_SIZE )
					)
				);
			}
		}

		// Check disk space.
		$upload_dir = wp_upload_dir();
		if ( function_exists( 'disk_free_space' ) ) {
			$free = @disk_free_space( $upload_dir['basedir'] );
			if ( false !== $free && $free < 52428800 ) { // 50 MB.
				return new WP_Error(
					'respira_low_disk_space',
					__( 'Insufficient disk space for image upload. Less than 50MB available.', 'respira-for-wordpress' )
				);
			}
		}

		// Download the image.
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'     => 30,
				'redirection' => 0,
				'stream'      => true,
				'filename'    => wp_tempnam(),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'respira_download_failed',
				__( 'Failed to download image.', 'respira-for-wordpress' ),
				array( 'original_error' => $response->get_error_message() )
			);
		}

		$tmp_file = $response['filename'] ?? '';
		if ( empty( $tmp_file ) || ! file_exists( $tmp_file ) ) {
			return new WP_Error(
				'respira_download_failed',
				__( 'Downloaded file not found.', 'respira-for-wordpress' )
			);
		}

		// Validate MIME type.
		$filetype = wp_check_filetype( basename( wp_parse_url( $url, PHP_URL_PATH ) ), null );
		$mime     = $filetype['type'] ?? '';

		// Also check the actual file content.
		$finfo = function_exists( 'finfo_open' ) ? finfo_open( FILEINFO_MIME_TYPE ) : null;
		if ( $finfo ) {
			$actual_mime = finfo_file( $finfo, $tmp_file );
			finfo_close( $finfo );
			if ( $actual_mime && ! in_array( $actual_mime, self::ALLOWED_MIME_TYPES, true ) ) {
				@unlink( $tmp_file );
				return new WP_Error(
					'respira_invalid_file_type',
					sprintf(
						/* translators: %s: MIME type */
						__( 'File type "%s" is not allowed. Only images are accepted.', 'respira-for-wordpress' ),
						$actual_mime
					)
				);
			}
		}

		// Prepare file for sideload.
		$file_array = array(
			'name'     => basename( wp_parse_url( $url, PHP_URL_PATH ) ),
			'tmp_name' => $tmp_file,
		);

		// Require media handling functions.
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$attachment_id = media_handle_sideload( $file_array, 0 );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp_file );
			return $attachment_id;
		}

		// Set caption with CC attribution.
		$caption = self::build_attribution_caption( $meta );
		if ( $caption ) {
			wp_update_post(
				array(
					'ID'           => $attachment_id,
					'post_excerpt' => $caption,
				)
			);
		}

		// Set alt text.
		if ( ! empty( $meta['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $meta['alt'] ) );
		} elseif ( ! empty( $meta['title'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $meta['title'] ) );
		}

		// Store source URL for deduplication.
		update_post_meta( $attachment_id, '_respira_source_url', esc_url_raw( $url ) );

		$attachment_url = wp_get_attachment_url( $attachment_id );

		return array(
			'media_id' => $attachment_id,
			'url'      => $attachment_url,
			'caption'  => $caption ?: '',
		);
	}

	/**
	 * Check if a domain is in the allowed list.
	 *
	 * @since 5.2.0
	 * @param string $domain Domain to check.
	 * @return bool
	 */
	private static function is_domain_allowed( $domain ) {
		$allowed = apply_filters(
			'respira_sideload_allowed_domains',
			array(
				'openverse.org',
				'wordpress.org',
				'unsplash.com',
				'pexels.com',
				'pixabay.com',
				'staticflickr.com',
				'rawpixel.com',
			)
		);

		foreach ( $allowed as $allowed_domain ) {
			// Match domain or subdomain.
			if ( $domain === $allowed_domain || substr( $domain, -strlen( '.' . $allowed_domain ) ) === '.' . $allowed_domain ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Follow a redirect safely, re-validating domain at each hop.
	 *
	 * @since 5.2.0
	 * @param array|WP_Error $response     HTTP response with Location header.
	 * @param int            $redirect_count Current redirect count.
	 * @return string|WP_Error Final URL or WP_Error.
	 */
	private static function follow_redirect_safely( $response, $redirect_count ) {
		if ( $redirect_count >= self::MAX_REDIRECTS ) {
			return new WP_Error(
				'respira_too_many_redirects',
				__( 'Too many redirects while following image URL.', 'respira-for-wordpress' )
			);
		}

		$location = wp_remote_retrieve_header( $response, 'Location' );
		if ( empty( $location ) ) {
			return new WP_Error(
				'respira_redirect_no_location',
				__( 'Redirect response missing Location header.', 'respira-for-wordpress' )
			);
		}

		// SSRF check: validate the redirect target domain.
		if ( strpos( $location, 'https://' ) !== 0 ) {
			return new WP_Error(
				'respira_redirect_not_https',
				__( 'Redirect target is not HTTPS.', 'respira-for-wordpress' )
			);
		}

		$redirect_domain = wp_parse_url( $location, PHP_URL_HOST );
		if ( ! self::is_domain_allowed( $redirect_domain ) ) {
			return new WP_Error(
				'respira_redirect_domain_not_allowed',
				sprintf(
					/* translators: %s: domain name */
					__( 'Redirect target domain "%s" is not in the allowed list.', 'respira-for-wordpress' ),
					$redirect_domain
				)
			);
		}

		// Follow the redirect.
		$next_response = wp_safe_remote_head(
			$location,
			array(
				'timeout'     => self::TIMEOUT,
				'redirection' => 0,
			)
		);

		if ( is_wp_error( $next_response ) ) {
			return $next_response;
		}

		$next_status = wp_remote_retrieve_response_code( $next_response );
		if ( in_array( $next_status, array( 301, 302, 307, 308 ), true ) ) {
			return self::follow_redirect_safely( $next_response, $redirect_count + 1 );
		}

		return $location;
	}

	/**
	 * Find an existing attachment by source URL.
	 *
	 * @since 5.2.0
	 * @param string $url Source URL.
	 * @return array|null {media_id, url, caption} or null.
	 */
	private static function find_existing_attachment( $url ) {
		global $wpdb;

		$attachment_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_respira_source_url' AND meta_value = %s LIMIT 1",
				esc_url_raw( $url )
			)
		);

		if ( ! $attachment_id ) {
			return null;
		}

		$attachment = get_post( $attachment_id );
		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return null;
		}

		return array(
			'media_id'     => (int) $attachment_id,
			'url'          => wp_get_attachment_url( $attachment_id ),
			'caption'      => $attachment->post_excerpt,
			'_deduplicated' => true,
		);
	}

	/**
	 * Build CC attribution caption.
	 *
	 * @since 5.2.0
	 * @param array $meta Image metadata with author, license, source, title.
	 * @return string Attribution caption.
	 */
	private static function build_attribution_caption( $meta ) {
		$parts = array();

		if ( ! empty( $meta['title'] ) ) {
			$parts[] = '"' . sanitize_text_field( $meta['title'] ) . '"';
		}

		if ( ! empty( $meta['author'] ) ) {
			$parts[] = 'by ' . sanitize_text_field( $meta['author'] );
		}

		if ( ! empty( $meta['license'] ) ) {
			$parts[] = 'licensed under ' . sanitize_text_field( strtoupper( $meta['license'] ) );
		}

		if ( ! empty( $meta['source'] ) ) {
			$parts[] = 'via ' . sanitize_text_field( $meta['source'] );
		}

		return implode( ' ', $parts );
	}
}
