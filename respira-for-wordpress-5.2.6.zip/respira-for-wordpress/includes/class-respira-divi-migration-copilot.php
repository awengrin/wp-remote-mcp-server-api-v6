<?php
/**
 * Divi 5 Migration Copilot helpers.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      2.0.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Divi 5 migration copilot service.
 */
class Respira_Divi_Migration_Copilot {

	/**
	 * Disclaimer line required in all migration-copilot messaging.
	 *
	 * @since 2.0.7
	 * @var string
	 */
	const DISCLAIMER = 'Respira helps you plan and validate your Divi 5 migration. Divi’s Migrator performs the actual conversion.';

	/**
	 * Build transient key for report cache.
	 *
	 * @since 2.0.7
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function get_report_transient_key( $user_id ) {
		return 'respira_divi5_migration_report_' . absint( $user_id );
	}

	/**
	 * Get cached readiness report.
	 *
	 * @since 2.0.7
	 * @param int $user_id User ID.
	 * @return array|null
	 */
	public static function get_cached_report( $user_id ) {
		$cached = get_transient( self::get_report_transient_key( $user_id ) );
		return is_array( $cached ) ? $cached : null;
	}

	/**
	 * Store readiness report for user.
	 *
	 * @since 2.0.7
	 * @param int   $user_id User ID.
	 * @param array $report Report data.
	 * @return void
	 */
	public static function cache_report( $user_id, $report ) {
		set_transient( self::get_report_transient_key( $user_id ), $report, HOUR_IN_SECONDS * 24 );
	}

	/**
	 * Generate migration readiness report.
	 *
	 * @since 2.0.7
	 * @return array
	 */
	public static function generate_readiness_report() {
		global $wpdb;

		$post_types = array( 'page', 'post', 'et_pb_layout', 'wp_template', 'wp_template_part' );
		$post_types_sql = "'" . implode( "','", array_map( 'esc_sql', $post_types ) ) . "'";

		$rows = $wpdb->get_results(
			"SELECT ID, post_title, post_type, post_content
			FROM {$wpdb->posts}
			WHERE post_status NOT IN ('trash','auto-draft')
				AND post_type IN ({$post_types_sql})",
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$known_divi_modules = self::get_known_divi4_module_names();

		$totals = array(
			'divi4_pages' => 0,
			'divi5_pages' => 0,
			'mixed_pages' => 0,
			'unknown'     => 0,
		);

		$high_risk_pages = array();
		$migration_candidates = array();
		$legacy_counts = array();
		$unknown_shortcode_counts = array();

		foreach ( $rows as $row ) {
			$post_id   = absint( $row['ID'] );
			$title     = ! empty( $row['post_title'] ) ? $row['post_title'] : sprintf( __( 'Untitled #%d', 'respira-for-wordpress' ), $post_id );
			$content   = (string) $row['post_content'];
			$has_divi4 = (bool) preg_match( '/\[et_pb_[a-z0-9_]+/i', $content );
			$has_divi5 = strpos( $content, '<!-- wp:divi/' ) !== false;
			$reasons   = array();

			if ( $has_divi4 && $has_divi5 ) {
				++$totals['mixed_pages'];
				$reasons[] = __( 'Contains both Divi 4 shortcodes and Divi 5 blocks (likely compatibility mode risk).', 'respira-for-wordpress' );
			} elseif ( $has_divi5 ) {
				++$totals['divi5_pages'];
			} elseif ( $has_divi4 ) {
				++$totals['divi4_pages'];
			} else {
				++$totals['unknown'];
			}

			$local_et_pb_counts = array();
			if ( preg_match_all( '/\[([a-zA-Z0-9_\-]+)(?:\s|\]|\/)/', $content, $shortcode_matches ) ) {
				foreach ( $shortcode_matches[1] as $shortcode ) {
					$tag = sanitize_key( $shortcode );
					if ( 0 === strpos( $tag, 'et_pb_' ) ) {
						if ( ! isset( $local_et_pb_counts[ $tag ] ) ) {
							$local_et_pb_counts[ $tag ] = 0;
						}
						++$local_et_pb_counts[ $tag ];
						if ( ! isset( $legacy_counts[ $tag ] ) ) {
							$legacy_counts[ $tag ] = 0;
						}
						++$legacy_counts[ $tag ];

						if ( ! in_array( $tag, $known_divi_modules, true ) ) {
							if ( ! isset( $unknown_shortcode_counts[ $tag ] ) ) {
								$unknown_shortcode_counts[ $tag ] = 0;
							}
							++$unknown_shortcode_counts[ $tag ];
						}
					}
				}
			}

			$risk_points = 0;
			if ( $has_divi4 && $has_divi5 ) {
				$risk_points += 4;
			}
			if ( ! empty( $unknown_shortcode_counts ) ) {
				$unknown_on_page = 0;
				foreach ( $local_et_pb_counts as $module_name => $count ) {
					if ( ! in_array( $module_name, $known_divi_modules, true ) ) {
						$unknown_on_page += $count;
					}
				}
				if ( $unknown_on_page > 0 ) {
					$risk_points += 2;
					$reasons[] = sprintf(
						/* translators: %d: shortcode count. */
						__( 'Contains %d unknown/third-party Divi shortcode modules.', 'respira-for-wordpress' ),
						$unknown_on_page
					);
				}
			}

			if ( $risk_points >= 3 ) {
				$high_risk_pages[] = array(
					'id'      => $post_id,
					'title'   => $title,
					'url'     => get_permalink( $post_id ),
					'reasons' => array_values( array_unique( $reasons ) ),
				);
			}

			if ( $has_divi4 && ! $has_divi5 ) {
				$migration_candidates[] = array(
					'id'         => $post_id,
					'title'      => $title,
					'url'        => get_permalink( $post_id ),
					'post_type'  => $row['post_type'],
					'risk_score' => $risk_points,
				);
			}
		}

		usort(
			$migration_candidates,
			function( $a, $b ) {
				if ( $a['risk_score'] === $b['risk_score'] ) {
					return $a['id'] - $b['id'];
				}
				return $a['risk_score'] - $b['risk_score'];
			}
		);

		$plugin_signals = self::detect_divi_extension_plugins();
		$risk_level = self::compute_risk_level( $totals, $high_risk_pages, $plugin_signals );

		$report = array(
			'generated_at' => gmdate( 'c' ),
			'disclaimer'   => self::DISCLAIMER,
			'totals'       => $totals,
			'risk'         => array(
				'score' => $risk_level['score'],
				'level' => $risk_level['level'],
			),
			'high_risk_pages' => array_slice( $high_risk_pages, 0, 30 ),
			'module_signals'  => array(
				'legacy_shortcode_counts_by_type' => $legacy_counts,
				'unknown_shortcode_counts'        => $unknown_shortcode_counts,
			),
			'plugin_signals' => $plugin_signals,
			'migration_candidates' => array_slice( $migration_candidates, 0, 20 ),
			'recommended_actions'  => self::build_recommended_actions( $totals, $high_risk_pages, $plugin_signals ),
		);

		return $report;
	}

	/**
	 * Build prompt pack tailored to report data.
	 *
	 * @since 2.0.7
	 * @param array $report Readiness report.
	 * @return array
	 */
	public static function build_prompt_pack( $report ) {
		$totals = $report['totals'] ?? array();
		$high_risk = $report['high_risk_pages'] ?? array();
		$third_party = $report['plugin_signals']['third_party_divi_plugins'] ?? array();
		$third_party_list = empty( $third_party ) ? 'None detected' : implode( ', ', $third_party );

		$shared_context = sprintf(
			"Site readiness snapshot:\n- Divi 4 pages: %d\n- Divi 5 pages: %d\n- Mixed pages: %d\n- High risk pages flagged: %d\n- Third-party Divi plugins: %s\n\n%s\n",
			absint( $totals['divi4_pages'] ?? 0 ),
			absint( $totals['divi5_pages'] ?? 0 ),
			absint( $totals['mixed_pages'] ?? 0 ),
			count( $high_risk ),
			$third_party_list,
			self::DISCLAIMER
		);

		return array(
			array(
				'id'          => 'readiness_audit',
				'title'       => __( 'Migration readiness audit', 'respira-for-wordpress' ),
				'description' => __( 'Inventories pages/templates and assigns migration risk with reasoning.', 'respira-for-wordpress' ),
				'prompt'      => $shared_context . "Create a Divi migration readiness audit. Inventory page/template cohorts, highlight third-party module risks, and assign Low/Medium/High risk with reasons for each cohort.\n\nDivi’s Migrator performs conversion. This plan helps you run it safely.",
			),
			array(
				'id'          => 'staging_backup_plan',
				'title'       => __( 'Staging + backup plan', 'respira-for-wordpress' ),
				'description' => __( 'Creates an ordered migration runbook with rollback and ownership.', 'respira-for-wordpress' ),
				'prompt'      => $shared_context . "Draft an execution plan for staging-first migration. Include backups, branch strategy, migration order, ownership checklist, and rollback triggers.\n\nDivi’s Migrator performs conversion. This plan helps you run it safely.",
			),
			array(
				'id'          => 'compatibility_cleanup',
				'title'       => __( 'Compatibility Mode cleanup', 'respira-for-wordpress' ),
				'description' => __( 'Prioritizes replacement of legacy modules and performance cleanup.', 'respira-for-wordpress' ),
				'prompt'      => $shared_context . "Create a cleanup roadmap for compatibility-mode pages. Prioritize legacy module replacements, identify the fastest wins, and specify performance-focused tasks.\n\nDivi’s Migrator performs conversion. This plan helps you run it safely.",
			),
			array(
				'id'          => 'post_migration_qa',
				'title'       => __( 'Post-migration QA', 'respira-for-wordpress' ),
				'description' => __( 'Builds a done-definition for visual checks, frontend diffing, and CSS stability.', 'respira-for-wordpress' ),
				'prompt'      => $shared_context . "Build a post-migration QA checklist covering Divi Visual Builder open tests, frontend diffs, CSS regressions, and explicit definition-of-done criteria.\n\nDivi’s Migrator performs conversion. This plan helps you run it safely.",
			),
			array(
				'id'          => 'modernize_layout',
				'title'       => __( 'Modernize this layout', 'respira-for-wordpress' ),
				'description' => __( 'Refactors selected migrated pages to reduce legacy islands while preserving design.', 'respira-for-wordpress' ),
				'prompt'      => $shared_context . "For a selected migrated page, propose a modernization plan that replaces legacy islands with native Divi 5 modules where feasible, while preserving the design system.\n\nDivi’s Migrator performs conversion. This plan helps you run it safely.",
			),
		);
	}

	/**
	 * Export prompt pack as markdown.
	 *
	 * @since 2.0.7
	 * @param array $prompts Prompt pack.
	 * @param array $report Report.
	 * @return string
	 */
	public static function export_prompt_pack_markdown( $prompts, $report ) {
		$lines   = array();
		$lines[] = '# Divi 5 Migration Copilot Prompt Pack';
		$lines[] = '';
		$lines[] = self::DISCLAIMER;
		$lines[] = '';
		$lines[] = 'Generated: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		$lines[] = '';

		foreach ( $prompts as $prompt ) {
			$lines[] = '## ' . $prompt['title'];
			$lines[] = '';
			$lines[] = $prompt['description'];
			$lines[] = '';
			$lines[] = '```text';
			$lines[] = $prompt['prompt'];
			$lines[] = '```';
			$lines[] = '';
		}

		return implode( "\n", $lines );
	}

	/**
	 * Build recommended actions list from report.
	 *
	 * @since 2.0.7
	 * @param array $totals Totals.
	 * @param array $high_risk High-risk pages.
	 * @param array $plugin_signals Plugin signals.
	 * @return array
	 */
	private static function build_recommended_actions( $totals, $high_risk, $plugin_signals ) {
		$actions = array(
			__( 'Run Divi migration first on staging and snapshot backups before each migration batch.', 'respira-for-wordpress' ),
			__( 'Start with low-risk Divi 4 pages that do not contain unknown shortcode modules.', 'respira-for-wordpress' ),
		);

		if ( ! empty( $high_risk ) ) {
			$actions[] = __( 'Review high-risk mixed pages before migration; expect compatibility mode and QA overhead.', 'respira-for-wordpress' );
		}

		if ( ! empty( $plugin_signals['third_party_divi_plugins'] ) ) {
			$actions[] = __( 'Validate third-party Divi extensions for Divi 5 compatibility before conversion.', 'respira-for-wordpress' );
		}

		if ( absint( $totals['mixed_pages'] ?? 0 ) > 0 ) {
			$actions[] = __( 'Prioritize compatibility-mode cleanup after migration to reduce long-term performance cost.', 'respira-for-wordpress' );
		}

		$actions[] = __( 'Use post-migration QA checklist for Visual Builder open tests and frontend diffs.', 'respira-for-wordpress' );

		return $actions;
	}

	/**
	 * Compute risk score/level from report signals.
	 *
	 * @since 2.0.7
	 * @param array $totals Totals.
	 * @param array $high_risk High-risk page list.
	 * @param array $plugin_signals Plugin signals.
	 * @return array
	 */
	private static function compute_risk_level( $totals, $high_risk, $plugin_signals ) {
		$score = 0;
		$score += min( 4, absint( $totals['mixed_pages'] ?? 0 ) );
		$score += min( 3, count( $high_risk ) );
		$score += ! empty( $plugin_signals['third_party_divi_plugins'] ) ? 2 : 0;

		$level = 'Low';
		if ( $score >= 6 ) {
			$level = 'High';
		} elseif ( $score >= 3 ) {
			$level = 'Medium';
		}

		return array(
			'score' => $score,
			'level' => $level,
		);
	}

	/**
	 * Get known Divi 4 module names from registry/schemas.
	 *
	 * @since 2.0.7
	 * @return array
	 */
	private static function get_known_divi4_module_names() {
		$known = array();

		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			$modules = Respira_Divi_Module_Registry::get_all_modules();
			foreach ( $modules as $module ) {
				$name = $module['name'] ?? '';
				if ( is_string( $name ) && 0 === strpos( $name, 'et_pb_' ) ) {
					$known[] = $name;
				}
			}
		}

		if ( empty( $known ) && class_exists( 'Respira_Divi_Module_Schema' ) ) {
			$schemas = Respira_Divi_Module_Schema::get_all_schemas();
			foreach ( array_keys( $schemas ) as $name ) {
				if ( 0 === strpos( $name, 'et_pb_' ) ) {
					$known[] = $name;
				}
			}
		}

		return array_values( array_unique( $known ) );
	}

	/**
	 * Detect likely third-party Divi plugins from active plugin list.
	 *
	 * @since 2.0.7
	 * @return array
	 */
	private static function detect_divi_extension_plugins() {
		$signals = array(
			'third_party_divi_plugins' => array(),
		);

		$active_plugins = (array) get_option( 'active_plugins', array() );
		$network_active = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
		$all_active     = array_unique( array_merge( $active_plugins, $network_active ) );

		$patterns = array(
			'divi',
			'elegantthemes',
			'supreme-modules',
			'divi-plus',
			'divi-essential',
			'dqe',
			'divi-pixel',
			'divi-bodycommerce',
		);

		foreach ( $all_active as $plugin_basename ) {
			$plugin_slug = strtolower( (string) $plugin_basename );
			$matched = false;
			foreach ( $patterns as $pattern ) {
				if ( strpos( $plugin_slug, $pattern ) !== false ) {
					$matched = true;
					break;
				}
			}

			if ( $matched && strpos( $plugin_slug, 'respira' ) === false ) {
				$signals['third_party_divi_plugins'][] = $plugin_basename;
			}
		}

		$signals['third_party_divi_plugins'] = array_values( array_unique( $signals['third_party_divi_plugins'] ) );
		return $signals;
	}
}

