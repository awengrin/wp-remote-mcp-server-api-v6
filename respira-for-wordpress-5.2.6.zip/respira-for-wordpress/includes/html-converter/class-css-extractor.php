<?php
/**
 * CSS Extractor for HTML-to-Builder conversion.
 *
 * Parses <style> blocks and inline styles from HTML input.
 * Extracts design tokens, computed styles, fonts, animations, and media queries.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/html-converter
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_CSS_Extractor {

	/**
	 * Maximum total CSS size in bytes (512KB).
	 *
	 * @var int
	 */
	const MAX_CSS_SIZE = 524288;

	/**
	 * Extract all CSS data from an HTML string.
	 *
	 * @param string $html Full HTML string.
	 * @return array|WP_Error Extracted CSS data or error.
	 */
	public function extract( $html ) {
		$css_blocks    = $this->extract_style_blocks( $html );
		$inline_styles = $this->extract_inline_styles( $html );

		$total_css = implode( "\n", $css_blocks );
		if ( strlen( $total_css ) > self::MAX_CSS_SIZE ) {
			return new WP_Error(
				'respira_css_too_large',
				sprintf(
					__( 'Total CSS content exceeds %s limit.', 'respira-for-wordpress' ),
					size_format( self::MAX_CSS_SIZE )
				)
			);
		}

		$tokens        = $this->extract_tokens( $total_css );
		$media_queries = $this->extract_media_queries( $total_css );
		$animations    = $this->extract_animations( $total_css );
		$fonts         = $this->extract_fonts( $html, $total_css );
		$rules         = $this->parse_rules( $total_css );
		$skipped_rules = 0;

		$element_styles = array();
		foreach ( $rules as $rule ) {
			if ( null === $rule ) {
				++$skipped_rules;
				continue;
			}
			$selector = $rule['selector'];
			if ( ! isset( $element_styles[ $selector ] ) ) {
				$element_styles[ $selector ] = array();
			}
			$element_styles[ $selector ] = array_merge( $element_styles[ $selector ], $rule['properties'] );
		}

		// Merge inline styles keyed by element index.
		foreach ( $inline_styles as $key => $props ) {
			$inline_key = '_inline_' . $key;
			$element_styles[ $inline_key ] = $props;
		}

		// Resolve CSS variables in all element styles using extracted tokens.
		foreach ( $element_styles as $selector => &$props ) {
			$props = $this->resolve_variables( $props, $tokens );
		}
		unset( $props );

		return array(
			'tokens'         => $tokens,
			'element_styles' => $element_styles,
			'fonts'          => $fonts,
			'animations'     => $animations,
			'media_queries'  => $media_queries,
			'skipped_rules'  => $skipped_rules,
		);
	}

	/**
	 * Resolve CSS custom property references in property values.
	 *
	 * Replaces var(--name) and var(--name, fallback) with actual token values.
	 * Handles nested var() references up to 5 levels deep.
	 *
	 * @since 5.2.0
	 * @param array $properties Property-value map.
	 * @param array $tokens     CSS custom property tokens from :root.
	 * @return array Properties with variables resolved.
	 */
	public function resolve_variables( $properties, $tokens ) {
		if ( empty( $tokens ) ) {
			return $properties;
		}

		foreach ( $properties as $prop => &$value ) {
			if ( ! is_string( $value ) || false === strpos( $value, 'var(' ) ) {
				continue;
			}
			// Resolve up to 5 levels of nested var() references.
			for ( $i = 0; $i < 5; $i++ ) {
				if ( false === strpos( $value, 'var(' ) ) {
					break;
				}
				$value = preg_replace_callback(
					'/var\(\s*(--[\w-]+)\s*(?:,\s*([^)]+))?\s*\)/',
					function ( $m ) use ( $tokens ) {
						$var_name = $m[1];
						$fallback = isset( $m[2] ) ? trim( $m[2] ) : null;
						if ( isset( $tokens[ $var_name ] ) ) {
							return $tokens[ $var_name ];
						}
						if ( null !== $fallback ) {
							return $fallback;
						}
						// Can't resolve — return original.
						return $m[0];
					},
					$value
				);
			}
		}
		unset( $value );

		return $properties;
	}

	/**
	 * Extract <style> block contents from HTML.
	 *
	 * @param string $html HTML string.
	 * @return array Array of CSS strings.
	 */
	private function extract_style_blocks( $html ) {
		$blocks = array();
		if ( preg_match_all( '/<style[^>]*>(.*?)<\/style>/si', $html, $matches ) ) {
			$blocks = $matches[1];
		}
		return $blocks;
	}

	/**
	 * Extract inline style attributes from HTML elements.
	 *
	 * @param string $html HTML string.
	 * @return array Indexed array of parsed property maps.
	 */
	private function extract_inline_styles( $html ) {
		$styles = array();
		if ( preg_match_all( '/style\s*=\s*["\']([^"\']+)["\']/i', $html, $matches ) ) {
			foreach ( $matches[1] as $i => $style_str ) {
				$props = $this->parse_declarations( $style_str );
				if ( ! empty( $props ) ) {
					$styles[ $i ] = $props;
				}
			}
		}
		return $styles;
	}

	/**
	 * Extract CSS custom properties (design tokens) from :root and html selectors.
	 *
	 * @param string $css CSS string.
	 * @return array Key-value map of tokens.
	 */
	private function extract_tokens( $css ) {
		$tokens = array();
		// Match :root { ... } and html { ... } blocks.
		if ( preg_match_all( '/(?::root|html)\s*\{([^}]+)\}/i', $css, $matches ) ) {
			foreach ( $matches[1] as $block ) {
				if ( preg_match_all( '/(--[\w-]+)\s*:\s*([^;]+);/i', $block, $vars ) ) {
					foreach ( $vars[1] as $j => $name ) {
						$tokens[ $name ] = trim( $vars[2][ $j ] );
					}
				}
			}
		}
		return $tokens;
	}

	/**
	 * Extract @media query blocks.
	 *
	 * @param string $css CSS string.
	 * @return array Array of media query data.
	 */
	private function extract_media_queries( $css ) {
		$queries = array();
		// Simple regex — doesn't handle nested @media but covers common cases.
		if ( preg_match_all( '/@media\s*([^{]+)\{((?:[^{}]|\{[^{}]*\})*)\}/si', $css, $matches ) ) {
			foreach ( $matches[1] as $i => $condition ) {
				$condition = trim( $condition );
				$max_width = null;
				$min_width = null;

				if ( preg_match( '/max-width\s*:\s*(\d+)px/', $condition, $mw ) ) {
					$max_width = (int) $mw[1];
				}
				if ( preg_match( '/min-width\s*:\s*(\d+)px/', $condition, $mw ) ) {
					$min_width = (int) $mw[1];
				}

				$rules = $this->parse_rules( $matches[2][ $i ] );

				$queries[] = array(
					'condition' => $condition,
					'max_width' => $max_width,
					'min_width' => $min_width,
					'rules'     => array_filter( $rules ),
				);
			}
		}
		return $queries;
	}

	/**
	 * Extract @keyframes animation names.
	 *
	 * @param string $css CSS string.
	 * @return array Array of animation names.
	 */
	private function extract_animations( $css ) {
		$animations = array();
		if ( preg_match_all( '/@keyframes\s+([\w-]+)/i', $css, $matches ) ) {
			$animations = array_unique( $matches[1] );
		}
		return array_values( $animations );
	}

	/**
	 * Extract font families from Google Fonts imports and @font-face declarations.
	 *
	 * @param string $html HTML string (for <link> tags).
	 * @param string $css  CSS string (for @import and @font-face).
	 * @return array Array of font family names.
	 */
	private function extract_fonts( $html, $css ) {
		$fonts = array();

		// Google Fonts <link> tags.
		if ( preg_match_all( '/fonts\.googleapis\.com\/css2?\?family=([^"\'&]+)/i', $html, $matches ) ) {
			foreach ( $matches[1] as $family_str ) {
				$families = explode( '|', urldecode( $family_str ) );
				foreach ( $families as $f ) {
					$name = explode( ':', $f )[0];
					$name = str_replace( '+', ' ', $name );
					$fonts[] = trim( $name );
				}
			}
		}

		// CSS @import for Google Fonts.
		if ( preg_match_all( '/@import\s+url\(["\']?[^)]*fonts\.googleapis\.com\/css2?\?family=([^"\'&)]+)/i', $css, $matches ) ) {
			foreach ( $matches[1] as $family_str ) {
				$families = explode( '|', urldecode( $family_str ) );
				foreach ( $families as $f ) {
					$name = explode( ':', $f )[0];
					$name = str_replace( '+', ' ', $name );
					$fonts[] = trim( $name );
				}
			}
		}

		// @font-face declarations.
		if ( preg_match_all( '/@font-face\s*\{[^}]*font-family\s*:\s*["\']?([^;"\']+)/i', $css, $matches ) ) {
			foreach ( $matches[1] as $name ) {
				$fonts[] = trim( $name );
			}
		}

		return array_values( array_unique( $fonts ) );
	}

	/**
	 * Parse CSS rules from a block of CSS (without @media wrappers).
	 *
	 * @param string $css CSS block.
	 * @return array Array of rule arrays or null for unparseable rules.
	 */
	private function parse_rules( $css ) {
		$rules = array();

		// Remove comments.
		$css = preg_replace( '/\/\*.*?\*\//s', '', $css );

		// Remove @import, @font-face, @keyframes blocks.
		$css = preg_replace( '/@import[^;]+;/i', '', $css );
		$css = preg_replace( '/@font-face\s*\{[^}]+\}/i', '', $css );
		$css = preg_replace( '/@keyframes\s+[\w-]+\s*\{(?:[^{}]|\{[^{}]*\})*\}/si', '', $css );
		$css = preg_replace( '/@media[^{]*\{(?:[^{}]|\{[^{}]*\})*\}/si', '', $css );

		// Split into selector { declarations } pairs.
		if ( preg_match_all( '/([^{]+)\{([^}]*)\}/s', $css, $matches ) ) {
			foreach ( $matches[1] as $i => $selector ) {
				$selector = trim( $selector );
				if ( empty( $selector ) || 0 === strpos( $selector, '@' ) ) {
					continue;
				}

				$props = $this->parse_declarations( $matches[2][ $i ] );
				if ( empty( $props ) ) {
					$rules[] = null; // Unparseable.
					continue;
				}

				$rules[] = array(
					'selector'   => $selector,
					'properties' => $props,
				);
			}
		}

		return $rules;
	}

	/**
	 * Parse CSS declarations string into property-value map.
	 *
	 * Handles shorthand expansion for padding, margin, border-radius.
	 *
	 * @param string $declarations CSS declarations (e.g., "color: red; font-size: 16px").
	 * @return array Property-value map.
	 */
	private function parse_declarations( $declarations ) {
		$props = array();
		$parts = array_filter( array_map( 'trim', explode( ';', $declarations ) ) );

		foreach ( $parts as $part ) {
			$colon = strpos( $part, ':' );
			if ( false === $colon ) {
				continue;
			}

			$property = trim( substr( $part, 0, $colon ) );
			$value    = trim( substr( $part, $colon + 1 ) );

			if ( empty( $property ) || empty( $value ) ) {
				continue;
			}

			$property = strtolower( $property );

			// Expand shorthand properties.
			$expanded = $this->expand_shorthand( $property, $value );
			if ( null !== $expanded ) {
				$props = array_merge( $props, $expanded );
			} else {
				$props[ $property ] = $value;
			}
		}

		return $props;
	}

	/**
	 * Expand CSS shorthand properties into individual properties.
	 *
	 * @param string $property CSS property name.
	 * @param string $value    CSS value.
	 * @return array|null Expanded properties or null if not a shorthand.
	 */
	private function expand_shorthand( $property, $value ) {
		if ( in_array( $property, array( 'padding', 'margin' ), true ) ) {
			return $this->expand_box_shorthand( $property, $value );
		}

		if ( 'border-radius' === $property ) {
			return $this->expand_border_radius( $value );
		}

		if ( 'background' === $property ) {
			return $this->expand_background( $value );
		}

		if ( 'border' === $property ) {
			return $this->expand_border( $value );
		}

		return null;
	}

	/**
	 * Expand background shorthand.
	 *
	 * @since 5.2.0
	 * @param string $value Background shorthand value.
	 * @return array Expanded properties.
	 */
	private function expand_background( $value ) {
		$result = array();

		// Check for gradient.
		if ( preg_match( '/((?:linear|radial|conic)-gradient\s*\(.+\))/', $value, $m ) ) {
			$result['background-image'] = $m[1];
			return $result;
		}

		// Check for url().
		if ( preg_match( '/url\(\s*["\']?([^"\')\s]+)["\']?\s*\)/', $value, $m ) ) {
			$result['background-image'] = 'url(' . $m[1] . ')';
			// Extract other parts.
			$remaining = preg_replace( '/url\([^)]+\)/', '', $value );
			// Look for size keywords.
			if ( preg_match( '/\b(cover|contain)\b/', $remaining, $sm ) ) {
				$result['background-size'] = $sm[1];
			}
			// Look for position keywords.
			if ( preg_match( '/\b(center|top|bottom|left|right)(?:\s+(center|top|bottom|left|right))?\b/', $remaining, $pm ) ) {
				$result['background-position'] = trim( $pm[0] );
			}
			// Look for repeat keywords.
			if ( preg_match( '/\b(no-repeat|repeat-x|repeat-y|repeat)\b/', $remaining, $rm ) ) {
				$result['background-repeat'] = $rm[1];
			}
		}

		// Check for color (hex, rgb, rgba, hsl, named).
		if ( preg_match( '/(#[0-9a-fA-F]{3,8}|rgba?\s*\([^)]+\)|hsla?\s*\([^)]+\)|var\([^)]+\))/', $value, $cm ) ) {
			$result['background-color'] = $cm[1];
		} elseif ( empty( $result ) ) {
			// Likely a plain color like 'background: red' or 'background: transparent'.
			$result['background-color'] = trim( $value );
		}

		return ! empty( $result ) ? $result : null;
	}

	/**
	 * Expand border shorthand (e.g., '1px solid #ccc').
	 *
	 * @since 5.2.0
	 * @param string $value Border shorthand value.
	 * @return array|null Expanded properties or null.
	 */
	private function expand_border( $value ) {
		$result = array();
		$parts = preg_split( '/\s+/', trim( $value ) );

		foreach ( $parts as $part ) {
			if ( preg_match( '/^\d+(\.\d+)?(px|em|rem|pt)?$/', $part ) ) {
				$result['border-width'] = $part;
			} elseif ( in_array( $part, array( 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset', 'none' ), true ) ) {
				$result['border-style'] = $part;
			} else {
				$result['border-color'] = $part;
			}
		}

		return ! empty( $result ) ? $result : null;
	}

	/**
	 * Expand padding/margin shorthand.
	 *
	 * @param string $property 'padding' or 'margin'.
	 * @param string $value    Shorthand value.
	 * @return array Expanded properties.
	 */
	private function expand_box_shorthand( $property, $value ) {
		// Don't expand values with calc/var that might contain spaces.
		if ( preg_match( '/(?:calc|var|clamp|min|max)\s*\(/', $value ) ) {
			return array( $property => $value );
		}

		$values = preg_split( '/\s+/', $value );
		$count  = count( $values );

		switch ( $count ) {
			case 1:
				return array(
					$property . '-top'    => $values[0],
					$property . '-right'  => $values[0],
					$property . '-bottom' => $values[0],
					$property . '-left'   => $values[0],
				);
			case 2:
				return array(
					$property . '-top'    => $values[0],
					$property . '-right'  => $values[1],
					$property . '-bottom' => $values[0],
					$property . '-left'   => $values[1],
				);
			case 3:
				return array(
					$property . '-top'    => $values[0],
					$property . '-right'  => $values[1],
					$property . '-bottom' => $values[2],
					$property . '-left'   => $values[1],
				);
			case 4:
				return array(
					$property . '-top'    => $values[0],
					$property . '-right'  => $values[1],
					$property . '-bottom' => $values[2],
					$property . '-left'   => $values[3],
				);
			default:
				return array( $property => $value );
		}
	}

	/**
	 * Expand border-radius shorthand.
	 *
	 * @param string $value Shorthand value.
	 * @return array Expanded properties.
	 */
	private function expand_border_radius( $value ) {
		if ( preg_match( '/(?:calc|var|clamp)\s*\(/', $value ) ) {
			return array( 'border-radius' => $value );
		}

		$values = preg_split( '/\s+/', $value );
		$count  = count( $values );

		switch ( $count ) {
			case 1:
				return array(
					'border-top-left-radius'     => $values[0],
					'border-top-right-radius'    => $values[0],
					'border-bottom-right-radius' => $values[0],
					'border-bottom-left-radius'  => $values[0],
				);
			case 2:
				return array(
					'border-top-left-radius'     => $values[0],
					'border-top-right-radius'    => $values[1],
					'border-bottom-right-radius' => $values[0],
					'border-bottom-left-radius'  => $values[1],
				);
			case 3:
				return array(
					'border-top-left-radius'     => $values[0],
					'border-top-right-radius'    => $values[1],
					'border-bottom-right-radius' => $values[2],
					'border-bottom-left-radius'  => $values[1],
				);
			case 4:
				return array(
					'border-top-left-radius'     => $values[0],
					'border-top-right-radius'    => $values[1],
					'border-bottom-right-radius' => $values[2],
					'border-bottom-left-radius'  => $values[3],
				);
			default:
				return array( 'border-radius' => $value );
		}
	}
}
