<?php
/**
 * Style Mapper for HTML-to-Builder conversion.
 *
 * Maps CSS properties to builder-specific widget settings.
 * Builder-agnostic core with per-builder overrides.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/html-converter
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_Style_Mapper {

	/**
	 * Builder-agnostic CSS → setting mapping.
	 *
	 * @return array
	 */
	private static function get_generic_map() {
		return array(
			// Background.
			'background-color'            => 'background_color',
			'background-image'            => 'background_image',
			// Typography.
			'font-family'                 => 'typography_font_family',
			'font-size'                   => 'typography_font_size',
			'font-weight'                 => 'typography_font_weight',
			'line-height'                 => 'typography_line_height',
			'letter-spacing'              => 'typography_letter_spacing',
			'text-align'                  => 'text_align',
			'color'                       => 'color',
			'text-transform'              => 'typography_text_transform',
			'text-decoration'             => 'typography_text_decoration',
			// Spacing.
			'padding-top'                 => 'padding.top',
			'padding-right'               => 'padding.right',
			'padding-bottom'              => 'padding.bottom',
			'padding-left'                => 'padding.left',
			'margin-top'                  => 'margin.top',
			'margin-right'                => 'margin.right',
			'margin-bottom'               => 'margin.bottom',
			'margin-left'                 => 'margin.left',
			'gap'                         => 'column_gap',
			// Border.
			'border-top-left-radius'      => 'border_radius.top_left',
			'border-top-right-radius'     => 'border_radius.top_right',
			'border-bottom-right-radius'  => 'border_radius.bottom_right',
			'border-bottom-left-radius'   => 'border_radius.bottom_left',
			'border-color'                => 'border_color',
			'border-width'                => 'border_width',
			'border-style'                => 'border_style',
			// Shadow.
			'box-shadow'                  => 'box_shadow',
			// Layout.
			'max-width'                   => 'max_width',
			'min-height'                  => 'min_height',
			'width'                       => 'width',
			'justify-content'             => 'justify_content',
			'align-items'                 => 'align_items',
			'flex-direction'              => 'flex_direction',
			// Visual.
			'opacity'                     => 'opacity',
			'z-index'                     => 'z_index',
			'overflow'                    => 'overflow',
			// Display (for layout detection, may not map to a builder setting directly).
			'display'                     => '_display',
			'position'                    => '_position',
		);
	}

	/**
	 * Elementor-specific setting overrides.
	 *
	 * Maps CSS properties to Elementor's actual control setting keys.
	 * Elementor uses specific naming conventions — e.g., background_color for
	 * section/container BG, title_color for heading text, padding uses
	 * {top,right,bottom,left} unit-based keys.
	 *
	 * @return array
	 */
	private static function get_elementor_overrides() {
		return array(
			'background-color'            => 'background_color',
			'background-image'            => '_background_image',
			'background-size'             => 'background_size',
			'background-position'         => 'background_position',
			'background-repeat'           => 'background_repeat',
			'color'                       => 'title_color',
			'font-family'                 => 'typography_font_family',
			'font-size'                   => 'typography_font_size',
			'font-weight'                 => 'typography_font_weight',
			'line-height'                 => 'typography_line_height',
			'letter-spacing'              => 'typography_letter_spacing',
			'text-transform'              => 'typography_text_transform',
			'text-decoration'             => 'typography_text_decoration',
			'padding-top'                 => 'padding.top',
			'padding-right'               => 'padding.right',
			'padding-bottom'              => 'padding.bottom',
			'padding-left'                => 'padding.left',
			'margin-top'                  => 'margin.top',
			'margin-right'                => 'margin.right',
			'margin-bottom'               => 'margin.bottom',
			'margin-left'                 => 'margin.left',
			'border-top-left-radius'      => 'border_radius.top',
			'border-top-right-radius'     => 'border_radius.right',
			'border-bottom-right-radius'  => 'border_radius.bottom',
			'border-bottom-left-radius'   => 'border_radius.left',
			'border-color'                => 'border_color',
			'border-width'                => 'border_width',
			'border-style'                => 'border_border',
			'box-shadow'                  => 'box_shadow_box_shadow',
			'max-width'                   => '_element_width',
			'min-height'                  => 'min_height',
			'gap'                         => 'gap',
			'justify-content'             => 'justify_content',
			'align-items'                 => 'align_items',
			'flex-direction'              => 'flex_direction',
		);
	}

	/**
	 * Divi 5 specific setting overrides.
	 *
	 * @return array
	 */
	private static function get_divi5_overrides() {
		return array(
			'background-color'            => 'module.decoration.background.desktop.value.color',
			'color'                       => 'module.decoration.font.desktop.value.color',
			'font-family'                 => 'module.decoration.font.desktop.value.family',
			'font-size'                   => 'module.decoration.font.desktop.value.size',
			'font-weight'                 => 'module.decoration.font.desktop.value.weight',
			'line-height'                 => 'module.decoration.font.desktop.value.lineHeight',
			'letter-spacing'              => 'module.decoration.font.desktop.value.letterSpacing',
			'padding-top'                 => 'module.decoration.spacing.desktop.value.padding.top',
			'padding-right'               => 'module.decoration.spacing.desktop.value.padding.right',
			'padding-bottom'              => 'module.decoration.spacing.desktop.value.padding.bottom',
			'padding-left'                => 'module.decoration.spacing.desktop.value.padding.left',
			'margin-top'                  => 'module.decoration.spacing.desktop.value.margin.top',
			'margin-bottom'               => 'module.decoration.spacing.desktop.value.margin.bottom',
			'border-top-left-radius'      => 'module.decoration.border.desktop.value.radius.topLeft',
			'border-top-right-radius'     => 'module.decoration.border.desktop.value.radius.topRight',
			'border-bottom-right-radius'  => 'module.decoration.border.desktop.value.radius.bottomRight',
			'border-bottom-left-radius'   => 'module.decoration.border.desktop.value.radius.bottomLeft',
			'box-shadow'                  => 'module.decoration.boxShadow.desktop.value',
		);
	}

	/**
	 * Gutenberg specific setting overrides.
	 *
	 * @return array
	 */
	private static function get_gutenberg_overrides() {
		return array(
			'background-color' => 'style.color.background',
			'color'            => 'style.color.text',
			'font-size'        => 'style.typography.fontSize',
			'font-weight'      => 'style.typography.fontWeight',
			'line-height'      => 'style.typography.lineHeight',
			'padding-top'      => 'style.spacing.padding.top',
			'padding-right'    => 'style.spacing.padding.right',
			'padding-bottom'   => 'style.spacing.padding.bottom',
			'padding-left'     => 'style.spacing.padding.left',
			'margin-top'       => 'style.spacing.margin.top',
			'margin-bottom'    => 'style.spacing.margin.bottom',
		);
	}

	/**
	 * Get the setting map for a specific builder.
	 *
	 * @param string $builder Builder slug.
	 * @return array Merged setting map.
	 */
	public function get_map_for_builder( $builder ) {
		$base = self::get_generic_map();

		switch ( strtolower( $builder ) ) {
			case 'elementor':
				return array_merge( $base, self::get_elementor_overrides() );
			case 'divi':
			case 'divi5':
				return array_merge( $base, self::get_divi5_overrides() );
			case 'gutenberg':
			case 'block-editor':
				return array_merge( $base, self::get_gutenberg_overrides() );
			default:
				return $base;
		}
	}

	/**
	 * Map a set of CSS properties to builder settings.
	 *
	 * @param array  $css_properties Property-value map from CSS extractor.
	 * @param string $builder        Target builder slug.
	 * @param string $element_type   Element type hint (heading, text, image, etc.).
	 * @return array Mapped builder settings and unmapped properties.
	 */
	public function map_properties( $css_properties, $builder, $element_type = '' ) {
		$setting_map = $this->get_map_for_builder( $builder );
		$mapped      = array();
		$unmapped    = array();

		foreach ( $css_properties as $property => $value ) {
			// Skip CSS custom properties — they're handled separately as tokens.
			if ( 0 === strpos( $property, '--' ) ) {
				continue;
			}

			// Check for gradient in background-image.
			if ( 'background-image' === $property && $this->is_gradient( $value ) ) {
				$gradient = $this->parse_gradient( $value );
				if ( $gradient ) {
					$mapped['_gradient'] = $gradient;
					continue;
				}
			}

			// Parse box-shadow specially.
			if ( 'box-shadow' === $property ) {
				$shadow = $this->parse_box_shadow( $value );
				if ( $shadow ) {
					$setting = isset( $setting_map[ $property ] ) ? $setting_map[ $property ] : 'box_shadow';
					$mapped[ $setting ] = $shadow;
					continue;
				}
			}

			if ( isset( $setting_map[ $property ] ) ) {
				$setting = $setting_map[ $property ];

				// Context-dependent color mapping.
				if ( 'color' === $property && ! empty( $element_type ) ) {
					$setting = $this->resolve_color_setting( $setting, $element_type, $builder );
				}

				$mapped[ $setting ] = $this->normalize_value( $value );
			} else {
				$unmapped[ $property ] = $value;
			}
		}

		// Post-process into builder-native control structures.
		if ( 'elementor' === strtolower( $builder ) ) {
			$mapped = $this->postprocess_elementor( $mapped );
		}

		return array(
			'settings' => $mapped,
			'unmapped' => $unmapped,
		);
	}

	/**
	 * Post-process mapped settings into Elementor's native control structures.
	 *
	 * Elementor uses specific array formats for padding, border_radius,
	 * typography, background, and box_shadow controls.
	 *
	 * @since 5.2.0
	 * @param array $mapped Flat mapped settings.
	 * @return array Elementor-native settings.
	 */
	private function postprocess_elementor( $mapped ) {
		$result = array();

		// Collect grouped settings.
		$padding = array();
		$margin  = array();
		$border_radius = array();
		$has_typography = false;

		foreach ( $mapped as $key => $value ) {
			// Padding group: padding.top → padding['top'].
			if ( 0 === strpos( $key, 'padding.' ) ) {
				$side = substr( $key, 8 );
				$padding[ $side ] = $this->extract_numeric_value( $value );
				continue;
			}
			// Margin group.
			if ( 0 === strpos( $key, 'margin.' ) ) {
				$side = substr( $key, 7 );
				$margin[ $side ] = $this->extract_numeric_value( $value );
				continue;
			}
			// Border radius group.
			if ( 0 === strpos( $key, 'border_radius.' ) ) {
				$corner = substr( $key, 14 );
				$border_radius[ $corner ] = $this->extract_numeric_value( $value );
				continue;
			}
			// Typography controls — enable the typography switcher.
			if ( 0 === strpos( $key, 'typography_' ) ) {
				$has_typography = true;
				// font_size needs size+unit structure.
				if ( 'typography_font_size' === $key ) {
					$parsed = $this->parse_size_value( $value );
					$result['typography_font_size'] = $parsed;
					continue;
				}
				if ( 'typography_line_height' === $key ) {
					$parsed = $this->parse_size_value( $value );
					$result['typography_line_height'] = $parsed;
					continue;
				}
				if ( 'typography_letter_spacing' === $key ) {
					$parsed = $this->parse_size_value( $value );
					$result['typography_letter_spacing'] = $parsed;
					continue;
				}
			}
			// Background image from CSS url().
			if ( '_background_image' === $key ) {
				$url = $this->extract_url_from_css( $value );
				if ( $url ) {
					$result['background_background'] = 'classic';
					$result['background_image'] = array( 'url' => $url, 'id' => '' );
				}
				continue;
			}
			// Background color — also set background type.
			if ( 'background_color' === $key ) {
				$result['background_background'] = isset( $result['background_background'] ) ? $result['background_background'] : 'classic';
				$result['background_color'] = $value;
				continue;
			}
			// Gradient.
			if ( '_gradient' === $key && is_array( $value ) ) {
				$result['background_background'] = 'gradient';
				if ( ! empty( $value['stops'][0]['color'] ) ) {
					$result['background_color'] = $value['stops'][0]['color'];
				}
				if ( ! empty( $value['stops'][1]['color'] ) ) {
					$result['background_color_b'] = $value['stops'][1]['color'];
				}
				if ( ! empty( $value['direction'] ) ) {
					$angle = intval( $value['direction'] );
					$result['background_gradient_angle'] = array( 'size' => $angle, 'unit' => 'deg' );
				}
				continue;
			}
			// Box shadow.
			if ( 'box_shadow_box_shadow' === $key && is_array( $value ) ) {
				$result['box_shadow_box_shadow_type'] = 'yes';
				$result['box_shadow_box_shadow'] = array(
					'horizontal' => intval( isset( $value['horizontal'] ) ? $value['horizontal'] : 0 ),
					'vertical'   => intval( isset( $value['vertical'] ) ? $value['vertical'] : 0 ),
					'blur'       => intval( isset( $value['blur'] ) ? $value['blur'] : 10 ),
					'spread'     => intval( isset( $value['spread'] ) ? $value['spread'] : 0 ),
					'color'      => isset( $value['color'] ) ? $value['color'] : 'rgba(0,0,0,0.5)',
				);
				continue;
			}
			// Min-height needs size structure.
			if ( 'min_height' === $key ) {
				$result['min_height'] = $this->parse_size_value( $value );
				continue;
			}
			// Pass through other settings directly.
			$result[ $key ] = $value;
		}

		// Build padding control.
		if ( ! empty( $padding ) ) {
			$unit = $this->detect_unit( $padding );
			$result['padding'] = array_merge(
				array( 'unit' => $unit, 'isLinked' => false ),
				$padding
			);
		}
		// Build margin control.
		if ( ! empty( $margin ) ) {
			$unit = $this->detect_unit( $margin );
			$result['margin'] = array_merge(
				array( 'unit' => $unit, 'isLinked' => false ),
				$margin
			);
		}
		// Build border radius control.
		if ( ! empty( $border_radius ) ) {
			$unit = $this->detect_unit( $border_radius );
			$result['border_radius'] = array_merge(
				array( 'unit' => $unit, 'isLinked' => false ),
				$border_radius
			);
		}
		// Enable typography toggle.
		if ( $has_typography ) {
			$result['typography_typography'] = 'custom';
		}

		return $result;
	}

	/**
	 * Extract numeric value from a CSS size string (e.g., '20px' → '20').
	 *
	 * @since 5.2.0
	 * @param string $value CSS value.
	 * @return string Numeric string.
	 */
	private function extract_numeric_value( $value ) {
		if ( preg_match( '/^(-?\d+(?:\.\d+)?)/', $value, $m ) ) {
			return $m[1];
		}
		return $value;
	}

	/**
	 * Parse a CSS size value into Elementor's {size, unit} structure.
	 *
	 * @since 5.2.0
	 * @param string $value CSS value (e.g., '16px', '1.5em', 'clamp(1rem,2vw,2rem)').
	 * @return array {size: number, unit: string}
	 */
	private function parse_size_value( $value ) {
		// Handle clamp() — use the middle (preferred) value.
		if ( preg_match( '/clamp\(\s*[^,]+,\s*([^,]+),/', $value, $m ) ) {
			$value = trim( $m[1] );
		}
		if ( preg_match( '/^(-?\d+(?:\.\d+)?)\s*(px|em|rem|%|vw|vh)?$/', $value, $m ) ) {
			return array(
				'size' => floatval( $m[1] ),
				'unit' => ! empty( $m[2] ) ? $m[2] : 'px',
			);
		}
		// Fallback — try to get any number.
		if ( preg_match( '/(-?\d+(?:\.\d+)?)/', $value, $m ) ) {
			return array( 'size' => floatval( $m[1] ), 'unit' => 'px' );
		}
		return array( 'size' => '', 'unit' => 'px' );
	}

	/**
	 * Detect the CSS unit from a set of values.
	 *
	 * @since 5.2.0
	 * @param array $values Associative array of side → value.
	 * @return string Detected unit (px, em, %, etc.).
	 */
	private function detect_unit( $values ) {
		foreach ( $values as $v ) {
			if ( preg_match( '/(px|em|rem|%|vw|vh)$/', $v, $m ) ) {
				return $m[1];
			}
		}
		return 'px';
	}

	/**
	 * Extract URL from CSS url() function.
	 *
	 * @since 5.2.0
	 * @param string $value CSS value like 'url("image.jpg")'.
	 * @return string|null URL or null.
	 */
	private function extract_url_from_css( $value ) {
		if ( preg_match( '/url\(\s*["\']?([^"\')\s]+)["\']?\s*\)/', $value, $m ) ) {
			return $m[1];
		}
		return null;
	}

	/**
	 * Map responsive CSS (from media queries) to builder breakpoints.
	 *
	 * @param array  $media_queries From CSS extractor.
	 * @param string $builder       Target builder slug.
	 * @return array Breakpoint-keyed settings.
	 */
	public function map_responsive( $media_queries, $builder ) {
		$breakpoints = $this->get_breakpoints( $builder );
		$responsive  = array();

		foreach ( $media_queries as $mq ) {
			$max = $mq['max_width'];
			if ( null === $max ) {
				continue;
			}

			$breakpoint = $this->resolve_breakpoint( $max, $breakpoints );
			if ( ! $breakpoint ) {
				continue;
			}

			foreach ( $mq['rules'] as $rule ) {
				if ( empty( $rule ) ) {
					continue;
				}
				$result = $this->map_properties( $rule['properties'], $builder );
				if ( ! empty( $result['settings'] ) ) {
					if ( ! isset( $responsive[ $breakpoint ] ) ) {
						$responsive[ $breakpoint ] = array();
					}
					$responsive[ $breakpoint ][ $rule['selector'] ] = $result['settings'];
				}
			}
		}

		return $responsive;
	}

	/**
	 * Get builder breakpoint definitions.
	 *
	 * @param string $builder Builder slug.
	 * @return array Breakpoint name → max-width mapping, descending.
	 */
	private function get_breakpoints( $builder ) {
		switch ( strtolower( $builder ) ) {
			case 'elementor':
				return array(
					'tablet' => 1024,
					'mobile' => 767,
				);
			case 'divi':
			case 'divi5':
				return array(
					'tablet'    => 980,
					'phoneWide' => 767,
					'phone'     => 479,
				);
			default:
				return array(
					'tablet' => 1024,
					'mobile' => 767,
				);
		}
	}

	/**
	 * Resolve a max-width value to the closest builder breakpoint.
	 *
	 * @param int   $max_width   CSS max-width in pixels.
	 * @param array $breakpoints Builder breakpoints.
	 * @return string|null Breakpoint name or null.
	 */
	private function resolve_breakpoint( $max_width, $breakpoints ) {
		$closest      = null;
		$closest_diff = PHP_INT_MAX;

		foreach ( $breakpoints as $name => $width ) {
			$diff = abs( $max_width - $width );
			if ( $diff < $closest_diff ) {
				$closest      = $name;
				$closest_diff = $diff;
			}
		}

		// Allow 100px tolerance for breakpoint matching.
		if ( $closest_diff <= 100 ) {
			return $closest;
		}

		return null;
	}

	/**
	 * Resolve color setting name based on element type context.
	 *
	 * @param string $default_setting Default setting name.
	 * @param string $element_type    Element type.
	 * @param string $builder         Builder slug.
	 * @return string Resolved setting name.
	 */
	private function resolve_color_setting( $default_setting, $element_type, $builder ) {
		switch ( $element_type ) {
			case 'heading':
				return 'elementor' === $builder ? 'title_color' : $default_setting;
			case 'text':
				return 'elementor' === $builder ? 'text_color' : $default_setting;
			case 'button':
				return 'elementor' === $builder ? 'button_text_color' : $default_setting;
			default:
				return $default_setting;
		}
	}

	/**
	 * Check if a CSS value is a gradient.
	 *
	 * @param string $value CSS value.
	 * @return bool
	 */
	private function is_gradient( $value ) {
		return (bool) preg_match( '/(linear|radial|conic)-gradient\s*\(/', $value );
	}

	/**
	 * Parse a CSS gradient value into structured data.
	 *
	 * @param string $value Gradient CSS value.
	 * @return array|null Gradient data or null.
	 */
	private function parse_gradient( $value ) {
		$gradient = array( 'raw' => $value );

		if ( preg_match( '/linear-gradient\s*\(\s*(\d+deg)?\s*,?\s*(.+)\)$/i', $value, $m ) ) {
			$gradient['type']      = 'linear';
			$gradient['direction'] = ! empty( $m[1] ) ? $m[1] : '180deg';
			$gradient['stops']     = $this->parse_gradient_stops( $m[2] );
		} elseif ( preg_match( '/radial-gradient\s*\(\s*(.+)\)$/i', $value, $m ) ) {
			$gradient['type'] = 'radial';
			$inner = $m[1];
			// Separate shape/position from color stops.
			// Radial format: radial-gradient([shape] [size] at [position], color-stop, ...)
			// The shape/position part ends at the first comma that's followed by a color.
			$stops_str = $inner;
			if ( preg_match( '/^((?:circle|ellipse)?\s*(?:\d+%?\s*)*(?:at\s+[^,]+)?)\s*,\s*(.+)$/i', $inner, $rm ) ) {
				$gradient['shape'] = trim( $rm[1] );
				$stops_str = $rm[2];
			}
			$gradient['stops'] = $this->parse_gradient_stops( $stops_str );
		} else {
			return null;
		}

		return $gradient;
	}

	/**
	 * Parse gradient color stops.
	 *
	 * Handles rgba/hsla values that contain commas by tracking parenthesis depth.
	 *
	 * @param string $stops_str Comma-separated stops string.
	 * @return array Array of stop data.
	 */
	private function parse_gradient_stops( $stops_str ) {
		$stops = array();

		// Split respecting parentheses (don't split inside rgba(), hsla(), etc.).
		$parts = array();
		$current = '';
		$depth = 0;
		for ( $i = 0, $len = strlen( $stops_str ); $i < $len; $i++ ) {
			$char = $stops_str[ $i ];
			if ( '(' === $char ) {
				++$depth;
			} elseif ( ')' === $char ) {
				--$depth;
			} elseif ( ',' === $char && 0 === $depth ) {
				$parts[] = trim( $current );
				$current = '';
				continue;
			}
			$current .= $char;
		}
		if ( '' !== trim( $current ) ) {
			$parts[] = trim( $current );
		}

		foreach ( $parts as $part ) {
			if ( preg_match( '/^(.+?)\s+(\d+%?)$/', trim( $part ), $m ) ) {
				$stops[] = array(
					'color'    => trim( $m[1] ),
					'position' => $m[2],
				);
			} else {
				$stops[] = array(
					'color'    => trim( $part ),
					'position' => null,
				);
			}
		}

		return $stops;
	}

	/**
	 * Parse a CSS box-shadow value.
	 *
	 * @param string $value Box-shadow CSS value.
	 * @return array|null Shadow data or null.
	 */
	private function parse_box_shadow( $value ) {
		if ( 'none' === strtolower( trim( $value ) ) ) {
			return null;
		}

		// Simple regex for common box-shadow patterns.
		// Matches: [inset] h-offset v-offset [blur] [spread] color
		$pattern = '/^(inset\s+)?(-?\d+(?:\.\d+)?(?:px|em|rem)?)\s+(-?\d+(?:\.\d+)?(?:px|em|rem)?)\s*(-?\d+(?:\.\d+)?(?:px|em|rem)?)?\s*(-?\d+(?:\.\d+)?(?:px|em|rem)?)?\s*(.*?)$/i';

		if ( preg_match( $pattern, trim( $value ), $m ) ) {
			return array(
				'position'   => ! empty( $m[1] ) ? 'inset' : 'outline',
				'horizontal' => $m[2],
				'vertical'   => $m[3],
				'blur'       => ! empty( $m[4] ) ? $m[4] : '0px',
				'spread'     => ! empty( $m[5] ) ? $m[5] : '0px',
				'color'      => ! empty( $m[6] ) ? trim( $m[6] ) : 'rgba(0,0,0,0.5)',
			);
		}

		return array( 'raw' => $value );
	}

	/**
	 * Normalize a CSS value for builder consumption.
	 *
	 * @param string $value Raw CSS value.
	 * @return string Normalized value.
	 */
	private function normalize_value( $value ) {
		$value = trim( $value );

		// Strip !important.
		$value = preg_replace( '/\s*!important\s*$/', '', $value );

		// Resolve var() references to their fallback values.
		if ( preg_match( '/var\([^,]+,\s*(.+)\)/', $value, $m ) ) {
			$value = trim( $m[1] );
		}

		return $value;
	}
}
