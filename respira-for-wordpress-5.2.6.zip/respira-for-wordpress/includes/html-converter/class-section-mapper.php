<?php
/**
 * Section Mapper for HTML-to-Builder conversion.
 *
 * Walks the HTML DOM tree and identifies semantic sections,
 * layout patterns, and element hierarchy for builder mapping.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/html-converter
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_Section_Mapper {

	/**
	 * Maximum nesting depth before flattening.
	 *
	 * @var int
	 */
	const MAX_DEPTH = 30;

	/**
	 * Maximum elements per page.
	 *
	 * @var int
	 */
	const MAX_ELEMENTS = 500;

	/**
	 * Semantic section tags.
	 *
	 * @var array
	 */
	private static $section_tags = array( 'header', 'section', 'article', 'footer', 'nav', 'aside', 'main' );

	/**
	 * Class-name heuristics for section identification.
	 *
	 * @var array
	 */
	private static $section_heuristics = array(
		'hero'         => 'hero',
		'features'     => 'features',
		'testimonial'  => 'testimonials',
		'cta'          => 'cta',
		'pricing'      => 'pricing',
		'faq'          => 'faq',
		'stats'        => 'stats',
		'contact'      => 'contact',
		'about'        => 'about',
		'team'         => 'team',
		'portfolio'    => 'portfolio',
		'services'     => 'services',
		'banner'       => 'banner',
		'footer'       => 'footer',
		'header'       => 'header',
		'navigation'   => 'navigation',
		'sidebar'      => 'sidebar',
	);

	/**
	 * Element counter for limit enforcement.
	 *
	 * @var int
	 */
	private $element_count = 0;

	/**
	 * Whether element limit has been reached.
	 *
	 * @var bool
	 */
	private $limit_reached = false;

	/**
	 * Map HTML string to a section structure.
	 *
	 * @param string $html Sanitized HTML string.
	 * @return array|WP_Error Array of section data or error.
	 */
	public function map( $html ) {
		if ( empty( trim( $html ) ) ) {
			return new WP_Error(
				'respira_empty_html',
				__( 'No convertible content detected in source HTML.', 'respira-for-wordpress' )
			);
		}

		$this->element_count = 0;
		$this->limit_reached = false;

		// Strip <style>, <script>, <link>, <meta> tags — we only care about structure.
		$html = preg_replace( '/<(style|script|link|meta)[^>]*>.*?<\/\1>/si', '', $html );
		$html = preg_replace( '/<(link|meta)[^>]*\/?>/i', '', $html );

		// Extract <body> content if present.
		if ( preg_match( '/<body[^>]*>(.*)<\/body>/si', $html, $body_match ) ) {
			$html = $body_match[1];
		}

		$dom = new DOMDocument();
		// Suppress malformed HTML warnings.
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8" ?><div id="respira-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		$root = $dom->getElementById( 'respira-root' );
		if ( ! $root ) {
			return new WP_Error(
				'respira_parse_error',
				__( 'Failed to parse HTML content.', 'respira-for-wordpress' )
			);
		}

		$sections = $this->walk_node( $root, 0 );

		$result = array(
			'sections'      => $sections,
			'element_count' => $this->element_count,
			'limit_reached' => $this->limit_reached,
		);

		return $result;
	}

	/**
	 * Recursively walk a DOM node and build section structure.
	 *
	 * @param DOMNode $node  DOM node.
	 * @param int     $depth Current nesting depth.
	 * @return array Array of section/element data.
	 */
	private function walk_node( $node, $depth ) {
		$children = array();

		if ( ! $node->hasChildNodes() ) {
			return $children;
		}

		foreach ( $node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				// Text node — capture if non-empty.
				if ( XML_TEXT_NODE === $child->nodeType ) {
					$text = trim( $child->textContent );
					if ( ! empty( $text ) ) {
						++$this->element_count;
						if ( $this->element_count > self::MAX_ELEMENTS ) {
							$this->limit_reached = true;
							$children[] = array(
								'type'          => 'html_fallback',
								'reason'        => 'Element limit exceeded',
								'html'          => $child->ownerDocument->saveHTML( $child ),
								'element_count' => 1,
							);
							return $children;
						}
						$children[] = array(
							'type'    => 'text',
							'content' => $text,
						);
					}
				}
				continue;
			}

			if ( $this->limit_reached ) {
				break;
			}

			++$this->element_count;
			if ( $this->element_count > self::MAX_ELEMENTS ) {
				$this->limit_reached = true;
				$children[] = array(
					'type'          => 'html_fallback',
					'reason'        => 'Element limit exceeded (' . self::MAX_ELEMENTS . ' max)',
					'html'          => $child->ownerDocument->saveHTML( $child ),
					'element_count' => 1,
				);
				break;
			}

			$tag     = strtolower( $child->nodeName );
			$classes = $child->getAttribute( 'class' ) ?: '';
			$id      = $child->getAttribute( 'id' ) ?: '';
			$style   = $child->getAttribute( 'style' ) ?: '';

			$element = array(
				'tag'     => $tag,
				'classes' => $classes,
				'id'      => $id,
				'style'   => $style,
				'layout'  => $this->detect_layout( $style, $classes ),
				'section_hint' => $this->detect_section_hint( $tag, $classes, $id ),
			);

			// Depth guard — flatten remaining children.
			if ( $depth >= self::MAX_DEPTH ) {
				$element['type']          = 'html_fallback';
				$element['reason']        = 'Max nesting depth exceeded (' . self::MAX_DEPTH . ')';
				$element['html']          = $child->ownerDocument->saveHTML( $child );
				$element['element_count'] = 1;
				$children[] = $element;
				continue;
			}

			// Classify the element.
			$element['type'] = $this->classify_element( $tag, $child );

			// Recursively process children.
			if ( $child->hasChildNodes() && 'leaf' !== $element['type'] ) {
				$element['children'] = $this->walk_node( $child, $depth + 1 );
			} else {
				$element['children'] = array();
			}

			// Count children for layout detection.
			$element['child_count'] = count( $element['children'] );

			// For leaf elements, capture content.
			if ( in_array( $element['type'], array( 'heading', 'text', 'image', 'button', 'link', 'leaf' ), true ) ) {
				$element['content'] = $this->extract_element_content( $tag, $child );
			}

			// Detect background images in inline styles for containers/sections.
			if ( ! empty( $style ) && in_array( $element['type'], array( 'section', 'container' ), true ) ) {
				if ( preg_match( '/background(?:-image)?\s*:\s*url\(\s*["\']?([^"\')\s]+)/', $style, $bg_match ) ) {
					if ( ! isset( $element['content'] ) ) {
						$element['content'] = array();
					}
					$element['content']['background_image'] = $bg_match[1];
				}
			}

			$children[] = $element;
		}

		return $children;
	}

	/**
	 * Classify an HTML element into a builder-friendly type.
	 *
	 * @param string  $tag  Tag name.
	 * @param DOMNode $node DOM node.
	 * @return string Element type.
	 */
	private function classify_element( $tag, $node ) {
		// Section-level containers.
		if ( in_array( $tag, self::$section_tags, true ) ) {
			return 'section';
		}

		// Headings.
		if ( preg_match( '/^h[1-6]$/', $tag ) ) {
			return 'heading';
		}

		// Images.
		if ( 'img' === $tag ) {
			return 'image';
		}

		// Videos.
		if ( in_array( $tag, array( 'video', 'iframe' ), true ) ) {
			return 'video';
		}

		// Buttons and CTAs.
		if ( 'button' === $tag ) {
			return 'button';
		}
		if ( 'a' === $tag ) {
			$classes = strtolower( $node->getAttribute( 'class' ) ?: '' );
			if ( preg_match( '/\b(btn|button|cta)\b/', $classes ) ) {
				return 'button';
			}
			return 'link';
		}

		// Lists.
		if ( in_array( $tag, array( 'ul', 'ol' ), true ) ) {
			return 'list';
		}

		// Forms.
		if ( 'form' === $tag ) {
			return 'form';
		}

		// Paragraphs and text.
		if ( in_array( $tag, array( 'p', 'span', 'blockquote', 'pre', 'code' ), true ) ) {
			return 'text';
		}

		// Horizontal rules / dividers.
		if ( 'hr' === $tag ) {
			return 'divider';
		}

		// Tables.
		if ( 'table' === $tag ) {
			return 'table';
		}

		// Divs — container or leaf depending on children.
		if ( in_array( $tag, array( 'div', 'figure', 'figcaption' ), true ) ) {
			if ( $node->hasChildNodes() ) {
				$has_element_children = false;
				foreach ( $node->childNodes as $child ) {
					if ( XML_ELEMENT_NODE === $child->nodeType ) {
						$has_element_children = true;
						break;
					}
				}
				return $has_element_children ? 'container' : 'text';
			}
			return 'leaf';
		}

		// SVG.
		if ( 'svg' === $tag ) {
			return 'leaf';
		}

		return 'container';
	}

	/**
	 * Detect layout pattern from inline styles and classes.
	 *
	 * @param string $style   Inline style string.
	 * @param string $classes Class string.
	 * @return string|null Layout type or null.
	 */
	private function detect_layout( $style, $classes ) {
		$combined = strtolower( $style . ' ' . $classes );

		if ( preg_match( '/display\s*:\s*grid/', $style ) || preg_match( '/\bgrid\b/', $classes ) ) {
			return 'grid';
		}

		if ( preg_match( '/display\s*:\s*flex/', $style ) || preg_match( '/\b(flex|d-flex)\b/', $classes ) ) {
			$direction = 'row';
			if ( preg_match( '/flex-direction\s*:\s*column/', $style ) || preg_match( '/\bflex-col/', $classes ) ) {
				$direction = 'column';
			}
			return 'flex-' . $direction;
		}

		if ( preg_match( '/\b(row|columns|col-\d|grid-cols)\b/', $combined ) ) {
			return 'flex-row';
		}

		// Detect flex-row from CSS class patterns that commonly indicate side-by-side layout.
		if ( preg_match( '/\b(features|cards|services|pricing|stats|team|benefits|grid-container|card-grid)\b/', $combined ) ) {
			return 'flex-row';
		}

		return null;
	}

	/**
	 * Detect section type hint from tag, classes, and id.
	 *
	 * @param string $tag     Tag name.
	 * @param string $classes Class string.
	 * @param string $id      ID attribute.
	 * @return string|null Section hint or null.
	 */
	private function detect_section_hint( $tag, $classes, $id ) {
		$search = strtolower( $tag . ' ' . $classes . ' ' . $id );

		foreach ( self::$section_heuristics as $keyword => $hint ) {
			if ( false !== strpos( $search, $keyword ) ) {
				return $hint;
			}
		}

		return null;
	}

	/**
	 * Extract content data from a leaf element.
	 *
	 * @param string  $tag  Tag name.
	 * @param DOMNode $node DOM node.
	 * @return array Content data.
	 */
	private function extract_element_content( $tag, $node ) {
		$content = array();

		switch ( $tag ) {
			case 'h1':
			case 'h2':
			case 'h3':
			case 'h4':
			case 'h5':
			case 'h6':
				$content['text']  = trim( $node->textContent );
				$content['level'] = (int) substr( $tag, 1, 1 );
				break;

			case 'img':
				$content['src'] = $node->getAttribute( 'src' ) ?: '';
				$content['alt'] = $node->getAttribute( 'alt' ) ?: '';
				$width = $node->getAttribute( 'width' );
				$height = $node->getAttribute( 'height' );
				if ( $width ) {
					$content['width'] = $width;
				}
				if ( $height ) {
					$content['height'] = $height;
				}
				break;

			case 'a':
				$content['text'] = trim( $node->textContent );
				$content['href'] = $node->getAttribute( 'href' ) ?: '';
				$content['target'] = $node->getAttribute( 'target' ) ?: '';
				break;

			case 'button':
				$content['text'] = trim( $node->textContent );
				break;

			default:
				$inner_html = '';
				foreach ( $node->childNodes as $child ) {
					$inner_html .= $node->ownerDocument->saveHTML( $child );
				}
				$content['html'] = trim( $inner_html );
				$content['text'] = trim( $node->textContent );
				break;
		}

		return $content;
	}
}
