<?php
/**
 * Fidelity Checker for HTML-to-Builder conversion.
 *
 * Post-conversion quality assurance — compares source HTML structure
 * against builder output to detect dropped sections, missed elements,
 * and unmapped design tokens.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/html-converter
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_Fidelity_Checker {

	/**
	 * Generate a fidelity report comparing source HTML analysis with builder output.
	 *
	 * @param array $source_analysis Source HTML analysis data.
	 * @param array $builder_output  Builder conversion result.
	 * @param array $css_data        CSS extraction data.
	 * @return array Fidelity report.
	 */
	public function check( $source_analysis, $builder_output, $css_data ) {
		$source_sections = $this->count_sections( $source_analysis );
		$source_elements = $this->count_elements_by_type( $source_analysis );
		$output_sections = isset( $builder_output['section_count'] ) ? $builder_output['section_count'] : 0;
		$output_elements = isset( $builder_output['element_count'] ) ? $builder_output['element_count'] : 0;

		// Guard against empty source.
		if ( 0 === $source_sections && 0 === array_sum( $source_elements ) ) {
			return array(
				'score'              => 0,
				'sections_matched'   => 0,
				'sections_total'     => 0,
				'sections_dropped'   => array(),
				'elements_matched'   => 0,
				'elements_total'     => 0,
				'elements_dropped'   => array(),
				'tokens_mapped'      => 0,
				'tokens_total'       => 0,
				'tokens_unmapped'    => array(),
				'fonts_available'    => array(),
				'fonts_substituted'  => array(),
				'animations_flagged' => 0,
				'responsive_mapped'  => false,
				'security_stripped'  => isset( $builder_output['security_stripped'] ) ? $builder_output['security_stripped'] : array(),
				'warnings'           => array( 'No convertible content detected in source HTML.' ),
			);
		}

		$sections_dropped = isset( $builder_output['sections_dropped'] ) ? $builder_output['sections_dropped'] : array();
		$sections_matched = max( 0, $source_sections - count( $sections_dropped ) );

		$elements_dropped = isset( $builder_output['elements_dropped'] ) ? $builder_output['elements_dropped'] : array();
		$total_source_elements = array_sum( $source_elements );
		$elements_matched = max( 0, $total_source_elements - count( $elements_dropped ) );

		// Token coverage.
		$tokens         = isset( $css_data['tokens'] ) ? $css_data['tokens'] : array();
		$tokens_mapped  = isset( $builder_output['tokens_mapped'] ) ? $builder_output['tokens_mapped'] : array();
		$tokens_total   = count( $tokens );
		$mapped_count   = is_array( $tokens_mapped ) ? count( $tokens_mapped ) : (int) $tokens_mapped;
		$unmapped_tokens = array_diff( array_keys( $tokens ), is_array( $tokens_mapped ) ? $tokens_mapped : array() );

		// Font coverage.
		$source_fonts       = isset( $css_data['fonts'] ) ? $css_data['fonts'] : array();
		$available_fonts    = isset( $builder_output['fonts_available'] ) ? $builder_output['fonts_available'] : array();
		$substituted_fonts  = isset( $builder_output['fonts_substituted'] ) ? $builder_output['fonts_substituted'] : array();

		// Animations.
		$animations = isset( $css_data['animations'] ) ? $css_data['animations'] : array();
		$animations_flagged = count( $animations );

		// Responsive mapping.
		$responsive_mapped = isset( $builder_output['responsive_mapped'] ) ? (bool) $builder_output['responsive_mapped'] : false;

		// Calculate score.
		$score = $this->calculate_score(
			$source_sections,
			$sections_matched,
			$total_source_elements,
			$elements_matched,
			$tokens_total,
			$mapped_count,
			$animations_flagged,
			$responsive_mapped
		);

		// Build warnings.
		$warnings = $this->generate_warnings( $source_analysis, $builder_output, $css_data );

		return array(
			'score'              => $score,
			'sections_matched'   => $sections_matched,
			'sections_total'     => $source_sections,
			'sections_dropped'   => $sections_dropped,
			'elements_matched'   => $elements_matched,
			'elements_total'     => $total_source_elements,
			'elements_dropped'   => $elements_dropped,
			'tokens_mapped'      => $mapped_count,
			'tokens_total'       => $tokens_total,
			'tokens_unmapped'    => array_values( $unmapped_tokens ),
			'fonts_available'    => $available_fonts,
			'fonts_substituted'  => $substituted_fonts,
			'animations_flagged' => $animations_flagged,
			'responsive_mapped'  => $responsive_mapped,
			'security_stripped'  => isset( $builder_output['security_stripped'] ) ? $builder_output['security_stripped'] : array(),
			'warnings'           => $warnings,
		);
	}

	/**
	 * Calculate overall fidelity score (0-100).
	 *
	 * Weighted:
	 * - 40% section coverage
	 * - 30% element coverage
	 * - 15% token coverage
	 * - 10% responsive mapping
	 * - 5%  no animations to flag
	 *
	 * @param int  $source_sections   Total source sections.
	 * @param int  $sections_matched  Matched sections.
	 * @param int  $total_elements    Total source elements.
	 * @param int  $elements_matched  Matched elements.
	 * @param int  $tokens_total      Total tokens.
	 * @param int  $tokens_mapped     Mapped tokens.
	 * @param int  $animations        Animations flagged.
	 * @param bool $responsive        Responsive mapped.
	 * @return int Score 0-100.
	 */
	private function calculate_score( $source_sections, $sections_matched, $total_elements, $elements_matched, $tokens_total, $tokens_mapped, $animations, $responsive ) {
		$section_score  = $source_sections > 0 ? ( $sections_matched / $source_sections ) : 1.0;
		$element_score  = $total_elements > 0 ? ( $elements_matched / $total_elements ) : 1.0;
		$token_score    = $tokens_total > 0 ? ( $tokens_mapped / $tokens_total ) : 1.0;
		$responsive_score = $responsive ? 1.0 : 0.0;
		$animation_score  = 0 === $animations ? 1.0 : 0.0;

		$score = (
			( $section_score * 40 ) +
			( $element_score * 30 ) +
			( $token_score * 15 ) +
			( $responsive_score * 10 ) +
			( $animation_score * 5 )
		);

		return max( 0, min( 100, (int) round( $score ) ) );
	}

	/**
	 * Count sections in the source analysis.
	 *
	 * @param array $analysis Section mapper output.
	 * @return int Section count.
	 */
	private function count_sections( $analysis ) {
		$sections = isset( $analysis['sections'] ) ? $analysis['sections'] : array();
		$count = 0;

		foreach ( $sections as $item ) {
			$type = isset( $item['type'] ) ? $item['type'] : '';
			if ( 'section' === $type || 'container' === $type ) {
				++$count;
			}
			if ( ! empty( $item['children'] ) ) {
				$count += $this->count_sections_recursive( $item['children'] );
			}
		}

		return max( $count, 1 ); // At least 1 implicit section.
	}

	/**
	 * Recursively count section-type elements.
	 *
	 * @param array $children Children array.
	 * @return int Count.
	 */
	private function count_sections_recursive( $children ) {
		$count = 0;
		foreach ( $children as $child ) {
			$type = isset( $child['type'] ) ? $child['type'] : '';
			if ( 'section' === $type ) {
				++$count;
			}
			if ( ! empty( $child['children'] ) ) {
				$count += $this->count_sections_recursive( $child['children'] );
			}
		}
		return $count;
	}

	/**
	 * Count elements by type in the source analysis.
	 *
	 * @param array $analysis Section mapper output.
	 * @return array Type => count map.
	 */
	private function count_elements_by_type( $analysis ) {
		$counts = array();
		$sections = isset( $analysis['sections'] ) ? $analysis['sections'] : array();
		$this->count_elements_recursive( $sections, $counts );
		return $counts;
	}

	/**
	 * Recursively count elements by type.
	 *
	 * @param array $items  Items to count.
	 * @param array $counts Running counts (by reference).
	 */
	private function count_elements_recursive( $items, &$counts ) {
		foreach ( $items as $item ) {
			$type = isset( $item['type'] ) ? $item['type'] : 'unknown';
			if ( ! isset( $counts[ $type ] ) ) {
				$counts[ $type ] = 0;
			}
			++$counts[ $type ];

			if ( ! empty( $item['children'] ) ) {
				$this->count_elements_recursive( $item['children'], $counts );
			}
		}
	}

	/**
	 * Generate warning messages for the fidelity report.
	 *
	 * @param array $source  Source analysis.
	 * @param array $output  Builder output.
	 * @param array $css     CSS data.
	 * @return array Warning strings.
	 */
	private function generate_warnings( $source, $output, $css ) {
		$warnings = array();

		// CSS grid → flex conversion.
		$sections = isset( $source['sections'] ) ? $source['sections'] : array();
		if ( $this->has_layout_type( $sections, 'grid' ) ) {
			$warnings[] = 'Source uses CSS Grid layouts — converted to flex rows (minor layout differences possible).';
		}

		// Animations present.
		$animations = isset( $css['animations'] ) ? $css['animations'] : array();
		if ( ! empty( $animations ) ) {
			$warnings[] = sprintf(
				'%d CSS animation(s) detected (%s) — these require manual setup in the builder.',
				count( $animations ),
				implode( ', ', array_slice( $animations, 0, 3 ) )
			);
		}

		// External @imports skipped.
		$skipped = isset( $css['skipped_rules'] ) ? $css['skipped_rules'] : 0;
		if ( $skipped > 0 ) {
			$warnings[] = sprintf( '%d CSS rule(s) could not be parsed and were skipped.', $skipped );
		}

		// Element limit reached.
		if ( isset( $source['limit_reached'] ) && $source['limit_reached'] ) {
			$warnings[] = 'Source HTML exceeded the 500 element limit — remaining elements grouped into an HTML widget.';
		}

		// HTML fallback elements.
		$fallback_count = isset( $output['html_fallback_count'] ) ? $output['html_fallback_count'] : 0;
		if ( $fallback_count > 0 ) {
			$warnings[] = sprintf(
				'%d element(s) could not be mapped to native widgets and were placed in HTML blocks.',
				$fallback_count
			);
		}

		// Font substitutions.
		$subs = isset( $output['fonts_substituted'] ) ? $output['fonts_substituted'] : array();
		foreach ( $subs as $sub ) {
			$warnings[] = sprintf(
				'Font "%s" not available in builder — substituted with "%s".',
				$sub['source'],
				$sub['substituted_with']
			);
		}

		return $warnings;
	}

	/**
	 * Check if any element in the tree has a specific layout type.
	 *
	 * @param array  $items  Elements array.
	 * @param string $layout Layout type to find.
	 * @return bool
	 */
	private function has_layout_type( $items, $layout ) {
		foreach ( $items as $item ) {
			if ( isset( $item['layout'] ) && $layout === $item['layout'] ) {
				return true;
			}
			if ( ! empty( $item['children'] ) && $this->has_layout_type( $item['children'], $layout ) ) {
				return true;
			}
		}
		return false;
	}
}
