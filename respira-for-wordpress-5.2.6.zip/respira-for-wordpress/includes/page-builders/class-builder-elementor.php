<?php
/**
 * Elementor page builder implementation.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 */

/**
 * Elementor builder class (PRO feature).
 *
 * @since 1.0.0
 */
class Respira_Builder_Elementor extends Respira_Builder_Interface {

	/**
	 * Get the children key for Elementor's simplified structure.
	 *
	 * @since 5.2.0
	 * @return string
	 */
	public function get_children_key() {
		return 'elements';
	}

	/**
	 * Get the attributes key for Elementor's simplified structure.
	 *
	 * @since 5.2.0
	 * @return string
	 */
	public function get_attributes_key() {
		return 'settings';
	}

	/**
	 * Get the ID key for Elementor's simplified structure.
	 *
	 * @since 5.2.0
	 * @return string
	 */
	public function get_id_key() {
		return 'id';
	}

	/**
	 * Detect if Elementor is active.
	 *
	 * Uses multiple fallbacks for different Elementor versions and load orders.
	 *
	 * @since 1.0.0
	 * @return bool True if Elementor is active.
	 */
	public function detect() {
		return defined( 'ELEMENTOR_VERSION' )
			|| class_exists( '\Elementor\Plugin' )
			|| function_exists( 'elementor' );
	}

	/**
	 * Get builder name.
	 *
	 * @since 1.0.0
	 * @return string Builder name.
	 */
	public function get_name() {
		return 'Elementor';
	}

	/**
	 * Get builder version.
	 *
	 * @since 1.0.0
	 * @return string Builder version.
	 */
	public function get_version() {
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			return ELEMENTOR_VERSION;
		}
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance ) && \Elementor\Plugin::$instance && method_exists( \Elementor\Plugin::$instance, 'get_version' ) ) {
			return \Elementor\Plugin::$instance->get_version();
		}
		return 'unknown';
	}

	/**
	 * Get Elementor plugin instance safely.
	 *
	 * @since 4.0.3
	 * @return object|null
	 */
	private function get_elementor_instance() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return null;
		}

		try {
			return \Elementor\Plugin::$instance ?? null;
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira Elementor: unable to read Plugin::$instance: ' . $e->getMessage() );
			}
		}

		return null;
	}

	/**
	 * Get Elementor version for meta writes safely.
	 *
	 * @since 4.0.3
	 * @return string
	 */
	private function get_elementor_version_for_meta() {
		$version = $this->get_version();
		return ( ! empty( $version ) && 'unknown' !== $version ) ? $version : '3.0.0';
	}

	/**
	 * Persist Elementor content via direct meta writes.
	 *
	 * Used as a fallback when Elementor's document API is unavailable or throws.
	 * Also invalidates Elementor's rendered element cache to avoid stale frontend output.
	 *
	 * @since 4.0.7
	 * @param int   $post_id           Post ID.
	 * @param mixed $elements          Elementor elements payload.
	 * @param string $elementor_version Elementor version to persist in meta.
	 * @return void
	 */
	private function persist_elementor_meta_fallback( $post_id, $elements, $elementor_version ) {
		// Ensure canonical array payload before encoding.
		if ( is_string( $elements ) ) {
			$decoded = json_decode( $elements, true );
			if ( is_array( $decoded ) ) {
				$elements = $decoded;
			}
		}

		if ( ! is_array( $elements ) ) {
			$elements = array();
		}

		// Use JSON_UNESCAPED_UNICODE so non-ASCII characters (Cyrillic, CJK, etc.)
		// are stored as literal UTF-8 rather than \uXXXX escape sequences.
		// This prevents WordPress's internal wp_unslash/stripslashes from stripping
		// the backslash prefix and corrupting \uXXXX sequences into literal uXXXX text.
		update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $post_id, '_elementor_version', $elementor_version );

		// Invalidate Elementor render cache for this post on fallback writes.
		delete_post_meta( $post_id, '_elementor_element_cache' );
	}

	/**
	 * Remove a UTF-8 BOM that can break json_decode().
	 *
	 * @since 4.1.2
	 * @param string $value Candidate string.
	 * @return string
	 */
	private function strip_utf8_bom( $value ) {
		if ( ! is_string( $value ) ) {
			return '';
		}

		return preg_replace( '/^\xEF\xBB\xBF/', '', $value );
	}

	/**
	 * Unwrap Elementor meta values that may be stored in wrappers.
	 *
	 * Supports `get_post_meta()`-style single item arrays, nested JSON strings,
	 * and serialized wrappers produced by bad historical writes.
	 *
	 * @since 4.1.2
	 * @param mixed $value Raw meta value.
	 * @param int   $max_depth Maximum unwrap depth.
	 * @return mixed
	 */
	private function unwrap_elementor_meta_value( $value, $max_depth = 5 ) {
		$current = $value;
		$depth   = 0;

		while ( $depth < $max_depth ) {
			if ( is_array( $current ) ) {
				$first = $current[0] ?? null;
				if ( is_array( $first ) ) {
					return $current;
				}

				if ( 1 === count( $current ) ) {
					$current = reset( $current );
					$depth++;
					continue;
				}

				return $current;
			}

			if ( ! is_string( $current ) ) {
				return $current;
			}

			$current = $this->strip_utf8_bom( wp_unslash( $current ) );
			$trimmed = trim( $current );
			if ( '' === $trimmed ) {
				return $trimmed;
			}

			if ( is_serialized( $trimmed ) ) {
				$unserialized = maybe_unserialize( $trimmed );
				if ( $unserialized !== $trimmed ) {
					$current = $unserialized;
					$depth++;
					continue;
				}
			}

			return $trimmed;
		}

		return $current;
	}

	/**
	 * Determine whether a method exists and is publicly callable.
	 *
	 * @since 4.1.2
	 * @param object $object Object instance.
	 * @param string $method Method name.
	 * @return bool
	 */
	private function has_public_method( $object, $method ) {
		if ( ! is_object( $object ) || ! method_exists( $object, $method ) ) {
			return false;
		}

		try {
			$reflection = new ReflectionMethod( $object, $method );
			return $reflection->isPublic();
		} catch ( ReflectionException $e ) {
			return false;
		}
	}

	/**
	 * Check if post uses Elementor.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return bool True if uses Elementor.
	 */
	public function is_builder_used( $post_id ) {
		$elementor_instance = $this->get_elementor_instance();
		if ( $elementor_instance && isset( $elementor_instance->documents ) && is_object( $elementor_instance->documents ) && method_exists( $elementor_instance->documents, 'get' ) ) {
			$document = $elementor_instance->documents->get( $post_id );
			return $document && $document->is_built_with_elementor();
		}

		return (bool) get_post_meta( $post_id, '_elementor_edit_mode', true );
	}

	/**
	 * Extract content from post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array Extracted elements.
	 */
	public function extract_content( $post_id ) {
		$start = microtime( true );

		$data = get_post_meta( $post_id, '_elementor_data', true );

		if ( empty( $data ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira Elementor: No _elementor_data found for post ' . $post_id );
			}
			return array();
		}

		$elements = $this->decode_elementor_meta_elements( $data, $post_id );

		// Fallback to Elementor's own document API for edge-case payloads that
		// Elementor can still parse but raw meta JSON decoding cannot.
		if ( empty( $elements ) && $this->has_non_empty_elementor_payload( $data ) ) {
			$document_elements = $this->get_document_elements_data( $post_id );
			if ( ! empty( $document_elements ) ) {
				$elements = $document_elements;

				// Self-heal stored meta to canonical JSON for future extraction calls.
				$canonical = wp_json_encode( $document_elements, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				if ( is_string( $canonical ) && '' !== $canonical ) {
					update_post_meta( $post_id, '_elementor_data', wp_slash( $canonical ) );
				}

				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( 'Respira Elementor: Recovered elements via document API fallback for post ' . $post_id );
				}
			}
		}

		if ( ! is_array( $elements ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira Elementor: _elementor_data is not an array for post ' . $post_id );
			}
			return array();
		}

		$result = $this->simplify_structure( $elements );

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'Respira Elementor: Extracted ' . count( $result ) . ' top-level elements from post ' . $post_id );
		}

		$this->log_performance( 'extract', $post_id, microtime( true ) - $start );

		return $result;
	}

	/**
	 * Decode raw `_elementor_data` values into element arrays.
	 *
	 * Handles canonical JSON strings, single-item wrappers, and accidental
	 * nested JSON-string wrappers caused by previous bad writes.
	 *
	 * @since 4.0.4
	 * @param mixed $raw_data Raw meta value.
	 * @param int   $post_id  Post ID (for optional repair persistence).
	 * @return array
	 */
	private function decode_elementor_meta_elements( $raw_data, $post_id ) {
		$raw_data = $this->unwrap_elementor_meta_value( $raw_data );

		if ( is_array( $raw_data ) ) {
			return $raw_data;
		}

		if ( ! is_string( $raw_data ) ) {
			return array();
		}

		// Try decoding without wp_unslash first: get_post_meta returns the raw DB
		// value, which already has backslashes in the correct state. Calling
		// wp_unslash/stripslashes unconditionally would strip the '\' from \uXXXX
		// Unicode escape sequences and corrupt non-ASCII text (e.g. Cyrillic).
		$current = $this->strip_utf8_bom( $raw_data );
		$depth   = 0;

		while ( $depth < 5 && is_string( $current ) ) {
			$current = trim( $current );
			if ( '' === $current ) {
				return array();
			}

			if ( is_serialized( $current ) ) {
				$unserialized = maybe_unserialize( $current );
				if ( is_array( $unserialized ) ) {
					return $this->unwrap_elementor_meta_value( $unserialized );
				}
				if ( is_string( $unserialized ) && $unserialized !== $current ) {
					$current = $this->strip_utf8_bom( $unserialized );
					$depth++;
					continue;
				}
			}

			$decoded = json_decode( $current, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				// Fallback: some legacy data may have been stored with an extra layer
				// of slashing. Apply wp_unslash and retry before giving up.
				$unslashed = $this->strip_utf8_bom( wp_unslash( $current ) );
				if ( $unslashed !== $current ) {
					$decoded_unslashed = json_decode( $unslashed, true );
					if ( JSON_ERROR_NONE === json_last_error() ) {
						return is_array( $decoded_unslashed ) ? $decoded_unslashed : array();
					}
				}

				// Try additional unslash passes for double-escaped JSON payloads.
				$decoded = $this->decode_json_with_extra_unslash_passes( $current );

				if ( JSON_ERROR_NONE === json_last_error() ) {
					return is_array( $decoded ) ? $decoded : array();
				}

				$repaired_data = $this->repair_unicode_escapes_for_json( $current );
				if ( $repaired_data !== $current ) {
					$decoded = json_decode( $repaired_data, true );
					if ( JSON_ERROR_NONE === json_last_error() ) {
						// Persist repaired JSON so future reads and edits work normally.
						update_post_meta( $post_id, '_elementor_data', wp_slash( $repaired_data ) );
						$current = $repaired_data;
					}
				}
			}

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					$prefix_hex = bin2hex( substr( (string) $current, 0, 8 ) );
					error_log(
						sprintf(
							'Respira Elementor: JSON decode error for post %d: %s (len=%d, prefix_hex=%s)',
							$post_id,
							json_last_error_msg(),
							strlen( (string) $current ),
							$prefix_hex
						)
					);
				}
				return array();
			}

			if ( is_string( $decoded ) ) {
				$current = $decoded;
				$depth++;
				continue;
			}

			return is_array( $decoded ) ? $decoded : array();
		}

		return array();
	}

	/**
	 * Decode JSON while attempting additional unslash passes.
	 *
	 * Some hosts/plugins can leave Elementor meta double-escaped even after one
	 * unslash pass, which yields JSON syntax errors in direct decoding.
	 *
	 * @since 4.1.6
	 * @param string $json JSON candidate.
	 * @return mixed
	 */
	private function decode_json_with_extra_unslash_passes( $json ) {
		$candidate = $json;

		for ( $i = 0; $i < 3 && is_string( $candidate ); $i++ ) {
			$decoded = json_decode( $candidate, true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				return $decoded;
			}

			$unslashed = wp_unslash( $candidate );
			if ( ! is_string( $unslashed ) || $unslashed === $candidate ) {
				break;
			}

			$candidate = $this->strip_utf8_bom( $unslashed );
		}

		return null;
	}

	/**
	 * Determine if raw Elementor payload appears non-empty.
	 *
	 * @since 4.1.6
	 * @param mixed $raw_data Raw `_elementor_data`.
	 * @return bool
	 */
	private function has_non_empty_elementor_payload( $raw_data ) {
		$normalized = $this->unwrap_elementor_meta_value( $raw_data );

		if ( is_array( $normalized ) ) {
			return ! empty( $normalized );
		}

		if ( ! is_string( $normalized ) ) {
			return false;
		}

		$trimmed = trim( $this->strip_utf8_bom( $normalized ) );
		return '' !== $trimmed && '[]' !== $trimmed;
	}

	/**
	 * Read Elementor elements through Elementor's document API.
	 *
	 * @since 4.1.6
	 * @param int $post_id Post ID.
	 * @return array
	 */
	private function get_document_elements_data( $post_id ) {
		$elementor_instance = $this->get_elementor_instance();
		if ( ! $elementor_instance || ! isset( $elementor_instance->documents ) || ! is_object( $elementor_instance->documents ) || ! method_exists( $elementor_instance->documents, 'get' ) ) {
			return array();
		}

		try {
			$document = $elementor_instance->documents->get( $post_id, false );
			if ( ! $document || ! is_object( $document ) ) {
				return array();
			}

			foreach ( array( 'get_elements_data', 'get_elements_raw_data' ) as $method ) {
				if ( ! $this->has_public_method( $document, $method ) ) {
					continue;
				}

				$elements = $document->{$method}();
				if ( is_array( $elements ) ) {
					return $elements;
				}
			}
		} catch ( Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira Elementor: document API fallback failed for post ' . $post_id . ': ' . $e->getMessage() );
			}
		}

		return array();
	}

	/**
	 * Repair broken unicode escapes in JSON strings (uXXXX -> \uXXXX).
	 *
	 * @since 2.0.8
	 * @param string $json JSON string.
	 * @return string Repaired JSON when valid, original string otherwise.
	 */
	private function repair_unicode_escapes_for_json( $json ) {
		if ( ! is_string( $json ) || ! preg_match( '/u[0-9a-fA-F]{4}/', $json ) ) {
			return $json;
		}

		$repaired = preg_replace( '/(?<!\\\\)u([0-9a-fA-F]{4})/', '\\\\u$1', $json );
		if ( ! is_string( $repaired ) || $repaired === $json ) {
			return $json;
		}

		json_decode( $repaired, true );

		return ( JSON_ERROR_NONE === json_last_error() ) ? $repaired : $json;
	}

	/**
	 * Inject content into post.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified content.
	 * @return bool|WP_Error True on success.
	 */
	public function inject_content( $post_id, $content, $skip_structure_validation = false ) {
		$start = microtime( true );
		$elementor_version = $this->get_elementor_version_for_meta();

		// Check if content is HTML string instead of structured data.
		// If so, convert it to Elementor structure first.
		if ( is_string( $content ) ) {
			// Check if it looks like HTML (contains HTML tags).
			$has_html_tags = ( strpos( $content, '<' ) !== false || strpos( $content, '&lt;' ) !== false );
			// Check if it's NOT already JSON (structured data would be JSON).
			$decoded = json_decode( $content, true );
			$is_not_json = ( $decoded === null || ( is_string( $decoded ) && $decoded === $content ) );
			
			if ( $has_html_tags && $is_not_json ) {
				// Content appears to be HTML, parse it to Elementor structure.
				$content = $this->parse_html_to_elementor_structure( $content );
			} elseif ( $decoded !== null && is_array( $decoded ) ) {
				// Content is JSON string, decode it.
				$content = $decoded;
			}
		} elseif ( is_array( $content ) && ! empty( $content ) ) {
			// Check if array has proper Elementor structure (type/widget keys).
			// If not, it might be raw content that needs parsing.
			$has_structure = false;
			if ( isset( $content[0] ) && is_array( $content[0] ) ) {
				$has_structure = isset( $content[0]['type'] ) || isset( $content[0]['widget'] );
			}
			
			// If no structure and contains HTML-like strings, try to parse.
			if ( ! $has_structure ) {
				$html_parts = array();
				foreach ( $content as $item ) {
					if ( is_string( $item ) && ( strpos( $item, '<' ) !== false || strpos( $item, '&lt;' ) !== false ) ) {
						$html_parts[] = $item;
					}
				}
				
				if ( ! empty( $html_parts ) ) {
					// Combine HTML parts and parse.
					$html_string = implode( "\n", $html_parts );
					$content = $this->parse_html_to_elementor_structure( $html_string );
				}
			}
		}

		// Normalize alternate payload shapes (e.g. {sections:[...]}, {elements:[...]}).
		$content = $this->normalize_incoming_content( $content );

		// Validate layout before injection.
		if ( class_exists( 'Respira_Elementor_Validator' ) ) {
			$validator = new Respira_Elementor_Validator();
			$validation = $validator->validate_layout( $content );
			if ( ! $validation['valid'] ) {
				return new WP_Error(
					'respira_elementor_validation_failed',
					__( 'Elementor layout validation failed:', 'respira-for-wordpress' ) . ' ' . implode( ' ', $validation['errors'] ),
					$validation['errors']
				);
			}
		}

		// Check if content needs container wrapping before complexifying.
		// This ensures modern Elementor (3.x) gets proper container structure.
		if ( $this->needs_container_wrapping( $content ) ) {
			// Log that we're auto-wrapping for debugging.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'Respira: Auto-wrapping Elementor widgets in container for page ' . $post_id );
			}
			
			// Wrap widgets in a container with default settings.
			$content = array( $this->wrap_in_container( $content ) );
		}

		$elements = $this->complexify_structure( $content );

		// Ensure elements is an array (Elementor requires array format).
		if ( ! is_array( $elements ) ) {
			$elements = array();
		}

		// Use Elementor's API to save data properly.
		// CRITICAL: Elementor expects _elementor_data to be stored as JSON string,
		// but when retrieved internally, it must be decoded to array.
		// Using Elementor's document API ensures proper format.
		$elementor_instance = $this->get_elementor_instance();
		if ( $elementor_instance ) {
			try {
				// Get or create Elementor document.
				$document = ( isset( $elementor_instance->documents ) && is_object( $elementor_instance->documents ) && method_exists( $elementor_instance->documents, 'get' ) )
					? $elementor_instance->documents->get( $post_id, false )
					: null;
				
				if ( ! $document ) {
					// Document doesn't exist yet, we'll create it by setting meta first.
					update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
					update_post_meta( $post_id, '_elementor_version', $elementor_version );
					
					// Set template type for proper Elementor initialization (only if not already set).
					$existing_template_type = get_post_meta( $post_id, '_elementor_template_type', true );
					if ( empty( $existing_template_type ) ) {
						$post = get_post( $post_id );
						if ( $post ) {
							$template_type = 'wp-page';
							if ( 'post' === $post->post_type ) {
								$template_type = 'wp-post';
							}
							update_post_meta( $post_id, '_elementor_template_type', $template_type );
						}
					}
					
					// Now get the document (it should exist after setting meta).
					$document = ( isset( $elementor_instance->documents ) && is_object( $elementor_instance->documents ) && method_exists( $elementor_instance->documents, 'get' ) )
						? $elementor_instance->documents->get( $post_id, false )
						: null;
				}

					// Save elements using Elementor's internal method.
					// This ensures data is stored and retrieved in the format Elementor expects.
					// CRITICAL: save_elements() expects an array, not JSON string.
					if ( $document && $this->has_public_method( $document, 'save_elements' ) ) {
						// Ensure elements is an array (not JSON string).
						if ( is_string( $elements ) ) {
							$elements = json_decode( $elements, true );
						}
						if ( ! is_array( $elements ) ) {
							$elements = array();
						}

						// Save elements and capture return value (if any).
						$save_result = $document->save_elements( $elements );

						// If Elementor reports failure, drop to the direct meta fallback.
						if ( $save_result === false || is_wp_error( $save_result ) ) {
							throw new Exception( 'Elementor save_elements() returned false or error' );
						}

						if ( $this->has_public_method( $document, 'save_builder_state' ) ) {
							$state_result = $document->save_builder_state();
							if ( $state_result === false || is_wp_error( $state_result ) ) {
								error_log( 'Respira: Elementor save_builder_state() returned false or error' );
							}
						}
					} else {
						// Fallback when the document API is unavailable.
						$this->persist_elementor_meta_fallback( $post_id, $elements, $elementor_version );
					}
			} catch ( Throwable $e ) {
				// If Elementor API fails, use fallback with proper JSON encoding.
				error_log( 'Respira: Elementor save failed, using fallback: ' . $e->getMessage() );
				$this->persist_elementor_meta_fallback( $post_id, $elements, $elementor_version );
			}

			// Clear Elementor cache to ensure changes are recognized.
			try {
				$files_manager = ( isset( $elementor_instance->files_manager ) && is_object( $elementor_instance->files_manager ) ) ? $elementor_instance->files_manager : null;
				if ( is_object( $files_manager ) && method_exists( $files_manager, 'clear_cache' ) ) {
					$files_manager->clear_cache();
				}
			} catch ( Throwable $e ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( 'Respira: Elementor cache clear failed: ' . $e->getMessage() );
				}
			}
		} else {
			// Elementor not active, use direct meta update.
			$this->persist_elementor_meta_fallback( $post_id, $elements, $elementor_version );
		}

		$this->log_performance( 'inject', $post_id, microtime( true ) - $start );

		return true;
	}

	/**
	 * Create a code block.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     CSS content.
	 * @param string $js      JavaScript content.
	 * @return bool|WP_Error True on success.
	 */
	public function create_code_block( $post_id, $html, $css = '', $js = '' ) {
		$data = get_post_meta( $post_id, '_elementor_data', true );
		$elements = json_decode( $data, true ) ?: array();

		// Create HTML widget element.
		$html_widget = array(
			'id'         => uniqid( 'respira_' ),
			'elType'     => 'widget',
			'widgetType' => 'html',
			'settings'   => array(
				'html' => $html . ( $css ? "\n<style>$css</style>" : '' ) . ( $js ? "\n<script>$js</script>" : '' ),
			),
		);

		$elements[] = $html_widget;

		update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );

		return true;
	}

	/**
	 * Get documentation.
	 *
	 * @since 1.0.0
	 * @return array Documentation.
	 */
	public function get_documentation() {
		$documentation = array(
			'name'        => 'Elementor',
			'description' => 'Popular drag-and-drop page builder plugin',
			'overview'    => 'Elementor uses sections, columns, and widgets. Data is stored as JSON in post meta.',
			'resources'   => array(
				'https://developers.elementor.com/',
			),
		);

		// Add widget catalog if available.
		if ( class_exists( 'Respira_Elementor_Widget_Registry' ) ) {
			$all_widgets = Respira_Elementor_Widget_Registry::get_all_widgets();
			$documentation['widgets'] = array(
				'total'     => count( $all_widgets ),
				'available' => array_column( $all_widgets, 'name' ),
			);
		}

		// Add patterns if available.
		if ( function_exists( 'respira_get_elementor_patterns' ) ) {
			$patterns = respira_get_elementor_patterns();
			$documentation['patterns'] = array(
				'count'    => count( $patterns ),
				'available' => array_keys( $patterns ),
			);
		}

		return $documentation;
	}

	/**
	 * Get available modules.
	 *
	 * @since 1.0.0
	 * @return array Available widgets.
	 */
	public function get_available_modules() {
		// Use dynamic widget registry if available.
		if ( class_exists( 'Respira_Elementor_Widget_Registry' ) ) {
			return Respira_Elementor_Widget_Registry::get_all_widgets();
		}

		// Fallback to basic enumeration.
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return array();
		}

		$widgets_manager = \Elementor\Plugin::$instance->widgets_manager;
		$widget_types = $widgets_manager->get_widget_types();

		$available = array();

		foreach ( $widget_types as $widget_type ) {
			$available[] = array(
				'name'  => $widget_type->get_name(),
				'title' => $widget_type->get_title(),
			);
		}

		return $available;
	}

	/**
	 * Get builder schema for AI context.
	 *
	 * @since  1.3.0
	 * @param  array $widgets_used Optional. Array of widget names used on the page.
	 * @return array Builder schema with widget information.
	 */
	public function get_builder_schema( $widgets_used = array() ) {
		// Use Elementor Intelligence if available.
		if ( class_exists( 'Respira_Elementor_Widget_Schema' ) ) {
			$schema_generator = new Respira_Elementor_Widget_Schema();
			return $schema_generator->get_builder_schema( $widgets_used );
		}

		// Fallback to base implementation.
		return parent::get_builder_schema( $widgets_used );
	}

	/**
	 * Simplify Elementor structure.
	 *
	 * @since  1.0.0
	 * @param  array $elements Elementor elements.
	 * @return array Simplified structure.
	 */
	protected function simplify_structure( $elements ) {
		return array_map(
			function( $element ) {
				$simplified = array(
					'type'     => $element['elType'] ?? 'unknown',
					'widget'   => $element['widgetType'] ?? null,
					'settings' => $element['settings'] ?? array(),
					'elements' => isset( $element['elements'] ) ? $this->simplify_structure( $element['elements'] ) : array(),
				);

				// Preserve the original Elementor ID for proper round-tripping.
				if ( isset( $element['id'] ) ) {
					$simplified['id'] = $element['id'];
				}

				// Preserve isInner flag for nested containers/columns.
				if ( isset( $element['isInner'] ) ) {
					$simplified['isInner'] = $element['isInner'];
				}

				// Expose Navigator label (_title) or CSS ID as admin_label for targeting.
				$label = $element['settings']['_title'] ?? $element['settings']['_widget_label'] ?? null;
				if ( ! empty( $label ) ) {
					$simplified['admin_label'] = $label;
				} elseif ( ! empty( $element['settings']['_element_id'] ) ) {
					$simplified['admin_label'] = $element['settings']['_element_id'];
				}

				return $simplified;
			},
			$elements
		);
	}

	/**
	 * Parse HTML content and convert to Elementor structure.
	 *
	 * Converts HTML elements to appropriate Elementor widgets:
	 * - Headings (h1-h6) → heading widget
	 * - Paragraphs → text-editor widget
	 * - Images → image widget
	 * - Links/Buttons → button widget
	 * - Lists → text-editor widget
	 * - Sections/Divs → sections with columns
	 *
	 * @since  1.8.28
	 * @param  string $html HTML content to parse.
	 * @return array Simplified Elementor structure.
	 */
	protected function parse_html_to_elementor_structure( $html ) {
		// Decode HTML entities if needed.
		$html = html_entity_decode( $html, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		
		// If content is empty or not valid HTML, return empty structure.
		if ( empty( $html ) || strpos( $html, '<' ) === false ) {
			return array();
		}

		// Use DOMDocument to parse HTML.
		libxml_use_internal_errors( true );
		$dom = new DOMDocument();
		
		// Wrap in UTF-8 encoding declaration for proper parsing.
		$html_wrapped = '<?xml encoding="UTF-8">' . $html;
		
		// Try to load HTML, suppress errors for malformed HTML.
		$loaded = @$dom->loadHTML( $html_wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		// If parsing failed, fall back to simple text editor widget.
		if ( ! $loaded ) {
			return array(
				array(
					'type'     => 'widget',
					'widget'   => 'text-editor',
					'settings' => array(
						'editor' => wp_kses_post( $html ),
					),
					'elements' => array(),
				),
			);
		}

		$body = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			// Fallback: wrap entire HTML in text editor.
			return array(
				array(
					'type'     => 'widget',
					'widget'   => 'text-editor',
					'settings' => array(
						'editor' => wp_kses_post( $html ),
					),
					'elements' => array(),
				),
			);
		}

		$elements = array();
		try {
			$this->parse_dom_node( $body, $elements );
		} catch ( Exception $e ) {
			// If parsing fails, log error and fall back to text editor.
			error_log( 'Respira: HTML parsing failed: ' . $e->getMessage() );
			return array(
				array(
					'type'     => 'widget',
					'widget'   => 'text-editor',
					'settings' => array(
						'editor' => wp_kses_post( $html ),
					),
					'elements' => array(),
				),
			);
		}

		// If no elements were created, wrap content in a text editor widget.
		if ( empty( $elements ) ) {
			$elements[] = array(
				'type'     => 'widget',
				'widget'   => 'text-editor',
				'settings' => array(
					'editor' => wp_kses_post( $html ),
				),
				'elements' => array(),
			);
		}

		return $elements;
	}

	/**
	 * Recursively parse DOM nodes and convert to Elementor structure.
	 *
	 * @since  1.8.28
	 * @param  DOMNode $node     DOM node to parse.
	 * @param  array   $elements Array to add elements to.
	 * @return void
	 */
	private function parse_dom_node( $node, &$elements ) {
		if ( ! $node ) {
			return;
		}

		foreach ( $node->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType ) {
				$text = trim( $child->textContent );
				if ( ! empty( $text ) ) {
					// Add text as text-editor widget.
					$elements[] = array(
						'type'     => 'widget',
						'widget'   => 'text-editor',
						'settings' => array(
							'editor' => $text,
						),
						'elements' => array(),
					);
				}
				continue;
			}

			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}

			$tag_name = strtolower( $child->tagName );
			$element  = null;

			switch ( $tag_name ) {
				case 'style':
				case 'script':
					// Preserve <style> and <script> tags as Elementor HTML widgets.
					// The HTML widget natively supports these tags without stripping.
					$raw_html = $child->ownerDocument->saveHTML( $child );
					if ( ! empty( trim( $raw_html ) ) ) {
						$element = array(
							'type'     => 'widget',
							'widget'   => 'html',
							'settings' => array(
								'html' => $raw_html,
							),
							'elements' => array(),
						);
					}
					break;

				case 'h1':
				case 'h2':
				case 'h3':
				case 'h4':
				case 'h5':
				case 'h6':
					// Convert heading to heading widget.
					$element = array(
						'type'     => 'widget',
						'widget'   => 'heading',
						'settings' => array(
							'title'    => $child->textContent,
							'size'     => $tag_name,
							'align'    => 'left',
						),
						'elements' => array(),
					);
					break;

				case 'p':
					// Convert paragraph to text-editor widget.
					$content = $this->get_inner_html( $child );
					if ( ! empty( trim( $content ) ) ) {
						$element = array(
							'type'     => 'widget',
							'widget'   => 'text-editor',
							'settings' => array(
								'editor' => $content,
							),
							'elements' => array(),
						);
					}
					break;

				case 'img':
					// Convert image to image widget.
					$src     = $child->getAttribute( 'src' );
					$alt     = $child->getAttribute( 'alt' );
					$caption = $child->getAttribute( 'title' );
					
					if ( ! empty( $src ) ) {
						$element = array(
							'type'     => 'widget',
							'widget'   => 'image',
							'settings' => array(
								'image'   => array( 'url' => $src ),
								'image_alt' => $alt,
								'caption' => $caption,
							),
							'elements' => array(),
						);
					}
					break;

				case 'a':
					// Convert link to button widget if it looks like a button, otherwise text-editor.
					$href    = $child->getAttribute( 'href' );
					$text    = trim( $child->textContent );
					$classes = $child->getAttribute( 'class' );
					
					if ( ! empty( $href ) && ! empty( $text ) ) {
						// Check if it looks like a button (has button class or is styled like one).
						$is_button = strpos( $classes, 'button' ) !== false || 
						             strpos( $classes, 'btn' ) !== false ||
						             strpos( $text, 'Click' ) !== false ||
						             strpos( $text, 'Learn' ) !== false ||
						             strpos( $text, 'Get' ) !== false ||
						             strpos( $text, 'Buy' ) !== false;

						if ( $is_button ) {
							$element = array(
								'type'     => 'widget',
								'widget'   => 'button',
								'settings' => array(
									'text'         => $text,
									'link'        => array( 'url' => $href ),
									'align'       => 'left',
								),
								'elements' => array(),
							);
						} else {
							// Regular link as text-editor with HTML.
							$element = array(
								'type'     => 'widget',
								'widget'   => 'text-editor',
								'settings' => array(
									'editor' => '<a href="' . esc_url( $href ) . '">' . esc_html( $text ) . '</a>',
								),
								'elements' => array(),
							);
						}
					}
					break;

				case 'button':
					// Convert button to button widget.
					$text = trim( $child->textContent );
					if ( ! empty( $text ) ) {
						$element = array(
							'type'     => 'widget',
							'widget'   => 'button',
							'settings' => array(
								'text'   => $text,
								'align'  => 'left',
							),
							'elements' => array(),
						);
					}
					break;

				case 'ul':
				case 'ol':
					// Convert lists to text-editor widget (Elementor doesn't have a native list widget).
					$list_items = array();
					foreach ( $child->getElementsByTagName( 'li' ) as $li ) {
						$list_items[] = trim( $li->textContent );
					}
					if ( ! empty( $list_items ) ) {
						$list_html = '<' . $tag_name . '>';
						foreach ( $list_items as $item ) {
							$list_html .= '<li>' . esc_html( $item ) . '</li>';
						}
						$list_html .= '</' . $tag_name . '>';
						
						$element = array(
							'type'     => 'widget',
							'widget'   => 'text-editor',
							'settings' => array(
								'editor' => $list_html,
							),
							'elements' => array(),
						);
					}
					break;

				case 'div':
				case 'section':
				case 'article':
					// For container elements, recursively parse children.
					$child_elements = array();
					$this->parse_dom_node( $child, $child_elements );
					
					if ( ! empty( $child_elements ) ) {
						// Wrap children in a section structure.
						// For simplicity, we'll just add the children directly.
						// In a more advanced implementation, we could create proper sections/columns.
						$elements = array_merge( $elements, $child_elements );
					}
					break;

				default:
					// For other elements, extract text content and add as text-editor.
					$content = $this->get_inner_html( $child );
					if ( ! empty( trim( wp_strip_all_tags( $content ) ) ) ) {
						$element = array(
							'type'     => 'widget',
							'widget'   => 'text-editor',
							'settings' => array(
								'editor' => $content,
							),
							'elements' => array(),
						);
					}
					break;
			}

			if ( $element ) {
				$elements[] = $element;
			}
		}
	}

	/**
	 * Get inner HTML of a DOM node.
	 *
	 * @since  1.8.28
	 * @param  DOMNode $node DOM node.
	 * @return string Inner HTML.
	 */
	private function get_inner_html( $node ) {
		$inner_html = '';
		$children   = $node->childNodes;
		
		foreach ( $children as $child ) {
			if ( XML_ELEMENT_NODE === $child->nodeType ) {
				$inner_html .= $node->ownerDocument->saveHTML( $child );
			} elseif ( XML_TEXT_NODE === $child->nodeType ) {
				$inner_html .= $child->textContent;
			}
		}
		
		return $inner_html;
	}

	/**
	 * Get default container settings for Elementor containers.
	 *
	 * @since  1.8.29
	 * @return array Default container settings.
	 */
	protected function get_default_container_settings() {
		return array(
			'content_width'     => 'boxed',
			'flex_direction'    => 'column',
			'flex_align_items'  => 'stretch',
			'padding'           => array(
				'unit'  => 'px',
				'top'   => '0',
				'bottom' => '0',
				'left'   => '0',
				'right'  => '0',
			),
		);
	}

	/**
	 * Wrap widgets in a container element.
	 *
	 * @since  1.8.29
	 * @param  array $widgets Array of widget elements to wrap.
	 * @param  array $container_settings Optional. Container settings. Defaults to default settings.
	 * @return array Container element with widgets as children.
	 */
	protected function wrap_in_container( $widgets, $container_settings = null ) {
		if ( null === $container_settings ) {
			$container_settings = $this->get_default_container_settings();
		}

		// Generate unique container ID.
		$container_id = 'respira_container_' . time() . '_' . substr( md5( wp_json_encode( $widgets ) ), 0, 7 );

		return array(
			'id'       => $container_id,
			'type'     => 'container',
			'settings' => $container_settings,
			'elements' => $widgets,
		);
	}

	/**
	 * Check if structure needs container wrapping.
	 *
	 * @since  1.8.29
	 * @param  array $simplified Simplified structure.
	 * @return bool True if widgets need container wrapping.
	 */
	protected function needs_container_wrapping( $simplified ) {
		if ( empty( $simplified ) || ! is_array( $simplified ) ) {
			return false;
		}

		// Check if top-level elements are containers.
		foreach ( $simplified as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			// If any top-level element is a container, structure is already wrapped.
			if ( isset( $item['type'] ) && 'container' === $item['type'] ) {
				return false;
			}

			// If any top-level element is a widget, it needs wrapping.
			if ( isset( $item['widget'] ) || ( isset( $item['type'] ) && 'widget' === $item['type'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if an array is associative.
	 *
	 * @param array $value Array value.
	 * @return bool
	 */
	private function is_associative_array( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}

		return array_keys( $value ) !== range( 0, count( $value ) - 1 );
	}

	/**
	 * Normalize incoming Elementor payloads to simplified Respira structure.
	 *
	 * Supports:
	 * - { sections: [...] }
	 * - { elements: [...] }
	 * - raw Elementor format using elType/widgetType
	 *
	 * @param mixed $content Incoming content payload.
	 * @return array
	 */
	private function normalize_incoming_content( $content ) {
		if ( ! is_array( $content ) ) {
			return array();
		}

		// Unwrap common object shapes to element list.
		if ( $this->is_associative_array( $content ) ) {
			if ( isset( $content['sections'] ) && is_array( $content['sections'] ) ) {
				$content = $content['sections'];
			} elseif ( isset( $content['elements'] ) && is_array( $content['elements'] ) ) {
				$content = $content['elements'];
			}
		}

		if ( empty( $content ) || ! is_array( $content ) ) {
			return array();
		}

		// Some clients may send object maps instead of numeric arrays.
		if ( $this->is_associative_array( $content ) ) {
			$content = array_values( $content );
		}

		$first = isset( $content[0] ) && is_array( $content[0] ) ? $content[0] : null;
		if ( $first && ( isset( $first['elType'] ) || isset( $first['widgetType'] ) ) ) {
			$content = $this->simplify_structure( $content );
		}

		return is_array( $content ) ? $content : array();
	}

	/**
	 * Convert simplified structure back to Elementor format.
	 *
	 * @since  1.0.0
	 * @param  array $simplified Simplified structure.
	 * @param  bool  $is_root    Whether this is the root conversion call.
	 * @param  int   $depth      Recursion depth guard.
	 * @return array Elementor format.
	 */
	protected function complexify_structure( $simplified, $is_root = true, $depth = 0, &$id_counter = null, &$used_ids = null ) {
		if ( ! is_array( $simplified ) ) {
			return array();
		}

		// Guard against malformed recursive structures.
		if ( $depth > 60 ) {
			return array();
		}

		if ( null === $id_counter ) {
			$id_counter = 0;
		}

		if ( null === $used_ids || ! is_array( $used_ids ) ) {
			$used_ids = array();
		}

		// Safety check: if structure still needs wrapping (shouldn't happen if inject_content worked),
		// wrap it before complexifying. This handles edge cases where complexify_structure is called directly.
		$needs_wrapping = $is_root ? $this->needs_container_wrapping( $simplified ) : false;
		if ( $needs_wrapping ) {
			// Wrap widgets in a container before complexifying.
			$simplified = array( $this->wrap_in_container( $simplified ) );
		}

		$elements = array();

		foreach ( $simplified as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$element_type = $item['type'] ?? 'widget';
			$element = array(
				'id'       => $this->reserve_elementor_id( $item['id'] ?? '', $id_counter, $used_ids ),
				'elType'   => $element_type,
				'settings' => $item['settings'] ?? array(),
				'isInner'  => $item['isInner'] ?? false,
			);

			if ( isset( $item['widget'] ) ) {
				$element['widgetType'] = $item['widget'];
			}

			if ( ! empty( $item['elements'] ) && $this->element_type_supports_children( $element_type ) ) {
				$element['elements'] = $this->complexify_structure( $item['elements'], false, $depth + 1, $id_counter, $used_ids );
			} elseif ( $this->element_type_supports_children( $element_type ) ) {
				$element['elements'] = array();
			}

			$elements[] = $element;
		}

		return $elements;
	}

	/**
	 * Reserve a unique Elementor element ID for the current tree.
	 *
	 * @since 5.2.1
	 * @param mixed $candidate Incoming preferred ID.
	 * @param int   $id_counter Running unique counter.
	 * @param array $used_ids Previously allocated IDs.
	 * @return string
	 */
	private function reserve_elementor_id( $candidate, &$id_counter, &$used_ids ) {
		$candidate = is_string( $candidate ) ? trim( $candidate ) : '';
		if ( '' !== $candidate && ! isset( $used_ids[ $candidate ] ) ) {
			$used_ids[ $candidate ] = true;
			return $candidate;
		}

		do {
			$generated = 'respira_' . substr( md5( microtime( true ) . '|' . ++$id_counter . '|' . wp_rand() ), 0, 8 );
		} while ( isset( $used_ids[ $generated ] ) );

		$used_ids[ $generated ] = true;

		return $generated;
	}

	/**
	 * Determine whether an Elementor element type can own child elements.
	 *
	 * @since 5.2.1
	 * @param string $element_type Simplified Elementor element type.
	 * @return bool
	 */
	private function element_type_supports_children( $element_type ) {
		return in_array( $element_type, array( 'section', 'container', 'column' ), true );
	}

	/**
	 * Find a module/widget by admin_label, path, or type+content match.
	 *
	 * @since 1.8.32
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier: 'admin_label', 'path', or 'type'.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional. Content to match when using type identifier.
	 * @return array|false Module data with path, or false if not found.
	 */
	public function find_module( $structure, $identifier_type, $identifier_value, $match_content = '' ) {
		$path = array();
		return $this->find_module_recursive( $structure, $identifier_type, $identifier_value, $match_content, $path );
	}

	/**
	 * Recursively find a module/widget in the structure.
	 *
	 * @since 1.8.32
	 * @param array  $elements Element structure to search.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional content match.
	 * @param array  $current_path Current path in structure.
	 * @return array|false Module with path or false.
	 */
	private function find_module_recursive( $elements, $identifier_type, $identifier_value, $match_content, $current_path ) {
		if ( ! is_array( $elements ) ) {
			return false;
		}

		foreach ( $elements as $index => $element ) {
			$element_path = array_merge( $current_path, array( $index ) );
			$match = false;

			switch ( $identifier_type ) {
				case 'id':
					$element_id = $element['id'] ?? '';
					if ( (string) $element_id === $identifier_value ) {
						$match = true;
					}
					break;

				case 'admin_label':
					// Elementor: check Navigator label (_title), widget label, CSS ID, and top-level admin_label
					$admin_label = $element['admin_label']
						?? $element['settings']['_title']
						?? $element['settings']['_widget_label']
						?? $element['settings']['admin_label']
						?? '';
					if ( $admin_label === $identifier_value ) {
						$match = true;
					}
					// Also match against CSS ID (_element_id) as fallback
					if ( ! $match && ! empty( $element['settings']['_element_id'] ) && $element['settings']['_element_id'] === $identifier_value ) {
						$match = true;
					}
					break;

				case 'path':
					// Path format: "elements[0].elements[0]", "0.0.1" (dot notation), or array of indices
					if ( is_string( $identifier_value ) ) {
						$path_parts = explode( '.', $identifier_value );
						$path_indices = array();
						foreach ( $path_parts as $part ) {
							if ( preg_match( '/\[(\d+)\]/', $part, $matches ) ) {
								// Bracket notation: "elements[0]"
								$path_indices[] = (int) $matches[1];
							} elseif ( ctype_digit( $part ) ) {
								// Dot notation: "0.0.1"
								$path_indices[] = (int) $part;
							}
						}
						if ( $element_path === $path_indices ) {
							$match = true;
						}
					} elseif ( is_array( $identifier_value ) ) {
						// Direct array of indices
						if ( $element_path === $identifier_value ) {
							$match = true;
						}
					}
					break;

				case 'type':
					// For Elementor, type means widget type (widgetType field)
					$widget_type = $element['widget'] ?? $element['widgetType'] ?? '';
					if ( $widget_type === $identifier_value ) {
						if ( empty( $match_content ) ) {
							$match = true;
						} else {
							// Match content in settings (common fields: title, text, editor, etc.)
							$settings = $element['settings'] ?? array();
							$content_fields = array( 'title', 'text', 'editor', 'html', 'content', 'description' );
							foreach ( $content_fields as $field ) {
								if ( isset( $settings[ $field ] ) && is_string( $settings[ $field ] ) ) {
									if ( strpos( $settings[ $field ], $match_content ) !== false ) {
										$match = true;
										break;
									}
								}
							}
						}
					}
					break;
			}

			if ( $match ) {
				return array(
					'module' => $element,
					'path' => $element_path,
					'path_string' => $this->build_path_string( $element_path ),
				);
			}

			// Search in children (elements array).
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$result = $this->find_module_recursive( $element['elements'], $identifier_type, $identifier_value, $match_content, $element_path );
				if ( $result ) {
					return $result;
				}
			}
		}

		return false;
	}

	/**
	 * Build path string from array indices.
	 *
	 * @since 1.8.32
	 * @param array $path Array of indices.
	 * @return string Path string like "elements[0].elements[0]".
	 */
	private function build_path_string( $path ) {
		if ( empty( $path ) ) {
			return '';
		}

		$parts = array();
		foreach ( $path as $index ) {
			$parts[] = 'elements[' . $index . ']';
		}

		return implode( '.', $parts );
	}

	/**
	 * Update a specific module/widget in the structure.
	 *
	 * @since 1.8.32
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param array  $updates Updates to apply (content, attributes).
	 * @return array|WP_Error Updated structure or error.
	 */
	public function update_module( $structure, $identifier_type, $identifier_value, $updates ) {
		$found = $this->find_module( $structure, $identifier_type, $identifier_value, $updates['match_content'] ?? '' );

		if ( ! $found ) {
			return new WP_Error(
				'respira_module_not_found',
				sprintf(
					/* translators: 1: identifier type, 2: identifier value */
					__( 'Module not found with %1$s: %2$s', 'respira-for-wordpress' ),
					$identifier_type,
					$identifier_value
				),
				array(
					'identifier_type' => $identifier_type,
					'identifier_value' => $identifier_value,
				)
			);
		}

		$path = $found['path'];
		$updated_structure = $structure;

		// Navigate to the module in the structure.
		$current = &$updated_structure;
		$path_length = count( $path );
		foreach ( $path as $path_index => $index ) {
			if ( ! isset( $current[ $index ] ) ) {
				return new WP_Error(
					'respira_module_path_invalid',
					__( 'Invalid module path in structure', 'respira-for-wordpress' ),
					array( 'path' => $path )
				);
			}
			
			// If not the last index, navigate into children.
			if ( $path_index < $path_length - 1 ) {
				$current = &$current[ $index ];
				// Navigate to elements if they exist.
				if ( isset( $current['elements'] ) && is_array( $current['elements'] ) ) {
					$current = &$current['elements'];
				} else {
					// Create elements array if it doesn't exist (shouldn't happen normally).
					$current['elements'] = array();
					$current = &$current['elements'];
				}
			} else {
				// Last index - this is the target module.
				$current = &$current[ $index ];
			}
		}

		// Apply updates.
		// For Elementor, content updates go into settings (e.g., settings['editor'] for text-editor)
		if ( isset( $updates['content'] ) ) {
			// Try to determine the appropriate settings field based on widget type
			$widget_type = $current['widget'] ?? $current['widgetType'] ?? '';
			$settings = $current['settings'] ?? array();
			
			// Map common widget types to their content fields
			$content_field_map = array(
				'text-editor' => 'editor',
				'heading' => 'title',
				'html' => 'html',
				'icon-box' => 'description_text',
				'icon-list' => 'icon_list',
			);
			
			$content_field = $content_field_map[ $widget_type ] ?? 'editor';
			$settings[ $content_field ] = $this->normalize_text_setting_value( $updates['content'] );
			$current['settings'] = $settings;
		}

		// Apply attribute updates (merge into settings).
		if ( isset( $updates['attributes'] ) && is_array( $updates['attributes'] ) ) {
			$settings = $current['settings'] ?? array();
			$normalized_attributes = $this->normalize_attribute_updates( $updates['attributes'] );
			$current['settings'] = array_merge( $settings, $normalized_attributes );
		}

		return $updated_structure;
	}

	/**
	 * Normalize text-like widget setting values to strings.
	 *
	 * Prevents Elementor internals from receiving arrays for controls that
	 * are expected to be scalar strings (a common cause of ltrim() type errors).
	 *
	 * @since 4.0.4
	 * @param mixed $value Incoming value.
	 * @return string
	 */
	private function normalize_text_setting_value( $value ) {
		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_bool( $value ) || is_numeric( $value ) ) {
			return (string) $value;
		}

		if ( is_array( $value ) ) {
			// Common wrapper forms from clients: [ "<html>" ] or { editor: "<html>" }.
			foreach ( array( 'editor', 'text', 'title', 'html', 'content', 'description' ) as $key ) {
				if ( isset( $value[ $key ] ) && ( is_string( $value[ $key ] ) || is_numeric( $value[ $key ] ) ) ) {
					return (string) $value[ $key ];
				}
			}

			if ( 1 === count( $value ) ) {
				return $this->normalize_text_setting_value( reset( $value ) );
			}

			$parts = array();
			foreach ( $value as $item ) {
				if ( is_string( $item ) || is_numeric( $item ) ) {
					$parts[] = (string) $item;
				}
			}
			if ( ! empty( $parts ) ) {
				return implode( "\n", $parts );
			}

			$json = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return is_string( $json ) ? $json : '';
		}

		return '';
	}

	/**
	 * Normalize risky attribute updates before merging with widget settings.
	 *
	 * @since 4.0.4
	 * @param array $attributes Incoming attribute updates.
	 * @return array
	 */
	private function normalize_attribute_updates( $attributes ) {
		$text_like_keys = array(
			'title',
			'text',
			'editor',
			'html',
			'content',
			'description',
			'description_text',
			'button_text',
			'caption',
			'subtitle',
		);

		foreach ( $attributes as $key => $value ) {
			if ( in_array( $key, $text_like_keys, true ) ) {
				$attributes[ $key ] = $this->normalize_text_setting_value( $value );
				continue;
			}

			// Elementor color controls expect scalar values. Prevent array payloads
			// from bubbling into internal sanitizers (ltrim() type errors).
			if ( is_string( $key ) && false !== strpos( $key, 'color' ) && is_array( $value ) ) {
				$coerced = $this->normalize_text_setting_value( $value );
				$attributes[ $key ] = '' !== $coerced ? $coerced : '';
			}
		}

		return $attributes;
	}
}
