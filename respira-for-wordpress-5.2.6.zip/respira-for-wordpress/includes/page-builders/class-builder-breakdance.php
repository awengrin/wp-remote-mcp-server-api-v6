<?php
/**
 * Breakdance page builder implementation.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 * @since      2.0.0
 */

/**
 * Breakdance builder class.
 *
 * Supports Breakdance, a modern performance-focused WordPress page builder
 * released in 2022 with 130+ elements, themeless mode, and deep dynamic
 * data integration.
 *
 * @since 2.0.0
 */
class Respira_Builder_Breakdance extends Respira_Builder_Interface {

	/**
	 * Detect if Breakdance is active.
	 *
	 * Uses multiple fallbacks for different versions and load orders.
	 *
	 * @since 2.0.0
	 * @return bool True if Breakdance is active.
	 */
	public function detect() {
		// Runtime symbols — available when Breakdance's bootstrap has run.
		if (
			defined( 'BREAKDANCE_PLUGIN_VERSION' )
			|| class_exists( 'Breakdance\\Plugin' )
			|| class_exists( 'Breakdance_Plugin' )
			|| function_exists( 'breakdance_init' )
			|| function_exists( 'breakdance_autoloader' )
		) {
			return true;
		}

		// Filesystem fallback — catches deferred-bootstrap versions (e.g. 2.6+)
		// where the constant/class may not yet exist at the hook priority
		// when Respira's detection runs.
		$active_plugins = (array) get_option( 'active_plugins', array() );
		if ( in_array( 'breakdance/plugin.php', $active_plugins, true ) ) {
			return true;
		}

		// Multisite network-activated check.
		if ( is_multisite() ) {
			$network_plugins = array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) );
			if ( in_array( 'breakdance/plugin.php', $network_plugins, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get builder name.
	 *
	 * @since 2.0.0
	 * @return string Builder name.
	 */
	public function get_name() {
		return 'Breakdance';
	}

	/**
	 * Get builder version.
	 *
	 * @since 2.0.0
	 * @return string Builder version.
	 */
	public function get_version() {
		if ( defined( 'BREAKDANCE_PLUGIN_VERSION' ) ) {
			return BREAKDANCE_PLUGIN_VERSION;
		}

		// Fallback: read from plugin file header.
		if ( function_exists( 'get_plugin_data' ) && defined( 'WP_PLUGIN_DIR' ) ) {
			$plugin_file = WP_PLUGIN_DIR . '/breakdance/plugin.php';
			if ( file_exists( $plugin_file ) ) {
				$data = get_plugin_data( $plugin_file, false, false );
				return $data['Version'] ?? 'unknown';
			}
		}

		return 'unknown';
	}

	/**
	 * Check if post uses Breakdance.
	 *
	 * @since 2.0.0
	 * @param int $post_id Post ID.
	 * @return bool True if uses Breakdance.
	 */
	public function is_builder_used( $post_id ) {
		$data = get_post_meta( $post_id, '_breakdance_data', true );
		return ! empty( $data );
	}

	/**
	 * Extract content from post.
	 *
	 * Traverses Breakdance's JSON tree structure and returns a simplified
	 * element list for AI consumption.
	 *
	 * @since 2.0.0
	 * @param int $post_id Post ID.
	 * @return array Extracted elements.
	 */
	public function extract_content( $post_id ) {
		$start = microtime( true );

		$raw = get_post_meta( $post_id, '_breakdance_data', true );

		if ( empty( $raw ) ) {
			return array();
		}

		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) ) {
			return array();
		}

		$children = $data['tree']['children'] ?? array();
		$result   = $this->simplify_structure( $children );

		$this->log_performance( 'extract', $post_id, microtime( true ) - $start );

		return $result;
	}

	/**
	 * Inject content into post.
	 *
	 * Converts simplified AI content back to Breakdance format and saves it,
	 * then clears the CSS cache so changes are visible immediately.
	 *
	 * @since 2.0.0
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified content from AI.
	 * @return bool|WP_Error True on success.
	 */
	public function inject_content( $post_id, $content, $skip_structure_validation = false ) {
		$start = microtime( true );

		$raw = get_post_meta( $post_id, '_breakdance_data', true );

		if ( empty( $raw ) ) {
			$this->log_performance( 'inject', $post_id, microtime( true ) - $start );
			return new WP_Error(
				'breakdance_no_data',
				__( 'No Breakdance data found for this post.', 'respira-for-wordpress' )
			);
		}

		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) ) {
			$this->log_performance( 'inject', $post_id, microtime( true ) - $start );
			return new WP_Error(
				'breakdance_invalid_json',
				__( 'Breakdance data is not valid JSON.', 'respira-for-wordpress' )
			);
		}

		// Replace children with complexified content.
		$data['tree']['children'] = $this->complexify_structure( $content );

		// Save back.
		update_post_meta( $post_id, '_breakdance_data', wp_json_encode( $data ) );

		// Clear Breakdance's static CSS cache.
		$this->clear_css_cache( $post_id );

		$this->log_performance( 'inject', $post_id, microtime( true ) - $start );

		return true;
	}

	/**
	 * Create a code block element with custom HTML/CSS/JS.
	 *
	 * Uses Breakdance's Code Block element as the official injection point.
	 * Finds an existing Respira-managed block or creates a new one.
	 *
	 * @since 2.0.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     Optional. CSS content.
	 * @param string $js      Optional. JavaScript content.
	 * @return bool|WP_Error True on success.
	 */
	public function create_code_block( $post_id, $html, $css = '', $js = '' ) {
		$raw = get_post_meta( $post_id, '_breakdance_data', true );

		if ( empty( $raw ) ) {
			return new WP_Error(
				'breakdance_no_data',
				__( 'No Breakdance data found for this post.', 'respira-for-wordpress' )
			);
		}

		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) ) {
			return new WP_Error(
				'breakdance_invalid_json',
				__( 'Breakdance data is not valid JSON.', 'respira-for-wordpress' )
			);
		}

		// Combine CSS into the HTML payload using <style> tag.
		$combined_html = $html;
		if ( ! empty( $css ) ) {
			$combined_html .= "\n<style>\n" . $css . "\n</style>";
		}
		if ( ! empty( $js ) ) {
			$combined_html .= "\n<script>\n" . $js . "\n</script>";
		}

		// Search for existing Respira-managed Code Block.
		$found = false;
		if ( isset( $data['tree']['children'] ) && is_array( $data['tree']['children'] ) ) {
			foreach ( $data['tree']['children'] as &$element ) {
				if (
					isset( $element['data']['respiraManaged'] ) &&
					true === $element['data']['respiraManaged']
				) {
					// Update existing block.
					$element['data']['html'] = $combined_html;
					$found = true;
					break;
				}
			}
			unset( $element );
		}

		if ( ! $found ) {
			// Create a new Code Block element at the end of the tree.
			$code_block = array(
				'id'       => 'respira-' . uniqid(),
				'type'     => 'EssentialElements\\CodeBlock',
				'data'     => array(
					'respiraManaged' => true,
					'html'           => $combined_html,
					'customCss'      => $css,
				),
				'children' => array(),
			);

			if ( ! isset( $data['tree']['children'] ) ) {
				$data['tree']['children'] = array();
			}

			$data['tree']['children'][] = $code_block;
		}

		// Save back.
		update_post_meta( $post_id, '_breakdance_data', wp_json_encode( $data ) );

		// Clear CSS cache.
		$this->clear_css_cache( $post_id );

		return true;
	}

	/**
	 * Get documentation for AI context.
	 *
	 * @since 2.0.0
	 * @return array Documentation.
	 */
	public function get_documentation() {
		return array(
			'name'        => 'Breakdance',
			'description' => 'Modern, performance-focused WordPress page builder (released 2022) with 130+ elements',
			'overview'    => 'Breakdance stores builder data as JSON in the _breakdance_data post meta key. It features a tree-based element structure, a Code Block element for custom CSS/HTML/JS, Global Blocks for reusable components, and a Post Loop Builder for dynamic content. It has deep integration with ACF, Meta Box, and WooCommerce.',
			'themeless'   => $this->is_themeless_mode(),
			'structure'   => array(
				'root'     => '_breakdance_data post meta (JSON)',
				'tree'     => '$data["tree"]["children"] — array of top-level elements',
				'element'  => array(
					'id'       => 'Unique element ID (e.g. "respira-abc123")',
					'type'     => 'Element type (e.g. "EssentialElements\\\\CodeBlock")',
					'data'     => 'Element-specific settings',
					'children' => 'Nested elements',
				),
			),
			'selectors'   => array(
				'container'   => '.breakdance',
				'section'     => '.bde-section',
				'column'      => '.bde-column',
				'div'         => '.bde-div',
				'any_element' => '[class*="bde-"]',
				'heading'     => '.bde-heading',
				'text'        => '.bde-text, .bde-rich-text',
				'button'      => '.bde-button',
				'image'       => '.bde-image',
				'video'       => '.bde-video',
				'code_block'  => '.bde-code-block',
				'post_loop'   => '.bde-post-loop-builder',
				'global_block' => '.bde-global-block',
				'form'        => '.bde-form-builder',
				'pattern_note' => 'Specific elements: .breakdance .bde-{type}-{unique-id}',
			),
			'capabilities' => array(
				'global_blocks'       => true,
				'post_loop_builder'   => true,
				'element_studio'      => true,
				'dynamic_data'        => true,
				'conditional_logic'   => true,
				'custom_code'         => true,
				'acf_integration'     => class_exists( 'ACF' ) || function_exists( 'acf_add_local_field_group' ),
				'metabox_integration' => class_exists( 'RWMB_Loader' ),
				'woocommerce'         => class_exists( 'WooCommerce' ),
			),
			'notes'        => array(
				'Breakdance uses Twig templating internally',
				'CSS is cached statically — cache is automatically cleared after Respira edits',
				'Global Blocks are shared across pages — CSS targeting them affects all instances',
				'Element Studio custom elements follow the pattern: .bde-custom-{name}-{id}',
				'Themeless mode means Breakdance replaces the active WordPress theme entirely',
				'The Code Block element is the official, safe way to inject custom CSS/HTML/JS',
				'Only the respiraManaged Code Block is modified — the rest of the tree is untouched',
			),
			'resources'    => array(
				'https://breakdance.com/documentation/',
				'https://wordpress.org/plugins/breakdance/',
			),
		);
	}

	/**
	 * Get available modules/elements.
	 *
	 * @since 2.0.0
	 * @return array Available Breakdance elements.
	 */
	public function get_available_modules() {
		return array(
			// Basic elements.
			array( 'name' => 'Section',      'title' => 'Section',      'description' => 'Full-width layout section',           'category' => 'layout' ),
			array( 'name' => 'Columns',      'title' => 'Columns',      'description' => 'Multi-column layout container',       'category' => 'layout' ),
			array( 'name' => 'Div',          'title' => 'Div',          'description' => 'Generic container div',               'category' => 'layout' ),
			array( 'name' => 'Heading',      'title' => 'Heading',      'description' => 'h1–h6 heading element',               'category' => 'basic' ),
			array( 'name' => 'Text',         'title' => 'Text',         'description' => 'Plain text element',                  'category' => 'basic' ),
			array( 'name' => 'RichText',     'title' => 'Rich Text',    'description' => 'Formatted text with HTML',            'category' => 'basic' ),
			array( 'name' => 'TextLink',     'title' => 'Text Link',    'description' => 'Inline text hyperlink',               'category' => 'basic' ),
			array( 'name' => 'Button',       'title' => 'Button',       'description' => 'Clickable button element',            'category' => 'basic' ),
			array( 'name' => 'Image',        'title' => 'Image',        'description' => 'Image element with lazy loading',     'category' => 'basic' ),
			array( 'name' => 'Video',        'title' => 'Video',        'description' => 'Video embed element',                 'category' => 'basic' ),
			array( 'name' => 'Icon',         'title' => 'Icon',         'description' => 'SVG icon element',                   'category' => 'basic' ),
			array( 'name' => 'Spacer',       'title' => 'Spacer',       'description' => 'Whitespace spacer',                  'category' => 'basic' ),
			array( 'name' => 'Divider',      'title' => 'Divider',      'description' => 'Horizontal rule / divider',          'category' => 'basic' ),
			// Design elements.
			array( 'name' => 'IconBox',      'title' => 'Icon Box',     'description' => 'Icon + text combination',            'category' => 'design' ),
			array( 'name' => 'ImageBox',     'title' => 'Image Box',    'description' => 'Image + text combination',           'category' => 'design' ),
			array( 'name' => 'PricingTable', 'title' => 'Pricing Table','description' => 'Pricing plan display',               'category' => 'design' ),
			array( 'name' => 'Testimonial',  'title' => 'Testimonial',  'description' => 'Customer testimonial element',       'category' => 'design' ),
			array( 'name' => 'Gallery',      'title' => 'Gallery',      'description' => 'Image gallery',                      'category' => 'design' ),
			array( 'name' => 'Slider',       'title' => 'Slider',       'description' => 'Image/content slider',               'category' => 'design' ),
			array( 'name' => 'Tabs',         'title' => 'Tabs',         'description' => 'Tabbed content container',           'category' => 'design' ),
			array( 'name' => 'Accordion',    'title' => 'Accordion',    'description' => 'Collapsible content sections',       'category' => 'design' ),
			array( 'name' => 'Counter',      'title' => 'Counter',      'description' => 'Animated number counter',            'category' => 'design' ),
			array( 'name' => 'ProgressBar',  'title' => 'Progress Bar', 'description' => 'Progress / skill bar',               'category' => 'design' ),
			array( 'name' => 'SocialIcons',  'title' => 'Social Icons', 'description' => 'Social media icon links',            'category' => 'design' ),
			array( 'name' => 'Map',          'title' => 'Map',          'description' => 'Google Maps embed',                  'category' => 'design' ),
			// Dynamic elements.
			array( 'name' => 'PostLoopBuilder',  'title' => 'Post Loop Builder',   'description' => 'Dynamic loop for posts/CPTs',        'category' => 'dynamic' ),
			array( 'name' => 'PostTitle',        'title' => 'Post Title',          'description' => 'Dynamic current post title',         'category' => 'dynamic' ),
			array( 'name' => 'PostContent',      'title' => 'Post Content',        'description' => 'Dynamic current post content',       'category' => 'dynamic' ),
			array( 'name' => 'PostMeta',         'title' => 'Post Meta',           'description' => 'Dynamic post meta field',            'category' => 'dynamic' ),
			array( 'name' => 'PostFeaturedImage','title' => 'Post Featured Image', 'description' => 'Dynamic featured image',             'category' => 'dynamic' ),
			array( 'name' => 'GlobalBlock',      'title' => 'Global Block',        'description' => 'Reusable component across pages',    'category' => 'dynamic' ),
			// Form elements.
			array( 'name' => 'FormBuilder',      'title' => 'Form Builder',    'description' => 'Custom form builder',        'category' => 'forms' ),
			array( 'name' => 'LoginForm',        'title' => 'Login Form',      'description' => 'WordPress login form',       'category' => 'forms' ),
			array( 'name' => 'RegisterForm',     'title' => 'Register Form',   'description' => 'User registration form',     'category' => 'forms' ),
			array( 'name' => 'ForgotPassword',   'title' => 'Forgot Password', 'description' => 'Password reset form',       'category' => 'forms' ),
			// WooCommerce elements.
			array( 'name' => 'WooProduct',       'title' => 'Product',         'description' => 'WooCommerce product display','category' => 'woo' ),
			array( 'name' => 'WooCart',          'title' => 'Cart',            'description' => 'WooCommerce cart',           'category' => 'woo' ),
			array( 'name' => 'WooCheckout',      'title' => 'Checkout',        'description' => 'WooCommerce checkout',       'category' => 'woo' ),
			array( 'name' => 'WooProductLoop',   'title' => 'Product Loop',    'description' => 'WooCommerce product loop',   'category' => 'woo' ),
			// Advanced elements.
			array( 'name' => 'CodeBlock',        'title' => 'Code Block',      'description' => 'Custom HTML/CSS/JS/PHP',     'category' => 'advanced' ),
			array( 'name' => 'CustomElement',    'title' => 'Custom Element',  'description' => 'Element Studio custom element', 'category' => 'advanced' ),
			array( 'name' => 'PopupBuilder',     'title' => 'Popup Builder',   'description' => 'Popup / modal builder',      'category' => 'advanced' ),
		);
	}

	/**
	 * Get builder schema for AI context.
	 *
	 * @since 2.0.0
	 * @param array $elements_used Optional. Array of element names used on the page.
	 * @return array Builder schema.
	 */
	public function get_builder_schema( $elements_used = array() ) {
		return array(
			'builder'         => 'breakdance',
			'builder_version' => $this->get_version(),
			'themeless_mode'  => $this->is_themeless_mode(),
			'elements'        => $this->get_available_modules(),
			'quick_reference' => array(
				'colors'   => 'Use hex format: #0000FF',
				'spacing'  => 'Format: 10px 20px 10px 20px (top right bottom left)',
				'sizing'   => 'Use px, em, %, vh, or vw',
				'selector' => 'Pattern: .breakdance .bde-{type}-{unique-id}',
			),
		);
	}

	/**
	 * Check if Breakdance is running in themeless mode.
	 *
	 * In themeless mode Breakdance replaces the active WordPress theme entirely.
	 *
	 * @since 2.0.0
	 * @return bool True if themeless mode is enabled.
	 */
	public function is_themeless_mode() {
		$settings = get_option( 'breakdance_settings', array() );
		return ! empty( $settings['disable_theme'] );
	}

	/**
	 * Simplify Breakdance tree for AI consumption.
	 *
	 * @since  2.0.0
	 * @param  array $elements Breakdance tree children array.
	 * @return array Simplified structure.
	 */
	protected function simplify_structure( $elements ) {
		if ( ! is_array( $elements ) ) {
			return array();
		}

		return array_map(
			function( $element ) {
				$type     = $element['type'] ?? 'unknown';
				$data     = $element['data'] ?? array();
				$children = $element['children'] ?? array();

				return array(
					'id'         => $element['id'] ?? '',
					'type'       => $type,
					'attributes' => $data,
					'children'   => $this->simplify_structure( $children ),
				);
			},
			$elements
		);
	}

	/**
	 * Convert simplified AI structure back to Breakdance element format.
	 *
	 * @since  2.0.0
	 * @param  array $simplified Simplified structure.
	 * @return array Breakdance format.
	 */
	protected function complexify_structure( $simplified ) {
		if ( ! is_array( $simplified ) ) {
			return array();
		}

		return array_map(
			function( $item ) {
				return array(
					'id'       => $item['id'] ?? uniqid( 'bde-' ),
					'type'     => $item['type'] ?? 'EssentialElements\\Text',
					'data'     => $item['attributes'] ?? array(),
					'children' => $this->complexify_structure( $item['children'] ?? array() ),
				);
			},
			$simplified
		);
	}

	/**
	 * Clear Breakdance CSS cache for a specific post.
	 *
	 * Breakdance caches generated CSS aggressively. This ensures changes
	 * injected by Respira are reflected on the next page load.
	 *
	 * @since 2.0.0
	 * @param int $post_id Post ID.
	 */
	private function clear_css_cache( $post_id ) {
		// Delete per-post CSS cache meta.
		delete_post_meta( $post_id, '_breakdance_css_cache' );

		// Clear object cache entry if an object cache plugin is active.
		wp_cache_delete( "breakdance_css_{$post_id}", 'breakdance' );

		// Trigger Breakdance's own cache regeneration hook.
		do_action( 'breakdance_clear_cache', $post_id );
	}
}
