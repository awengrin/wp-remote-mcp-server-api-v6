<?php
/**
 * Page builder interface and factory.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 */

/**
 * Page builder interface.
 *
 * All page builder implementations must implement this interface.
 *
 * @since 1.0.0
 */
abstract class Respira_Builder_Interface {

	/**
	 * Detect if this builder is active on the site.
	 *
	 * @since 1.0.0
	 * @return bool True if builder is active.
	 */
	abstract public function detect();

	/**
	 * Get the builder name.
	 *
	 * @since 1.0.0
	 * @return string Builder name.
	 */
	abstract public function get_name();

	/**
	 * Get the builder version.
	 *
	 * @since 1.0.0
	 * @return string Builder version.
	 */
	abstract public function get_version();

	/**
	 * Extract content from a post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array Extracted content in simplified format.
	 */
	abstract public function extract_content( $post_id );

	/**
	 * Inject content into a post.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Post ID.
	 * @param array $content Content to inject.
	 * @param bool  $skip_structure_validation Optional. Skip structural validation for module-level updates.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	abstract public function inject_content( $post_id, $content, $skip_structure_validation = false );

	/**
	 * Create a code block in the builder.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     Optional. CSS content.
	 * @param string $js      Optional. JavaScript content.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	abstract public function create_code_block( $post_id, $html, $css = '', $js = '' );

	/**
	 * Get builder documentation for AI.
	 *
	 * @since 1.0.0
	 * @return array Documentation array.
	 */
	abstract public function get_documentation();

	/**
	 * Get available modules/widgets/blocks.
	 *
	 * @since 1.0.0
	 * @return array Available modules.
	 */
	abstract public function get_available_modules();

	/**
	 * Get builder schema for AI context.
	 *
	 * @since  1.3.0
	 * @param  array $modules_used Optional. Array of module names used on the page.
	 * @return array Builder schema with module information.
	 */
	public function get_builder_schema( $modules_used = array() ) {
		// Default implementation - can be overridden.
		return array(
			'builder'          => $this->get_name(),
			'builder_version'  => $this->get_version(),
			'available_modules' => $this->get_available_modules(),
			'quick_reference'  => array(
				'colors'  => __( 'Use hex format: #0000FF', 'respira-for-wordpress' ),
				'spacing' => __( 'Format: 10px|20px|10px|20px (top|right|bottom|left)', 'respira-for-wordpress' ),
				'sizing'  => __( 'Use px, em, %, or vw', 'respira-for-wordpress' ),
				'fonts'   => __( 'Font names from Google Fonts or system fonts', 'respira-for-wordpress' ),
			),
		);
	}

	/**
	 * Check if intelligence is available for this builder.
	 *
	 * @since  1.3.0
	 * @return bool True if intelligence package is available.
	 */
	public function is_intelligence_available() {
		$builder_name = strtolower( $this->get_name() );
		$loader_path  = RESPIRA_PLUGIN_DIR . 'includes/' . $builder_name . '-intelligence/class-' . $builder_name . '-intelligence-loader.php';

		return file_exists( $loader_path );
	}

	/**
	 * Detect which builder is used on a specific post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Optional. Post ID to check. If not provided, checks globally.
	 * @return Respira_Builder_Interface|null Builder instance or null.
	 */
	public static function detect_builder( $post_id = null ) {
		$builders = self::get_available_builders();
		$matches  = array();

		foreach ( $builders as $builder_class ) {
			$builder = new $builder_class();

			if ( $builder->detect() ) {
				// If checking specific post, verify it uses this builder.
				if ( $post_id ) {
					if ( $builder->is_builder_used( $post_id ) ) {
						$matches[] = $builder;
					}
				} else {
					$matches[] = $builder;
				}
			}
		}

		if ( empty( $matches ) ) {
			return null;
		}

		if ( 1 === count( $matches ) ) {
			return $matches[0];
		}

		// Theme signal is a high-confidence tie breaker for Divi.
		if ( function_exists( 'wp_get_theme' ) ) {
			$theme          = wp_get_theme();
			$theme_name     = strtolower( (string) $theme->get( 'Name' ) );
			$theme_template = strtolower( (string) $theme->get_template() );

			if ( 'divi' === $theme_name || 'divi' === $theme_template ) {
				foreach ( $matches as $builder ) {
					if ( 'Divi' === $builder->get_name() ) {
						return $builder;
					}
				}
			}
		}

		// Prefer builder-specific matches over Gutenberg when multiple match.
		foreach ( $matches as $builder ) {
			if ( 'Gutenberg' !== $builder->get_name() ) {
				return $builder;
			}
		}

		return $matches[0];
	}

	/**
	 * Get a builder instance by name.
	 *
	 * @since 1.0.0
	 * @param string $name Builder name.
	 * @return Respira_Builder_Interface|WP_Error Builder instance or error.
	 */
	public static function get_builder( $name ) {
		$builders = self::get_available_builders();

		// Normalize slug: replace underscores/hyphens with spaces for comparison.
		$normalized_name = strtolower( str_replace( array( '_', '-' ), ' ', $name ) );
		// Also create a compact version with no spaces for partial matching.
		$compact_name = str_replace( ' ', '', $normalized_name );

		foreach ( $builders as $builder_class ) {
			$builder = new $builder_class();

			$builder_name_lower  = strtolower( $builder->get_name() );
			$builder_name_compact = str_replace( ' ', '', $builder_name_lower );

			// Match: exact name, normalized name, compact name, or first-word match.
			// This handles "beaver" → "Beaver Builder", "visual-composer" → "Visual Composer", etc.
			$matched = $builder_name_lower === strtolower( $name )
				|| $builder_name_lower === $normalized_name
				|| $builder_name_compact === $compact_name
				|| ( strpos( $builder_name_lower, $normalized_name . ' ' ) === 0 );

			if ( $matched ) {
				if ( ! $builder->detect() ) {
					return new WP_Error(
						'respira_builder_not_active',
						sprintf(
							/* translators: %s: builder name */
							__( '%s is not active on this site.', 'respira-for-wordpress' ),
							$builder->get_name()
						)
					);
				}

				return $builder;
			}
		}

		return new WP_Error(
			'respira_builder_not_found',
			sprintf(
				/* translators: %s: builder name */
				__( 'Builder "%s" not supported. Use exactly: gutenberg, divi, elementor, bricks, beaver, oxygen, breakdance, brizy, thrive, visual-composer, wpbakery.', 'respira-for-wordpress' ),
				$name
			)
		);
	}

	/**
	 * Get all available builder classes.
	 *
	 * @since 1.0.0
	 * @return array Builder class names.
	 */
	private static function get_available_builders() {
		return array(
			'Respira_Builder_Divi',
			'Respira_Builder_Elementor',
			'Respira_Builder_WPBakery',
			'Respira_Builder_Oxygen',
			'Respira_Builder_Bricks',
			'Respira_Builder_Beaver',
			'Respira_Builder_Brizy',
			'Respira_Builder_Visual_Composer',
			'Respira_Builder_Thrive',
			'Respira_Builder_Breakdance',
			'Respira_Builder_Gutenberg',
		);
	}

	/**
	 * Check if this builder is used on a specific post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return bool True if builder is used.
	 */
	public function is_builder_used( $post_id ) {
		// Default implementation - can be overridden.
		return false;
	}

	/**
	 * Helper method to simplify block/module structure for AI.
	 *
	 * @since  1.0.0
	 * @param  array $builder_data Raw builder data.
	 * @return array Simplified structure.
	 */
	protected function simplify_structure( $builder_data ) {
		// To be implemented by each builder.
		return $builder_data;
	}

	/**
	 * Helper method to convert simplified structure back to builder format.
	 *
	 * @since  1.0.0
	 * @param  array $simplified_data Simplified data from AI.
	 * @return array Builder-specific format.
	 */
	protected function complexify_structure( $simplified_data ) {
		// To be implemented by each builder.
		return $simplified_data;
	}

	// =========================================================================
	// Element-level operations (WS1 — Elemental v5.2.0)
	//
	// Default implementations use the tree utility. Builders that use
	// different children/attribute keys should override get_children_key(),
	// get_attributes_key(), and get_id_key().
	// =========================================================================

	/**
	 * Get the key used for child elements in the simplified structure.
	 *
	 * Override in builders that use a different key.
	 *
	 * @since 5.2.0
	 * @return string Children key name.
	 */
	public function get_children_key() {
		return 'children';
	}

	/**
	 * Get the key used for element attributes/settings in the simplified structure.
	 *
	 * @since 5.2.0
	 * @return string Attributes key name.
	 */
	public function get_attributes_key() {
		return 'attributes';
	}

	/**
	 * Get the key used for element IDs in the simplified structure.
	 *
	 * @since 5.2.0
	 * @return string|null ID key name, or null if builder has no IDs.
	 */
	public function get_id_key() {
		return null;
	}

	/**
	 * Find an element in a post's builder content.
	 *
	 * @since 5.2.0
	 * @param int         $post_id          Post ID.
	 * @param string      $identifier_type  How to identify: 'id', 'admin_label', 'path', 'type'.
	 * @param string      $identifier_value Value to search for.
	 * @param string|null $match_content    Optional content match for 'type' searches.
	 * @return array|WP_Error Found element with '_path', or WP_Error.
	 */
	public function find_element( $post_id, $identifier_type, $identifier_value, $match_content = null ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}
		if ( empty( $content ) ) {
			return new WP_Error( 'respira_no_content', 'Post has no builder content.' );
		}

		if ( 'path' === $identifier_type ) {
			$path    = array_map( 'intval', explode( '.', $identifier_value ) );
			$element = Respira_Builder_Tree_Utility::get_at( $content, $path, $this->get_children_key() );
			if ( null === $element ) {
				return new WP_Error( 'respira_element_not_found', 'No element found at path ' . $identifier_value, array( 'status' => 404 ) );
			}
			$element['_path'] = $path;
			return $element;
		}

		$found = Respira_Builder_Tree_Utility::find(
			$content,
			$identifier_type,
			$identifier_value,
			$this->get_children_key(),
			$match_content
		);

		if ( null === $found ) {
			return new WP_Error(
				'respira_element_not_found',
				sprintf( 'No element found with %s "%s".', $identifier_type, $identifier_value ),
				array( 'status' => 404 )
			);
		}

		return $found;
	}

	/**
	 * Update an element's attributes in a post's builder content.
	 *
	 * @since 5.2.0
	 * @param int    $post_id          Post ID.
	 * @param string $identifier_type  How to identify the element.
	 * @param string $identifier_value Value to search for.
	 * @param array  $updates          Key-value pairs to merge into the element.
	 * @return array|WP_Error Updated element, or WP_Error.
	 */
	public function update_element( $post_id, $identifier_type, $identifier_value, array $updates ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}
		if ( empty( $content ) ) {
			return new WP_Error( 'respira_no_content', 'Post has no builder content.' );
		}

		$found = $this->find_element( $post_id, $identifier_type, $identifier_value );
		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$path        = $found['_path'];
		$children_key = $this->get_children_key();
		$new_tree    = Respira_Builder_Tree_Utility::update_at( $content, $path, $updates, $children_key );

		// Skip structure validation — content came from extract_content() (already valid)
		// and only targeted modifications were applied. Same rationale as update_module.
		$result = $this->inject_content( $post_id, $new_tree, true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return Respira_Builder_Tree_Utility::get_at( $new_tree, $path, $children_key );
	}

	/**
	 * Move an element to a new container and position.
	 *
	 * @since 5.2.0
	 * @param int    $post_id              Post ID.
	 * @param string $element_id_type      Identifier type for the element.
	 * @param string $element_id_value     Identifier value.
	 * @param array  $target_container_path Path to target container (e.g. [0, 1]).
	 * @param int    $position             Position in container. -1 = append.
	 * @return true|WP_Error True on success.
	 */
	public function move_element( $post_id, $element_id_type, $element_id_value, array $target_container_path, $position = -1 ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		$found = $this->find_element( $post_id, $element_id_type, $element_id_value );
		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$path         = $found['_path'];
		$children_key = $this->get_children_key();
		$element      = $found;
		unset( $element['_path'] );

		// Remove from old position.
		$tree = Respira_Builder_Tree_Utility::remove( $content, $path, $children_key );

		// Insert at new position.
		$tree = Respira_Builder_Tree_Utility::insert( $tree, $target_container_path, $element, $position, $children_key );

		// Skip validation — round-trip from extract_content.
		$result = $this->inject_content( $post_id, $tree, true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}

	/**
	 * Duplicate an element (insert clone after original).
	 *
	 * @since 5.2.0
	 * @param int    $post_id      Post ID.
	 * @param string $id_type      Identifier type.
	 * @param string $id_value     Identifier value.
	 * @return array|WP_Error The cloned element, or WP_Error.
	 */
	public function duplicate_element( $post_id, $id_type, $id_value ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		$found = $this->find_element( $post_id, $id_type, $id_value );
		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$path         = $found['_path'];
		$children_key = $this->get_children_key();
		$element      = $found;
		unset( $element['_path'] );

		$cloned = Respira_Builder_Tree_Utility::clone_with_new_ids( $element, $children_key, $this->get_id_key() );

		// Insert after the original: same parent, position + 1.
		$parent_path = array_slice( $path, 0, -1 );
		$insert_pos  = end( $path ) + 1;

		$tree   = Respira_Builder_Tree_Utility::insert( $content, $parent_path, $cloned, $insert_pos, $children_key );
		// Skip validation — round-trip from extract_content.
		$result = $this->inject_content( $post_id, $tree, true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $cloned;
	}

	/**
	 * Remove an element from a post's builder content.
	 *
	 * @since 5.2.0
	 * @param int    $post_id  Post ID.
	 * @param string $id_type  Identifier type.
	 * @param string $id_value Identifier value.
	 * @return true|WP_Error True on success.
	 */
	public function remove_element( $post_id, $id_type, $id_value ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		$found = $this->find_element( $post_id, $id_type, $id_value );
		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$tree   = Respira_Builder_Tree_Utility::remove( $content, $found['_path'], $this->get_children_key() );
		// Skip validation — round-trip from extract_content.
		$result = $this->inject_content( $post_id, $tree, true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}

	/**
	 * Apply multiple operations atomically (extract once, inject once).
	 *
	 * @since 5.2.0
	 * @param int   $post_id    Post ID.
	 * @param array $operations Array of operations: [{action, identifier_type, identifier_value, ...}].
	 * @return array|WP_Error Results per operation, or WP_Error if any fails (no partial writes).
	 */
	public function batch_update( $post_id, array $operations ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		$children_key = $this->get_children_key();
		$results      = array();

		foreach ( $operations as $index => $op ) {
			$action          = isset( $op['action'] ) ? $op['action'] : '';
			$op_id_type      = isset( $op['identifier_type'] ) ? $op['identifier_type'] : '';
			$op_id_value     = isset( $op['identifier_value'] ) ? $op['identifier_value'] : '';

			if ( '' === $op_id_type || '' === $op_id_value ) {
				return new WP_Error(
					'respira_batch_op_failed',
					sprintf( 'Operation %d failed: identifier_type and identifier_value are required.', $index ),
					array( 'failed_op_index' => $index )
				);
			}

			switch ( $action ) {
				case 'update':
					$found = Respira_Builder_Tree_Utility::find(
						$content,
						$op_id_type,
						$op_id_value,
						$children_key
					);
					if ( null === $found ) {
						return new WP_Error(
							'respira_batch_op_failed',
							sprintf( 'Operation %d failed: element not found (%s: %s).', $index, $op_id_type, $op_id_value ),
							array( 'failed_op_index' => $index )
						);
					}
					$op_updates = isset( $op['updates'] ) && is_array( $op['updates'] ) ? $op['updates'] : array();
					$content    = Respira_Builder_Tree_Utility::update_at( $content, $found['_path'], $op_updates, $children_key );
					$results[]  = array( 'status' => 'ok', 'action' => 'update', 'path' => $found['_path'] );
					break;

				case 'remove':
					$found = Respira_Builder_Tree_Utility::find(
						$content,
						$op_id_type,
						$op_id_value,
						$children_key
					);
					if ( null === $found ) {
						return new WP_Error(
							'respira_batch_op_failed',
							sprintf( 'Operation %d failed: element not found.', $index ),
							array( 'failed_op_index' => $index )
						);
					}
					$content   = Respira_Builder_Tree_Utility::remove( $content, $found['_path'], $children_key );
					$results[] = array( 'status' => 'ok', 'action' => 'remove', 'path' => $found['_path'] );
					break;

				default:
					return new WP_Error(
						'respira_batch_unknown_action',
						sprintf( 'Operation %d: unknown action "%s".', $index, $action ),
						array( 'failed_op_index' => $index )
					);
			}
		}

		// Single inject for all operations — skip validation (round-trip from extract_content).
		$result = $this->inject_content( $post_id, $content, true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $results;
	}

	/**
	 * Reorder children of a container element.
	 *
	 * @since 5.2.0
	 * @param int    $post_id        Post ID.
	 * @param string $container_path Dot-notation path to container (e.g. "0.1"), or empty for root.
	 * @param array  $new_order      Array of current indices in desired order.
	 * @return true|WP_Error True on success.
	 */
	public function reorder_elements( $post_id, $container_path, array $new_order ) {
		$content = $this->extract_content( $post_id );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		// Map "root" or empty to root-level reorder.
		$path_array = ( '' === $container_path || 'root' === $container_path )
			? array()
			: array_map( 'intval', explode( '.', $container_path ) );

		$tree = Respira_Builder_Tree_Utility::reorder( $content, $path_array, $new_order, $this->get_children_key() );
		if ( is_wp_error( $tree ) ) {
			return $tree;
		}

		// Skip validation — round-trip from extract_content.
		$result = $this->inject_content( $post_id, $tree, true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}

	/**
	 * Build a complete page from a declarative structure.
	 *
	 * @since 5.2.0
	 * @param string $title     Page title.
	 * @param array  $structure Builder-specific content structure.
	 * @param string $status    Post status (default 'draft').
	 * @return array|WP_Error {page_id, edit_url, preview_url, element_count} or WP_Error.
	 */
	public function build_page( $title, array $structure, $status = 'draft' ) {
		$element_count = Respira_Builder_Tree_Utility::count_elements( $structure, $this->get_children_key() );
		$limit         = (int) apply_filters( 'respira_element_limit', 200 );

		if ( $element_count > $limit ) {
			return new WP_Error(
				'respira_element_limit_exceeded',
				sprintf( 'Structure has %d elements (limit: %d).', $element_count, $limit )
			);
		}

		$page_id = wp_insert_post(
			array(
				'post_title'  => sanitize_text_field( $title ),
				'post_status' => in_array( $status, array( 'draft', 'publish', 'pending' ), true ) ? $status : 'draft',
				'post_type'   => 'page',
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}

		$result = $this->inject_content( $page_id, $structure, true );
		if ( is_wp_error( $result ) ) {
			// Clean up orphan page.
			wp_delete_post( $page_id, true );
			return $result;
		}

		return array(
			'page_id'       => $page_id,
			'edit_url'      => get_edit_post_link( $page_id, 'raw' ),
			'preview_url'   => get_preview_post_link( $page_id ),
			'element_count' => $element_count,
		);
	}

	/**
	 * Get dynamic schema for this builder (runtime detection).
	 *
	 * Default falls back to get_builder_schema(). Builders with dynamic
	 * registry detection (e.g. Elementor) should override this.
	 *
	 * @since 5.2.0
	 * @return array Builder schema.
	 */
	public function get_dynamic_schema() {
		return $this->get_builder_schema();
	}

	/**
	 * Validate settings for a module type.
	 *
	 * Default: allow all settings (no validation). Builders with validation
	 * intelligence (e.g. Elementor, Divi 5) should override this.
	 *
	 * @since 5.2.0
	 * @param string $module_type Module/widget type.
	 * @param array  $settings    Settings to validate.
	 * @return true|WP_Error True if valid, WP_Error with suggestions if not.
	 */
	public function validate_settings( $module_type, array $settings ) {
		return true;
	}

	/**
	 * Log performance metrics.
	 *
	 * @since  1.3.0
	 * @param  string $operation Operation name.
	 * @param  int    $post_id   Post ID.
	 * @param  float  $time      Time taken in seconds.
	 * @param  float  $threshold Threshold in seconds (default 2.0).
	 */
	protected function log_performance( $operation, $post_id, $time, $threshold = 2.0 ) {
		if ( $time > $threshold ) {
			error_log(
				sprintf(
					/* translators: 1: builder name, 2: operation, 3: post ID, 4: time in seconds */
					'Respira: Slow %s %s - Post ID %d took %.2fs',
					$this->get_name(),
					$operation,
					$post_id,
					$time
				)
			);
		}
	}
}

// Load tree utility for element-level operations.
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-tree-utility.php';

// Load all builder implementations.
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-gutenberg.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-divi.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-elementor.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-wpbakery.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-oxygen.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-bricks.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-beaver.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-brizy.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-visual-composer.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-thrive.php';
require_once RESPIRA_PLUGIN_DIR . 'includes/page-builders/class-builder-breakdance.php';

// Auto-load intelligence packages for all builders.
$intelligence_builders = array(
	'gutenberg'       => 'Gutenberg',
	'divi'            => 'Divi',
	'elementor'       => 'Elementor',
	'wpbakery'        => 'WPBakery',
	'oxygen'          => 'Oxygen',
	'bricks'          => 'Bricks',
	'beaver'          => 'Beaver',
	'brizy'           => 'Brizy',
	'visual-composer' => 'Visual_Composer',
	'thrive'          => 'Thrive',
	'breakdance'      => 'Breakdance',
);

foreach ( $intelligence_builders as $folder => $class_name ) {
	$loader_path = RESPIRA_PLUGIN_DIR . 'includes/' . $folder . '-intelligence/class-' . str_replace( '_', '-', strtolower( $class_name ) ) . '-intelligence-loader.php';
	if ( file_exists( $loader_path ) ) {
		require_once $loader_path;
		$loader_class = 'Respira_' . $class_name . '_Intelligence_Loader';
		if ( class_exists( $loader_class ) && method_exists( $loader_class, 'load' ) ) {
			call_user_func( array( $loader_class, 'load' ) );
		}
	}
}
