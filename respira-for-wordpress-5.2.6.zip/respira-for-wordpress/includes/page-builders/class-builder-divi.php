<?php
/**
 * Divi page builder implementation.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 */

/**
 * Divi builder class.
 *
 * @since 1.0.0
 */
class Respira_Builder_Divi extends Respira_Builder_Interface {

	/**
	 * Last extraction diagnostics.
	 *
	 * @since 1.0.0
	 * @var array
	 */
	private $last_extraction_diagnostics = array();

	/**
	 * Divi 5 script warnings collected during inject.
	 *
	 * @since 4.4.4
	 * @var array
	 */
	private $divi5_script_warnings = array();

	/**
	 * Detect if Divi is active.
	 *
	 * Uses multiple fallbacks for Divi theme, Divi Builder plugin, and load orders.
	 *
	 * @since 1.0.0
	 * @return bool True if Divi is active.
	 */
	public function detect() {
		$theme = wp_get_theme();

		return ( 'Divi' === $theme->get( 'Name' ) ||
				'Divi' === $theme->get_template() ||
				defined( 'ET_BUILDER_PLUGIN_VERSION' ) ||
				function_exists( 'et_pb_is_pagebuilder_used' ) ||
				class_exists( 'ET_Builder_Element' ) );
	}

	/**
	 * Get builder name.
	 *
	 * @since 1.0.0
	 * @return string Builder name.
	 */
	public function get_name() {
		return 'Divi';
	}

	/**
	 * Get builder version.
	 *
	 * @since 1.0.0
	 * @return string Builder version.
	 */
	public function get_version() {
		if ( defined( 'ET_BUILDER_PLUGIN_VERSION' ) ) {
			return ET_BUILDER_PLUGIN_VERSION;
		}

		$theme = wp_get_theme();
		if ( 'Divi' === $theme->get( 'Name' ) || 'Divi' === $theme->get_template() ) {
			return $theme->get( 'Version' );
		}

		return 'unknown';
	}

	/**
	 * Detect if Divi 5 runtime is enabled.
	 *
	 * @since 1.9.2
	 * @return bool True if Divi 5 runtime is enabled.
	 */
	private function is_divi5_runtime() {
		return function_exists( 'et_builder_d5_enabled' ) && et_builder_d5_enabled();
	}

	/**
	 * Detect Divi 5 blocks in post content.
	 *
	 * @since 1.9.2
	 * @param string $post_content Post content.
	 * @return bool True if Divi 5 blocks are present.
	 */
	private function has_divi5_blocks( $post_content ) {
		return is_string( $post_content ) && strpos( $post_content, '<!-- wp:divi/' ) !== false;
	}

	/**
	 * Check if post uses Divi builder.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return bool True if uses Divi.
	 */
	public function is_builder_used( $post_id ) {
		// Check if Divi builder is enabled for this post.
		$enabled = get_post_meta( $post_id, '_et_pb_use_builder', true );

		if ( 'on' === $enabled ) {
			return true;
		}

		// Also check if content contains Divi shortcodes in post_content.
		$post = get_post( $post_id );
		if ( $post && $this->has_divi5_blocks( $post->post_content ) ) {
			return true;
		}

		if ( $post && ! empty( $post->post_content ) && preg_match( '/\[et_pb_/', $post->post_content ) ) {
			return true;
		}

		// Check alternative content sources (Divi stores content in multiple places).
		$layout_content = get_post_meta( $post_id, '_et_pb_layout_content', true );
		if ( ! empty( $layout_content ) && ( is_string( $layout_content ) && preg_match( '/\[et_pb_/', $layout_content ) ) ) {
			return true;
		}

		$page_content = get_post_meta( $post_id, '_et_pb_page_content', true );
		if ( ! empty( $page_content ) ) {
			$unserialized = maybe_unserialize( $page_content );
			if ( is_string( $unserialized ) && preg_match( '/\[et_pb_/', $unserialized ) ) {
				return true;
			}
		}

		// Check _et_pb_page_layout meta (serialized array format).
		$page_layout = get_post_meta( $post_id, '_et_pb_page_layout', true );
		if ( ! empty( $page_layout ) ) {
			// If it's an array or can be unserialized to array, Divi is likely used.
			$layout_data = maybe_unserialize( $page_layout );
			if ( is_array( $layout_data ) && ! empty( $layout_data ) ) {
				return true;
			}
			// If it's a string with shortcodes, also return true.
			if ( is_string( $layout_data ) && preg_match( '/\[et_pb_/', $layout_data ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Extract content from post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array Extracted modules with diagnostic information.
	 */
	public function extract_content( $post_id ) {
		$start = microtime( true );

		$post = get_post( $post_id );

		if ( ! $post ) {
			return array(
				'content' => array(),
				'diagnostics' => array(
					'error' => 'Post not found',
					'post_id' => $post_id,
				),
			);
		}

		if ( $this->is_divi5_runtime() || $this->has_divi5_blocks( $post->post_content ) ) {
			return $this->extract_content_divi5( $post_id, $post );
		}

		// Check if Divi builder is enabled for this post.
		$builder_enabled = get_post_meta( $post_id, '_et_pb_use_builder', true );
		$builder_version = get_post_meta( $post_id, '_et_pb_builder_version', true );

		// Try multiple content sources in priority order.
		// Priority: post_content (most reliable) > _et_pb_page_layout > _et_pb_layout_content > _et_pb_page_content
		$content = '';
		$content_source = 'none';
		$diagnostics = array(
			'builder_enabled' => ( 'on' === $builder_enabled ),
			'builder_version' => $builder_version ? $builder_version : 'unknown',
			'content_sources_checked' => array(),
			'meta_fields_status' => array(),
		);

		// 1. Check post_content for shortcodes FIRST (most reliable source).
		if ( ! empty( $post->post_content ) ) {
			$post_content_length = strlen( $post->post_content );
			$has_shortcodes = preg_match( '/\[et_pb_/', $post->post_content );
			$diagnostics['meta_fields_status']['post_content'] = array(
				'exists' => true,
				'length' => $post_content_length,
				'has_shortcodes' => $has_shortcodes,
				'first_500_chars' => substr( $post->post_content, 0, 500 ),
			);

			if ( $has_shortcodes ) {
				$content = $post->post_content;
				$content_source = 'post_content_shortcodes';
				$diagnostics['content_sources_checked'][] = 'post_content (shortcodes found, length: ' . $post_content_length . ')';
			} else {
				$diagnostics['content_sources_checked'][] = 'post_content (no shortcodes, length: ' . $post_content_length . ')';
			}
		} else {
			$diagnostics['meta_fields_status']['post_content'] = array( 'exists' => false );
			$diagnostics['content_sources_checked'][] = 'post_content (empty)';
		}

		// 0. Check _et_pb_page_layout meta (primary Divi layout storage - serialized PHP array).
		// Only use this if post_content doesn't have shortcodes.
		if ( empty( $content ) ) {
			$page_layout = get_post_meta( $post_id, '_et_pb_page_layout', true );
			if ( ! empty( $page_layout ) ) {
				$diagnostics['meta_fields_status']['_et_pb_page_layout'] = array(
					'exists' => true,
					'type' => gettype( $page_layout ),
					'length' => is_string( $page_layout ) ? strlen( $page_layout ) : ( is_array( $page_layout ) ? count( $page_layout ) : 0 ),
				);

				// Unserialize if it's a string (serialized PHP array).
				$layout_data = maybe_unserialize( $page_layout );
				
				if ( is_array( $layout_data ) ) {
					// Convert array structure to shortcodes.
					$converted_content = $this->convert_layout_array_to_shortcodes( $layout_data );
					if ( ! empty( $converted_content ) ) {
						$content = $converted_content;
						$content_source = 'page_layout_array';
						$diagnostics['content_sources_checked'][] = '_et_pb_page_layout (array converted to shortcodes)';
					} else {
						$diagnostics['content_sources_checked'][] = '_et_pb_page_layout (array conversion failed)';
					}
				} elseif ( is_string( $layout_data ) && preg_match( '/\[et_pb_/', $layout_data ) ) {
					// Already in shortcode format.
					$content = $layout_data;
					$content_source = 'page_layout_shortcodes';
					$diagnostics['content_sources_checked'][] = '_et_pb_page_layout (shortcodes found)';
				} else {
					$diagnostics['content_sources_checked'][] = '_et_pb_page_layout (unrecognized format)';
				}
			} else {
				$diagnostics['meta_fields_status']['_et_pb_page_layout'] = array( 'exists' => false );
				$diagnostics['content_sources_checked'][] = '_et_pb_page_layout (empty)';
			}
		}

		// 2. Check _et_pb_layout_content meta (visual builder JSON format).
		if ( empty( $content ) ) {
			$layout_content = get_post_meta( $post_id, '_et_pb_layout_content', true );
			if ( ! empty( $layout_content ) ) {
				$diagnostics['meta_fields_status']['_et_pb_layout_content'] = array(
					'exists' => true,
					'type' => gettype( $layout_content ),
					'length' => is_string( $layout_content ) ? strlen( $layout_content ) : 0,
				);

				// Try to decode JSON.
				$json_data = json_decode( $layout_content, true );
				if ( is_array( $json_data ) ) {
					// Convert JSON to shortcodes.
					$content = $this->convert_json_to_shortcodes( $json_data );
					$content_source = 'layout_content_json';
					$diagnostics['content_sources_checked'][] = '_et_pb_layout_content (JSON converted)';
				} else {
					// Might be serialized or already shortcodes.
					$content = maybe_unserialize( $layout_content );
					if ( is_string( $content ) && preg_match( '/\[et_pb_/', $content ) ) {
						$content_source = 'layout_content_shortcodes';
						$diagnostics['content_sources_checked'][] = '_et_pb_layout_content (shortcodes found)';
					} else {
						$diagnostics['content_sources_checked'][] = '_et_pb_layout_content (unrecognized format)';
					}
				}
			} else {
				$diagnostics['meta_fields_status']['_et_pb_layout_content'] = array( 'exists' => false );
				$diagnostics['content_sources_checked'][] = '_et_pb_layout_content (empty)';
			}
		}

		// 3. Check _et_pb_page_content meta as fallback.
		if ( empty( $content ) ) {
			$page_content = get_post_meta( $post_id, '_et_pb_page_content', true );
			if ( ! empty( $page_content ) ) {
				$diagnostics['meta_fields_status']['_et_pb_page_content'] = array(
					'exists' => true,
					'type' => gettype( $page_content ),
					'length' => is_string( $page_content ) ? strlen( $page_content ) : 0,
				);

				$content = maybe_unserialize( $page_content );
				if ( is_string( $content ) && preg_match( '/\[et_pb_/', $content ) ) {
					$content_source = 'page_content';
					$diagnostics['content_sources_checked'][] = '_et_pb_page_content (shortcodes found)';
				} else {
					$diagnostics['content_sources_checked'][] = '_et_pb_page_content (no shortcodes)';
				}
			} else {
				$diagnostics['meta_fields_status']['_et_pb_page_content'] = array( 'exists' => false );
				$diagnostics['content_sources_checked'][] = '_et_pb_page_content (empty)';
			}
		}

		// If still no content, check if builder is enabled but content is missing.
		if ( empty( $content ) && 'on' === $builder_enabled ) {
			$diagnostics['warning'] = 'Divi builder is enabled but no content found in any source';
		}

		$diagnostics['content_source_used'] = $content_source;
		$diagnostics['content_length'] = strlen( $content );

		// Parse Divi shortcodes.
		$modules = array();
		if ( ! empty( $content ) ) {
			// Try standard parsing first.
			$modules = $this->parse_divi_shortcodes( $content );
			$diagnostics['modules_found'] = count( $modules );
			$diagnostics['parsing_method'] = 'standard';
			
			// If parsing returned empty but content exists, try optimized parser for large content.
			if ( empty( $modules ) && strlen( $content ) > 100000 ) {
				$modules = $this->parse_divi_shortcodes_optimized( $content );
				$diagnostics['modules_found'] = count( $modules );
				$diagnostics['parsing_method'] = 'optimized';
				$diagnostics['warning'] = ( isset( $diagnostics['warning'] ) ? $diagnostics['warning'] . '. ' : '' ) . 'Used optimized parser for large content';
			}
			
			// If still empty, add diagnostic information.
			if ( empty( $modules ) ) {
				$diagnostics['error'] = 'Content found but parsing returned no modules';
				$diagnostics['content_preview'] = substr( $content, 0, 1000 );
				
				// Count shortcode tags properly.
				$shortcode_matches = array();
				$shortcode_count = preg_match_all( '/\[et_pb_/', $content, $shortcode_matches );
				$diagnostics['shortcode_count'] = $shortcode_count;
				
				// Try to identify why parsing failed.
				if ( $shortcode_count > 0 ) {
					$diagnostics['warning'] = ( isset( $diagnostics['warning'] ) ? $diagnostics['warning'] . '. ' : '' ) . sprintf(
						'Found %d shortcode tags but parsing failed. Content may have malformed shortcodes or unsupported structure.',
						$shortcode_count
					);
					
					// Extract first few shortcode tags for debugging.
					preg_match_all( '/\[et_pb_(\w+)/', $content, $tag_matches, PREG_SET_ORDER );
					$first_tags = array_slice( $tag_matches, 0, 5 );
					$diagnostics['sample_tags'] = array_map( function( $match ) {
						return $match[1] ?? 'unknown';
					}, $first_tags );
				} else {
					$diagnostics['warning'] = ( isset( $diagnostics['warning'] ) ? $diagnostics['warning'] . '. ' : '' ) . 'No Divi shortcode tags found in content despite content being present.';
				}
			}
		} else {
			$diagnostics['modules_found'] = 0;
			$diagnostics['error'] = 'No Divi content found in any source';
		}

		// Resolve global modules if any.
		if ( ! empty( $modules ) && class_exists( 'Respira_Divi_Global_Modules' ) ) {
			$modules = Respira_Divi_Global_Modules::resolve_global_modules( $modules );
		}

		$result = $this->simplify_structure( $modules );

		// Add diagnostic information to result.
		$diagnostics['extraction_time'] = round( microtime( true ) - $start, 3 );
		$diagnostics['result_count'] = count( $result );

		// Performance monitoring: log if extraction takes > 2 seconds.
		$time = microtime( true ) - $start;
		if ( $time > 2.0 ) {
			error_log(
				sprintf(
					/* translators: 1: post ID, 2: time in seconds */
					'Respira: Slow Divi extract - Post ID %d took %.2fs',
					$post_id,
					$time
				)
			);
		}

		// Store diagnostics in a property for API access.
		$this->last_extraction_diagnostics = $diagnostics;

		// Return content array directly for backward compatibility.
		return $result;
	}

	/**
	 * Get last extraction diagnostics.
	 *
	 * @since 1.0.0
	 * @return array Diagnostic information from last extraction.
	 */
	public function get_last_extraction_diagnostics() {
		return $this->last_extraction_diagnostics ?? array();
	}

	/**
	 * Inject content into post.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified module content.
	 * @return bool|WP_Error True on success.
	 */
	public function inject_content( $post_id, $content, $skip_structure_validation = false ) {
		$start = microtime( true );
		$post  = get_post( $post_id );

		if ( ! $post ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' )
			);
		}

		if ( $this->has_divi5_blocks( $post->post_content ) || $this->contains_divi5_structure( $content ) ) {
			return $this->inject_content_divi5( $post_id, $content, $start, $skip_structure_validation );
		}

		// Validate layout before injection.
		if ( class_exists( 'Respira_Divi_Validator' ) ) {
			$validation = Respira_Divi_Validator::validate_layout( $content );
			if ( ! $validation['valid'] ) {
				return new WP_Error(
					'respira_divi_validation_failed',
					__( 'Divi layout validation failed:', 'respira-for-wordpress' ) . ' ' . implode( ' ', $validation['errors'] ),
					$validation['errors']
				);
			}
		}

		// Convert simplified structure back to Divi shortcodes.
		$shortcodes = $this->build_divi_shortcodes( $content );

		// Log content sizes for debugging
		$shortcode_length = strlen( $shortcodes );
		error_log( sprintf(
			/* translators: 1: post ID, 2: shortcode length in bytes */
			'Respira: Divi inject - Post ID %d, Shortcode length: %d bytes',
			$post_id,
			$shortcode_length
		) );

		// Update post content.
		// wp_update_post() internally calls wp_unslash() on all fields,
		// so we must wp_slash() first to preserve backslashes in content
		// (e.g. \u003c in Divi 5 JSON blocks).
		$result = wp_update_post(
			wp_slash(
				array(
					'ID'           => $post_id,
					'post_content' => $shortcodes,
				)
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// After wp_update_post, verify content wasn't truncated
		$saved_content = get_post_field( 'post_content', $post_id );
		$saved_length = strlen( $saved_content );
		if ( $saved_length !== $shortcode_length ) {
			error_log( sprintf(
				/* translators: 1: post ID, 2: expected length, 3: saved length */
				'Respira: WARNING - Content truncation detected! Post ID %d, Expected: %d bytes, Saved: %d bytes',
				$post_id,
				$shortcode_length,
				$saved_length
			) );
		}

		// Sync Divi post meta fields to prevent structure breakage
		// Update _et_pb_page_content meta (Divi uses this for layout)
		update_post_meta( $post_id, '_et_pb_page_content', $shortcodes );
		error_log( sprintf(
			/* translators: 1: post ID */
			'Respira: Divi meta sync - Post ID %d, Updated _et_pb_page_content',
			$post_id
		) );

		// If _et_pb_layout_content exists, update it too (visual builder format)
		$existing_layout_content = get_post_meta( $post_id, '_et_pb_layout_content', true );
		if ( ! empty( $existing_layout_content ) ) {
			// Keep layout_content in sync - update it to match page_content to maintain consistency
			update_post_meta( $post_id, '_et_pb_layout_content', $shortcodes );
			error_log( sprintf(
				/* translators: 1: post ID */
				'Respira: Divi meta sync - Post ID %d, Updated _et_pb_layout_content',
				$post_id
			) );
		}

		// Ensure Divi builder is enabled.
		update_post_meta( $post_id, '_et_pb_use_builder', 'on' );
		
		// Get dynamic builder version instead of hardcoding.
		$builder_version = $this->get_version();
		if ( 'unknown' !== $builder_version ) {
			// Extract major version (e.g., "4.0" from "4.0.1").
			$version_parts = explode( '.', $builder_version );
			$major_version = $version_parts[0] . '.' . ( $version_parts[1] ?? '0' );
			update_post_meta( $post_id, '_et_pb_builder_version', $major_version );
		} else {
		update_post_meta( $post_id, '_et_pb_builder_version', '4.0' );
		}

		// Fire Divi hooks to ensure proper initialization and cache invalidation
		do_action( 'et_pb_ab_clear_cache', $post_id );
		if ( function_exists( 'et_pb_ab_clear_cache' ) ) {
			et_pb_ab_clear_cache( $post_id );
		}

		// Clear Divi static CSS cache
		if ( function_exists( 'et_core_page_resource_clear' ) ) {
			et_core_page_resource_clear( $post_id );
		}

		// Performance monitoring: log if injection takes > 2 seconds.
		$time = microtime( true ) - $start;
		if ( $time > 2.0 ) {
			error_log(
				sprintf(
					/* translators: 1: post ID, 2: time in seconds */
					'Respira: Slow Divi inject - Post ID %d took %.2fs',
					$post_id,
					$time
				)
			);
		}

		return true;
	}

	/**
	 * Determine if simplified structure is Divi 5 block-based.
	 *
	 * @since 1.9.2
	 * @param array $content Simplified content structure.
	 * @return bool True when Divi 5 block nodes are present.
	 */
	private function contains_divi5_structure( $content ) {
		if ( ! is_array( $content ) ) {
			return false;
		}

		foreach ( $content as $node ) {
			$type = $node['type'] ?? '';
			if ( is_string( $type ) && strpos( $type, 'divi/' ) === 0 ) {
				return true;
			}

			if ( ! empty( $node['children'] ) && $this->contains_divi5_structure( $node['children'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Auto-wrap bare Divi 5 modules in Section > Row > Column.
	 *
	 * When the top-level nodes are leaf modules (not divi/section), wrap them
	 * in a proper hierarchy so Divi 5 validation passes. Structural nodes
	 * (divi/section, divi/row, divi/column) are left untouched.
	 *
	 * @since 5.2.3
	 * @param array $nodes Simplified content nodes.
	 * @return array Wrapped content nodes.
	 */
	private function auto_wrap_divi5_modules( $nodes ) {
		if ( empty( $nodes ) ) {
			return $nodes;
		}

		$structural_types = array( 'divi/section', 'divi/row', 'divi/column' );
		$needs_wrap       = false;

		foreach ( $nodes as $node ) {
			$type = $node['type'] ?? '';
			if ( strpos( $type, 'divi/' ) === 0 && ! in_array( $type, $structural_types, true ) ) {
				$needs_wrap = true;
				break;
			}
		}

		if ( ! $needs_wrap ) {
			return $nodes;
		}

		$builder_version = $this->get_version() ?: '5.0.1';

		return array(
			array(
				'type'     => 'divi/section',
				'attrs'    => array( 'builderVersion' => $builder_version ),
				'children' => array(
					array(
						'type'     => 'divi/row',
						'attrs'    => array( 'builderVersion' => $builder_version ),
						'children' => array(
							array(
								'type'     => 'divi/column',
								'attrs'    => array(
									'builderVersion' => $builder_version,
									'module'         => array(
										'advanced' => array(
											'type' => array(
												'desktop' => array( 'value' => '4_4' ),
											),
										),
									),
								),
								'children' => $nodes,
							),
						),
					),
				),
			),
		);
	}

	/**
	 * Extract Divi 5 content from block tree.
	 *
	 * @since 1.9.2
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return array Simplified structure.
	 */
	private function extract_content_divi5( $post_id, $post ) {
		if ( ! function_exists( 'parse_blocks' ) ) {
			return array();
		}

		$content = $post->post_content;

		// Divi 5 sometimes stores only a self-closing placeholder in post_content
		// while the real block tree lives in the latest revision. Detect this and
		// fall back to the most recent revision that contains the full layout.
		if ( $this->is_divi5_placeholder_only( $content ) ) {
			$revision_content = $this->get_latest_divi5_revision_content( $post_id );
			if ( $revision_content ) {
				$content = $revision_content;
			}
		}

		$blocks = parse_blocks( $content );
		return $this->simplify_divi5_blocks( $blocks );
	}

	/**
	 * Check if post_content is just a self-closing divi/placeholder with no real layout.
	 *
	 * A full Divi 5 layout has the placeholder as a wrapper: <!-- wp:divi/placeholder {...} -->...<!-- /wp:divi/placeholder -->
	 * A placeholder-only page has it self-closing: <!-- wp:divi/placeholder {...} /-->
	 *
	 * @since 4.4.4
	 * @param string $content Post content.
	 * @return bool True if content is placeholder-only.
	 */
	private function is_divi5_placeholder_only( $content ) {
		if ( ! is_string( $content ) ) {
			return false;
		}
		$trimmed = trim( $content );
		// Self-closing placeholder with no inner blocks.
		if ( preg_match( '/\A<!--\s+wp:divi\/placeholder\s+\{.*\}\s+\/-->\s*\z/s', $trimmed ) ) {
			return true;
		}
		// Opening+closing placeholder but no divi/ blocks inside (empty wrapper).
		$blocks = parse_blocks( $trimmed );
		if ( count( $blocks ) === 1 && isset( $blocks[0]['blockName'] ) && 'divi/placeholder' === $blocks[0]['blockName'] && empty( $blocks[0]['innerBlocks'] ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Find the latest revision that contains a full Divi 5 block tree.
	 *
	 * @since 4.4.4
	 * @param int $post_id Post ID.
	 * @return string|false Revision post_content or false if none found.
	 */
	private function get_latest_divi5_revision_content( $post_id ) {
		global $wpdb;

		// Get revisions ordered by most recent first, looking for ones with real Divi 5 content.
		$revisions = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_content FROM {$wpdb->posts}
				WHERE post_parent = %d AND post_type = 'revision'
				AND LENGTH(post_content) > 500
				ORDER BY post_modified DESC
				LIMIT 5",
				$post_id
			)
		);

		if ( empty( $revisions ) ) {
			return false;
		}

		foreach ( $revisions as $revision ) {
			// Must contain divi/ blocks beyond just the placeholder.
			if ( strpos( $revision->post_content, '<!-- wp:divi/section' ) !== false ||
				 strpos( $revision->post_content, '<!-- wp:divi/row' ) !== false ) {
				return $revision->post_content;
			}
		}

		return false;
	}

	/**
	 * Inject Divi 5 content by serializing blocks.
	 *
	 * @since 1.9.2
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified structure.
	 * @param float $start   Start timestamp.
	 * @return bool|WP_Error True on success.
	 */
	private function inject_content_divi5( $post_id, $content, $start, $skip_structure_validation = false ) {
		// Safety: never overwrite a full layout with just a placeholder.
		// Count real Divi 5 layout nodes (sections/rows/columns/modules) in the incoming content.
		$real_node_count = $this->count_divi5_layout_nodes( $content );
		if ( 0 === $real_node_count ) {
			// Check if the page currently has real content (in post or revisions).
			$post = get_post( $post_id );
			if ( $post && ! $this->is_divi5_placeholder_only( $post->post_content ) ) {
				return new WP_Error(
					'respira_divi5_empty_inject_blocked',
					__( 'Refusing to overwrite existing Divi 5 layout with empty/placeholder-only content.', 'respira-for-wordpress' )
				);
			}
			$revision_content = $this->get_latest_divi5_revision_content( $post_id );
			if ( $revision_content ) {
				return new WP_Error(
					'respira_divi5_empty_inject_blocked',
					__( 'Refusing to overwrite existing Divi 5 layout with empty/placeholder-only content. The page has revision content that would be lost.', 'respira-for-wordpress' )
				);
			}
		}

		// Auto-wrap bare modules in Section > Row > Column hierarchy for Divi 5.
		// When build_page or inject_builder_content receives a flat list of modules
		// (e.g. divi/code, divi/text) without the required structural wrappers,
		// wrap them automatically so the content passes Divi 5 validation.
		if ( is_array( $content ) ) {
			$content = $this->auto_wrap_divi5_modules( $content );
		}

		// Warn when <script> tags appear in divi/text modules — Divi strips them at render time.
		$this->divi5_script_warnings = array();
		if ( is_array( $content ) ) {
			$this->collect_divi5_script_warnings( $content );
		}

		// Skip structural validation for module-level updates — only content/attributes changed,
		// the overall structure is unchanged from the previously-valid state.
		if ( ! $skip_structure_validation && class_exists( 'Respira_Divi_Validator' ) ) {
			$validation = Respira_Divi_Validator::validate_layout( $content );
			if ( ! $validation['valid'] ) {
				return new WP_Error(
					'respira_divi5_validation_failed',
					__( 'Divi 5 layout validation failed:', 'respira-for-wordpress' ) . ' ' . implode( ' ', $validation['errors'] ),
					$validation['errors']
				);
			}
		}

		$blocks = $this->complexify_divi5_blocks( $content );

		if ( ! function_exists( 'serialize_blocks' ) ) {
			return new WP_Error(
				'respira_divi5_blocks_unavailable',
				__( 'Block serialization is unavailable on this WordPress installation.', 'respira-for-wordpress' )
			);
		}

		$serialized = serialize_blocks( $blocks );
		$serialized = $this->fix_divi5_html_encoding( $serialized );

		// Write directly to the database to bypass Divi's wp_insert_post_data filter
		// (convert_divi_blocks_before_save in BlockEditorIntegration.php) which
		// can strip block content and rewrite post_content to placeholder-only.
		global $wpdb;
		$updated = $wpdb->update(
			$wpdb->posts,
			array( 'post_content' => $serialized, 'post_modified' => current_time( 'mysql' ), 'post_modified_gmt' => current_time( 'mysql', true ) ),
			array( 'ID' => $post_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'respira_divi5_db_update_failed',
				__( 'Failed to update Divi 5 post content in database.', 'respira-for-wordpress' ),
				array( 'db_error' => $wpdb->last_error )
			);
		}

		// Clear WordPress post cache so subsequent reads see the new content.
		clean_post_cache( $post_id );


		// NOTE: Divi cache-clearing functions (et_core_page_resource_clear,
		// et_pb_ab_clear_cache) are intentionally NOT called here. They call
		// wp_die()/exit() when invoked outside the Divi builder context, which
		// kills the REST API response. The content is already written to the DB
		// and clean_post_cache() above ensures WordPress sees the update.
		// Divi's static CSS cache will regenerate on the next frontend page load.
		$this->log_performance( 'inject', $post_id, microtime( true ) - $start );

		if ( ! empty( $this->divi5_script_warnings ) ) {
			return array(
				'success'  => true,
				'warnings' => $this->divi5_script_warnings,
			);
		}

		return true;
	}

	/**
	 * Collect warnings about <script> tags in divi/text modules.
	 * Divi strips script tags at render time — divi/code should be used instead.
	 *
	 * Count real Divi 5 layout nodes (sections, rows, columns, modules) in a simplified structure.
	 * Used to detect when content is placeholder-only vs a real layout.
	 *
	 * @since 4.4.4
	 * @param array $nodes Simplified structure.
	 * @return int Number of real layout nodes.
	 */
	private function count_divi5_layout_nodes( $nodes ) {
		if ( ! is_array( $nodes ) ) {
			return 0;
		}
		$count = 0;
		foreach ( $nodes as $node ) {
			$type = isset( $node['type'] ) ? $node['type'] : '';
			// Skip placeholder and freeform — count real layout nodes.
			if ( 'divi/placeholder' !== $type && 'core/freeform' !== $type && strpos( $type, 'divi/' ) === 0 ) {
				$count++;
			}
			if ( ! empty( $node['children'] ) ) {
				$count += $this->count_divi5_layout_nodes( $node['children'] );
			}
		}
		return $count;
	}

	/**
	 * Collect warnings about <script> tags in divi/text modules.
	 * Divi strips script tags at render time — divi/code should be used instead.
	 *
	 * @since 4.4.4
	 * @param array  $modules Content array.
	 * @param string $path    Current path for error messages.
	 */
	private function collect_divi5_script_warnings( $modules, $path = '' ) {
		foreach ( $modules as $index => $module ) {
			$module_path = $path ? $path . '.' . $index : (string) $index;
			$type = isset( $module['type'] ) ? $module['type'] : '';

			if ( 'divi/text' === $type || 'divi/text-inline' === $type ) {
				$inner = isset( $module['content'] ) ? $module['content'] : '';
				if ( is_array( $inner ) ) {
					$inner = implode( '', $inner );
				}
				if ( preg_match( '/<script|\\\\u003cscript/i', $inner ) ) {
					$this->divi5_script_warnings[] = sprintf(
						'<script> tags in %s (path %s) will be stripped by Divi at render time. Use divi/code for executable scripts.',
						$type,
						$module_path
					);
				}
			}

			if ( ! empty( $module['children'] ) && is_array( $module['children'] ) ) {
				$this->collect_divi5_script_warnings( $module['children'], $module_path );
			}
		}
	}

	/**
	 * Convert parsed blocks to Respira simplified structure.
	 *
	 * @since 1.9.2
	 * @param array $blocks Parsed blocks.
	 * @return array Simplified nodes.
	 */
	private function simplify_divi5_blocks( $blocks ) {
		$simplified = array();

		foreach ( $blocks as $block ) {
			$type = $block['blockName'] ?? 'core/freeform';
			if ( empty( $type ) ) {
				$type = 'core/freeform';
			}

			$children = array();
			if ( ! empty( $block['innerBlocks'] ) ) {
				$children = $this->simplify_divi5_blocks( $block['innerBlocks'] );
			}

			$attrs = $block['attrs'] ?? array();

			// Divi 5 stores module content in attrs.content.innerContent.desktop.value,
			// not in innerHTML (which is often empty or whitespace-only for Divi 5 blocks).
			// Always prefer the attrs path for divi/* blocks — innerHTML may contain
			// only "\n\n" after round-trip which masks the real content.
			$content = $block['innerHTML'] ?? '';
			if ( strpos( $type, 'divi/' ) === 0 && isset( $attrs['content']['innerContent']['desktop']['value'] ) ) {
				$content = $attrs['content']['innerContent']['desktop']['value'];
			} elseif ( empty( $content ) && isset( $attrs['content']['innerContent']['desktop']['value'] ) ) {
				$content = $attrs['content']['innerContent']['desktop']['value'];
			}

			$simplified[] = array(
				'type'            => $type,
				'attributes'      => $attrs,
				'attrs'           => $attrs,
				'content'         => $content,
				'children'        => $children,
				// Preserve the original block innerContent array for lossless round-tripping.
				// WordPress serialize_blocks() uses this to know where to place inner blocks
				// (null entries = inner block positions, strings = HTML fragments between blocks).
				'_innerContent'   => $block['innerContent'] ?? array(),
				'_innerHTML'      => $block['innerHTML'] ?? '',
			);
		}

		return $simplified;
	}

	/**
	 * Convert simplified structure back to block arrays.
	 *
	 * @since 1.9.2
	 * @param array $nodes Simplified nodes.
	 * @return array Block arrays.
	 */
	private function complexify_divi5_blocks( $nodes ) {
		$blocks = array();

		// Detect Divi builder version from existing blocks for builderVersion injection.
		$builder_version = $this->get_version() ?: '5.0.1';

		foreach ( $nodes as $node ) {
			$type       = $node['type'] ?? 'core/freeform';
			$attributes = $node['attributes'] ?? ( $node['attrs'] ?? array() );
			$settings   = $node['settings'] ?? array();
			$content    = $node['content'] ?? '';
			$children   = ! empty( $node['children'] ) ? $this->complexify_divi5_blocks( $node['children'] ) : array();

			// For Divi modules, map simplified settings to nested Divi 5 attribute paths.
			// This allows build_page and inject_builder_content to accept a simple format:
			//   {"type": "divi/code", "settings": {"content": "<style>...</style>", "admin_label": "My Label"}}
			// instead of requiring the deep nested Divi 5 format.
			if ( strpos( $type, 'divi/' ) === 0 && is_array( $attributes ) ) {
				// Inject builderVersion if missing.
				if ( ! isset( $attributes['builderVersion'] ) ) {
					$attributes['builderVersion'] = $builder_version;
				}

				// Map settings.content → attrs.content.innerContent.desktop.value
				$simplified_content = $settings['content'] ?? ( is_string( $content ) && '' !== $content ? $content : null );
				if ( null !== $simplified_content && ! isset( $attributes['content']['innerContent']['desktop']['value'] ) ) {
					$attributes['content'] = array(
						'innerContent' => array(
							'desktop' => array( 'value' => $simplified_content ),
						),
					);
				}

				// Map settings.admin_label → attrs.module.meta.adminLabel.desktop.value
				$admin_label = $settings['admin_label'] ?? null;
				if ( null !== $admin_label && ! isset( $attributes['module']['meta']['adminLabel']['desktop']['value'] ) ) {
					if ( ! isset( $attributes['module'] ) ) {
						$attributes['module'] = array();
					}
					if ( ! isset( $attributes['module']['meta'] ) ) {
						$attributes['module']['meta'] = array();
					}
					$attributes['module']['meta']['adminLabel'] = array(
						'desktop' => array( 'value' => $admin_label ),
					);
				}

				// Map other common simplified settings to Divi 5 attribute paths.
				$setting_mappings = array(
					'title'      => array( 'content', 'title', 'desktop', 'value' ),
					'body'       => array( 'content', 'body', 'desktop', 'value' ),
					'heading'    => array( 'content', 'title', 'desktop', 'value' ),
					'button_text'=> array( 'content', 'button', 'desktop', 'value' ),
					'button_url' => array( 'content', 'buttonLink', 'desktop', 'value' ),
					'src'        => array( 'content', 'src', 'desktop', 'value' ),
					'alt'        => array( 'content', 'alt', 'desktop', 'value' ),
					'url'        => array( 'content', 'url', 'desktop', 'value' ),
				);

				foreach ( $setting_mappings as $setting_key => $attr_path ) {
					if ( isset( $settings[ $setting_key ] ) ) {
						$this->set_nested_value( $attributes, $attr_path, $settings[ $setting_key ] );
					}
				}
			}

			$block = array(
				'blockName'   => 'core/freeform' === $type ? null : $type,
				'attrs'       => is_array( $attributes ) ? $attributes : array(),
				'innerBlocks' => $children,
				'innerHTML'   => '',
				'innerContent'=> array(),
			);

			// Restore the original innerContent/innerHTML if preserved from extraction.
			// This is critical for serialize_blocks() — it uses innerContent to know
			// where to place inner blocks (null = inner block slot, string = HTML).
			if ( ! empty( $node['_innerContent'] ) ) {
				$block['innerContent'] = $node['_innerContent'];
				$block['innerHTML']    = $node['_innerHTML'] ?? '';
			} elseif ( ! empty( $children ) ) {
				// No preserved innerContent but we have children — build the array.
				// serialize_blocks() needs one null per inner block to output them.
				$inner = array();
				foreach ( $children as $ignored ) {
					$inner[] = null;
				}
				$block['innerContent'] = $inner;
			} elseif ( ! empty( $content ) && strpos( $type, 'divi/' ) !== 0 ) {
				// Non-Divi leaf blocks: content goes in innerHTML.
				$block['innerHTML']    = $content;
				$block['innerContent'] = array( $content );
			}

			$blocks[] = $block;
		}

		return $blocks;
	}

	/**
	 * Set a deeply nested value in an array using a path of keys.
	 *
	 * Only sets if the target path does not already exist (no overwrite).
	 *
	 * @since 5.2.3
	 * @param array    &$arr  Target array (modified by reference).
	 * @param string[]  $path  Array of keys forming the nested path.
	 * @param mixed     $value Value to set.
	 */
	private function set_nested_value( &$arr, $path, $value ) {
		$ref = &$arr;
		foreach ( $path as $i => $key ) {
			if ( $i === count( $path ) - 1 ) {
				if ( ! isset( $ref[ $key ] ) ) {
					$ref[ $key ] = $value;
				}
				return;
			}
			if ( ! isset( $ref[ $key ] ) || ! is_array( $ref[ $key ] ) ) {
				$ref[ $key ] = array();
			}
			$ref = &$ref[ $key ];
		}
	}

	/**
	 * Fix HTML encoding in Divi 5 block comment JSON.
	 *
	 * Divi 5's block parser expects angle brackets inside attribute values to be
	 * unicode-escaped (\u003c / \u003e). WordPress serialize_block_attributes()
	 * uses JSON_UNESCAPED_UNICODE which leaves raw < / > in the JSON, causing
	 * Divi 5 to render HTML as visible text instead of parsing it.
	 *
	 * This re-encodes the JSON inside each <!-- wp:divi/... --> comment using
	 * JSON_HEX_TAG so that < becomes \u003C and > becomes \u003E.
	 *
	 * @since 5.0.1
	 * @param string $serialized Serialized block HTML.
	 * @return string Fixed serialized block HTML.
	 */
	private function fix_divi5_html_encoding( $serialized ) {
		return preg_replace_callback(
			'/<!--\s+wp:divi\/([^\s]+)\s+(\{.+\})\s+(\/)?-->/s',
			function ( $matches ) {
				$block_name = $matches[1];
				$json_str   = $matches[2];
				$self_close = isset( $matches[3] ) ? $matches[3] : '';

				$attrs = json_decode( $json_str, true );
				if ( null === $attrs ) {
					// JSON didn't parse — return original unchanged.
					return $matches[0];
				}

				$re_encoded = wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG );
				if ( false === $re_encoded || '{}' === $re_encoded ) {
					return $matches[0];
				}

				return '<!-- wp:divi/' . $block_name . ' ' . $re_encoded . ' ' . $self_close . '-->';
			},
			$serialized
		);
	}

	/**
	 * Build attribute string from array (helper for convert_layout_array_to_shortcodes).
	 *
	 * @since  1.0.0
	 * @param  array $attrs Attributes array.
	 * @return string Attribute string.
	 */
	private function build_attr_string_from_array( $attrs ) {
		if ( empty( $attrs ) || ! is_array( $attrs ) ) {
			return '';
		}

		$attr_string = '';
		foreach ( $attrs as $key => $value ) {
			// Handle array/object values (encode as JSON).
			if ( is_array( $value ) || is_object( $value ) ) {
				$value = wp_json_encode( $value );
			}

			// Convert to string if not already.
			$value = (string) $value;

			// Escape for HTML attribute context.
			$value = esc_attr( $value );

			$attr_string .= ' ' . sanitize_key( $key ) . '="' . $value . '"';
		}

		return $attr_string;
	}

	/**
	 * Convert Divi layout array (_et_pb_page_layout) to shortcodes.
	 *
	 * @since  1.0.0
	 * @param  array $layout_data Layout data from _et_pb_page_layout meta.
	 * @return string Shortcode string.
	 */
	private function convert_layout_array_to_shortcodes( $layout_data ) {
		if ( ! is_array( $layout_data ) ) {
			return '';
		}

		$shortcodes = '';

		// Handle different layout data structures.
		// Structure 1: Direct sections array.
		if ( isset( $layout_data['sections'] ) && is_array( $layout_data['sections'] ) ) {
			$sections = $layout_data['sections'];
		}
		// Structure 2: Root level is sections array.
		elseif ( isset( $layout_data[0] ) && is_array( $layout_data[0] ) ) {
			// Check if first element looks like a section.
			$sections = $layout_data;
		}
		// Structure 3: Single section.
		elseif ( isset( $layout_data['type'] ) && 'et_pb_section' === $layout_data['type'] ) {
			$sections = array( $layout_data );
		}
		// Structure 4: Try to find sections in nested structure.
		else {
			// Look for sections recursively.
			$sections = $this->find_sections_in_array( $layout_data );
		}

		if ( empty( $sections ) ) {
			return '';
		}

		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}

			// Build section shortcode.
			$section_attrs_array = $section['attrs'] ?? $section['attributes'] ?? array();
			$section_attrs = $this->build_attr_string_from_array( $section_attrs_array );
			$section_content = '';

			// Process rows within section.
			if ( ! empty( $section['rows'] ) ) {
				foreach ( $section['rows'] as $row ) {
					$row_attrs_array = $row['attrs'] ?? $row['attributes'] ?? array();
					$row_attrs = $this->build_attr_string_from_array( $row_attrs_array );
					$row_content = '';

					// Process modules within row.
					if ( ! empty( $row['modules'] ) ) {
						foreach ( $row['modules'] as $module ) {
							$module_attrs_array = $module['attrs'] ?? $module['attributes'] ?? array();
							$module_attrs = $this->build_attr_string_from_array( $module_attrs_array );
							$module_content = $module['content'] ?? '';
							$module_type = str_replace( 'et_pb_', '', $module['type'] ?? 'text' );
							$row_content .= '[et_pb_' . $module_type . $module_attrs . ']' . $module_content . '[/et_pb_' . $module_type . ']';
						}
					}

					$section_content .= '[et_pb_row' . $row_attrs . ']' . $row_content . '[/et_pb_row]';
				}
			}
			// Handle direct modules in section (no rows).
			elseif ( ! empty( $section['modules'] ) ) {
				foreach ( $section['modules'] as $module ) {
					$module_attrs_array = $module['attrs'] ?? $module['attributes'] ?? array();
					$module_attrs = $this->build_attr_string_from_array( $module_attrs_array );
					$module_content = $module['content'] ?? '';
					$module_type = str_replace( 'et_pb_', '', $module['type'] ?? 'text' );
					$section_content .= '[et_pb_' . $module_type . $module_attrs . ']' . $module_content . '[/et_pb_' . $module_type . ']';
				}
			}

			$shortcodes .= '[et_pb_section' . $section_attrs . ']' . $section_content . '[/et_pb_section]';
		}

		return $shortcodes;
	}

	/**
	 * Convert JSON layout data to shortcodes.
	 *
	 * @since  1.0.0
	 * @param  array $json_data JSON layout data.
	 * @return string Shortcode string.
	 */
	private function convert_json_to_shortcodes( $json_data ) {
		if ( ! is_array( $json_data ) ) {
			return '';
		}

		// JSON data structure is similar to array layout, so reuse the conversion method.
		return $this->convert_layout_array_to_shortcodes( $json_data );
	}

	/**
	 * Recursively find sections in array structure.
	 *
	 * @since  1.0.0
	 * @param  array $data Array data to search.
	 * @return array Sections found.
	 */
	private function find_sections_in_array( $data ) {
		$sections = array();

		if ( ! is_array( $data ) ) {
			return $sections;
		}

		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				// Check if this is a section.
				if ( isset( $value['type'] ) && 'et_pb_section' === $value['type'] ) {
					$sections[] = $value;
				}
				// Or if key is 'sections'.
				elseif ( 'sections' === $key && is_array( $value ) ) {
					$sections = array_merge( $sections, $value );
				}
				// Recursively search.
				else {
					$found = $this->find_sections_in_array( $value );
					if ( ! empty( $found ) ) {
						$sections = array_merge( $sections, $found );
					}
				}
			}
		}

		return $sections;
	}

	/**
	 * Create a code block.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     CSS content.
	 * @param string $js      JavaScript content.
	 * @return bool|WP_Error True on success.
	 */
	public function create_code_block( $post_id, $html, $css = '', $js = '' ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' )
			);
		}

		// Combine code.
		$combined_code = $html;

		if ( ! empty( $css ) ) {
			$combined_code .= "\n\n<style>\n" . $css . "\n</style>";
		}

		if ( ! empty( $js ) ) {
			$combined_code .= "\n\n<script>\n" . $js . "\n</script>";
		}

		// Create Divi code module shortcode.
		$code_module = '[et_pb_code]' . base64_encode( $combined_code ) . '[/et_pb_code]';

		// Append to existing content.
		$updated_content = $post->post_content . "\n" . $code_module;

		// wp_update_post() internally calls wp_unslash() — wp_slash() preserves
		// backslashes in content (Divi shortcodes and JSON).
		$result = wp_update_post(
			wp_slash(
				array(
					'ID'           => $post_id,
					'post_content' => $updated_content,
				)
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}

	/**
	 * Get documentation.
	 *
	 * @since 1.0.0
	 * @return array Documentation.
	 */
	public function get_documentation() {
		$divi_generation = $this->is_divi5_runtime() ? 'divi5' : 'divi4';

		$documentation = array(
			'name'        => 'Divi Builder',
			'description' => 'Premium drag-and-drop page builder by Elegant Themes',
			'overview'    => 'Divi uses a hierarchical structure: Sections > Rows > Modules. Divi 5 uses block-based storage, Divi 4 uses shortcode storage.',
			'generation'  => $divi_generation,
			'structure'   => array(
				'section' => 'Top-level container (et_pb_section)',
				'row'     => 'Layout container with columns (et_pb_row)',
				'module'  => 'Content element (et_pb_text, et_pb_image, etc.)',
			),
			'specialty_sections' => array(
				'description' => 'Specialty sections allow complex column layouts within sections',
				'usage'       => 'Set specialty="on" attribute on et_pb_section to enable specialty layout',
				'structure'   => 'Specialty sections can contain rows with different column structures',
			),
			'global_modules' => array(
				'description' => 'Global modules are reusable modules stored separately',
				'usage'       => 'Use global_module="123" attribute to reference a global module',
				'benefits'    => 'Update once, changes reflect everywhere the module is used',
			),
			'resources'   => array(
				'https://www.elegantthemes.com/documentation/divi/',
			),
		);

		$available_modules = $this->get_available_modules();
		$documentation['modules'] = array(
			'total'     => count( $available_modules ),
			'available' => array_column( $available_modules, 'name' ),
		);

		// Add module catalog and conservative Divi 5 block support diagnostics.
		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			$all_modules        = Respira_Divi_Module_Registry::get_all_modules();
			$registered_blocks  = Respira_Divi_Module_Registry::get_block_modules();
			$safe_blocks        = Respira_Divi_Module_Registry::get_ai_safe_block_modules();
			$restricted_blocks  = Respira_Divi_Module_Registry::get_ai_restricted_block_modules();
			$documentation['modules']['registered_total'] = count( $all_modules );

			if ( ! empty( $registered_blocks ) ) {
				$documentation['block_support'] = array(
					'mode'                        => 'conservative',
					'registered_blocks'           => array_column( $registered_blocks, 'name' ),
					'safe_default_blocks'         => array_column( $safe_blocks, 'name' ),
					'restricted_registered_blocks'=> array_column( $restricted_blocks, 'name' ),
					'warning'                     => __(
						'Respira advertises only a conservative subset of Divi 5 native blocks by default. Some registered blocks can save or render incorrectly on specific Divi runtimes unless the site explicitly opts in.',
						'respira-for-wordpress'
					),
				);
			}
		}

		// Add layout patterns if available (from Divi Intelligence).
		$patterns_file = RESPIRA_PLUGIN_DIR . 'includes/divi-intelligence/divi-patterns.php';
		if ( file_exists( $patterns_file ) ) {
			require_once $patterns_file;
			if ( function_exists( 'respira_get_divi_patterns' ) ) {
				$patterns = respira_get_divi_patterns();
				$documentation['patterns'] = array(
					'count'    => count( $patterns ),
					'available' => array_keys( $patterns ),
				);
			}
		}

		return $documentation;
	}

	/**
	 * Get available modules.
	 *
	 * @since 1.0.0
	 * @param int|null $tier Deprecated. All modules are now returned regardless of tier.
	 * @return array Available Divi modules.
	 */
	public function get_available_modules( $tier = null ) {
		// Use a conservative AI-safe module list for Divi 5 native blocks.
		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			return Respira_Divi_Module_Registry::get_ai_safe_modules();
		}

		// Fallback to basic list if registry not available.
		return array(
			array(
				'name'        => 'et_pb_section',
				'title'       => 'Section',
				'description' => 'Top-level container',
			),
			array(
				'name'        => 'et_pb_row',
				'title'       => 'Row',
				'description' => 'Column layout container',
			),
			array(
				'name'        => 'et_pb_text',
				'title'       => 'Text',
				'description' => 'Text content module',
			),
			array(
				'name'        => 'et_pb_image',
				'title'       => 'Image',
				'description' => 'Image module',
			),
			array(
				'name'        => 'et_pb_button',
				'title'       => 'Button',
				'description' => 'Button module',
			),
		);
	}

	/**
	 * Get builder schema for AI context.
	 *
	 * @since 1.0.0
	 * @param array $modules_used Optional. Array of module names used on the page.
	 * @return array Builder schema with module information.
	 */
	public function get_builder_schema( $modules_used = array() ) {
		$divi_generation = $this->is_divi5_runtime() ? 'divi5' : 'divi4';

		$schema = array(
			'builder'          => 'divi',
			'builder_version'  => $this->get_version(),
			'generation'       => $divi_generation,
			'available_modules' => array(),
			'quick_reference'  => array(
				'colors'  => 'Use hex format: #0000FF',
				'spacing' => 'Format: 10px|20px|10px|20px (top|right|bottom|left)',
				'sizing'  => 'Use px, em, %, or vw',
				'fonts'   => 'Font names from Google Fonts or system fonts',
			),
		);

		// Get schemas for modules used on the page (or all modules if none specified).
		if ( empty( $modules_used ) ) {
			$all_modules   = $this->get_available_modules();
			$modules_used  = array_column( $all_modules, 'name' );
		} else {
			$modules_used = array_values(
				array_unique(
					array_merge(
						$modules_used,
						array_column( $this->get_available_modules(), 'name' )
					)
				)
			);
		}

		if ( class_exists( 'Respira_Divi_Module_Schema' ) ) {
			$module_schemas = Respira_Divi_Module_Schema::get_module_schemas( $modules_used );
			foreach ( $module_schemas as $module_name => $module_schema ) {
				$schema['available_modules'][ $module_name ] = array(
					'title'       => $module_schema['title'] ?? '',
					'description' => $module_schema['description'] ?? '',
					'common_attributes' => array(),
				);

				// Include common attributes (limit to most important for performance).
				if ( isset( $module_schema['attributes'] ) ) {
					$common_attrs = array( 'text_color', 'background_color', 'content', 'button_text', 'button_url', 'src', 'url' );
					foreach ( $common_attrs as $attr_name ) {
						if ( isset( $module_schema['attributes'][ $attr_name ] ) ) {
							$schema['available_modules'][ $module_name ]['common_attributes'][ $attr_name ] = array(
								'type'    => $module_schema['attributes'][ $attr_name ]['type'] ?? 'string',
								'format'  => $module_schema['attributes'][ $attr_name ]['format'] ?? 'text',
								'example' => $module_schema['attributes'][ $attr_name ]['example'] ?? '',
							);
						}
					}
				}
			}
		}

		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			$safe_blocks       = Respira_Divi_Module_Registry::get_ai_safe_block_modules();
			$restricted_blocks = Respira_Divi_Module_Registry::get_ai_restricted_block_modules();
			if ( ! empty( $safe_blocks ) || ! empty( $restricted_blocks ) ) {
				$schema['safe_mode']                  = 'conservative';
				$schema['safe_default_blocks']        = array_column( $safe_blocks, 'name' );
				$schema['restricted_registered_blocks'] = array_column( $restricted_blocks, 'name' );
				$schema['warnings']                   = array(
					__(
						'Native Divi 5 blocks are advertised conservatively by default. Prefer the safe default block list unless you have verified additional native modules round-trip correctly on this site.',
						'respira-for-wordpress'
					),
				);
			}
		}

		return $schema;
	}

	/**
	 * Parse Divi shortcodes into structured array.
	 *
	 * Uses WordPress's shortcode regex for accurate parsing while handling
	 * nested shortcodes recursively.
	 *
	 * @since  1.0.0
	 * @param  string $content Post content with Divi shortcodes.
	 * @return array  Structured array of modules.
	 */
	private function parse_divi_shortcodes( $content ) {
		$modules = array();

		if ( empty( $content ) ) {
			return $modules;
		}

		// Get all Divi modules dynamically for parsing.
		$divi_modules = array();
		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			$all_modules = Respira_Divi_Module_Registry::get_all_modules();
			$divi_modules = array_column( $all_modules, 'name' );
		}
		
		// If no modules found, use generic pattern that matches all et_pb_* shortcodes.
		if ( empty( $divi_modules ) ) {
			// Use generic pattern that matches any et_pb_* shortcode.
			// Updated pattern to handle self-closing tags and better nested content.
			$pattern = '/\[et_pb_(\w+)([^\]]*?)(?:\s*\/\s*\]|(?:\](.*?)\[\/et_pb_\1\]))/s';
		} else {
			// Use WordPress's shortcode regex with all detected modules.
			$pattern = get_shortcode_regex( $divi_modules );
		}

		// If pattern is empty, fall back to generic Divi pattern.
		if ( empty( $pattern ) ) {
			// Improved pattern: handles self-closing tags, escaped quotes, multi-line content.
			$pattern = '/\[et_pb_(\w+)([^\]]*?)(?:\s*\/\s*\]|(?:\](.*?)\[\/et_pb_\1\]))/s';
		}

		// Match all Divi shortcodes.
		preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER );

		foreach ( $matches as $match ) {
			// Extract module type from first capture group.
			$module_type_raw = isset( $match[1] ) ? $match[1] : '';
			$module_type = 'et_pb_' . $module_type_raw;
			
			// Check if this is a self-closing tag (ends with />).
			$is_self_closing = false;
			$full_match = $match[0] ?? '';
			if ( preg_match( '/\/\s*\]$/', $full_match ) ) {
				$is_self_closing = true;
			}

			// Extract attributes string.
			$attr_string = isset( $match[2] ) ? trim( $match[2] ) : '';
			
			// Extract content (only if not self-closing).
			$module_content = '';
			if ( ! $is_self_closing ) {
				// Try different match indices based on regex pattern used.
				if ( isset( $match[4] ) ) {
					$module_content = $match[4]; // WordPress shortcode regex format.
				} elseif ( isset( $match[3] ) ) {
					$module_content = $match[3]; // Generic pattern format.
				}
			}

			$module = array(
				'type'    => $module_type,
				'attrs'   => $this->parse_shortcode_attrs( $attr_string ),
				'content' => $module_content,
			);

			// Check for nested modules recursively.
			if ( ! empty( $module['content'] ) && preg_match( '/\[et_pb_/', $module['content'] ) ) {
				$nested_modules = $this->parse_divi_shortcodes( $module['content'] );
				
				// Special handling for rows: if children are columns, flatten structure.
				if ( 'et_pb_row' === $module_type ) {
					$column_modules = array();
					$column_widths = array();
					
					foreach ( $nested_modules as $nested ) {
						if ( 'et_pb_column' === $nested['type'] ) {
							// Extract column width from type attribute (e.g., "4_12").
							$column_type = $nested['attrs']['type'] ?? '12_12';
							if ( preg_match( '/(\d+)_12/', $column_type, $matches ) ) {
								$column_widths[] = $matches[1];
							} else {
								$column_widths[] = '12';
							}
							
							// Get modules inside this column.
							if ( ! empty( $nested['children'] ) ) {
								$column_modules = array_merge( $column_modules, $nested['children'] );
							} elseif ( ! empty( $nested['content'] ) && preg_match( '/\[et_pb_/', $nested['content'] ) ) {
								// Parse column content if it contains modules.
								$column_modules = array_merge( $column_modules, $this->parse_divi_shortcodes( $nested['content'] ) );
							}
						} else {
							// Direct child (not a column) - keep as is.
							$column_modules[] = $nested;
						}
					}
					
					// Set column_structure attribute if we found columns.
					if ( ! empty( $column_widths ) ) {
						$module['attrs']['column_structure'] = implode( '_', $column_widths );
					}
					
					$module['children'] = $column_modules;
				} else {
					$module['children'] = $nested_modules;
				}
			}

			$modules[] = $module;
		}

		// If no matches with WordPress pattern, try fallback regex.
		if ( empty( $modules ) ) {
			preg_match_all( '/\[et_pb_(\w+)([^\]]*)\](.*?)\[\/et_pb_\1\]/s', $content, $matches, PREG_SET_ORDER );

		foreach ( $matches as $match ) {
			$module = array(
				'type'    => 'et_pb_' . $match[1],
				'attrs'   => $this->parse_shortcode_attrs( $match[2] ),
				'content' => $match[3],
			);

			// Check for nested modules.
			if ( preg_match( '/\[et_pb_/', $module['content'] ) ) {
				$nested_modules = $this->parse_divi_shortcodes( $module['content'] );
				
				// Special handling for rows: if children are columns, flatten structure.
				if ( 'et_pb_row' === $module['type'] ) {
					$column_modules = array();
					$column_widths = array();
					
					foreach ( $nested_modules as $nested ) {
						if ( 'et_pb_column' === $nested['type'] ) {
							// Extract column width from type attribute (e.g., "4_12").
							$column_type = $nested['attrs']['type'] ?? '12_12';
							if ( preg_match( '/(\d+)_12/', $column_type, $matches ) ) {
								$column_widths[] = $matches[1];
							} else {
								$column_widths[] = '12';
							}
							
							// Get modules inside this column.
							if ( ! empty( $nested['children'] ) ) {
								$column_modules = array_merge( $column_modules, $nested['children'] );
							} elseif ( ! empty( $nested['content'] ) && preg_match( '/\[et_pb_/', $nested['content'] ) ) {
								// Parse column content if it contains modules.
								$column_modules = array_merge( $column_modules, $this->parse_divi_shortcodes( $nested['content'] ) );
							}
						} else {
							// Direct child (not a column) - keep as is.
							$column_modules[] = $nested;
						}
					}
					
					// Set column_structure attribute if we found columns.
					if ( ! empty( $column_widths ) ) {
						$module['attrs']['column_structure'] = implode( '_', $column_widths );
					}
					
					$module['children'] = $column_modules;
				} else {
					$module['children'] = $nested_modules;
				}
			}

			$modules[] = $module;
			}
		}

		return $modules;
	}

	/**
	 * Optimized parsing for very large content (100K+ characters).
	 * Uses simpler regex pattern to avoid catastrophic backtracking.
	 *
	 * @since  1.0.0
	 * @param  string $content Post content with Divi shortcodes.
	 * @return array  Structured array of modules.
	 */
	private function parse_divi_shortcodes_optimized( $content ) {
		// For very large content, use a simpler pattern that avoids backtracking.
		// This pattern matches: [et_pb_module attrs]content[/et_pb_module]
		// Using non-greedy matching and limiting recursion depth.
		$pattern = '/\[et_pb_(\w+)([^\]]*)\](.*?)\[\/et_pb_\1\]/s';
		
		// Set recursion limit to prevent stack overflow on very nested content.
		$recursion_limit = 50;
		return $this->parse_divi_shortcodes_recursive( $content, $pattern, $recursion_limit );
	}

	/**
	 * Recursive parser with depth limit for large content.
	 *
	 * @since  1.0.0
	 * @param  string $content Content to parse.
	 * @param  string $pattern Regex pattern to use.
	 * @param  int    $max_depth Maximum recursion depth.
	 * @return array  Parsed modules.
	 */
	private function parse_divi_shortcodes_recursive( $content, $pattern, $max_depth = 50 ) {
		$modules = array();

		if ( empty( $content ) || $max_depth <= 0 ) {
			return $modules;
		}

		preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER );

		foreach ( $matches as $match ) {
			$module_type_raw = isset( $match[1] ) ? $match[1] : '';
			$module_type = 'et_pb_' . $module_type_raw;
			$attr_string = isset( $match[2] ) ? trim( $match[2] ) : '';
			$module_content = isset( $match[3] ) ? $match[3] : '';

			$module = array(
				'type'    => $module_type,
				'attrs'   => $this->parse_shortcode_attrs( $attr_string ),
				'content' => $module_content,
			);

			// Check for nested modules recursively.
			if ( ! empty( $module['content'] ) && preg_match( '/\[et_pb_/', $module['content'] ) ) {
				$nested_modules = $this->parse_divi_shortcodes_recursive( $module['content'], $pattern, $max_depth - 1 );
				
				// Special handling for rows: if children are columns, flatten structure.
				if ( 'et_pb_row' === $module_type ) {
					$column_modules = array();
					$column_widths = array();
					
					foreach ( $nested_modules as $nested ) {
						if ( 'et_pb_column' === $nested['type'] ) {
							// Extract column width from type attribute (e.g., "4_12").
							$column_type = $nested['attrs']['type'] ?? '12_12';
							if ( preg_match( '/(\d+)_12/', $column_type, $col_matches ) ) {
								$column_widths[] = $col_matches[1];
							} else {
								$column_widths[] = '12';
							}
							
							// Get modules inside this column.
							if ( ! empty( $nested['children'] ) ) {
								$column_modules = array_merge( $column_modules, $nested['children'] );
							} elseif ( ! empty( $nested['content'] ) && preg_match( '/\[et_pb_/', $nested['content'] ) ) {
								// Parse column content if it contains modules.
								$column_modules = array_merge( $column_modules, $this->parse_divi_shortcodes_recursive( $nested['content'], $pattern, $max_depth - 1 ) );
							}
						} else {
							// Direct child (not a column) - keep as is.
							$column_modules[] = $nested;
						}
					}
					
					// Set column_structure attribute if we found columns.
					if ( ! empty( $column_widths ) ) {
						$module['attrs']['column_structure'] = implode( '_', $column_widths );
					}
					
					$module['children'] = $column_modules;
				} else {
					$module['children'] = $nested_modules;
				}
			}

			$modules[] = $module;
		}

		return $modules;
	}

	/**
	 * Parse shortcode attributes.
	 *
	 * Handles attributes with special characters, JSON-encoded values,
	 * and preserves attribute order.
	 *
	 * @since  1.0.0
	 * @param  string $attr_string Attribute string.
	 * @return array  Attributes array.
	 */
	private function parse_shortcode_attrs( $attr_string ) {
		$attrs = array();

		if ( empty( $attr_string ) ) {
			return $attrs;
		}

		// Use WordPress's shortcode_atts parsing if available, but we need to handle
		// the raw attribute string first.
		// Pattern: key="value" or key='value' or key=value
		// Handle both quoted and unquoted values.
		preg_match_all( '/(\w+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s]+)))?/s', $attr_string, $matches, PREG_SET_ORDER );

		foreach ( $matches as $match ) {
			$key = $match[1];
			
			// Get value from whichever capture group matched.
			$value = '';
			if ( ! empty( $match[2] ) ) {
				$value = $match[2]; // Double-quoted.
			} elseif ( ! empty( $match[3] ) ) {
				$value = $match[3]; // Single-quoted.
			} elseif ( ! empty( $match[4] ) ) {
				$value = $match[4]; // Unquoted.
			}

			// Decode HTML entities.
			$value = html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

			// Try to decode JSON if it looks like JSON.
			if ( ! empty( $value ) && ( $value[0] === '{' || $value[0] === '[' ) ) {
				$json_decoded = json_decode( $value, true );
				if ( json_last_error() === JSON_ERROR_NONE ) {
					$value = $json_decoded;
				}
			}

			$attrs[ $key ] = $value;
		}

		return $attrs;
	}

	/**
	 * Build Divi shortcodes from structured array.
	 *
	 * Properly escapes attributes and handles complex attribute values
	 * including arrays and special characters.
	 *
	 * @since  1.0.0
	 * @param  array $modules Structured modules array.
	 * @return string Divi shortcodes.
	 */
	private function build_divi_shortcodes( $modules ) {
		$shortcodes = '';

		foreach ( $modules as $module ) {
			$type     = $module['type'] ?? 'et_pb_text';
			$attrs    = $module['attrs'] ?? ( $module['attributes'] ?? array() );
			$content  = $module['content'] ?? '';
			$children = $module['children'] ?? array();

			// Special handling for rows - always create columns if children exist.
			if ( 'et_pb_row' === $type && ! empty( $children ) ) {
				// Determine column structure.
				$column_structure = '';
				$column_widths = array();

				if ( ! empty( $attrs['column_structure'] ) ) {
					// Use provided column structure (e.g., "4_4_4" = 3 columns of equal width).
					$column_structure = $attrs['column_structure'];
					$column_widths = explode( '_', $column_structure );
				} else {
					// Default: create one column for all children.
					$column_widths = array( '12' );
					$column_structure = '12';
				}

				$num_columns = count( $column_widths );

				// Remove column_structure from row attributes before building attribute string.
				$row_attrs = $attrs;
				unset( $row_attrs['column_structure'] );

				// Build row attribute string.
				$attr_string = '';
				foreach ( $row_attrs as $key => $value ) {
					if ( is_array( $value ) || is_object( $value ) ) {
						$value = wp_json_encode( $value );
					}
					$value = (string) $value;
					$value = esc_attr( $value );
					$attr_string .= ' ' . sanitize_key( $key ) . '="' . $value . '"';
				}

				// Add column_structure as a real attribute for Divi.
				if ( ! empty( $column_structure ) ) {
					$attr_string .= ' column_structure="' . esc_attr( $column_structure ) . '"';
				}

				// Build row opening tag.
				$shortcodes .= '[et_pb_row' . $attr_string . ']';

				// Distribute children across columns.
				// If we have exactly N children and N columns, put one per column.
				// Otherwise, distribute evenly (round-robin).
				$children_per_column = array();
				$num_children = count( $children );

				if ( $num_children === $num_columns ) {
					// One child per column.
					foreach ( $children as $index => $child ) {
						$children_per_column[ $index ] = array( $child );
					}
				} else {
					// Distribute evenly across columns.
					$current_column = 0;
					foreach ( $children as $child ) {
						if ( ! isset( $children_per_column[ $current_column ] ) ) {
							$children_per_column[ $current_column ] = array();
						}
						$children_per_column[ $current_column ][] = $child;
						$current_column = ( $current_column + 1 ) % $num_columns;
					}
				}

				// Create column modules and add children.
				foreach ( $children_per_column as $column_index => $column_children ) {
					$column_width = isset( $column_widths[ $column_index ] ) ? $column_widths[ $column_index ] : '12';
					
					// Create column module with width attribute (format: "4_12" means 4/12 = 1/3 width).
					$shortcodes .= '[et_pb_column type="' . esc_attr( $column_width ) . '_12"]';

					// Add children to this column.
					if ( ! empty( $column_children ) ) {
						$shortcodes .= $this->build_divi_shortcodes( $column_children );
					}

					$shortcodes .= '[/et_pb_column]';
				}

				// Close row.
				$shortcodes .= '[/et_pb_row]' . "\n";
				continue;
			}

			// Build attribute string with proper escaping.
			$attr_string = '';
			foreach ( $attrs as $key => $value ) {
				// Handle array/object values (encode as JSON).
				if ( is_array( $value ) || is_object( $value ) ) {
					$value = wp_json_encode( $value );
				}

				// Convert to string if not already.
				$value = (string) $value;

				// Escape for HTML attribute context.
				$value = esc_attr( $value );

				$attr_string .= ' ' . sanitize_key( $key ) . '="' . $value . '"';
			}

			// Build shortcode opening tag.
			$shortcodes .= '[' . sanitize_key( $type ) . $attr_string . ']';

			// Add children if present (nested modules).
			if ( ! empty( $children ) ) {
				$shortcodes .= $this->build_divi_shortcodes( $children );
			} else {
				// Add content (may contain HTML, scripts, etc.).
				// Content is already in the format Divi expects.
				$shortcodes .= $content;
			}

			// Close shortcode tag.
			$shortcodes .= '[/' . sanitize_key( $type ) . ']' . "\n";
		}

		return $shortcodes;
	}

	/**
	 * Simplify Divi structure for AI.
	 *
	 * @since  1.0.0
	 * @param  array $modules Parsed modules.
	 * @return array Simplified structure.
	 */
	protected function simplify_structure( $modules ) {
		// Divi structure is already relatively simple, just ensure consistency.
		return array_map(
			function( $module ) {
				$simplified = array(
					'type'       => $module['type'],
					'attributes' => $module['attrs'],
					'content'    => $module['content'],
					'children'   => isset( $module['children'] ) ? $this->simplify_structure( $module['children'] ) : array(),
				);

				// Add admin_label to top level for easier module identification.
				if ( ! empty( $module['attrs']['admin_label'] ) ) {
					$simplified['admin_label'] = $module['attrs']['admin_label'];
				}

				return $simplified;
			},
			$modules
		);
	}

	/**
	 * Find a module by admin_label, path, or type+content match.
	 *
	 * For type+match_content, returns WP_Error if multiple modules match (ambiguous).
	 *
	 * @since 1.0.0
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier: 'admin_label', 'path', or 'type'.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional. Content to match when using type identifier.
	 * @return array|false|WP_Error Module data with path, false if not found, or WP_Error if ambiguous.
	 */
	public function find_module( $structure, $identifier_type, $identifier_value, $match_content = '' ) {
		$path = array();

		// For type+match_content, collect ALL matches to detect ambiguity.
		if ( 'type' === $identifier_type && ! empty( $match_content ) ) {
			$all_matches = array();
			$this->find_all_matching_modules( $structure, $identifier_type, $identifier_value, $match_content, $path, $all_matches );

			if ( empty( $all_matches ) ) {
				return false;
			}
			if ( count( $all_matches ) === 1 ) {
				return $all_matches[0];
			}

			// Multiple matches — return WP_Error with candidate paths.
			$candidates = array_map(
				function ( $m ) {
					return $m['path_string'];
				},
				$all_matches
			);
			return new \WP_Error(
				'respira_ambiguous_match',
				sprintf(
					__( 'match_content "%s" matched %d modules. Use a unique substring or specify a path.', 'respira-for-wordpress' ),
					$match_content,
					count( $all_matches )
				),
				array(
					'status'     => 409,
					'candidates' => $candidates,
				)
			);
		}

		return $this->find_module_recursive( $structure, $identifier_type, $identifier_value, $match_content, $path );
	}

	/**
	 * Collect all modules matching the identifier (for ambiguity detection).
	 *
	 * @since 5.0.8
	 */
	private function find_all_matching_modules( $modules, $identifier_type, $identifier_value, $match_content, $current_path, &$results ) {
		foreach ( $modules as $index => $module ) {
			$module_path = array_merge( $current_path, array( $index ) );

			if ( $this->module_matches_type( $module, $identifier_value, $match_content ) ) {
				$results[] = array(
					'module'      => $module,
					'path'        => $module_path,
					'path_string' => $this->build_path_string( $module_path ),
				);
			}

			if ( ! empty( $module['children'] ) ) {
				$this->find_all_matching_modules( $module['children'], $identifier_type, $identifier_value, $match_content, $module_path, $results );
			}
		}
	}

	/**
	 * Check if a module matches a type + optional content substring.
	 *
	 * Checks both the simplified 'content' field AND attrs.content.innerContent.desktop.value
	 * to avoid misses when the simplified content is empty.
	 *
	 * @since 5.0.8
	 */
	private function module_matches_type( $module, $type_value, $match_content ) {
		$module_type = $module['type'] ?? '';
		if ( $module_type !== $type_value ) {
			return false;
		}
		if ( empty( $match_content ) ) {
			return true;
		}

		// Check simplified content field.
		$content = $module['content'] ?? '';
		if ( ! empty( $content ) && strpos( $content, $match_content ) !== false ) {
			return true;
		}

		// Also check the Divi 5 attrs content path (in case simplified content is empty/stale).
		$attrs_content = $module['attributes']['content']['innerContent']['desktop']['value']
			?? $module['attrs']['content']['innerContent']['desktop']['value']
			?? '';
		if ( ! empty( $attrs_content ) && strpos( $attrs_content, $match_content ) !== false ) {
			return true;
		}

		return false;
	}

	/**
	 * Recursively find a module in the structure.
	 *
	 * @since 1.0.0
	 * @param array  $modules Module structure to search.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional content match.
	 * @param array  $current_path Current path in structure.
	 * @return array|false Module with path or false.
	 */
	private function find_module_recursive( $modules, $identifier_type, $identifier_value, $match_content, $current_path ) {
		foreach ( $modules as $index => $module ) {
			$module_path = array_merge( $current_path, array( $index ) );
			$match = false;

			switch ( $identifier_type ) {
				case 'admin_label':
					$admin_label = $module['attributes']['admin_label'] ?? $module['attrs']['admin_label'] ?? $module['admin_label'] ?? '';
					if ( $admin_label === $identifier_value ) {
						$match = true;
					}
					break;

				case 'path':
					$path_indices = $this->parse_path_string( $identifier_value );
					if ( $module_path === $path_indices ) {
						$match = true;
					}
					break;

				case 'type':
					$match = $this->module_matches_type( $module, $identifier_value, $match_content );
					break;
			}

			if ( $match ) {
				return array(
					'module' => $module,
					'path' => $module_path,
					'path_string' => $this->build_path_string( $module_path ),
				);
			}

			// Search in children.
			if ( ! empty( $module['children'] ) ) {
				$result = $this->find_module_recursive( $module['children'], $identifier_type, $identifier_value, $match_content, $module_path );
				if ( $result ) {
					return $result;
				}
			}
		}

		return false;
	}

	/**
	 * Parse a path string into an array of integer indices.
	 *
	 * Supports bracket format: "sections[0].rows[0].modules[2]"
	 * and dot-index format: "0.0.0.0.0"
	 *
	 * @since 5.0.8
	 */
	private function parse_path_string( $path_string ) {
		// Dot-index format: all segments are plain integers (e.g. "0.0.0.0.0").
		$parts = explode( '.', $path_string );
		$all_numeric = true;
		foreach ( $parts as $part ) {
			if ( ! ctype_digit( $part ) ) {
				$all_numeric = false;
				break;
			}
		}
		if ( $all_numeric && count( $parts ) > 1 ) {
			return array_map( 'intval', $parts );
		}

		// Bracket format: "sections[0].rows[0].modules[2]".
		$path_indices = array();
		foreach ( $parts as $part ) {
			if ( preg_match( '/\[(\d+)\]/', $part, $matches ) ) {
				$path_indices[] = (int) $matches[1];
			}
		}
		return $path_indices;
	}

	/**
	 * Build path string from array indices.
	 *
	 * @since 1.0.0
	 * @param array $path Array of indices.
	 * @return string Path string like "sections[0].rows[0].modules[2]".
	 */
	private function build_path_string( $path ) {
		if ( empty( $path ) ) {
			return '';
		}

		$parts = array();
		$level = 0;
		foreach ( $path as $index ) {
			if ( $level === 0 ) {
				$parts[] = 'sections[' . $index . ']';
			} elseif ( $level === 1 ) {
				$parts[] = 'rows[' . $index . ']';
			} else {
				$parts[] = 'modules[' . $index . ']';
			}
			$level++;
		}

		return implode( '.', $parts );
	}

	/**
	 * Update a specific module in the structure.
	 *
	 * @since 1.0.0
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param array  $updates Updates to apply (content, attributes).
	 * @return array|WP_Error Updated structure or error.
	 */
	public function update_module( $structure, $identifier_type, $identifier_value, $updates ) {
		$found = $this->find_module( $structure, $identifier_type, $identifier_value, $updates['match_content'] ?? '' );

		if ( is_wp_error( $found ) ) {
			return $found;
		}

		if ( ! $found ) {
			return new WP_Error(
				'respira_module_not_found',
				sprintf(
					/* translators: 1: identifier type, 2: identifier value */
					__( 'Module not found with %1$s: %2$s', 'respira-for-wordpress' ),
					$identifier_type,
					$identifier_value
				),
				array(
					'identifier_type' => $identifier_type,
					'identifier_value' => $identifier_value,
				)
			);
		}

		$path = $found['path'];
		$updated_structure = $structure;

		// Navigate to the module in the structure.
		$current = &$updated_structure;
		$path_length = count( $path );
		foreach ( $path as $path_index => $index ) {
			if ( ! isset( $current[ $index ] ) ) {
				return new WP_Error(
					'respira_module_path_invalid',
					__( 'Invalid module path in structure', 'respira-for-wordpress' ),
					array( 'path' => $path )
				);
			}
			
			// If not the last index, navigate into children.
			if ( $path_index < $path_length - 1 ) {
				$current = &$current[ $index ];
				// Navigate to children if they exist.
				if ( isset( $current['children'] ) ) {
					$current = &$current['children'];
				} else {
					// Create children array if it doesn't exist (shouldn't happen normally).
					$current['children'] = array();
					$current = &$current['children'];
				}
			} else {
				// Last index - this is the target module.
				$current = &$current[ $index ];
			}
		}

		$target_type = $current['type'] ?? '';
		if ( $this->is_legacy_wrapper_node( $target_type, $current ) ) {
			if ( isset( $updates['content'] ) || isset( $updates['attributes'] ) ) {
				return new WP_Error(
					'respira_legacy_module_opaque',
					__( 'Legacy/shortcode wrapper modules are treated as opaque. Use move/delete operations instead of deep edits.', 'respira-for-wordpress' ),
					array(
						'type' => $target_type,
						'path' => $path,
					)
				);
			}
		}

		// Apply updates.
		if ( isset( $updates['content'] ) ) {
			$current['content'] = $updates['content'];

			// Divi 5: also update the attribute path where the real content lives.
			if ( isset( $current['attributes']['content']['innerContent']['desktop']['value'] ) ) {
				$current['attributes']['content']['innerContent']['desktop']['value'] = $updates['content'];
				$current['attrs']['content']['innerContent']['desktop']['value'] = $updates['content'];
			}
		}

		if ( isset( $updates['attributes'] ) && is_array( $updates['attributes'] ) ) {
			$current['attributes'] = array_merge( $current['attributes'] ?? array(), $updates['attributes'] );
			// Also update attrs for backward compatibility.
			$current['attrs'] = $current['attributes'];
		}

		return $updated_structure;
	}

	/**
	 * Detect legacy wrapper nodes that should remain opaque.
	 *
	 * @since 1.9.2
	 * @param string $type Module type.
	 * @param array  $module Module node.
	 * @return bool
	 */
	private function is_legacy_wrapper_node( $type, $module ) {
		if ( 'core/shortcode' === $type ) {
			return true;
		}

		if ( strpos( $type, 'legacy' ) !== false || strpos( $type, 'shortcode' ) !== false ) {
			return true;
		}

		$content = $module['content'] ?? '';
		return is_string( $content ) && strpos( $content, '[et_pb_' ) !== false;
	}
}
