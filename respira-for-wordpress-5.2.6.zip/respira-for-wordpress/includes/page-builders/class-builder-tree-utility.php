<?php
/**
 * Generic tree traversal utility for builder content structures.
 *
 * Provides find, clone, move, and remove operations on builder element trees.
 * Builder-agnostic: caller passes the children key name (e.g. 'elements',
 * 'children', 'inner_blocks') to adapt to each builder's format.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Tree utility for builder content structures.
 *
 * @since 5.2.0
 */
class Respira_Builder_Tree_Utility {

	/**
	 * Maximum recursion depth to prevent stack overflow from circular references.
	 *
	 * @since 5.2.0
	 * @var int
	 */
	const MAX_DEPTH = 50;

	/**
	 * Find an element in the tree by identifier.
	 *
	 * @since 5.2.0
	 * @param array  $tree            The content tree (array of elements).
	 * @param string $identifier_type How to identify: 'id', 'admin_label', 'path', 'type'.
	 * @param string $identifier      The value to search for.
	 * @param string $children_key    Key for nested elements ('elements', 'children', 'inner_blocks').
	 * @param string $match_content   Optional. For 'type' search, also match content containing this string.
	 * @return array|null Found element with '_path' key added, or null.
	 */
	public static function find(
		array $tree,
		$identifier_type,
		$identifier,
		$children_key = 'elements',
		$match_content = null
	) {
		return self::find_recursive( $tree, $identifier_type, $identifier, $children_key, $match_content, array(), 0 );
	}

	/**
	 * Find all elements matching a condition.
	 *
	 * @since 5.2.0
	 * @param array    $tree         The content tree.
	 * @param callable $predicate    Function($element) => bool.
	 * @param string   $children_key Key for nested elements.
	 * @return array Array of matching elements, each with '_path' key.
	 */
	public static function find_all( array $tree, callable $predicate, $children_key = 'elements' ) {
		$results = array();
		self::walk( $tree, $children_key, function ( $element, $path ) use ( $predicate, &$results ) {
			if ( call_user_func( $predicate, $element ) ) {
				$element['_path'] = $path;
				$results[]        = $element;
			}
		} );
		return $results;
	}

	/**
	 * Walk the entire tree, calling a visitor on each element.
	 *
	 * @since 5.2.0
	 * @param array    $tree         The content tree.
	 * @param string   $children_key Key for nested elements.
	 * @param callable $visitor      Function($element, $path, $depth).
	 * @param array    $path         Current path (internal).
	 * @param int      $depth        Current depth (internal).
	 */
	public static function walk( array $tree, $children_key, callable $visitor, array $path = array(), $depth = 0 ) {
		if ( $depth > self::MAX_DEPTH ) {
			return;
		}

		foreach ( $tree as $index => $element ) {
			$current_path = array_merge( $path, array( $index ) );
			call_user_func( $visitor, $element, $current_path, $depth );

			$children = isset( $element[ $children_key ] ) && is_array( $element[ $children_key ] )
				? $element[ $children_key ]
				: array();

			if ( ! empty( $children ) ) {
				self::walk( $children, $children_key, $visitor, $current_path, $depth + 1 );
			}
		}
	}

	/**
	 * Count all elements in the tree.
	 *
	 * @since 5.2.0
	 * @param array  $tree         The content tree.
	 * @param string $children_key Key for nested elements.
	 * @return int Total element count.
	 */
	public static function count_elements( array $tree, $children_key = 'elements' ) {
		$count = 0;
		self::walk( $tree, $children_key, function () use ( &$count ) {
			$count++;
		} );
		return $count;
	}

	/**
	 * Remove an element from the tree by path.
	 *
	 * @since 5.2.0
	 * @param array  $tree         The content tree (modified in place via return).
	 * @param array  $path         Path to the element (array of indices).
	 * @param string $children_key Key for nested elements.
	 * @return array The modified tree.
	 */
	public static function remove( array $tree, array $path, $children_key = 'elements' ) {
		if ( empty( $path ) ) {
			return $tree;
		}

		if ( 1 === count( $path ) ) {
			array_splice( $tree, $path[0], 1 );
			return $tree;
		}

		$index     = array_shift( $path );
		$remaining = $path;

		if ( ! isset( $tree[ $index ] ) ) {
			return $tree;
		}

		$children = isset( $tree[ $index ][ $children_key ] ) && is_array( $tree[ $index ][ $children_key ] )
			? $tree[ $index ][ $children_key ]
			: array();

		$tree[ $index ][ $children_key ] = self::remove( $children, $remaining, $children_key );

		return $tree;
	}

	/**
	 * Insert an element into the tree at a specific container and position.
	 *
	 * @since 5.2.0
	 * @param array  $tree              The content tree.
	 * @param array  $container_path    Path to the target container.
	 * @param array  $element           The element to insert.
	 * @param int    $position          Position within container's children. -1 = append.
	 * @param string $children_key      Key for nested elements.
	 * @return array The modified tree.
	 */
	public static function insert( array $tree, array $container_path, array $element, $position = -1, $children_key = 'elements' ) {
		if ( empty( $container_path ) ) {
			// Insert at root level.
			if ( -1 === $position || $position >= count( $tree ) ) {
				$tree[] = $element;
			} else {
				array_splice( $tree, max( 0, $position ), 0, array( $element ) );
			}
			return $tree;
		}

		$index     = array_shift( $container_path );
		$remaining = $container_path;

		if ( ! isset( $tree[ $index ] ) ) {
			return $tree;
		}

		if ( empty( $remaining ) ) {
			// This is the container — insert into its children.
			if ( ! isset( $tree[ $index ][ $children_key ] ) || ! is_array( $tree[ $index ][ $children_key ] ) ) {
				$tree[ $index ][ $children_key ] = array();
			}

			$children = &$tree[ $index ][ $children_key ];
			if ( -1 === $position || $position >= count( $children ) ) {
				$children[] = $element;
			} else {
				array_splice( $children, max( 0, $position ), 0, array( $element ) );
			}
			return $tree;
		}

		$children = isset( $tree[ $index ][ $children_key ] ) && is_array( $tree[ $index ][ $children_key ] )
			? $tree[ $index ][ $children_key ]
			: array();

		$tree[ $index ][ $children_key ] = self::insert( $children, $remaining, $element, $position, $children_key );

		return $tree;
	}

	/**
	 * Deep clone an element, generating new IDs for all nested elements.
	 *
	 * @since 5.2.0
	 * @param array  $element     The element to clone.
	 * @param string $children_key Key for nested elements.
	 * @param string $id_key       Key for element IDs (e.g. 'id'). Null to skip ID regeneration.
	 * @param int    $depth        Current depth (internal).
	 * @return array The cloned element with new IDs.
	 */
	public static function clone_with_new_ids( array $element, $children_key = 'elements', $id_key = 'id', $depth = 0 ) {
		if ( $depth > self::MAX_DEPTH ) {
			return $element;
		}

		$cloned = $element;

		// Generate new ID if the element has one.
		if ( null !== $id_key && isset( $cloned[ $id_key ] ) ) {
			$cloned[ $id_key ] = wp_generate_uuid4();
		}

		// Remove internal path marker if present.
		unset( $cloned['_path'] );

		// Recursively clone children.
		if ( isset( $cloned[ $children_key ] ) && is_array( $cloned[ $children_key ] ) ) {
			$cloned[ $children_key ] = array_map(
				function ( $child ) use ( $children_key, $id_key, $depth ) {
					return self::clone_with_new_ids( $child, $children_key, $id_key, $depth + 1 );
				},
				$cloned[ $children_key ]
			);
		}

		return $cloned;
	}

	/**
	 * Update an element at a given path with new data.
	 *
	 * @since 5.2.0
	 * @param array  $tree         The content tree.
	 * @param array  $path         Path to the element.
	 * @param array  $updates      Key-value pairs to merge into the element.
	 * @param string $children_key Key for nested elements.
	 * @return array The modified tree.
	 */
	public static function update_at( array $tree, array $path, array $updates, $children_key = 'elements' ) {
		if ( empty( $path ) ) {
			return $tree;
		}

		if ( 1 === count( $path ) ) {
			$index = $path[0];
			if ( isset( $tree[ $index ] ) ) {
				$tree[ $index ] = array_merge( $tree[ $index ], $updates );
			}
			return $tree;
		}

		$index     = array_shift( $path );
		$remaining = $path;

		if ( ! isset( $tree[ $index ] ) ) {
			return $tree;
		}

		$children = isset( $tree[ $index ][ $children_key ] ) && is_array( $tree[ $index ][ $children_key ] )
			? $tree[ $index ][ $children_key ]
			: array();

		$tree[ $index ][ $children_key ] = self::update_at( $children, $remaining, $updates, $children_key );

		return $tree;
	}

	/**
	 * Reorder children of a container.
	 *
	 * @since 5.2.0
	 * @param array  $tree           The content tree.
	 * @param array  $container_path Path to the container (empty = root).
	 * @param array  $new_order      Array of current indices in desired order (e.g. [2, 0, 1]).
	 * @param string $children_key   Key for nested elements.
	 * @return array|WP_Error The modified tree, or WP_Error on invalid order.
	 */
	public static function reorder( array $tree, array $container_path, array $new_order, $children_key = 'elements' ) {
		$container = self::get_at( $tree, $container_path, $children_key );

		if ( null === $container && ! empty( $container_path ) ) {
			return new WP_Error( 'respira_container_not_found', 'Container not found at given path.' );
		}

		$children = empty( $container_path )
			? $tree
			: ( isset( $container[ $children_key ] ) && is_array( $container[ $children_key ] ) ? $container[ $children_key ] : array() );

		if ( count( $new_order ) !== count( $children ) ) {
			return new WP_Error(
				'respira_reorder_count_mismatch',
				sprintf( 'Order array has %d items but container has %d children.', count( $new_order ), count( $children ) )
			);
		}

		$reordered = array();
		foreach ( $new_order as $old_index ) {
			if ( ! isset( $children[ $old_index ] ) ) {
				return new WP_Error(
					'respira_reorder_invalid_index',
					sprintf( 'Index %d does not exist in container.', $old_index )
				);
			}
			$reordered[] = $children[ $old_index ];
		}

		if ( empty( $container_path ) ) {
			return $reordered;
		}

		return self::set_children_at( $tree, $container_path, $reordered, $children_key );
	}

	/**
	 * Get an element at a specific path.
	 *
	 * @since 5.2.0
	 * @param array  $tree         The content tree.
	 * @param array  $path         Path to the element.
	 * @param string $children_key Key for nested elements.
	 * @return array|null The element, or null if not found.
	 */
	public static function get_at( array $tree, array $path, $children_key = 'elements' ) {
		if ( empty( $path ) ) {
			return null;
		}

		$index = array_shift( $path );

		if ( ! isset( $tree[ $index ] ) ) {
			return null;
		}

		if ( empty( $path ) ) {
			return $tree[ $index ];
		}

		$children = isset( $tree[ $index ][ $children_key ] ) && is_array( $tree[ $index ][ $children_key ] )
			? $tree[ $index ][ $children_key ]
			: array();

		return self::get_at( $children, $path, $children_key );
	}

	/**
	 * Recursive find implementation.
	 *
	 * @param array       $tree            The content tree.
	 * @param string      $identifier_type Identifier type.
	 * @param string      $identifier      Identifier value.
	 * @param string      $children_key    Children key.
	 * @param string|null $match_content   Optional content match.
	 * @param array       $path            Current path.
	 * @param int         $depth           Current depth.
	 * @return array|null
	 */
	private static function find_recursive( array $tree, $identifier_type, $identifier, $children_key, $match_content, array $path, $depth ) {
		if ( $depth > self::MAX_DEPTH ) {
			return null;
		}

		foreach ( $tree as $index => $element ) {
			$current_path = array_merge( $path, array( $index ) );

			if ( self::matches( $element, $identifier_type, $identifier, $match_content ) ) {
				$element['_path'] = $current_path;
				return $element;
			}

			$children = isset( $element[ $children_key ] ) && is_array( $element[ $children_key ] )
				? $element[ $children_key ]
				: array();

			if ( ! empty( $children ) ) {
				$found = self::find_recursive( $children, $identifier_type, $identifier, $children_key, $match_content, $current_path, $depth + 1 );
				if ( null !== $found ) {
					return $found;
				}
			}
		}

		return null;
	}

	/**
	 * Check if an element matches the identifier.
	 *
	 * @param array       $element         The element.
	 * @param string      $identifier_type Identifier type.
	 * @param string      $identifier      Identifier value.
	 * @param string|null $match_content   Optional content match.
	 * @return bool
	 */
	private static function matches( array $element, $identifier_type, $identifier, $match_content ) {
		switch ( $identifier_type ) {
			case 'id':
				return isset( $element['id'] ) && (string) $element['id'] === (string) $identifier;

			case 'admin_label':
				return isset( $element['admin_label'] ) && strtolower( $element['admin_label'] ) === strtolower( $identifier );

			case 'path':
				// Path matching is handled externally via get_at().
				return false;

			case 'type':
				$type_match = false;
				if ( isset( $element['type'] ) && strtolower( $element['type'] ) === strtolower( $identifier ) ) {
					$type_match = true;
				}
				if ( isset( $element['widget'] ) && strtolower( $element['widget'] ) === strtolower( $identifier ) ) {
					$type_match = true;
				}

				if ( ! $type_match ) {
					return false;
				}

				if ( null !== $match_content ) {
					$content = isset( $element['content'] ) ? $element['content'] : '';
					return false !== stripos( $content, $match_content );
				}

				return true;

			case 'content':
				$content = isset( $element['content'] ) ? $element['content'] : '';
				if ( '' === $content ) {
					return false;
				}
				return false !== stripos( $content, $identifier );

			case 'class':
				$classes = '';
				if ( isset( $element['attributes']['class'] ) ) {
					$classes = $element['attributes']['class'];
				} elseif ( isset( $element['attributes']['_css_classes'] ) ) {
					$classes = $element['attributes']['_css_classes'];
				} elseif ( isset( $element['attributes']['custom_css_class'] ) ) {
					$classes = $element['attributes']['custom_css_class'];
				} elseif ( isset( $element['settings']['className'] ) ) {
					$classes = $element['settings']['className'];
				}
				if ( '' === $classes ) {
					return false;
				}
				return false !== stripos( $classes, $identifier );

			default:
				return false;
		}
	}

	/**
	 * Set children of a container at a given path.
	 *
	 * @param array  $tree         The content tree.
	 * @param array  $path         Path to the container.
	 * @param array  $new_children The new children array.
	 * @param string $children_key Key for nested elements.
	 * @return array The modified tree.
	 */
	private static function set_children_at( array $tree, array $path, array $new_children, $children_key ) {
		if ( empty( $path ) ) {
			return $new_children;
		}

		if ( 1 === count( $path ) ) {
			$index = $path[0];
			if ( isset( $tree[ $index ] ) ) {
				$tree[ $index ][ $children_key ] = $new_children;
			}
			return $tree;
		}

		$index     = array_shift( $path );
		$remaining = $path;

		if ( ! isset( $tree[ $index ] ) ) {
			return $tree;
		}

		$children = isset( $tree[ $index ][ $children_key ] ) && is_array( $tree[ $index ][ $children_key ] )
			? $tree[ $index ][ $children_key ]
			: array();

		$tree[ $index ][ $children_key ] = self::set_children_at( $children, $remaining, $new_children, $children_key );

		return $tree;
	}
}
