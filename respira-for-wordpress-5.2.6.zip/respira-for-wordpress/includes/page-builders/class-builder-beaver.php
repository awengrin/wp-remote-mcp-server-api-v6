<?php
/**
 * Beaver Builder implementation.
 *
 * Beaver Builder stores page data as a flat associative array keyed by
 * generated node IDs (e.g. "jk2l3m4n"). Each node has a `type`
 * (row, column-group, column, module) and a `parent` reference to its
 * parent node ID. Modules additionally store their widget type inside
 * `settings.type` (e.g. "text-editor", "html", "heading").
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 * @since      1.3.0
 */

/**
 * Beaver Builder class (PRO feature).
 *
 * @since 1.3.0
 */
class Respira_Builder_Beaver extends Respira_Builder_Interface {

	/**
	 * Detect if Beaver Builder is active.
	 *
	 * @since 1.3.0
	 * @return bool True if Beaver Builder is active.
	 */
	public function detect() {
		return class_exists( 'FLBuilder' )
			|| class_exists( 'FLBuilderModel' )
			|| defined( 'FL_BUILDER_VERSION' )
			|| get_option( '_fl_builder_version', false );
	}

	/**
	 * Get builder name.
	 *
	 * @since 1.3.0
	 * @return string Builder name.
	 */
	public function get_name() {
		return 'Beaver Builder';
	}

	/**
	 * Get builder version.
	 *
	 * @since 1.3.0
	 * @return string Builder version.
	 */
	public function get_version() {
		return defined( 'FL_BUILDER_VERSION' ) ? FL_BUILDER_VERSION : 'unknown';
	}

	/**
	 * Check if post uses Beaver Builder.
	 *
	 * @since 1.3.0
	 * @param int $post_id Post ID.
	 * @return bool True if uses Beaver Builder.
	 */
	public function is_builder_used( $post_id ) {
		$data = get_post_meta( $post_id, '_fl_builder_data', true );
		return ! empty( $data );
	}

	/**
	 * Extract content from post.
	 *
	 * @since 1.3.0
	 * @param int $post_id Post ID.
	 * @return array Simplified nested tree.
	 */
	public function extract_content( $post_id ) {
		$start = microtime( true );

		$data = get_post_meta( $post_id, '_fl_builder_data', true );

		if ( empty( $data ) ) {
			return array();
		}

		$nodes = is_string( $data ) ? json_decode( $data, true ) : $data;

		if ( ! is_array( $nodes ) ) {
			return array();
		}

		$result = $this->simplify_structure( $nodes );

		$this->log_performance( 'extract', $post_id, microtime( true ) - $start );

		return $result;
	}

	/**
	 * Inject content into post.
	 *
	 * @since 1.3.0
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified content tree.
	 * @return bool|WP_Error True on success.
	 */
	public function inject_content( $post_id, $content, $skip_structure_validation = false ) {
		$start = microtime( true );

		// Decode JSON string payloads.
		if ( is_string( $content ) ) {
			$decoded = json_decode( $content, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
				$content = $decoded;
			}
		}

		// Normalize alternate payload shapes (e.g. {modules:[...]}, {elements:[...]}).
		$content = $this->normalize_incoming_content( $content );

		// Convert simplified structure back to Beaver Builder flat node map.
		$flat_nodes = $this->complexify_structure( $content );

		// Validate with intelligence if available.
		// Skip validation for module updates — the structure came from extract_content()
		// (already valid) and only targeted modifications were applied.
		if ( ! $skip_structure_validation && class_exists( 'Respira_Beaver_Validator' ) ) {
			$validator = new Respira_Beaver_Validator();
			$validation = $validator->validate_layout( $flat_nodes );

			if ( ! $validation['valid'] ) {
				$this->log_performance( 'inject', $post_id, microtime( true ) - $start );
				$error_details = implode( '; ', array_slice( $validation['errors'], 0, 5 ) );
				return new WP_Error(
					'validation_failed',
					sprintf(
						/* translators: %s: validation error details */
						__( 'Content validation failed: %s', 'respira-for-wordpress' ),
						$error_details
					),
					array( 'errors' => $validation['errors'] )
				);
			}
		}

		// Update postmeta — BB stores data as PHP-serialized stdClass objects, not JSON.
		// WordPress's update_post_meta handles serialization automatically.
		update_post_meta( $post_id, '_fl_builder_data', $flat_nodes );
		update_post_meta( $post_id, '_fl_builder_enabled', '1' );
		update_post_meta( $post_id, '_fl_builder_draft', '' );

		// Clear Beaver Builder cache.
		if ( class_exists( 'FLBuilder' ) && method_exists( 'FLBuilder', 'delete_all_asset_cache' ) ) {
			FLBuilder::delete_all_asset_cache( $post_id );
		}

		$this->log_performance( 'inject', $post_id, microtime( true ) - $start );

		return true;
	}

	/**
	 * Create a code block with proper Beaver Builder row > column-group > column > module hierarchy.
	 *
	 * @since 1.3.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     CSS content.
	 * @param string $js      JavaScript content.
	 * @return bool|WP_Error True on success.
	 */
	public function create_code_block( $post_id, $html, $css = '', $js = '' ) {
		$data = get_post_meta( $post_id, '_fl_builder_data', true );
		$nodes = array();

		if ( ! empty( $data ) ) {
			$nodes = is_string( $data ) ? json_decode( $data, true ) : $data;
			if ( ! is_array( $nodes ) ) {
				$nodes = array();
			}
		}

		// Combine code.
		$combined_code = $html;
		if ( ! empty( $css ) ) {
			$combined_code .= "\n\n<style>\n" . $css . "\n</style>";
		}
		if ( ! empty( $js ) ) {
			$combined_code .= "\n\n<script>\n" . $js . "\n</script>";
		}

		// Generate unique node IDs.
		$row_id    = $this->generate_node_id();
		$colgrp_id = $this->generate_node_id();
		$col_id    = $this->generate_node_id();
		$mod_id    = $this->generate_node_id();

		// Build the row > column-group > column > module hierarchy.
		// BB stores each node as stdClass with settings as stdClass.
		$row          = new stdClass();
		$row->node     = $row_id;
		$row->type     = 'row';
		$row->parent   = null;
		$row->position = $this->get_next_position( $nodes, null );
		$row->settings = new stdClass();
		$nodes[ $row_id ] = $row;

		$colgrp          = new stdClass();
		$colgrp->node     = $colgrp_id;
		$colgrp->type     = 'column-group';
		$colgrp->parent   = $row_id;
		$colgrp->position = 0;
		$colgrp->settings = new stdClass();
		$nodes[ $colgrp_id ] = $colgrp;

		$col          = new stdClass();
		$col->node     = $col_id;
		$col->type     = 'column';
		$col->parent   = $colgrp_id;
		$col->position = 0;
		$col->settings = (object) array( 'size' => '100' );
		$nodes[ $col_id ] = $col;

		$mod          = new stdClass();
		$mod->node     = $mod_id;
		$mod->type     = 'module';
		$mod->parent   = $col_id;
		$mod->position = 0;
		$mod->settings = (object) array( 'type' => 'html', 'html' => $combined_code );
		$nodes[ $mod_id ] = $mod;

		// BB expects PHP-serialized stdClass objects, not JSON.
		update_post_meta( $post_id, '_fl_builder_data', $nodes );
		update_post_meta( $post_id, '_fl_builder_enabled', '1' );

		// Clear Beaver Builder cache.
		if ( class_exists( 'FLBuilder' ) && method_exists( 'FLBuilder', 'delete_all_asset_cache' ) ) {
			FLBuilder::delete_all_asset_cache( $post_id );
		}

		return true;
	}

	/**
	 * Find a module in the simplified structure.
	 *
	 * @since 4.4.0
	 * @param array  $structure Full simplified page structure.
	 * @param string $identifier_type Type of identifier: id, admin_label, path, or type.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional content to match when using type identifier.
	 * @return array|false Module data with path, or false if not found.
	 */
	public function find_module( $structure, $identifier_type, $identifier_value, $match_content = '' ) {
		$path = array();
		return $this->find_module_recursive( $structure, $identifier_type, $identifier_value, $match_content, $path );
	}

	/**
	 * Update a specific module in the simplified structure.
	 *
	 * @since 4.4.0
	 * @param array  $structure Full simplified page structure.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param array  $updates Updates to apply (content, attributes).
	 * @return array|WP_Error Updated structure or error.
	 */
	public function update_module( $structure, $identifier_type, $identifier_value, $updates ) {
		$found = $this->find_module( $structure, $identifier_type, $identifier_value, $updates['match_content'] ?? '' );

		if ( ! $found ) {
			return new WP_Error(
				'respira_module_not_found',
				sprintf(
					/* translators: 1: identifier type, 2: identifier value */
					__( 'Module not found with %1$s: %2$s', 'respira-for-wordpress' ),
					$identifier_type,
					$identifier_value
				),
				array(
					'identifier_type'  => $identifier_type,
					'identifier_value' => $identifier_value,
				)
			);
		}

		$updated_structure = $structure;
		$applied = $this->apply_updates_at_path( $updated_structure, $found['path'], $updates );
		if ( ! $applied ) {
			return new WP_Error(
				'respira_module_path_invalid',
				__( 'Invalid module path in Beaver Builder structure.', 'respira-for-wordpress' ),
				array( 'path' => $found['path'] )
			);
		}

		return $updated_structure;
	}

	/**
	 * Update a module directly in _fl_builder_data without round-tripping
	 * through simplify→complexify. This preserves BB's exact stdClass/array
	 * format and prevents the serialisation corruption that crashes pages.
	 *
	 * @param int    $post_id         The post ID.
	 * @param string $node_id         The BB node ID to update.
	 * @param array  $updates         Updates payload (content, attributes).
	 * @return true|WP_Error
	 */
	public function update_module_direct( $post_id, $node_id, $updates ) {
		$flat_nodes = get_post_meta( $post_id, '_fl_builder_data', true );
		if ( empty( $flat_nodes ) || ! is_array( $flat_nodes ) ) {
			return new WP_Error(
				'respira_no_builder_data',
				__( 'No Beaver Builder data found for this page.', 'respira-for-wordpress' )
			);
		}

		if ( ! isset( $flat_nodes[ $node_id ] ) ) {
			return new WP_Error(
				'respira_module_not_found',
				sprintf( __( 'Module not found with id: %s', 'respira-for-wordpress' ), $node_id )
			);
		}

		// Deep-clone the entire structure to avoid polluting WordPress's meta
		// cache. PHP objects are references — modifying in-place would make
		// update_post_meta think old === new and skip the DB write.
		$flat_nodes = unserialize( serialize( $flat_nodes ) );
		$node = $flat_nodes[ $node_id ];

		// Ensure settings is a stdClass (BB's native format).
		if ( ! isset( $node->settings ) || ! is_object( $node->settings ) ) {
			$node->settings = new stdClass();
		}

		// Apply content update — set the appropriate content field.
		if ( isset( $updates['content'] ) ) {
			$module_type = isset( $node->settings->type ) ? $node->settings->type : '';
			$content_field_map = array(
				'text-editor' => 'text',
				'rich-text'   => 'text',
				'heading'     => 'heading',
				'html'        => 'html',
				'code'        => 'html',
				'button'      => 'text',
				'callout'     => 'text',
			);
			$content_field = isset( $content_field_map[ $module_type ] ) ? $content_field_map[ $module_type ] : '';

			if ( empty( $content_field ) ) {
				foreach ( array( 'text', 'html', 'heading', 'content', 'code' ) as $field ) {
					if ( isset( $node->settings->$field ) ) {
						$content_field = $field;
						break;
					}
				}
			}

			if ( empty( $content_field ) ) {
				$content_field = 'text';
			}

			$node->settings->$content_field = $updates['content'];
		}

		// Apply attribute updates — set individual settings properties.
		if ( isset( $updates['attributes'] ) && is_array( $updates['attributes'] ) ) {
			foreach ( $updates['attributes'] as $key => $value ) {
				$node->settings->$key = $value;
			}
		}

		$flat_nodes[ $node_id ] = $node;

		// Force DB write by deleting then adding (avoids update_post_meta's
		// old===new comparison which can fail with object graphs).
		delete_post_meta( $post_id, '_fl_builder_data' );
		add_post_meta( $post_id, '_fl_builder_data', $flat_nodes, true );
		update_post_meta( $post_id, '_fl_builder_draft', '' );

		// Clear BB cache so frontend renders fresh content.
		if ( class_exists( 'FLBuilder' ) && method_exists( 'FLBuilder', 'delete_all_asset_cache' ) ) {
			FLBuilder::delete_all_asset_cache( $post_id );
		}
		wp_cache_delete( $post_id, 'post_meta' );

		return true;
	}

	/**
	 * Get documentation.
	 *
	 * @since 1.3.0
	 * @return array Documentation.
	 */
	public function get_documentation() {
		$docs = array(
			'name'        => 'Beaver Builder',
			'description' => 'Popular front-end page builder plugin',
			'overview'    => 'Beaver Builder uses a flat node map with row > column-group > column > module hierarchy. Data is stored as JSON in _fl_builder_data postmeta, keyed by node IDs with parent references.',
			'structure'   => array(
				'row'          => 'Top-level layout container',
				'column-group' => 'Groups columns within a row',
				'column'       => 'Column container within a column-group',
				'module'       => 'Content element within a column (widget type in settings.type)',
			),
			'resources'   => array(
				'https://docs.wpbeaverbuilder.com/',
			),
		);

		// Add patterns if intelligence is available.
		if ( function_exists( 'respira_get_beaver_patterns' ) ) {
			$docs['patterns'] = respira_get_beaver_patterns();
		}

		// Add module catalog if intelligence is available.
		if ( class_exists( 'Respira_Beaver_Module_Registry' ) ) {
			$docs['modules'] = Respira_Beaver_Module_Registry::get_all_modules();
		}

		return $docs;
	}

	/**
	 * Get available modules.
	 *
	 * @since 1.3.0
	 * @return array Available modules.
	 */
	public function get_available_modules() {
		// Use dynamic module registry if available.
		if ( class_exists( 'Respira_Beaver_Module_Registry' ) ) {
			return Respira_Beaver_Module_Registry::get_all_modules();
		}

		// Fallback to basic list.
		return array(
			array(
				'name'        => 'row',
				'title'       => 'Row',
				'description' => 'Layout container',
			),
			array(
				'name'        => 'column-group',
				'title'       => 'Column Group',
				'description' => 'Groups columns within a row',
			),
			array(
				'name'        => 'column',
				'title'       => 'Column',
				'description' => 'Column container',
			),
			array(
				'name'        => 'text-editor',
				'title'       => 'Text Editor',
				'description' => 'Rich text content module',
			),
			array(
				'name'        => 'html',
				'title'       => 'HTML',
				'description' => 'Custom HTML/CSS/JS',
			),
			array(
				'name'        => 'heading',
				'title'       => 'Heading',
				'description' => 'Heading module',
			),
			array(
				'name'        => 'photo',
				'title'       => 'Photo',
				'description' => 'Image module',
			),
			array(
				'name'        => 'button',
				'title'       => 'Button',
				'description' => 'Button module',
			),
		);
	}

	/**
	 * Get builder schema for AI context.
	 *
	 * @since 1.4.0
	 * @param array $elements_used Optional. Array of element names used on the page.
	 * @return array Builder schema with element information.
	 */
	public function get_builder_schema( $elements_used = array() ) {
		if ( class_exists( 'Respira_Beaver_Module_Schema' ) ) {
			$schema_generator = new Respira_Beaver_Module_Schema();
			return $schema_generator->get_builder_schema( $elements_used );
		}

		// Fallback to basic schema.
		return array(
			'builder'         => 'beaver',
			'builder_version' => $this->get_version(),
			'modules'         => $this->get_available_modules(),
		);
	}

	/**
	 * Check if intelligence is available.
	 *
	 * @since 1.4.0
	 * @return bool True if intelligence is available.
	 */
	public function is_intelligence_available() {
		return class_exists( 'Respira_Beaver_Intelligence_Loader' ) &&
			   class_exists( 'Respira_Beaver_Module_Registry' ) &&
			   class_exists( 'Respira_Beaver_Module_Schema' ) &&
			   class_exists( 'Respira_Beaver_Validator' );
	}

	// -------------------------------------------------------------------------
	// Structure conversion: flat node map <-> nested tree
	// -------------------------------------------------------------------------

	/**
	 * Convert Beaver Builder flat node map to a nested simplified tree.
	 *
	 * Beaver stores data as {"nodeId": {type, parent, settings, ...}, ...}.
	 * This converts it to an indexed array of {type, id, attributes, content, children}.
	 *
	 * @since  1.3.0
	 * @param  array $nodes Beaver Builder flat node map.
	 * @return array Simplified nested tree.
	 */
	protected function simplify_structure( $nodes ) {
		if ( ! is_array( $nodes ) || empty( $nodes ) ) {
			return array();
		}

		// If this is already an indexed array (not a flat node map), handle gracefully.
		if ( ! $this->is_associative_array( $nodes ) ) {
			return array_map(
				function( $node ) {
					return array(
						'type'       => $node['type'] ?? 'unknown',
						'id'         => $node['id'] ?? $node['node'] ?? '',
						'attributes' => $node['settings'] ?? $node['attributes'] ?? array(),
						'content'    => $this->extract_content_from_settings( $node['settings'] ?? array(), $node['type'] ?? '' ),
						'children'   => isset( $node['children'] ) ? $this->simplify_structure( $node['children'] ) : array(),
					);
				},
				$nodes
			);
		}

		// Build lookup of all nodes with empty children arrays.
		$lookup = array();
		foreach ( $nodes as $node_id => $node ) {
			// BB stores nodes as stdClass objects — cast to array.
			if ( is_object( $node ) ) {
				$node = (array) $node;
			}
			if ( ! is_array( $node ) ) {
				continue;
			}

			$node_type    = $node['type'] ?? 'unknown';
			$settings     = $node['settings'] ?? array();
			if ( is_object( $settings ) ) {
				$settings = (array) $settings;
			}
			$module_type  = '';

			// For module nodes, the actual widget type is in settings.type.
			if ( 'module' === $node_type && isset( $settings['type'] ) ) {
				$module_type = $settings['type'];
			}

			$display_type = ! empty( $module_type ) ? $module_type : $node_type;

			$lookup[ $node_id ] = array(
				'type'       => $display_type,
				'id'         => (string) $node_id,
				'attributes' => is_array( $settings ) ? $settings : (array) $settings,
				'content'    => $this->extract_content_from_settings( $settings, $display_type ),
				'children'   => array(),
				'_parent'    => isset( $node['parent'] ) ? (string) $node['parent'] : '',
				'_position'  => isset( $node['position'] ) ? (int) $node['position'] : 0,
				'_node_type' => $node_type,
			);
		}

		// Build tree by assigning children to parents.
		$roots = array();
		foreach ( $lookup as $node_id => &$node ) {
			$parent_id = $node['_parent'];
			if ( ! empty( $parent_id ) && isset( $lookup[ $parent_id ] ) ) {
				$lookup[ $parent_id ]['children'][] = &$node;
			} else {
				$roots[] = &$node;
			}
		}
		unset( $node );

		// Sort children by position at every level.
		$this->sort_children_recursive( $roots );

		// Clean up internal fields.
		return $this->clean_simplified_nodes( $roots );
	}

	/**
	 * Convert simplified nested tree back to Beaver Builder flat node map.
	 *
	 * @since  1.3.0
	 * @param  array $simplified Simplified nested tree.
	 * @return array Beaver Builder flat node map keyed by node IDs.
	 */
	protected function complexify_structure( $simplified ) {
		if ( ! is_array( $simplified ) ) {
			return array();
		}

		// Auto-wrap top-level modules in row → column-group → column so the
		// validator doesn't reject them.  This is the normal case for build_page()
		// and widget-shortcut calls where the caller sends a flat list of widgets.
		$structural_types = array( 'row', 'column-group', 'column' );
		$needs_wrap       = false;
		foreach ( $simplified as $node ) {
			if ( is_array( $node ) && ! in_array( $node['type'] ?? '', $structural_types, true ) ) {
				$needs_wrap = true;
				break;
			}
		}

		if ( $needs_wrap ) {
			$simplified = array(
				array(
					'type'     => 'row',
					'children' => array(
						array(
							'type'     => 'column-group',
							'children' => array(
								array(
									'type'       => 'column',
									'attributes' => array( 'size' => '100' ),
									'children'   => $simplified,
								),
							),
						),
					),
				),
			);
		}

		$flat = array();
		$this->flatten_tree_recursive( $simplified, null, $flat );
		return $flat;
	}

	// -------------------------------------------------------------------------
	// Module search and update
	// -------------------------------------------------------------------------

	/**
	 * Recursively find a module in the simplified tree.
	 *
	 * @param array  $elements Elements to search.
	 * @param string $identifier_type Identifier type.
	 * @param mixed  $identifier_value Identifier value.
	 * @param string $match_content Optional content match for type lookups.
	 * @param array  $current_path Current traversal path.
	 * @return array|false
	 */
	private function find_module_recursive( $elements, $identifier_type, $identifier_value, $match_content, $current_path ) {
		if ( ! is_array( $elements ) ) {
			return false;
		}

		foreach ( $elements as $index => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			$element_path = array_merge( $current_path, array( $index ) );
			$match = false;

			switch ( $identifier_type ) {
				case 'id':
					$element_id = $element['id'] ?? '';
					$match = ( (string) $element_id === (string) $identifier_value );
					break;

				case 'admin_label':
					$admin_label = $element['attributes']['admin_label']
						?? $element['attributes']['_admin_label']
						?? $element['label'] ?? '';
					$match = ( $admin_label === $identifier_value );
					break;

				case 'path':
					$path_indices = $this->parse_path_indices( $identifier_value );
					$match = ( $element_path === $path_indices );
					break;

				case 'type':
					$element_type = (string) ( $element['type'] ?? '' );
					if ( $element_type === $identifier_value ) {
						if ( empty( $match_content ) ) {
							$match = true;
						} else {
							$attrs = $element['attributes'] ?? array();
							$content_fields = array( 'text', 'html', 'heading', 'content', 'code' );
							foreach ( $content_fields as $field ) {
								if ( isset( $attrs[ $field ] ) && is_string( $attrs[ $field ] ) && strpos( $attrs[ $field ], $match_content ) !== false ) {
									$match = true;
									break;
								}
							}
							// Also check the content field.
							if ( ! $match && ! empty( $element['content'] ) && strpos( $element['content'], $match_content ) !== false ) {
								$match = true;
							}
						}
					}
					break;
			}

			if ( $match ) {
				return array(
					'module'      => $element,
					'path'        => $element_path,
					'path_string' => $this->build_path_string( $element_path ),
				);
			}

			if ( ! empty( $element['children'] ) && is_array( $element['children'] ) ) {
				$result = $this->find_module_recursive( $element['children'], $identifier_type, $identifier_value, $match_content, $element_path );
				if ( $result ) {
					return $result;
				}
			}
		}

		return false;
	}

	/**
	 * Build a standardized path string from array indices.
	 *
	 * @param array $path Array indices.
	 * @return string
	 */
	private function build_path_string( $path ) {
		if ( empty( $path ) ) {
			return '';
		}

		$parts = array();
		foreach ( $path as $index ) {
			$parts[] = 'elements[' . $index . ']';
		}

		return implode( '.', $parts );
	}

	/**
	 * Parse path formats (array or string) into index array.
	 *
	 * @param mixed $path Path value.
	 * @return array
	 */
	private function parse_path_indices( $path ) {
		if ( is_array( $path ) ) {
			return array_map( 'intval', $path );
		}

		if ( ! is_string( $path ) ) {
			return array();
		}

		preg_match_all( '/\[(\d+)\]/', $path, $matches );
		return isset( $matches[1] ) ? array_map( 'intval', $matches[1] ) : array();
	}

	/**
	 * Apply updates to module located at path in the simplified tree.
	 *
	 * @param array &$elements Elements structure.
	 * @param array $path Path indices.
	 * @param array $updates Updates payload.
	 * @return bool True when updates were applied.
	 */
	private function apply_updates_at_path( &$elements, $path, $updates ) {
		if ( ! is_array( $elements ) || ! is_array( $path ) || empty( $path ) ) {
			return false;
		}

		$index = array_shift( $path );
		if ( ! isset( $elements[ $index ] ) || ! is_array( $elements[ $index ] ) ) {
			return false;
		}

		if ( empty( $path ) ) {
			$this->apply_module_updates( $elements[ $index ], $updates );
			return true;
		}

		if ( isset( $elements[ $index ]['children'] ) && is_array( $elements[ $index ]['children'] ) ) {
			return $this->apply_updates_at_path( $elements[ $index ]['children'], $path, $updates );
		}

		return false;
	}

	/**
	 * Apply content and attribute updates to a single simplified module.
	 *
	 * @param array &$module Module reference (simplified format).
	 * @param array $updates Updates payload.
	 */
	private function apply_module_updates( &$module, $updates ) {
		if ( ! isset( $module['attributes'] ) || ! is_array( $module['attributes'] ) ) {
			$module['attributes'] = array();
		}

		if ( isset( $updates['content'] ) ) {
			$element_type = (string) ( $module['type'] ?? '' );
			$content_field_map = array(
				'text-editor' => 'text',
				'rich-text'   => 'text',
				'heading'     => 'heading',
				'html'        => 'html',
				'code'        => 'html',
				'button'      => 'text',
			);
			$content_field = $content_field_map[ $element_type ] ?? '';

			if ( empty( $content_field ) ) {
				foreach ( array( 'text', 'html', 'heading', 'content', 'code' ) as $field ) {
					if ( array_key_exists( $field, $module['attributes'] ) ) {
						$content_field = $field;
						break;
					}
				}
			}

			if ( empty( $content_field ) ) {
				$content_field = 'text';
			}

			$module['attributes'][ $content_field ] = $updates['content'];
			$module['content'] = $updates['content'];
		}

		if ( isset( $updates['attributes'] ) && is_array( $updates['attributes'] ) ) {
			$module['attributes'] = array_merge( $module['attributes'], $updates['attributes'] );
		}
	}

	// -------------------------------------------------------------------------
	// Internal helpers
	// -------------------------------------------------------------------------

	/**
	 * Extract readable content from Beaver module settings.
	 *
	 * @param array|object $settings Module settings.
	 * @param string       $type Module type.
	 * @return string
	 */
	private function extract_content_from_settings( $settings, $type ) {
		if ( ! is_array( $settings ) ) {
			$settings = (array) $settings;
		}

		$content_fields = array(
			'text-editor' => 'text',
			'rich-text'   => 'text',
			'heading'     => 'heading',
			'html'        => 'html',
			'button'      => 'text',
		);

		if ( isset( $content_fields[ $type ] ) && isset( $settings[ $content_fields[ $type ] ] ) ) {
			return (string) $settings[ $content_fields[ $type ] ];
		}

		// Generic fallback.
		foreach ( array( 'text', 'html', 'heading', 'content', 'code' ) as $field ) {
			if ( isset( $settings[ $field ] ) && is_string( $settings[ $field ] ) && '' !== $settings[ $field ] ) {
				return $settings[ $field ];
			}
		}

		return '';
	}

	/**
	 * Recursively sort children arrays by _position.
	 *
	 * @param array &$nodes Nodes at current level.
	 */
	private function sort_children_recursive( &$nodes ) {
		usort(
			$nodes,
			function( $a, $b ) {
				return ( $a['_position'] ?? 0 ) - ( $b['_position'] ?? 0 );
			}
		);

		foreach ( $nodes as &$node ) {
			if ( ! empty( $node['children'] ) ) {
				$this->sort_children_recursive( $node['children'] );
			}
		}
	}

	/**
	 * Remove internal tracking fields from simplified nodes.
	 *
	 * @param array $nodes Nodes with internal fields.
	 * @return array Clean nodes.
	 */
	private function clean_simplified_nodes( $nodes ) {
		$clean = array();
		foreach ( $nodes as $node ) {
			$item = array(
				'type'       => $node['type'],
				'id'         => $node['id'],
				'attributes' => $node['attributes'],
				'content'    => $node['content'],
				'children'   => ! empty( $node['children'] ) ? $this->clean_simplified_nodes( $node['children'] ) : array(),
			);
			$clean[] = $item;
		}
		return $clean;
	}

	/**
	 * Recursively flatten a simplified tree into Beaver's flat node map.
	 *
	 * @param array      $nodes Simplified tree nodes.
	 * @param string|null $parent_id Parent node ID or null for roots.
	 * @param array      &$flat Accumulator for flat node map.
	 */
	private function flatten_tree_recursive( $nodes, $parent_id, &$flat ) {
		if ( ! is_array( $nodes ) ) {
			return;
		}

		$position = 0;
		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) ) {
				continue;
			}

			$type = $node['type'] ?? $node['module'] ?? 'module';

			// Use existing ID if present, otherwise generate one.
			$node_id = ! empty( $node['id'] ) ? (string) $node['id'] : $this->generate_node_id();

			// Determine the Beaver node type and settings.
			$beaver_type = $type;
			$settings    = array();

			if ( isset( $node['attributes'] ) && is_array( $node['attributes'] ) ) {
				$settings = $node['attributes'];
			} elseif ( isset( $node['settings'] ) && is_array( $node['settings'] ) ) {
				$settings = $node['settings'];
			}

			// Structural types keep their type as-is.
			$structural_types = array( 'row', 'column-group', 'column' );
			if ( ! in_array( $type, $structural_types, true ) ) {
				// It's a module — store the widget type in settings.type.
				$beaver_type = 'module';
				if ( ! isset( $settings['type'] ) ) {
					$settings['type'] = $type;
				}
			}

			// BB stores each node as a stdClass object with settings also as stdClass.
			$flat_node            = new stdClass();
			$flat_node->node      = $node_id;
			$flat_node->type      = $beaver_type;
			$flat_node->parent    = $parent_id;
			$flat_node->position  = $position;
			$flat_node->settings  = ! empty( $settings ) ? $this->array_to_object_deep( $settings ) : new stdClass();

			$flat[ $node_id ] = $flat_node;

			// Process children and collect child IDs for structural nodes.
			$child_ids = array();
			if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
				// Pre-generate child IDs so we can reference them.
				foreach ( $node['children'] as $child ) {
					if ( is_array( $child ) ) {
						$child_ids[] = ! empty( $child['id'] ) ? (string) $child['id'] : null;
					}
				}
				$this->flatten_tree_recursive( $node['children'], $node_id, $flat );

				// Populate child_ids with actual generated IDs from the flat map.
				$child_ids = array();
				foreach ( $flat as $fid => $fnode ) {
					if ( isset( $fnode->parent ) && $fnode->parent === $node_id ) {
						$child_ids[] = $fid;
					}
				}
			}

			// Add columns array to rows for validator compatibility.
			if ( 'row' === $beaver_type && ! empty( $child_ids ) ) {
				$flat[ $node_id ]->columns = $child_ids;
			}

			$position++;
		}
	}

	/**
	 * Recursively convert associative arrays to stdClass objects.
	 * BB stores settings as deeply nested stdClass and its renderer
	 * breaks if it encounters plain arrays where it expects objects.
	 *
	 * @param mixed $data The data to convert.
	 * @return mixed
	 */
	private function array_to_object_deep( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		// Indexed (sequential) arrays stay as arrays — only associative arrays become objects.
		if ( array_values( $data ) === $data ) {
			return array_map( array( $this, 'array_to_object_deep' ), $data );
		}

		$obj = new stdClass();
		foreach ( $data as $key => $value ) {
			$obj->$key = $this->array_to_object_deep( $value );
		}
		return $obj;
	}

	/**
	 * Generate a Beaver Builder-style node ID (13 chars, alphanumeric).
	 *
	 * @return string
	 */
	private function generate_node_id() {
		return substr( str_replace( '.', '', uniqid( '', true ) ), -13 );
	}

	/**
	 * Get the next position index for a given parent.
	 *
	 * @param array       $nodes Flat node map.
	 * @param string|null $parent_id Parent node ID.
	 * @return int
	 */
	private function get_next_position( $nodes, $parent_id ) {
		$max = -1;
		foreach ( $nodes as $node ) {
			if ( is_object( $node ) ) {
				$node = (array) $node;
			}
			if ( ! is_array( $node ) ) {
				continue;
			}
			$node_parent = $node['parent'] ?? null;
			if ( $node_parent === $parent_id ) {
				$pos = isset( $node['position'] ) ? (int) $node['position'] : 0;
				if ( $pos > $max ) {
					$max = $pos;
				}
			}
		}
		return $max + 1;
	}

	/**
	 * Normalize incoming Beaver payloads to simplified Respira structure.
	 *
	 * @param mixed $content Incoming content payload.
	 * @return array
	 */
	private function normalize_incoming_content( $content ) {
		if ( ! is_array( $content ) ) {
			return array();
		}

		// Unwrap common object shapes.
		if ( $this->is_associative_array( $content ) ) {
			// Check if this looks like a Beaver flat node map (keys are node IDs, values have 'type' and 'parent').
			$first_value = reset( $content );
			if ( is_array( $first_value ) && isset( $first_value['type'] ) && array_key_exists( 'parent', $first_value ) ) {
				// This is already a native Beaver flat node map — simplify it first.
				return $this->simplify_structure( $content );
			}

			if ( isset( $content['modules'] ) && is_array( $content['modules'] ) ) {
				$content = $content['modules'];
			} elseif ( isset( $content['elements'] ) && is_array( $content['elements'] ) ) {
				$content = $content['elements'];
			} elseif ( isset( $content['rows'] ) && is_array( $content['rows'] ) ) {
				$content = $content['rows'];
			} elseif ( isset( $content['type'] ) || isset( $content['module'] ) ) {
				$content = array( $content );
			}
		}

		if ( ! is_array( $content ) || empty( $content ) ) {
			return array();
		}

		// Convert object maps to indexed arrays.
		if ( $this->is_associative_array( $content ) ) {
			$content = array_values( $content );
		}

		return is_array( $content ) ? $content : array();
	}

	/**
	 * Check if an array is associative.
	 *
	 * @param mixed $value Array candidate.
	 * @return bool
	 */
	private function is_associative_array( $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		return array_keys( $value ) !== range( 0, count( $value ) - 1 );
	}
}
