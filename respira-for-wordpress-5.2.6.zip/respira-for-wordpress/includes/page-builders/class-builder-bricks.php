<?php
/**
 * Bricks page builder implementation (PRO).
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders
 */

/**
 * Bricks builder class (PRO feature).
 *
 * @since 1.0.0
 */
class Respira_Builder_Bricks extends Respira_Builder_Interface {

	/**
	 * Bricks post-meta key that stores page content as a serialised element array.
	 *
	 * Bricks 1.x used `_bricks_page_content`; 2.x uses the `_2` variant.
	 * All reads and writes in this class go through this constant so a future
	 * key-name change only requires a one-line update.
	 *
	 * @since 1.0.0
	 */
	const BRICKS_META_KEY = '_bricks_page_content_2';

	/**
	 * Detect if Bricks is active.
	 *
	 * Uses multiple fallbacks for different Bricks versions and load orders.
	 *
	 * @since 1.0.0
	 * @return bool True if Bricks is active.
	 */
	public function detect() {
		return defined( 'BRICKS_VERSION' )
			|| class_exists( 'Bricks\Database' )
			|| class_exists( 'Bricks\Plugin' )
			|| function_exists( 'bricks_is_builder' );
	}

	/**
	 * Get builder name.
	 *
	 * @since 1.0.0
	 * @return string Builder name.
	 */
	public function get_name() {
		return 'Bricks';
	}

	/**
	 * Get builder version.
	 *
	 * @since 1.0.0
	 * @return string Builder version.
	 */
	public function get_version() {
		return defined( 'BRICKS_VERSION' ) ? BRICKS_VERSION : 'unknown';
	}

	/**
	 * Check if post uses Bricks.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return bool True if uses Bricks.
	 */
	public function is_builder_used( $post_id ) {
		$content = get_post_meta( $post_id, self::BRICKS_META_KEY, true );
		return ! empty( $content ) && is_array( $content );
	}

	/**
	 * Extract content from post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array Extracted elements.
	 */
	public function extract_content( $post_id ) {
		$content = get_post_meta( $post_id, self::BRICKS_META_KEY, true );

		if ( empty( $content ) || ! is_array( $content ) ) {
			return array();
		}

		return $this->simplify_structure( $content );
	}

	/**
	 * Inject content into post.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Post ID.
	 * @param array $content Simplified content.
	 * @return bool|WP_Error True on success.
	 */
	public function inject_content( $post_id, $content, $skip_structure_validation = false ) {
		$start = microtime( true );

		// Decode JSON string payloads.
		if ( is_string( $content ) ) {
			$decoded = json_decode( $content, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
				$content = $decoded;
			}
		}

		// Normalize alternate payload shapes (e.g. {elements:[...]}, {sections:[...]}).
		$content = $this->normalize_incoming_content( $content );

		// Convert simplified structure to native Bricks elements before validation.
		$elements = $this->complexify_structure( $content );

		// Validate with intelligence if available.
		if ( class_exists( 'Respira_Bricks_Validator' ) ) {
			$validator = new Respira_Bricks_Validator();
			$validation = $validator->validate_layout( $elements );

			if ( ! $validation['valid'] ) {
				$this->log_performance( 'inject', $post_id, microtime( true ) - $start );
				return new WP_Error(
					'validation_failed',
					__( 'Content validation failed.', 'respira-for-wordpress' ),
					array( 'errors' => $validation['errors'] )
				);
			}
		}

		// Write Bricks content meta.
		// Some Bricks versions register sanitize_meta callbacks that strip writes
		// from non-Bricks contexts. Use $wpdb directly to bypass those filters,
		// similar to the Divi 5 direct-write approach.
		global $wpdb;
		$serialized = maybe_serialize( $elements );
		$existing   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s LIMIT 1",
				$post_id,
				self::BRICKS_META_KEY
			)
		);
		if ( $existing ) {
			$wpdb->update(
				$wpdb->postmeta,
				array( 'meta_value' => $serialized ),
				array( 'post_id' => $post_id, 'meta_key' => self::BRICKS_META_KEY ),
				array( '%s' ),
				array( '%d', '%s' )
			);
		} else {
			$wpdb->insert(
				$wpdb->postmeta,
				array(
					'post_id'    => $post_id,
					'meta_key'   => self::BRICKS_META_KEY,
					'meta_value' => $serialized,
				),
				array( '%d', '%s', '%s' )
			);
		}
		wp_cache_delete( $post_id, 'post_meta' );

		// Mark as Bricks-built.
		update_post_meta( $post_id, '_bricks_editor_mode', 'bricks' );

		// Clear page-level cache.
		if ( function_exists( 'bricks_clear_page_cache' ) ) {
			bricks_clear_page_cache( $post_id );
		}

		// Trigger Bricks CSS asset regeneration (documented hook, @since Bricks 1.x).
		// Without this, Bricks' external-file CSS loading mode keeps serving the
		// pre-edit stylesheet and the frontend appears unchanged despite a valid write.
		do_action( 'bricks/generate_css_file', $post_id );

		$this->log_performance( 'inject', $post_id, microtime( true ) - $start );

		return true;
	}

	/**
	 * Create a code block.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Post ID.
	 * @param string $html    HTML content.
	 * @param string $css     CSS content.
	 * @param string $js      JavaScript content.
	 * @return bool|WP_Error True on success.
	 */
	public function create_code_block( $post_id, $html, $css = '', $js = '' ) {
		$content = get_post_meta( $post_id, self::BRICKS_META_KEY, true );
		$elements = is_array( $content ) ? $content : array();

		// Create code element.
		$code_element = array(
			'id'       => 'respira_' . uniqid(),
			'name'     => 'code',
			'parent'   => 0,
			'settings' => array(
				'code' => $html,
			),
		);

		// Add CSS if provided.
		if ( ! empty( $css ) ) {
			$code_element['settings']['css'] = $css;
		}

		// Add JS if provided.
		if ( ! empty( $js ) ) {
			$code_element['settings']['executeCode'] = true;
			$code_element['settings']['code'] .= "\n<script>\n" . $js . "\n</script>";
		}

		// Add CSS via style tag if provided.
		if ( ! empty( $css ) ) {
			$code_element['settings']['code'] .= "\n<style>\n" . $css . "\n</style>";
		}

		$elements[] = $code_element;

		// Use $wpdb directly to bypass potential Bricks sanitize_meta filters.
		global $wpdb;
		$serialized = maybe_serialize( $elements );
		$existing   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s LIMIT 1",
				$post_id,
				self::BRICKS_META_KEY
			)
		);
		if ( $existing ) {
			$wpdb->update(
				$wpdb->postmeta,
				array( 'meta_value' => $serialized ),
				array( 'post_id' => $post_id, 'meta_key' => self::BRICKS_META_KEY ),
				array( '%s' ),
				array( '%d', '%s' )
			);
		} else {
			$wpdb->insert(
				$wpdb->postmeta,
				array(
					'post_id'    => $post_id,
					'meta_key'   => self::BRICKS_META_KEY,
					'meta_value' => $serialized,
				),
				array( '%d', '%s', '%s' )
			);
		}
		wp_cache_delete( $post_id, 'post_meta' );

		return true;
	}

	/**
	 * Get documentation.
	 *
	 * @since 1.0.0
	 * @return array Documentation.
	 */
	public function get_documentation() {
		$docs = array(
			'name'        => 'Bricks',
			'description' => 'Modern, performance-focused visual website builder',
			'overview'    => 'Bricks uses a element-based structure stored as arrays. Focus on speed and clean code output.',
			'structure'   => array(
				'elements'   => 'Individual UI elements',
				'containers' => 'Structural containers',
				'settings'   => 'Element-specific settings',
			),
			'meta_key'    => self::BRICKS_META_KEY,
			'resources'   => array(
				'https://academy.bricksbuilder.io/',
			),
			// DOM events dispatched by Bricks on the frontend. Browser AI (WebMCP)
			// should await the relevant event before reading or acting on dynamic
			// content to avoid racing against Bricks AJAX operations.
			'browser_events' => array(
				'bricks/ajax/end'                      => 'Fired after any Bricks AJAX call completes (infinite scroll, load-more, AJAX pagination, query filters). Safe general-purpose signal.',
				'bricks/ajax/query_result/displayed'   => 'Fired after AJAX query-filter results are injected into the DOM. Await this before reading filtered content.',
				'bricks/ajax/load_page/completed'      => 'Fired after an infinite-scroll page append. Await before reading newly loaded items.',
				'bricks/ajax/pagination/completed'     => 'Fired after AJAX pagination completes. Await before reading the new page of results.',
				'bricks/popup/open'                    => 'Fired after a Bricks popup opens. Await before interacting with popup content.',
				'bricks/tabs/changed'                  => 'Fired after a tab switch. Event detail includes elementId, activeIndex, activeTitle.',
				'bricks/accordion/open'                => 'Fired after an accordion item expands. Event detail includes elementId, openItem.',
				'bricks/form/success'                  => 'Fired after a successful Bricks form submission AJAX response.',
				'bricks/form/error'                    => 'Fired after a failed Bricks form submission AJAX response.',
			),
		);

		// Add patterns if intelligence is available.
		if ( function_exists( 'respira_get_bricks_patterns' ) ) {
			$docs['patterns'] = respira_get_bricks_patterns();
		}

		// Add element catalog if intelligence is available.
		if ( class_exists( 'Respira_Bricks_Element_Registry' ) ) {
			$docs['elements'] = Respira_Bricks_Element_Registry::get_all_elements();
		}

		return $docs;
	}

	/**
	 * Get available modules.
	 *
	 * @since 1.0.0
	 * @return array Available elements.
	 */
	public function get_available_modules() {
		// Use dynamic element registry if available.
		if ( class_exists( 'Respira_Bricks_Element_Registry' ) ) {
			return Respira_Bricks_Element_Registry::get_all_elements();
		}

		// Fallback to basic list (known elements).
		return array(
			array(
				'name'        => 'section',
				'title'       => 'Section',
				'description' => 'Main structural container',
			),
			array(
				'name'        => 'container',
				'title'       => 'Container',
				'description' => 'Generic container element',
			),
			array(
				'name'        => 'block',
				'title'       => 'Block',
				'description' => 'Basic block element',
			),
			array(
				'name'        => 'div',
				'title'       => 'Div',
				'description' => 'Division element',
			),
			array(
				'name'        => 'text',
				'title'       => 'Text',
				'description' => 'Text content',
			),
			array(
				'name'        => 'heading',
				'title'       => 'Heading',
				'description' => 'Heading element',
			),
			array(
				'name'        => 'image',
				'title'       => 'Image',
				'description' => 'Image element',
			),
			array(
				'name'        => 'video',
				'title'       => 'Video',
				'description' => 'Video element',
			),
			array(
				'name'        => 'button',
				'title'       => 'Button',
				'description' => 'Button element',
			),
			array(
				'name'        => 'icon',
				'title'       => 'Icon',
				'description' => 'Icon element',
			),
			array(
				'name'        => 'code',
				'title'       => 'Code',
				'description' => 'Custom HTML/CSS/JS',
			),
			array(
				'name'        => 'html',
				'title'       => 'HTML',
				'description' => 'Raw HTML element',
			),
		);
	}

	/**
	 * Get builder schema for AI context.
	 *
	 * @since 1.4.0
	 * @param array $elements_used Optional. Array of element names used on the page.
	 * @return array Builder schema with element information.
	 */
	public function get_builder_schema( $elements_used = array() ) {
		if ( class_exists( 'Respira_Bricks_Element_Schema' ) ) {
			$schema_generator = new Respira_Bricks_Element_Schema();
			return $schema_generator->get_builder_schema( $elements_used );
		}

		// Fallback to basic schema.
		return array(
			'builder'         => 'bricks',
			'builder_version' => $this->get_version(),
			'elements'        => $this->get_available_modules(),
		);
	}

	/**
	 * Check if intelligence is available.
	 *
	 * @since 1.4.0
	 * @return bool True if intelligence is available.
	 */
	public function is_intelligence_available() {
		return class_exists( 'Respira_Bricks_Intelligence_Loader' ) &&
			   class_exists( 'Respira_Bricks_Element_Registry' ) &&
			   class_exists( 'Respira_Bricks_Element_Schema' ) &&
			   class_exists( 'Respira_Bricks_Validator' );
	}

	/**
	 * Simplify Bricks structure for AI.
	 *
	 * @since  1.0.0
	 * @param  array $elements Bricks elements.
	 * @return array Simplified structure.
	 */
	protected function simplify_structure( $elements ) {
		if ( ! is_array( $elements ) ) {
			return array();
		}

		return array_map(
			function( $element ) {
				$simplified = array(
					'type'     => $element['name'] ?? 'div',
					'id'       => $element['id'] ?? '',
					'parent'   => $element['parent'] ?? 0,
					'settings' => $element['settings'] ?? array(),
				);

				// Include label if present.
				if ( isset( $element['label'] ) ) {
					$simplified['label'] = $element['label'];
				}

				// Include children if this element has them.
				if ( isset( $element['children'] ) && is_array( $element['children'] ) ) {
					$simplified['children'] = $this->simplify_structure( $element['children'] );
				}

				return $simplified;
			},
			$elements
		);
	}

	/**
	 * Convert simplified structure back to Bricks format.
	 *
	 * @since  1.0.0
	 * @param  array $simplified Simplified structure.
	 * @return array Bricks format.
	 */
	protected function complexify_structure( $simplified ) {
		if ( ! is_array( $simplified ) ) {
			return array();
		}

		return array_map(
			function( $item ) {
				$element = array(
					'id'       => $item['id'] ?? 'respira_' . uniqid(),
					'name'     => $item['type'] ?? $item['name'] ?? 'div',
					'parent'   => $item['parent'] ?? 0,
					'settings' => $item['settings'] ?? array(),
				);

				// Include label if present.
				if ( isset( $item['label'] ) ) {
					$element['label'] = $item['label'];
				}

				// Process children if present.
				// Bricks native format uses children as string ID references (e.g. ["tst02"]).
				// Simplified format uses children as nested element objects.
				$children = array();
				if ( ! empty( $item['children'] ) && is_array( $item['children'] ) ) {
					$children = $item['children'];
				} elseif ( ! empty( $item['elements'] ) && is_array( $item['elements'] ) ) {
					$children = $item['elements'];
				}
				if ( ! empty( $children ) ) {
					// If children are string IDs (Bricks native), keep as-is.
					// If children are nested element objects, recursively complexify.
					if ( is_string( $children[0] ) ) {
						$element['children'] = $children;
					} else {
						$element['children'] = $this->complexify_structure( $children );
					}
				}

				return $element;
			},
			$simplified
		);
	}

	/**
	 * Find a module in the Bricks structure.
	 *
	 * @since 1.8.32
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier: admin_label, path, or type.
	 * @param string $identifier_value Value to match.
	 * @param string $match_content Optional. Content to match when using type identifier.
	 * @return array|false Module data with path, or false if not found.
	 */
	public function find_module( $structure, $identifier_type, $identifier_value, $match_content = '' ) {
		$path = array();
		return $this->find_module_recursive( $structure, $identifier_type, $identifier_value, $match_content, $path );
	}

	/**
	 * Update a specific module in the Bricks structure.
	 *
	 * @since 1.8.32
	 * @param array  $structure Full page structure.
	 * @param string $identifier_type Type of identifier.
	 * @param string $identifier_value Value to match.
	 * @param array  $updates Updates to apply (content, attributes).
	 * @return array|WP_Error Updated structure or error.
	 */
	public function update_module( $structure, $identifier_type, $identifier_value, $updates ) {
		$found = $this->find_module( $structure, $identifier_type, $identifier_value, $updates['match_content'] ?? '' );

		if ( ! $found ) {
			return new WP_Error(
				'respira_module_not_found',
				sprintf(
					/* translators: 1: identifier type, 2: identifier value */
					__( 'Module not found with %1$s: %2$s', 'respira-for-wordpress' ),
					$identifier_type,
					$identifier_value
				),
				array(
					'identifier_type'  => $identifier_type,
					'identifier_value' => $identifier_value,
				)
			);
		}

		$updated_structure = $structure;
		$applied = $this->apply_updates_at_path( $updated_structure, $found['path'], $updates );
		if ( ! $applied ) {
			return new WP_Error(
				'respira_module_path_invalid',
				__( 'Invalid module path in Bricks structure.', 'respira-for-wordpress' ),
				array( 'path' => $found['path'] )
			);
		}

		return $updated_structure;
	}

	/**
	 * Recursively find a Bricks module in structure.
	 *
	 * @param array  $elements Elements to search.
	 * @param string $identifier_type Identifier type.
	 * @param mixed  $identifier_value Identifier value.
	 * @param string $match_content Optional. Match text for type lookups.
	 * @param array  $current_path Current traversal path.
	 * @return array|false
	 */
	private function find_module_recursive( $elements, $identifier_type, $identifier_value, $match_content, $current_path ) {
		if ( ! is_array( $elements ) ) {
			return false;
		}

		foreach ( $elements as $index => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			$element_path = array_merge( $current_path, array( $index ) );
			$match = false;

			switch ( $identifier_type ) {
				case 'admin_label':
					$admin_label = $element['settings']['admin_label'] ?? $element['settings']['_admin_label'] ?? $element['label'] ?? '';
					$match = ( $admin_label === $identifier_value );
					break;

				case 'path':
					$path_indices = $this->parse_path_indices( $identifier_value );
					$match = ( $element_path === $path_indices );
					break;

				case 'type':
					$element_type = (string) ( $element['type'] ?? $element['name'] ?? '' );
					if ( $element_type === $identifier_value ) {
						if ( empty( $match_content ) ) {
							$match = true;
						} else {
							$settings = $element['settings'] ?? array();
							$content_fields = array( 'text', 'content', 'title', 'code', 'html' );
							foreach ( $content_fields as $field ) {
								if ( isset( $settings[ $field ] ) && is_string( $settings[ $field ] ) && strpos( $settings[ $field ], $match_content ) !== false ) {
									$match = true;
									break;
								}
							}
						}
					}
					break;
			}

			if ( $match ) {
				return array(
					'module'      => $element,
					'path'        => $element_path,
					'path_string' => $this->build_path_string( $element_path ),
				);
			}

			$children = array();
			if ( isset( $element['children'] ) && is_array( $element['children'] ) ) {
				$children = $element['children'];
			} elseif ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$children = $element['elements'];
			}

			if ( ! empty( $children ) ) {
				$result = $this->find_module_recursive( $children, $identifier_type, $identifier_value, $match_content, $element_path );
				if ( $result ) {
					return $result;
				}
			}
		}

		return false;
	}

	/**
	 * Build a standardized path string from array indices.
	 *
	 * @param array $path Array indices.
	 * @return string
	 */
	private function build_path_string( $path ) {
		if ( empty( $path ) ) {
			return '';
		}

		$parts = array();
		foreach ( $path as $index ) {
			$parts[] = 'elements[' . $index . ']';
		}

		return implode( '.', $parts );
	}

	/**
	 * Parse path formats (array or string) into index array.
	 *
	 * @param mixed $path Path value.
	 * @return array
	 */
	private function parse_path_indices( $path ) {
		if ( is_array( $path ) ) {
			return array_map( 'intval', $path );
		}

		if ( ! is_string( $path ) ) {
			return array();
		}

		preg_match_all( '/\[(\d+)\]/', $path, $matches );
		return isset( $matches[1] ) ? array_map( 'intval', $matches[1] ) : array();
	}

	/**
	 * Apply updates to module located at path.
	 *
	 * @param array &$elements Elements structure.
	 * @param array $path Path indices.
	 * @param array $updates Updates payload.
	 * @return bool True when updates were applied.
	 */
	private function apply_updates_at_path( &$elements, $path, $updates ) {
		if ( ! is_array( $elements ) || ! is_array( $path ) || empty( $path ) ) {
			return false;
		}

		$index = array_shift( $path );
		if ( ! isset( $elements[ $index ] ) || ! is_array( $elements[ $index ] ) ) {
			return false;
		}

		if ( empty( $path ) ) {
			$this->apply_module_updates( $elements[ $index ], $updates );
			return true;
		}

		foreach ( array( 'children', 'elements' ) as $child_key ) {
			if ( isset( $elements[ $index ][ $child_key ] ) && is_array( $elements[ $index ][ $child_key ] ) ) {
				if ( $this->apply_updates_at_path( $elements[ $index ][ $child_key ], $path, $updates ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Apply content and attribute updates to a single module.
	 *
	 * @param array &$module Module reference.
	 * @param array $updates Updates payload.
	 */
	private function apply_module_updates( &$module, $updates ) {
		if ( ! isset( $module['settings'] ) || ! is_array( $module['settings'] ) ) {
			$module['settings'] = array();
		}

		if ( isset( $updates['content'] ) ) {
			$element_type = (string) ( $module['type'] ?? $module['name'] ?? '' );
			$content_field_map = array(
				'heading' => 'text',
				'text'    => 'text',
				'button'  => 'text',
				'code'    => 'code',
				'html'    => 'code',
			);
			$content_field = $content_field_map[ $element_type ] ?? '';

			if ( empty( $content_field ) ) {
				foreach ( array( 'text', 'content', 'title', 'code', 'html' ) as $field ) {
					if ( array_key_exists( $field, $module['settings'] ) ) {
						$content_field = $field;
						break;
					}
				}
			}

			if ( empty( $content_field ) ) {
				$content_field = 'text';
			}

			$module['settings'][ $content_field ] = $updates['content'];
		}

		if ( isset( $updates['attributes'] ) && is_array( $updates['attributes'] ) ) {
			$module['settings'] = array_merge( $module['settings'], $updates['attributes'] );
		}
	}

	/**
	 * Normalize incoming Bricks payloads to simplified Respira structure.
	 *
	 * @param mixed $content Incoming content payload.
	 * @return array
	 */
	private function normalize_incoming_content( $content ) {
		if ( ! is_array( $content ) ) {
			return array();
		}

		// Unwrap common object shapes.
		if ( $this->is_associative_array( $content ) ) {
			if ( isset( $content['sections'] ) && is_array( $content['sections'] ) ) {
				return $this->flatten_legacy_sections( $content['sections'] );
			}
			if ( isset( $content['elements'] ) && is_array( $content['elements'] ) ) {
				$content = $content['elements'];
			} elseif ( isset( $content['modules'] ) && is_array( $content['modules'] ) ) {
				$content = $content['modules'];
			} elseif ( isset( $content['id'] ) || isset( $content['type'] ) || isset( $content['name'] ) ) {
				$content = array( $content );
			}
		}

		if ( empty( $content ) || ! is_array( $content ) ) {
			return array();
		}

		// Some clients may send object maps instead of numeric arrays.
		if ( $this->is_associative_array( $content ) ) {
			$content = array_values( $content );
		}

		$looks_like_sections = false;
		foreach ( $content as $item ) {
			if ( is_array( $item ) && ( isset( $item['rows'] ) || isset( $item['modules'] ) || isset( $item['sections'] ) ) ) {
				$looks_like_sections = true;
				break;
			}
		}

		if ( $looks_like_sections ) {
			return $this->flatten_legacy_sections( $content );
		}

		$normalized = array();
		foreach ( $content as $item ) {
			$this->append_normalized_item( $normalized, $item, 0 );
		}

		return $normalized;
	}

	/**
	 * Flatten nested section/row/module payloads to Bricks-like flat elements.
	 *
	 * @param array $sections Sections payload.
	 * @return array
	 */
	private function flatten_legacy_sections( $sections ) {
		$normalized = array();
		if ( ! is_array( $sections ) ) {
			return $normalized;
		}

		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}

			// If already a Bricks-like element, keep it and process nested children.
			if ( isset( $section['id'] ) || isset( $section['type'] ) || isset( $section['name'] ) ) {
				$this->append_normalized_item( $normalized, $section, 0 );
				continue;
			}

			$section_id = 'respira_section_' . uniqid();
			$section_settings = $section['settings'] ?? ( $section['attributes'] ?? array() );
			if ( ! is_array( $section_settings ) ) {
				$section_settings = array();
			}

			$normalized[] = array(
				'id'       => $section_id,
				'type'     => 'section',
				'parent'   => 0,
				'settings' => $section_settings,
			);

			if ( isset( $section['rows'] ) && is_array( $section['rows'] ) ) {
				foreach ( $section['rows'] as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					$row_id = $row['id'] ?? 'respira_row_' . uniqid();
					$row_settings = $row['settings'] ?? ( $row['attributes'] ?? array() );
					if ( ! is_array( $row_settings ) ) {
						$row_settings = array();
					}

					$normalized[] = array(
						'id'       => $row_id,
						'type'     => $row['type'] ?? $row['name'] ?? 'container',
						'parent'   => $section_id,
						'settings' => $row_settings,
					);

					if ( isset( $row['modules'] ) && is_array( $row['modules'] ) ) {
						foreach ( $row['modules'] as $module ) {
							$this->append_normalized_item( $normalized, $module, $row_id );
						}
					}
				}
			}

			if ( isset( $section['modules'] ) && is_array( $section['modules'] ) ) {
				foreach ( $section['modules'] as $module ) {
					$this->append_normalized_item( $normalized, $module, $section_id );
				}
			}
		}

		return $normalized;
	}

	/**
	 * Normalize an element and append it (plus descendants) to a flat list.
	 *
	 * @param array &$normalized Accumulator.
	 * @param mixed $item Element candidate.
	 * @param mixed $parent_id Parent identifier.
	 */
	private function append_normalized_item( &$normalized, $item, $parent_id ) {
		if ( ! is_array( $item ) ) {
			return;
		}

		$normalized_item = $this->normalize_bricks_item( $item );
		if ( empty( $normalized_item['id'] ) ) {
			$normalized_item['id'] = 'respira_' . uniqid();
		}

		if ( $parent_id && ( ! isset( $normalized_item['parent'] ) || empty( $normalized_item['parent'] ) ) ) {
			$normalized_item['parent'] = $parent_id;
		}

		$normalized[] = $normalized_item;

		$children = array();
		if ( isset( $item['children'] ) && is_array( $item['children'] ) ) {
			$children = $item['children'];
		} elseif ( isset( $item['elements'] ) && is_array( $item['elements'] ) ) {
			$children = $item['elements'];
		} elseif ( isset( $item['modules'] ) && is_array( $item['modules'] ) ) {
			$children = $item['modules'];
		}

		foreach ( $children as $child ) {
			$this->append_normalized_item( $normalized, $child, $normalized_item['id'] );
		}
	}

	/**
	 * Normalize one Bricks element-like item.
	 *
	 * @param array $item Raw item.
	 * @return array
	 */
	private function normalize_bricks_item( $item ) {
		$settings = array();
		if ( isset( $item['settings'] ) && is_array( $item['settings'] ) ) {
			$settings = $item['settings'];
		} elseif ( isset( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
			$settings = $item['attributes'];
		}

		$normalized = array(
			'id'       => $item['id'] ?? '',
			'type'     => $item['type'] ?? $item['name'] ?? 'div',
			'parent'   => $item['parent'] ?? 0,
			'settings' => $settings,
		);

		if ( isset( $item['label'] ) ) {
			$normalized['label'] = $item['label'];
		}

		return $normalized;
	}

	/**
	 * Check if an array is associative.
	 *
	 * @param mixed $value Array candidate.
	 * @return bool
	 */
	private function is_associative_array( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}

		return array_keys( $value ) !== range( 0, count( $value ) - 1 );
	}
}
