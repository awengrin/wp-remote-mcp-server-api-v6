<?php
/**
 * SEO Analyzer
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/analyzers
 */

/**
 * Analyzes SEO factors including meta tags, content structure, and readability.
 *
 * @since 1.0.0
 */
class Respira_SEO_Analyzer {

	/**
	 * Perform comprehensive SEO analysis
	 *
	 * @since 1.0.0
	 * @param int $page_id Page ID to analyze.
	 * @return array SEO analysis results.
	 */
	public function analyze_seo( $page_id ) {
		$post = get_post( $page_id );
		if ( ! $post ) {
			return array(
				'success' => false,
				'message' => 'Page not found',
			);
		}

		$issues         = array();
		$recommendations = array();
		$metrics        = array();

		// Meta tags analysis.
		$meta_analysis  = $this->analyze_meta_tags( $page_id );
		$metrics        = array_merge( $metrics, $meta_analysis['metrics'] );
		$issues         = array_merge( $issues, $meta_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $meta_analysis['recommendations'] );

		// Heading structure analysis.
		$heading_analysis = $this->analyze_headings( $post->post_content );
		$metrics         = array_merge( $metrics, $heading_analysis['metrics'] );
		$issues          = array_merge( $issues, $heading_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $heading_analysis['recommendations'] );

		// Image alt text analysis.
		$image_analysis = $this->analyze_image_alt_text( $post->post_content );
		$metrics       = array_merge( $metrics, $image_analysis['metrics'] );
		$issues        = array_merge( $issues, $image_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $image_analysis['recommendations'] );

		// Internal linking analysis.
		$link_analysis  = $this->analyze_internal_links( $post->post_content );
		$metrics        = array_merge( $metrics, $link_analysis['metrics'] );
		$issues         = array_merge( $issues, $link_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $link_analysis['recommendations'] );

		// Content analysis.
		$content_analysis = $this->analyze_content( $post->post_content, $post->post_title );
		$metrics         = array_merge( $metrics, $content_analysis['metrics'] );
		$issues          = array_merge( $issues, $content_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $content_analysis['recommendations'] );

		// Schema markup analysis.
		$schema_analysis = $this->analyze_schema_markup( $page_id );
		$metrics        = array_merge( $metrics, $schema_analysis['metrics'] );
		$issues         = array_merge( $issues, $schema_analysis['issues'] );
		$recommendations = array_merge( $recommendations, $schema_analysis['recommendations'] );

		// Calculate overall SEO score.
		$score = $this->calculate_seo_score( $issues, $metrics );
		$grade = $this->get_grade_from_score( $score );

		return array(
			'success'         => true,
			'score'           => $score,
			'grade'           => $grade,
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Check for common SEO issues
	 *
	 * @since 1.0.0
	 * @param int $page_id Page ID to analyze.
	 * @return array SEO issues.
	 */
	public function check_seo_issues( $page_id ) {
		$post = get_post( $page_id );
		if ( ! $post ) {
			return array(
				'success' => false,
				'message' => 'Page not found',
			);
		}

		$issues = array();

		// Check for critical SEO issues.
		$meta_title = $this->get_meta_title( $page_id );
		if ( empty( $meta_title ) ) {
			$issues[] = array(
				'type'     => 'error',
				'message'  => 'Missing meta title',
				'severity' => 'critical',
				'fix'      => 'Add a meta title using an SEO plugin like Yoast or RankMath',
			);
		}

		$meta_description = $this->get_meta_description( $page_id );
		if ( empty( $meta_description ) ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Missing meta description',
				'severity' => 'high',
				'fix'      => 'Add a meta description between 120-160 characters',
			);
		}

		// Check content length.
		$content      = strip_tags( $post->post_content );
		$word_count   = $this->unicode_word_count( $content );
		if ( $word_count < 300 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Thin content detected',
				'severity' => 'medium',
				'fix'      => sprintf( 'Add more content (current: %d words, recommended: 300+ words)', $word_count ),
			);
		}

		// Check for H1 tag.
		if ( ! preg_match( '/<h1[^>]*>/i', $post->post_content ) ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'No H1 heading found',
				'severity' => 'high',
				'fix'      => 'Add one H1 heading that describes the main topic',
			);
		}

		$score = count( $issues ) === 0 ? 100 : max( 0, 100 - ( count( $issues ) * 15 ) );
		$grade = $this->get_grade_from_score( $score );

		return array(
			'success' => true,
			'score'   => $score,
			'grade'   => $grade,
			'issues'  => $issues,
		);
	}

	/**
	 * Analyze content readability
	 *
	 * @since 1.0.0
	 * @param int $page_id Page ID to analyze.
	 * @return array Readability analysis.
	 */
	public function analyze_readability( $page_id ) {
		$post = get_post( $page_id );
		if ( ! $post ) {
			return array(
				'success' => false,
				'message' => 'Page not found',
			);
		}

		$content = strip_tags( $post->post_content );
		$issues  = array();
		$metrics = array();

		// Calculate readability metrics.
		$word_count      = $this->unicode_word_count( $content );
		$sentence_count  = preg_match_all( '/[.!?]+/', $content, $matches );
		$avg_words_per_sentence = $sentence_count > 0 ? $word_count / $sentence_count : 0;

		$metrics['word_count']             = $word_count;
		$metrics['sentence_count']         = $sentence_count;
		$metrics['avg_words_per_sentence'] = round( $avg_words_per_sentence, 1 );

		// Calculate Flesch Reading Ease (simplified).
		$flesch_score              = $this->calculate_flesch_score( $content );
		$metrics['flesch_score']   = $flesch_score;
		$metrics['reading_level']  = $this->get_reading_level( $flesch_score );

		// Check for readability issues.
		if ( $avg_words_per_sentence > 25 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Sentences are too long',
				'severity' => 'medium',
				'fix'      => 'Break long sentences into shorter ones (average: ' . round( $avg_words_per_sentence ) . ' words per sentence)',
			);
		}

		if ( $flesch_score < 60 ) {
			$issues[] = array(
				'type'     => 'info',
				'message'  => 'Content may be difficult to read',
				'severity' => 'low',
				'fix'      => 'Simplify language and use shorter sentences (Flesch score: ' . $flesch_score . ')',
			);
		}

		// Paragraph analysis.
		$paragraphs = preg_split( '/\n\s*\n/', $content );
		$long_paragraphs = 0;
		foreach ( $paragraphs as $paragraph ) {
			if ( $this->unicode_word_count( $paragraph ) > 150 ) {
				$long_paragraphs++;
			}
		}

		if ( $long_paragraphs > 0 ) {
			$issues[] = array(
				'type'     => 'info',
				'message'  => sprintf( '%d long paragraphs detected', $long_paragraphs ),
				'severity' => 'low',
				'fix'      => 'Break long paragraphs into shorter ones for better readability',
			);
		}

		$score = $this->calculate_readability_score( $issues, $metrics );
		$grade = $this->get_grade_from_score( $score );

		return array(
			'success'         => true,
			'score'           => $score,
			'grade'           => $grade,
			'issues'          => $issues,
			'recommendations' => array(),
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze meta tags
	 *
	 * @param int $page_id Page ID.
	 * @return array Meta tag analysis.
	 */
	private function analyze_meta_tags( $page_id ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array();

		// Get meta title.
		$meta_title = $this->get_meta_title( $page_id );
		$metrics['meta_title_length'] = mb_strlen( $meta_title, 'UTF-8' );

		if ( empty( $meta_title ) ) {
			$issues[] = array(
				'type'     => 'error',
				'message'  => 'Missing meta title',
				'severity' => 'critical',
				'fix'      => 'Add a meta title using an SEO plugin',
			);
		} elseif ( mb_strlen( $meta_title, 'UTF-8' ) < 30 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Meta title too short',
				'severity' => 'medium',
				'fix'      => 'Expand meta title to 50-60 characters',
			);
		} elseif ( mb_strlen( $meta_title, 'UTF-8' ) > 60 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Meta title too long',
				'severity' => 'medium',
				'fix'      => 'Shorten meta title to 50-60 characters',
			);
		}

		// Get meta description.
		$meta_description = $this->get_meta_description( $page_id );
		$metrics['meta_description_length'] = mb_strlen( $meta_description, 'UTF-8' );

		if ( empty( $meta_description ) ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Missing meta description',
				'severity' => 'high',
				'fix'      => 'Add meta description between 120-160 characters',
			);
		} elseif ( mb_strlen( $meta_description, 'UTF-8' ) < 120 ) {
			$issues[] = array(
				'type'     => 'info',
				'message'  => 'Meta description too short',
				'severity' => 'low',
				'fix'      => 'Expand meta description to 120-160 characters',
			);
		} elseif ( mb_strlen( $meta_description, 'UTF-8' ) > 160 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Meta description too long',
				'severity' => 'medium',
				'fix'      => 'Shorten meta description to 120-160 characters',
			);
		}

		// Check for Open Graph tags — supports Yoast, RankMath, AIOSEO, SEOPress.
		$og_title = get_post_meta( $page_id, '_yoast_wpseo_opengraph-title', true )
			?: get_post_meta( $page_id, 'rank_math_facebook_title', true )
			?: get_post_meta( $page_id, '_aioseo_og_title', true )
			?: get_post_meta( $page_id, '_seopress_social_fb_title', true );

		$og_description = get_post_meta( $page_id, '_yoast_wpseo_opengraph-description', true )
			?: get_post_meta( $page_id, 'rank_math_facebook_description', true )
			?: get_post_meta( $page_id, '_aioseo_og_description', true )
			?: get_post_meta( $page_id, '_seopress_social_fb_desc', true );

		$og_image = get_post_meta( $page_id, '_yoast_wpseo_opengraph-image', true )
			?: get_post_meta( $page_id, 'rank_math_facebook_image_id', true )
			?: get_post_meta( $page_id, '_aioseo_og_image_url', true )
			?: get_post_meta( $page_id, '_seopress_social_fb_img', true );

		// Major SEO plugins auto-generate OG from the primary title/description when no
		// explicit OG override is set, so fall back to detecting their primary meta.
		if ( empty( $og_title ) ) {
			$og_title = get_post_meta( $page_id, 'rank_math_title', true )
				?: get_post_meta( $page_id, '_yoast_wpseo_title', true )
				?: get_post_meta( $page_id, '_aioseo_title', true );
		}
		if ( empty( $og_description ) ) {
			$og_description = get_post_meta( $page_id, 'rank_math_description', true )
				?: get_post_meta( $page_id, '_yoast_wpseo_metadesc', true )
				?: get_post_meta( $page_id, '_aioseo_description', true );
		}

		$metrics['has_og_title']       = ! empty( $og_title );
		$metrics['has_og_description'] = ! empty( $og_description );
		$metrics['has_og_image']       = ! empty( $og_image );

		if ( ! $metrics['has_og_title'] && ! $metrics['has_og_description'] && ! $metrics['has_og_image'] ) {
			$recommendations[] = array(
				'priority' => 'medium',
				'action'   => 'Add Open Graph tags',
				'details'  => 'Add OG tags for better social media sharing',
			);
		}

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze heading structure
	 *
	 * @param string $content Page content.
	 * @return array Heading analysis.
	 */
	private function analyze_headings( $content ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array(
			'h1_count' => 0,
			'h2_count' => 0,
			'h3_count' => 0,
			'h4_count' => 0,
			'h5_count' => 0,
			'h6_count' => 0,
		);

		// Count headings.
		for ( $i = 1; $i <= 6; $i++ ) {
			preg_match_all( "/<h{$i}[^>]*>/i", $content, $matches );
			$metrics[ "h{$i}_count" ] = count( $matches[0] );
		}

		// Check H1 usage.
		if ( $metrics['h1_count'] === 0 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'No H1 heading found',
				'severity' => 'high',
				'fix'      => 'Add one H1 heading that describes the main topic',
			);
		} elseif ( $metrics['h1_count'] > 1 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => sprintf( 'Multiple H1 headings found (%d)', $metrics['h1_count'] ),
				'severity' => 'medium',
				'fix'      => 'Use only one H1 heading per page',
			);
		}

		// Check for heading hierarchy.
		if ( $metrics['h2_count'] === 0 && ( $metrics['h3_count'] > 0 || $metrics['h4_count'] > 0 ) ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Improper heading hierarchy',
				'severity' => 'low',
				'fix'      => 'Use H2 headings before H3/H4 headings',
			);
		}

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze image alt text
	 *
	 * @param string $content Page content.
	 * @return array Image alt text analysis.
	 */
	private function analyze_image_alt_text( $content ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array(
			'total_images'       => 0,
			'images_with_alt'    => 0,
			'images_without_alt' => 0,
		);

		// Find all images.
		preg_match_all( '/<img[^>]+>/i', $content, $matches );
		$images = $matches[0];

		$metrics['total_images'] = count( $images );

		foreach ( $images as $img_tag ) {
			if ( preg_match( '/alt=["\']([^"\']*)["\']/', $img_tag, $alt_match ) ) {
				if ( ! empty( $alt_match[1] ) ) {
					$metrics['images_with_alt']++;
				} else {
					$metrics['images_without_alt']++;
				}
			} else {
				$metrics['images_without_alt']++;
			}
		}

		if ( $metrics['images_without_alt'] > 0 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => sprintf( '%d images missing alt text', $metrics['images_without_alt'] ),
				'severity' => 'medium',
				'fix'      => 'Add descriptive alt text to all images',
			);
		}

		$alt_coverage = $metrics['total_images'] > 0 ? ( $metrics['images_with_alt'] / $metrics['total_images'] ) * 100 : 100;
		$metrics['alt_text_coverage'] = round( $alt_coverage, 1 );

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze internal links
	 *
	 * @param string $content Page content.
	 * @return array Internal link analysis.
	 */
	private function analyze_internal_links( $content ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array(
			'total_links'    => 0,
			'internal_links' => 0,
			'external_links' => 0,
		);

		// Find all links.
		preg_match_all( '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>/i', $content, $matches );
		$links = $matches[1];

		$metrics['total_links'] = count( $links );

		$site_url = get_site_url();
		foreach ( $links as $link ) {
			if ( strpos( $link, $site_url ) !== false || strpos( $link, '/' ) === 0 ) {
				$metrics['internal_links']++;
			} else {
				$metrics['external_links']++;
			}
		}

		if ( $metrics['internal_links'] < 2 ) {
			$recommendations[] = array(
				'priority' => 'low',
				'action'   => 'Add more internal links',
				'details'  => 'Link to related content on your site to improve SEO and user experience',
			);
		}

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze content
	 *
	 * @param string $content Page content.
	 * @param string $title Page title.
	 * @return array Content analysis.
	 */
	private function analyze_content( $content, $title ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array();

		// Remove HTML tags for text analysis.
		$text = strip_tags( $content );

		// Word count — Unicode-aware to handle Cyrillic, CJK, and other non-ASCII scripts.
		$word_count = $this->unicode_word_count( $text );
		$metrics['word_count'] = $word_count;

		if ( $word_count < 300 ) {
			$issues[] = array(
				'type'     => 'warning',
				'message'  => 'Content too short',
				'severity' => 'medium',
				'fix'      => sprintf( 'Add more content (current: %d words, recommended: 300+ words)', $word_count ),
			);
		}

		// Character count — use mb_strlen to count characters, not bytes.
		$char_count = mb_strlen( $text, 'UTF-8' );
		$metrics['character_count'] = $char_count;

		// Keyword density (simple check for title words in content).
		$title_words = $this->unicode_word_array( mb_strtolower( $title, 'UTF-8' ) );
		$content_lower = mb_strtolower( $text, 'UTF-8' );
		$keyword_mentions = 0;
		foreach ( $title_words as $word ) {
			if ( mb_strlen( $word, 'UTF-8' ) > 3 ) { // Only count significant words.
				$keyword_mentions += substr_count( $content_lower, $word );
			}
		}
		$metrics['title_word_mentions'] = $keyword_mentions;

		if ( $word_count > 0 ) {
			$keyword_density = ( $keyword_mentions / $word_count ) * 100;
			$metrics['keyword_density'] = round( $keyword_density, 2 );

			if ( $keyword_density < 1 ) {
				$recommendations[] = array(
					'priority' => 'low',
					'action'   => 'Improve keyword usage',
					'details'  => 'Include title keywords more naturally throughout the content',
				);
			}
		}

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Analyze schema markup
	 *
	 * @param int $page_id Page ID.
	 * @return array Schema analysis.
	 */
	private function analyze_schema_markup( $page_id ) {
		$issues         = array();
		$recommendations = array();
		$metrics        = array(
			'has_schema' => false,
		);

		// Check for schema markup — supports Yoast, RankMath, AIOSEO, SEOPress, Genesis.
		$schema_meta_keys = array(
			'_yoast_wpseo_schema',
			'_genesis_schema',
			'schema_type',
			'_aioseo_schema_type',
			'_seopress_pro_schemas',
		);

		foreach ( $schema_meta_keys as $meta_key ) {
			$schema_data = get_post_meta( $page_id, $meta_key, true );
			if ( ! empty( $schema_data ) ) {
				$metrics['has_schema'] = true;
				break;
			}
		}

		// RankMath stores individual schemas as rank_math_schema_{block_id} meta keys.
		// Scan all post meta for any RankMath schema entry.
		if ( ! $metrics['has_schema'] ) {
			$all_meta = get_post_meta( $page_id );
			foreach ( array_keys( $all_meta ) as $meta_key ) {
				if ( strpos( $meta_key, 'rank_math_schema_' ) === 0 ) {
					$metrics['has_schema'] = true;
					break;
				}
			}
		}

		// Major SEO plugins (Yoast, RankMath, AIOSEO) auto-generate Article/WebPage schema
		// for posts/pages even without explicit schema meta. Detect active plugins as proxy.
		if ( ! $metrics['has_schema'] ) {
			$auto_schema_active = defined( 'RANK_MATH_VERSION' )
				|| defined( 'WPSEO_VERSION' )
				|| defined( 'AIOSEO_VERSION' )
				|| class_exists( 'RankMath' )
				|| class_exists( 'WPSEO_Options' );

			if ( $auto_schema_active ) {
				$metrics['has_schema'] = true;
			}
		}

		if ( ! $metrics['has_schema'] ) {
			$recommendations[] = array(
				'priority' => 'medium',
				'action'   => 'Add schema markup',
				'details'  => 'Add structured data (JSON-LD) for better search engine understanding',
			);
		}

		return array(
			'issues'          => $issues,
			'recommendations' => $recommendations,
			'metrics'         => $metrics,
		);
	}

	/**
	 * Get meta title
	 *
	 * @param int $page_id Page ID.
	 * @return string Meta title.
	 */
	private function get_meta_title( $page_id ) {
		// Try Yoast.
		$yoast_title = get_post_meta( $page_id, '_yoast_wpseo_title', true );
		if ( ! empty( $yoast_title ) ) {
			return $yoast_title;
		}

		// Try RankMath.
		$rankmath_title = get_post_meta( $page_id, 'rank_math_title', true );
		if ( ! empty( $rankmath_title ) ) {
			return $rankmath_title;
		}

		// Try All in One SEO.
		$aioseo_title = get_post_meta( $page_id, '_aioseo_title', true );
		if ( ! empty( $aioseo_title ) ) {
			return $aioseo_title;
		}

		// Fallback to post title.
		$post = get_post( $page_id );
		return $post ? $post->post_title : '';
	}

	/**
	 * Get meta description
	 *
	 * @param int $page_id Page ID.
	 * @return string Meta description.
	 */
	private function get_meta_description( $page_id ) {
		// Try Yoast.
		$yoast_desc = get_post_meta( $page_id, '_yoast_wpseo_metadesc', true );
		if ( ! empty( $yoast_desc ) ) {
			return $yoast_desc;
		}

		// Try RankMath.
		$rankmath_desc = get_post_meta( $page_id, 'rank_math_description', true );
		if ( ! empty( $rankmath_desc ) ) {
			return $rankmath_desc;
		}

		// Try All in One SEO.
		$aioseo_desc = get_post_meta( $page_id, '_aioseo_description', true );
		if ( ! empty( $aioseo_desc ) ) {
			return $aioseo_desc;
		}

		return '';
	}

	/**
	 * Calculate Flesch Reading Ease score (simplified)
	 *
	 * @param string $text Text to analyze.
	 * @return int Flesch score.
	 */
	private function calculate_flesch_score( $text ) {
		$word_count     = $this->unicode_word_count( $text );
		$sentence_count = preg_match_all( '/[.!?]+/', $text, $matches );
		$syllable_count = $this->count_syllables( $text );

		if ( $word_count === 0 || $sentence_count === 0 ) {
			return 0;
		}

		$asl = $word_count / $sentence_count;
		$asw = $syllable_count / $word_count;

		$flesch = 206.835 - ( 1.015 * $asl ) - ( 84.6 * $asw );

		return max( 0, min( 100, round( $flesch ) ) );
	}

	/**
	 * Count syllables in text (simplified)
	 *
	 * @param string $text Text to analyze.
	 * @return int Syllable count.
	 */
	private function count_syllables( $text ) {
		$words = $this->unicode_word_array( strtolower( $text ) );
		$syllables = 0;

		foreach ( $words as $word ) {
			$syllables += $this->count_word_syllables( $word );
		}

		return $syllables;
	}

	/**
	 * Count syllables in a word (simplified)
	 *
	 * @param string $word Word to analyze.
	 * @return int Syllable count.
	 */
	private function count_word_syllables( $word ) {
		$word = strtolower( trim( $word ) );
		if ( strlen( $word ) <= 3 ) {
			return 1;
		}

		$syllables = 0;
		$vowels    = array( 'a', 'e', 'i', 'o', 'u', 'y' );
		$previous_was_vowel = false;

		for ( $i = 0; $i < strlen( $word ); $i++ ) {
			$is_vowel = in_array( $word[ $i ], $vowels, true );

			if ( $is_vowel && ! $previous_was_vowel ) {
				$syllables++;
			}

			$previous_was_vowel = $is_vowel;
		}

		// Adjust for silent 'e'.
		if ( substr( $word, -1 ) === 'e' ) {
			$syllables--;
		}

		return max( 1, $syllables );
	}

	/**
	 * Get reading level from Flesch score
	 *
	 * @param int $score Flesch score.
	 * @return string Reading level.
	 */
	private function get_reading_level( $score ) {
		if ( $score >= 90 ) {
			return 'Very Easy (5th grade)';
		} elseif ( $score >= 80 ) {
			return 'Easy (6th grade)';
		} elseif ( $score >= 70 ) {
			return 'Fairly Easy (7th grade)';
		} elseif ( $score >= 60 ) {
			return 'Standard (8th-9th grade)';
		} elseif ( $score >= 50 ) {
			return 'Fairly Difficult (10th-12th grade)';
		} elseif ( $score >= 30 ) {
			return 'Difficult (College)';
		} else {
			return 'Very Difficult (College graduate)';
		}
	}

	/**
	 * Calculate SEO score
	 *
	 * @param array $issues Issues found.
	 * @param array $metrics Metrics collected.
	 * @return int Score (0-100).
	 */
	private function calculate_seo_score( $issues, $metrics ) {
		$score = 100;

		// Deduct points for issues.
		foreach ( $issues as $issue ) {
			switch ( $issue['severity'] ) {
				case 'critical':
					$score -= 25;
					break;
				case 'high':
					$score -= 15;
					break;
				case 'medium':
					$score -= 10;
					break;
				case 'low':
					$score -= 5;
					break;
			}
		}

		// Bonus points for good metrics.
		if ( isset( $metrics['alt_text_coverage'] ) && $metrics['alt_text_coverage'] >= 90 ) {
			$score += 5;
		}

		if ( isset( $metrics['word_count'] ) && $metrics['word_count'] >= 500 ) {
			$score += 5;
		}

		return max( 0, min( 100, $score ) );
	}

	/**
	 * Calculate readability score
	 *
	 * @param array $issues Issues found.
	 * @param array $metrics Metrics collected.
	 * @return int Score (0-100).
	 */
	private function calculate_readability_score( $issues, $metrics ) {
		$score = 100;

		// Deduct points for issues.
		foreach ( $issues as $issue ) {
			switch ( $issue['severity'] ) {
				case 'high':
					$score -= 20;
					break;
				case 'medium':
					$score -= 15;
					break;
				case 'low':
					$score -= 5;
					break;
			}
		}

		// Bonus for good Flesch score.
		if ( isset( $metrics['flesch_score'] ) && $metrics['flesch_score'] >= 60 ) {
			$score += 10;
		}

		return max( 0, min( 100, $score ) );
	}

	/**
	 * Count words in a Unicode-aware way (handles Cyrillic, CJK, etc.)
	 *
	 * @param string $text Plain text (no HTML).
	 * @return int Word count.
	 */
	private function unicode_word_count( $text ) {
		return count( $this->unicode_word_array( $text ) );
	}

	/**
	 * Extract word tokens from text using Unicode letter sequences.
	 *
	 * @param string $text Plain text.
	 * @return string[] Array of word tokens.
	 */
	private function unicode_word_array( $text ) {
		preg_match_all( '/\p{L}+/u', $text, $matches );
		return $matches[0];
	}

	/**
	 * Get letter grade from score
	 *
	 * @param int $score Score (0-100).
	 * @return string Letter grade.
	 */
	private function get_grade_from_score( $score ) {
		if ( $score >= 90 ) {
			return 'A';
		} elseif ( $score >= 80 ) {
			return 'B';
		} elseif ( $score >= 70 ) {
			return 'C';
		} elseif ( $score >= 60 ) {
			return 'D';
		} else {
			return 'F';
		}
	}

	/**
	 * Analyze Rank Math SEO fields and re-run its core checks server-side.
	 *
	 * Returns the cached Rank Math score, all current field values, a per-check
	 * pass/fail breakdown, and a ready-to-use `meta_updates` object you can
	 * pass directly to wordpress_update_post to fix every failing check.
	 *
	 * @since 4.3.2
	 * @param int $post_id Post ID to analyze.
	 * @return array
	 */
	public function analyze_rankmath( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array( 'success' => false, 'message' => 'Post not found' );
		}

		$is_rankmath_active = defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) || class_exists( 'RankMath\\RankMath' );

		// --- Collect all Rank Math meta fields ---
		$focus_keyword  = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
		$title          = (string) get_post_meta( $post_id, 'rank_math_title', true );
		$description    = (string) get_post_meta( $post_id, 'rank_math_description', true );
		$robots         = get_post_meta( $post_id, 'rank_math_robots', true );
		$canonical      = (string) get_post_meta( $post_id, 'rank_math_canonical_url', true );
		$og_title       = (string) get_post_meta( $post_id, 'rank_math_facebook_title', true );
		$og_desc        = (string) get_post_meta( $post_id, 'rank_math_facebook_description', true );
		$og_image_id    = get_post_meta( $post_id, 'rank_math_facebook_image_id', true );
		$tw_title       = (string) get_post_meta( $post_id, 'rank_math_twitter_title', true );
		$tw_desc        = (string) get_post_meta( $post_id, 'rank_math_twitter_description', true );
		$pillar         = (bool) get_post_meta( $post_id, 'rank_math_pillar_content', true );
		$cached_score   = get_post_meta( $post_id, 'rank_math_seo_score', true );

		// Collect schema blocks (rank_math_schema_{id} pattern).
		$all_meta = get_post_meta( $post_id );
		$schema_blocks = array();
		foreach ( $all_meta as $key => $values ) {
			if ( strpos( $key, 'rank_math_schema_' ) === 0 ) {
				$block = maybe_unserialize( $values[0] );
				$schema_blocks[ $key ] = $block;
			}
		}

		// --- Content signals ---
		$raw_content   = $post->post_content;
		$plain_content = wp_strip_all_tags( $raw_content );
		$word_count    = $this->unicode_word_count( $plain_content );
		$permalink     = get_permalink( $post_id );
		$slug          = $post->post_name;
		$post_title    = $post->post_title;

		// Effective title/description (Rank Math supports %title% variables; resolve common ones).
		$effective_title = $title ?: $post_title;
		$effective_title = str_replace( array( '%title%', '%page_title%', '%post_title%' ), $post_title, $effective_title );

		$kw_lower      = mb_strtolower( trim( $focus_keyword ) );
		$title_lower   = mb_strtolower( $effective_title );
		$desc_lower    = mb_strtolower( $description );
		$content_lower = mb_strtolower( $plain_content );
		$slug_lower    = mb_strtolower( $slug );

		// First-paragraph text (first 200 chars of content).
		$first_para    = mb_substr( $plain_content, 0, 200 );

		// Count keyword occurrences in content.
		$kw_count = 0;
		if ( '' !== $kw_lower && '' !== $content_lower ) {
			$kw_count = substr_count( $content_lower, $kw_lower );
		}

		// Image count and images missing alt.
		preg_match_all( '/<img[^>]+>/i', $raw_content, $img_tags );
		$img_total    = count( $img_tags[0] );
		$img_no_alt   = 0;
		$img_alt_with_kw = 0;
		foreach ( $img_tags[0] as $img ) {
			if ( preg_match( '/alt=["\']([^"\']*)["\']/', $img, $alt_match ) ) {
				$alt = mb_strtolower( $alt_match[1] );
				if ( '' === trim( $alt ) ) {
					++$img_no_alt;
				} elseif ( '' !== $kw_lower && false !== strpos( $alt, $kw_lower ) ) {
					++$img_alt_with_kw;
				}
			} else {
				++$img_no_alt;
			}
		}

		// Link counts.
		preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/i', $raw_content, $link_matches );
		$site_host      = wp_parse_url( home_url(), PHP_URL_HOST );
		$internal_links = 0;
		$external_links = 0;
		foreach ( $link_matches[1] as $href ) {
			$link_host = wp_parse_url( $href, PHP_URL_HOST );
			if ( ! $link_host || $link_host === $site_host ) {
				++$internal_links;
			} else {
				++$external_links;
			}
		}

		// Title & description lengths (after variable resolution, strip remaining %vars%).
		$clean_title = preg_replace( '/%[a-z_]+%/', '', $effective_title );
		$title_len   = mb_strlen( trim( $clean_title ) );
		$desc_len    = mb_strlen( trim( $description ) );

		// --- Run Rank Math-equivalent checks ---
		$checks = array();

		// 1. Focus keyword set.
		$checks[] = $this->rm_check(
			'focus_keyword_set',
			'Focus keyword is set',
			'' !== $kw_lower,
			'Set rank_math_focus_keyword to your primary target keyword.',
			array( 'rank_math_focus_keyword' => 'your-primary-keyword' ),
			10
		);

		// 2. Keyword in title.
		$checks[] = $this->rm_check(
			'keyword_in_title',
			'Focus keyword used in SEO title',
			'' !== $kw_lower && false !== strpos( $title_lower, $kw_lower ),
			'Include "' . $focus_keyword . '" in rank_math_title.',
			array( 'rank_math_title' => '%title% - ' . $focus_keyword . ' %sep% %sitename%' ),
			9
		);

		// 3. Keyword in meta description.
		$checks[] = $this->rm_check(
			'keyword_in_description',
			'Focus keyword used in meta description',
			'' !== $kw_lower && false !== strpos( $desc_lower, $kw_lower ),
			'Include "' . $focus_keyword . '" naturally in rank_math_description.',
			array( 'rank_math_description' => 'Description mentioning ' . $focus_keyword . '.' ),
			9
		);

		// 4. Keyword in first paragraph.
		$checks[] = $this->rm_check(
			'keyword_in_intro',
			'Focus keyword appears in introduction',
			'' !== $kw_lower && false !== strpos( mb_strtolower( $first_para ), $kw_lower ),
			'Use "' . $focus_keyword . '" in the opening paragraph of the page content.',
			null,
			8
		);

		// 5. Keyword in URL/slug.
		$checks[] = $this->rm_check(
			'keyword_in_url',
			'Focus keyword used in URL',
			'' !== $kw_lower && false !== strpos( $slug_lower, str_replace( ' ', '-', $kw_lower ) ),
			'Set the post slug to include "' . str_replace( ' ', '-', $kw_lower ) . '".',
			null,
			7
		);

		// 6. Meta title length (50–70 chars).
		$title_ok = '' !== $title && $title_len >= 50 && $title_len <= 70;
		$checks[] = $this->rm_check(
			'title_length',
			'SEO title width (50–70 chars)',
			$title_ok,
			'' === $title
				? 'Set rank_math_title. Aim for 50–70 characters.'
				: 'Current SEO title is ' . $title_len . ' chars. Adjust to 50–70.',
			'' === $title ? array( 'rank_math_title' => '%title% %sep% %sitename%' ) : null,
			8
		);

		// 7. Meta description length (120–160 chars).
		$desc_ok = '' !== $description && $desc_len >= 120 && $desc_len <= 160;
		$checks[] = $this->rm_check(
			'description_length',
			'Meta description length (120–160 chars)',
			$desc_ok,
			'' === $description
				? 'Set rank_math_description. Aim for 120–160 characters.'
				: 'Current description is ' . $desc_len . ' chars. Adjust to 120–160.',
			'' === $description ? array( 'rank_math_description' => 'Compelling description with ' . $focus_keyword . ' (aim for 150 chars).' ) : null,
			8
		);

		// 8. Content length (≥600 words).
		$checks[] = $this->rm_check(
			'content_length',
			'Content length (≥600 words)',
			$word_count >= 600,
			'Content is ' . $word_count . ' words. Add more depth to reach at least 600 words.',
			null,
			7
		);

		// 9. Keyword density (0.5%–2.5%).
		$density      = $word_count > 0 ? round( ( $kw_count / $word_count ) * 100, 2 ) : 0;
		$density_ok   = '' !== $kw_lower && $density >= 0.5 && $density <= 2.5;
		$checks[] = $this->rm_check(
			'keyword_density',
			'Keyword density (0.5%–2.5%)',
			$density_ok,
			'' === $kw_lower
				? 'Set a focus keyword first.'
				: ( $density < 0.5
					? 'Keyword appears only ' . $kw_count . ' times (' . $density . '%). Use it more naturally.'
					: 'Keyword density is ' . $density . '% — too high. Reduce repetition.' ),
			null,
			6
		);

		// 10. Has images.
		$checks[] = $this->rm_check(
			'has_images',
			'Content includes images',
			$img_total > 0,
			'Add at least one image to the post content.',
			null,
			5
		);

		// 11. Image alt text.
		$checks[] = $this->rm_check(
			'image_alt',
			'Images have alt text',
			$img_total === 0 || $img_no_alt === 0,
			$img_no_alt . ' of ' . $img_total . ' images are missing alt text. Add descriptive alt attributes.',
			null,
			6
		);

		// 12. Has internal links.
		$checks[] = $this->rm_check(
			'internal_links',
			'Post has internal links',
			$internal_links > 0,
			'Add at least one internal link to related content on your site.',
			null,
			5
		);

		// 13. Has schema markup.
		$has_schema = count( $schema_blocks ) > 0 || $is_rankmath_active;
		$checks[] = $this->rm_check(
			'schema_markup',
			'Schema markup present',
			$has_schema,
			count( $schema_blocks ) === 0
				? 'Add schema markup via Rank Math\'s Schema tab in the post editor.'
				: null,
			null,
			7
		);

		// --- Compute score ---
		$total_weight  = 0;
		$earned_weight = 0;
		foreach ( $checks as $check ) {
			$total_weight  += $check['weight'];
			if ( $check['pass'] ) {
				$earned_weight += $check['weight'];
			}
		}
		$computed_score = $total_weight > 0 ? (int) round( ( $earned_weight / $total_weight ) * 100 ) : 0;

		// Build actionable meta_updates from failing checks.
		$meta_updates = array();
		foreach ( $checks as $check ) {
			if ( ! $check['pass'] && ! empty( $check['meta_fix'] ) ) {
				$meta_updates = array_merge( $meta_updates, $check['meta_fix'] );
			}
		}

		$failing = array_filter( $checks, fn( $c ) => ! $c['pass'] );
		$passing = array_filter( $checks, fn( $c ) => $c['pass'] );

		return array(
			'success'          => true,
			'post_id'          => $post_id,
			'post_title'       => $post_title,
			'rankmath_active'  => $is_rankmath_active,
			'cached_score'     => '' !== (string) $cached_score ? (int) $cached_score : null,
			'computed_score'   => $computed_score,
			'grade'            => $this->get_grade_from_score( $computed_score ),
			'checks_passed'    => count( $passing ),
			'checks_failed'    => count( $failing ),
			'checks'           => array_values( $checks ),
			'current_fields'   => array(
				'focus_keyword'    => $focus_keyword ?: null,
				'title'            => $title ?: null,
				'description'      => $description ?: null,
				'robots'           => $robots ?: null,
				'canonical_url'    => $canonical ?: null,
				'og_title'         => $og_title ?: null,
				'og_description'   => $og_desc ?: null,
				'og_image_id'      => $og_image_id ?: null,
				'twitter_title'    => $tw_title ?: null,
				'twitter_desc'     => $tw_desc ?: null,
				'pillar_content'   => $pillar,
				'schema_blocks'    => array_keys( $schema_blocks ),
			),
			'content_signals'  => array(
				'word_count'       => $word_count,
				'keyword_count'    => $kw_count,
				'keyword_density'  => $density,
				'title_length'     => $title_len,
				'description_length' => $desc_len,
				'image_count'      => $img_total,
				'images_no_alt'    => $img_no_alt,
				'internal_links'   => $internal_links,
				'external_links'   => $external_links,
			),
			'meta_updates'     => ! empty( $meta_updates ) ? $meta_updates : null,
		);
	}

	/**
	 * Build a single Rank Math check result entry.
	 *
	 * @param string      $id       Check identifier.
	 * @param string      $label    Human-readable label.
	 * @param bool        $pass     Whether the check passes.
	 * @param string|null $fix      Recommendation when failing.
	 * @param array|null  $meta_fix Ready-to-use meta key→value pairs to fix this check.
	 * @param int         $weight   Relative weight for score calculation.
	 * @return array
	 */
	private function rm_check( $id, $label, $pass, $fix = null, $meta_fix = null, $weight = 5 ) {
		return array(
			'id'       => $id,
			'label'    => $label,
			'pass'     => (bool) $pass,
			'fix'      => $pass ? null : $fix,
			'meta_fix' => ( ! $pass && ! empty( $meta_fix ) ) ? $meta_fix : null,
			'weight'   => $weight,
		);
	}
}
