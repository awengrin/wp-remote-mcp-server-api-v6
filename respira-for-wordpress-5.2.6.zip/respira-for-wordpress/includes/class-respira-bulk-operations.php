<?php
/**
 * Bulk Page Operations for multi-page batch processing.
 *
 * Applies operations across multiple pages with mandatory snapshots,
 * rate limiting, and per-page error handling.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_Bulk_Operations {

	/**
	 * Maximum pages per bulk operation.
	 *
	 * @var int
	 */
	const MAX_PAGES = 100;

	/**
	 * Maximum non-dry-run bulk operations per hour per API key.
	 *
	 * @var int
	 */
	const RATE_LIMIT = 3;

	/**
	 * Register REST routes.
	 *
	 * @since 5.2.0
	 */
	public function register_routes() {
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/bulk',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_bulk_operation' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'page_ids'  => array(
						'required' => true,
						'type'     => 'array',
					),
					'operation' => array(
						'required' => true,
						'type'     => 'object',
					),
					'options'   => array(
						'required' => false,
						'type'     => 'object',
						'default'  => array(),
					),
				),
			)
		);
	}

	/**
	 * Permission check — requires API key + manage_options.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function permission_check( $request ) {
		$api = new Respira_API();
		$result = $api->api_key_permission_check( $request );
		if ( is_wp_error( $result ) || true !== $result ) {
			return $result;
		}

		$is_dev_mode = defined( 'RESPIRA_DEV_MODE' ) && RESPIRA_DEV_MODE;
		if ( ! $is_dev_mode && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'respira_insufficient_permissions',
				__( 'Bulk operations require manage_options capability.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Handle bulk operation request.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_bulk_operation( $request ) {
		$page_ids  = $request->get_param( 'page_ids' );
		$operation = $request->get_param( 'operation' );
		$options   = $request->get_param( 'options' );
		$dry_run   = ! empty( $options['dry_run'] );

		// Validate page count.
		if ( count( $page_ids ) > self::MAX_PAGES ) {
			return new WP_Error(
				'respira_bulk_too_many_pages',
				sprintf(
					__( 'Maximum %d pages per bulk operation.', 'respira-for-wordpress' ),
					self::MAX_PAGES
				),
				array( 'status' => 400 )
			);
		}

		// Validate operation type.
		$op_type = isset( $operation['type'] ) ? $operation['type'] : '';
		$valid_types = array( 'strip_inline_styles', 'find_and_replace', 'custom' );
		if ( ! in_array( $op_type, $valid_types, true ) ) {
			return new WP_Error(
				'respira_invalid_operation',
				sprintf(
					__( 'Invalid operation type. Valid types: %s', 'respira-for-wordpress' ),
					implode( ', ', $valid_types )
				),
				array( 'status' => 400 )
			);
		}

		// Rate limit check (skip for dry runs).
		if ( ! $dry_run ) {
			$rate_check = $this->check_rate_limit( $request );
			if ( is_wp_error( $rate_check ) ) {
				return $rate_check;
			}
		}

		// Concurrent execution lock (skip for dry runs).
		if ( ! $dry_run ) {
			$lock = $this->acquire_lock();
			if ( is_wp_error( $lock ) ) {
				return $lock;
			}
		}

		// Process pages.
		$results   = array();
		$succeeded = 0;
		$failed    = 0;

		foreach ( $page_ids as $page_id ) {
			$page_id = absint( $page_id );
			$page_result = array(
				'page_id'      => $page_id,
				'status'       => 'skipped',
				'changes_made' => array(),
				'snapshot_id'  => null,
				'error'        => null,
			);

			$post = get_post( $page_id );
			if ( ! $post ) {
				$page_result['status'] = 'failed';
				$page_result['error']  = 'Post not found.';
				++$failed;
				$results[] = $page_result;
				continue;
			}

			// Create snapshot before changes (mandatory for non-dry-run).
			if ( ! $dry_run && class_exists( 'Respira_Snapshots' ) ) {
				$snapshots = Respira_Snapshots::get_instance();
				if ( method_exists( $snapshots, 'create_snapshot' ) ) {
					$snapshot_id = $snapshots->create_snapshot( $page_id, array(
						'kind'   => 'bulk',
						'reason' => sprintf( 'Pre-bulk %s operation', $op_type ),
					) );
					if ( ! is_wp_error( $snapshot_id ) ) {
						$page_result['snapshot_id'] = $snapshot_id;
					}
				}
			}

			// Apply operation.
			$op_result = $this->apply_operation( $page_id, $post, $operation, $dry_run );

			if ( is_wp_error( $op_result ) ) {
				$page_result['status'] = 'failed';
				$page_result['error']  = $op_result->get_error_message();
				++$failed;
			} else {
				$page_result['status']       = $dry_run ? 'preview' : 'success';
				$page_result['changes_made'] = $op_result;
				++$succeeded;
			}

			$results[] = $page_result;
		}

		// Release lock.
		if ( ! $dry_run ) {
			$this->release_lock();
			$this->increment_rate_counter( $request );
		}

		// Log action.
		$this->log_action( $request, 'bulk_operation', array(
			'operation' => $op_type,
			'page_count' => count( $page_ids ),
			'succeeded'  => $succeeded,
			'failed'     => $failed,
			'dry_run'    => $dry_run,
		) );

		return new WP_REST_Response(
			array(
				'processed' => count( $page_ids ),
				'succeeded' => $succeeded,
				'failed'    => $failed,
				'dry_run'   => $dry_run,
				'results'   => $results,
			),
			200
		);
	}

	/**
	 * Apply an operation to a single page.
	 *
	 * @param int     $page_id   Page ID.
	 * @param WP_Post $post      Post object.
	 * @param array   $operation Operation config.
	 * @param bool    $dry_run   Whether this is a dry run.
	 * @return array|WP_Error Changes made or error.
	 */
	private function apply_operation( $page_id, $post, $operation, $dry_run ) {
		$op_type    = $operation['type'];
		$op_options = isset( $operation['options'] ) ? $operation['options'] : array();

		switch ( $op_type ) {
			case 'strip_inline_styles':
				return $this->op_strip_inline_styles( $page_id, $post, $op_options, $dry_run );

			case 'find_and_replace':
				return $this->op_find_and_replace( $page_id, $post, $op_options, $dry_run );

			case 'custom':
				return $this->op_custom( $page_id, $post, $op_options, $dry_run );

			default:
				return new WP_Error(
					'respira_unknown_operation',
					__( 'Unknown operation type.', 'respira-for-wordpress' )
				);
		}
	}

	/**
	 * Strip inline styles from all content.
	 *
	 * @param int     $page_id    Page ID.
	 * @param WP_Post $post       Post object.
	 * @param array   $options    Operation options.
	 * @param bool    $dry_run    Dry run flag.
	 * @return array Changes made.
	 */
	private function op_strip_inline_styles( $page_id, $post, $options, $dry_run ) {
		$content  = $post->post_content;
		$original = $content;

		// Remove inline style attributes.
		$content = preg_replace( '/\s+style\s*=\s*["\'][^"\']*["\']/i', '', $content );

		$changes = array();
		if ( $content !== $original ) {
			$changes[] = 'Stripped inline styles from post content.';

			if ( ! $dry_run ) {
				wp_update_post( array(
					'ID'           => $page_id,
					'post_content' => $content,
				) );
			}
		}

		// Also check builder meta if available.
		if ( class_exists( 'Respira_Builder_Interface' ) ) {
			$builder = Respira_Builder_Interface::detect_builder( $page_id );
			if ( $builder && method_exists( $builder, 'extract_content' ) ) {
				$builder_content = $builder->extract_content( $page_id );
				if ( ! is_wp_error( $builder_content ) && is_string( $builder_content ) ) {
					$stripped = preg_replace( '/\s+style\s*=\s*["\'][^"\']*["\']/i', '', $builder_content );
					if ( $stripped !== $builder_content ) {
						$changes[] = 'Stripped inline styles from builder content.';
						if ( ! $dry_run && method_exists( $builder, 'inject_content' ) ) {
							$builder->inject_content( $page_id, $stripped );
						}
					}
				}
			}
		}

		if ( empty( $changes ) ) {
			$changes[] = 'No inline styles found.';
		}

		return $changes;
	}

	/**
	 * Find and replace text/attributes across page content.
	 *
	 * @param int     $page_id    Page ID.
	 * @param WP_Post $post       Post object.
	 * @param array   $options    Operation options.
	 * @param bool    $dry_run    Dry run flag.
	 * @return array|WP_Error Changes made.
	 */
	private function op_find_and_replace( $page_id, $post, $options, $dry_run ) {
		$find    = isset( $options['find'] ) ? $options['find'] : '';
		$replace = isset( $options['replace'] ) ? $options['replace'] : '';
		$is_regex = ! empty( $options['regex'] );

		if ( empty( $find ) ) {
			return new WP_Error(
				'respira_missing_find',
				__( 'find_and_replace requires a "find" parameter.', 'respira-for-wordpress' )
			);
		}

		$content  = $post->post_content;
		$original = $content;
		$count    = 0;

		if ( $is_regex ) {
			$content = preg_replace( $find, $replace, $content, -1, $count );
			if ( null === $content ) {
				return new WP_Error(
					'respira_invalid_regex',
					__( 'Invalid regex pattern.', 'respira-for-wordpress' )
				);
			}
		} else {
			$count   = substr_count( $content, $find );
			$content = str_replace( $find, $replace, $content );
		}

		$changes = array();
		if ( $count > 0 ) {
			$changes[] = sprintf( 'Replaced %d occurrence(s) in post content.', $count );
			if ( ! $dry_run ) {
				wp_update_post( array(
					'ID'           => $page_id,
					'post_content' => $content,
				) );
			}
		} else {
			$changes[] = 'No matches found in post content.';
		}

		return $changes;
	}

	/**
	 * Apply custom batch_update operations.
	 *
	 * @param int     $page_id    Page ID.
	 * @param WP_Post $post       Post object.
	 * @param array   $options    Operation options (batch_update format).
	 * @param bool    $dry_run    Dry run flag.
	 * @return array|WP_Error Changes made.
	 */
	private function op_custom( $page_id, $post, $options, $dry_run ) {
		$operations = isset( $options['operations'] ) ? $options['operations'] : array();

		if ( empty( $operations ) ) {
			return new WP_Error(
				'respira_missing_operations',
				__( 'Custom operation requires an "operations" array.', 'respira-for-wordpress' )
			);
		}

		if ( $dry_run ) {
			return array( sprintf( 'Would apply %d operation(s) to page %d.', count( $operations ), $page_id ) );
		}

		if ( ! class_exists( 'Respira_Builder_Interface' ) ) {
			return new WP_Error(
				'respira_no_builder',
				__( 'Builder interface not available.', 'respira-for-wordpress' )
			);
		}

		$builder = Respira_Builder_Interface::detect_builder( $page_id );
		if ( ! $builder ) {
			return new WP_Error(
				'respira_no_builder',
				__( 'No builder detected for this page.', 'respira-for-wordpress' )
			);
		}

		if ( ! method_exists( $builder, 'batch_update' ) ) {
			return new WP_Error(
				'respira_not_supported',
				__( 'Builder does not support batch_update.', 'respira-for-wordpress' )
			);
		}

		$result = $builder->batch_update( $page_id, $operations );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array( sprintf( 'Applied %d operation(s) to page %d.', count( $operations ), $page_id ) );
	}

	/**
	 * Check rate limit.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return true|WP_Error
	 */
	private function check_rate_limit( $request ) {
		$key_prefix = $this->get_key_prefix( $request );
		$transient  = 'respira_bulk_rate_' . $key_prefix;
		$count      = (int) get_transient( $transient );

		if ( $count >= self::RATE_LIMIT ) {
			return new WP_Error(
				'respira_bulk_rate_limit',
				sprintf(
					__( 'Maximum %d bulk operations per hour. Please try again later.', 'respira-for-wordpress' ),
					self::RATE_LIMIT
				),
				array( 'status' => 429 )
			);
		}

		return true;
	}

	/**
	 * Increment rate counter after successful operation.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	private function increment_rate_counter( $request ) {
		$key_prefix = $this->get_key_prefix( $request );
		$transient  = 'respira_bulk_rate_' . $key_prefix;
		$count      = (int) get_transient( $transient );
		set_transient( $transient, $count + 1, HOUR_IN_SECONDS );
	}

	/**
	 * Get API key prefix for rate limiting.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return string
	 */
	private function get_key_prefix( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$key      = isset( $key_data['api_key'] ) ? $key_data['api_key'] : 'unknown';
		return substr( $key, 0, 16 );
	}

	/**
	 * Acquire concurrent execution lock.
	 *
	 * @return true|WP_Error
	 */
	private function acquire_lock() {
		if ( get_transient( 'respira_bulk_lock' ) ) {
			return new WP_Error(
				'respira_bulk_in_progress',
				__( 'Another bulk operation is running. Please wait.', 'respira-for-wordpress' ),
				array( 'status' => 409 )
			);
		}

		set_transient( 'respira_bulk_lock', time(), 10 * MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Release concurrent execution lock.
	 */
	private function release_lock() {
		delete_transient( 'respira_bulk_lock' );
	}

	/**
	 * Log bulk action.
	 *
	 * @param WP_REST_Request $request Request.
	 * @param string          $action  Action name.
	 * @param array           $details Details.
	 */
	private function log_action( $request, $action, $details = array() ) {
		$key_data = $request->get_param( '_respira_key_data' );
		if ( $key_data && class_exists( 'Respira_Auth' ) ) {
			Respira_Auth::log_action(
				isset( $key_data['id'] ) ? $key_data['id'] : 0,
				isset( $key_data['user_id'] ) ? $key_data['user_id'] : 0,
				$action,
				'bulk_operations',
				null
			);
		}
	}
}
