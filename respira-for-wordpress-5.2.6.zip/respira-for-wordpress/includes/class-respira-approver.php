<?php
/**
 * Page/post approval functionality.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * Page/post approval functionality.
 *
 * Handles the approval of duplicate pages/posts to replace originals.
 *
 * @since 1.2.0
 */
class Respira_Approver {

	/**
	 * Approve a duplicate page/post to replace the original.
	 *
	 * @since 1.2.0
	 * @param int $duplicate_id The ID of the duplicate post to approve.
	 * @param array $args Optional approval arguments.
	 * @return array|WP_Error Array on success, WP_Error on failure.
	 */
	public static function approve_duplicate( $duplicate_id, $args = array() ) {
		$force         = ! empty( $args['force'] );
		$allow_force   = ! empty( $args['allow_force'] );
		$actor_api_key = isset( $args['actor_api_key_id'] ) ? absint( $args['actor_api_key_id'] ) : null;
		if ( ! $allow_force && isset( $args['key_data'] ) && is_array( $args['key_data'] ) && class_exists( 'Respira_Auth' ) ) {
			$allow_force = Respira_Auth::has_v2_scope( $args['key_data'], 'approve_force' );
		}

		// Verify it's a duplicate.
		if ( ! Respira_Duplicator::is_duplicate( $duplicate_id ) ) {
			return new WP_Error(
				'respira_not_duplicate',
				__( 'This page/post is not a Respira duplicate and cannot be approved.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		// Get the original post ID.
		$original_id = Respira_Duplicator::get_original_id( $duplicate_id );
		if ( ! $original_id ) {
			return new WP_Error(
				'respira_original_not_found',
				__( 'Original post not found for this duplicate.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		// Get post objects.
		$duplicate = get_post( $duplicate_id );
		$original  = get_post( $original_id );

		if ( ! $duplicate || ! $original ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$duplicate_base_uuid   = (string) get_post_meta( $duplicate_id, '_respira_snapshot_base_uuid', true );
		$original_current_uuid = (string) get_post_meta( $original_id, '_respira_snapshot_current_uuid', true );
		$stale_base            = false;
		$stale_context         = array(
			'duplicate_id'          => $duplicate_id,
			'original_id'           => $original_id,
			'base_snapshot_uuid'    => $duplicate_base_uuid,
			'current_snapshot_uuid' => $original_current_uuid,
		);

		if ( $duplicate_base_uuid && class_exists( 'Respira_Snapshots' ) && class_exists( 'Respira_Fidelity' ) ) {
			$base_snapshot = Respira_Snapshots::get_instance()->get_snapshot( $duplicate_base_uuid, false );
			if ( ! is_wp_error( $base_snapshot ) ) {
				$base_hashes    = isset( $base_snapshot['hashes'] ) && is_array( $base_snapshot['hashes'] ) ? $base_snapshot['hashes'] : array();
				$current_hashes = Respira_Fidelity::compute_hashes( $original_id );

				foreach ( array( 'builder_hash', 'rendered_hash', 'allowlisted_meta_hash' ) as $hash_key ) {
					$from = isset( $base_hashes[ $hash_key ] ) ? (string) $base_hashes[ $hash_key ] : '';
					$to   = isset( $current_hashes[ $hash_key ] ) ? (string) $current_hashes[ $hash_key ] : '';
					if ( '' !== $from && '' !== $to && $from !== $to ) {
						$stale_base = true;
						break;
					}
				}

				$stale_context['base_hashes']    = $base_hashes;
				$stale_context['current_hashes'] = $current_hashes;
			}
		} elseif ( $duplicate_base_uuid && $original_current_uuid && $duplicate_base_uuid !== $original_current_uuid ) {
			$stale_base = true;
		}

		if ( $stale_base ) {
			if ( ! $force ) {
				return new WP_Error(
					'respira_stale_base',
					__( 'Approval blocked: original content changed after duplicate creation. Re-sync or force approve with elevated authorization.', 'respira-for-wordpress' ),
					array_merge(
						array( 'status' => 409 ),
						$stale_context
					)
				);
			}

			if ( ! $allow_force ) {
				return new WP_Error(
					'respira_force_not_allowed',
					__( 'Force approval requires elevated authorization.', 'respira-for-wordpress' ),
					array( 'status' => 403 )
				);
			}
		}

		if ( class_exists( 'Respira_Snapshots' ) ) {
			Respira_Snapshots::get_instance()->capture_snapshot(
				$duplicate_id,
				'before_approve',
				array( 'actor_api_key_id' => $actor_api_key )
			);
		}

		$approval_mode = 'swap_duplicate_live';
		$approved_id   = $duplicate_id;
		$live_id       = $duplicate_id;
		$old_slug      = '';
		$original_slug = (string) $original->post_name;
		if ( empty( $original_slug ) ) {
			$original_slug = sanitize_title( $original->post_title );
		}

		if ( self::should_preserve_original_id_on_approve( $original ) ) {
			$approval_mode = 'merge_into_original_id';

			// Create a WP revision of the original so pre-approval state is in the editor Revisions panel.
			if ( function_exists( 'wp_save_post_revision' ) ) {
				wp_save_post_revision( $original_id );
			}

			$merge_result  = self::approve_duplicate_by_merging_into_original( $duplicate, $original, $actor_api_key );
			if ( is_wp_error( $merge_result ) ) {
				return $merge_result;
			}
			$approved_id = $original_id;
			$live_id     = $original_id;
		} else {
			// Handle original page: make private and rename slug.
			$old_slug = self::handle_slug_conflict( $original_slug . '-old', $original_id );
			$result   = wp_update_post(
				array(
					'ID'          => $original_id,
					'post_status' => 'private',
					'post_name'   => $old_slug,
				),
				true
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			// Update duplicate: set to original slug and publish.
			// For legacy duplicates that carried a technical title suffix, normalize back
			// to the clean original title to avoid leaking internal markers on storefronts.
			$approved_title = self::resolve_approved_duplicate_title( $duplicate, $original );
			$result         = wp_update_post(
				array(
					'ID'          => $duplicate_id,
					'post_title'  => $approved_title,
					'post_status' => 'publish',
					'post_name'   => $original_slug,
				),
				true
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			// Reassign nav menu items that pointed to the original (now private).
			self::reassign_menu_items( $original_id, $duplicate_id );

			// Remove duplicate marker from approved page.
			delete_post_meta( $duplicate_id, '_respira_duplicate' );
			delete_post_meta( $duplicate_id, '_respira_original_id' );
			delete_post_meta( $duplicate_id, '_respira_duplicated_at' );

			// Store approval metadata.
			update_post_meta( $duplicate_id, '_respira_approved_at', current_time( 'mysql' ) );
			update_post_meta( $duplicate_id, '_respira_approved_by', get_current_user_id() );
			update_post_meta( $duplicate_id, '_respira_old_post_id', $original_id );

			if ( class_exists( 'Respira_Snapshots' ) ) {
				$after = Respira_Snapshots::get_instance()->capture_snapshot(
					$duplicate_id,
					'after_approve',
					array( 'actor_api_key_id' => $actor_api_key )
				);
				if ( ! is_wp_error( $after ) && ! empty( $after['snapshot_uuid'] ) ) {
					update_post_meta( $duplicate_id, '_respira_snapshot_base_uuid', $after['snapshot_uuid'] );
				}
			}
		}

		// Log approval action.
		if ( class_exists( 'Respira_Auth' ) ) {
			Respira_Auth::log_action(
				null,
				get_current_user_id(),
				'approve_duplicate',
				$duplicate->post_type,
				$duplicate_id,
				array(
						'original_id' => $original_id,
						'old_slug'    => $old_slug,
						'new_slug'    => $original_slug,
						'forced'      => (bool) $force,
						'approval_mode' => $approval_mode,
						'live_post_id'  => $live_id,
					)
				);
		}

		/**
		 * Fires after a duplicate has been approved.
		 *
		 * @since 1.2.0
		 * @param int $duplicate_id The ID of the approved duplicate.
		 * @param int $original_id  The ID of the original post (now private).
		 */
		do_action( 'respira_after_approve_duplicate', $duplicate_id, $original_id );

		return array(
			'success'       => true,
			'approval_mode' => $approval_mode,
			'live_post_id'  => $live_id,
			'approved_id'   => $approved_id,
			'original_id'   => $original_id,
			'duplicate_id'  => $duplicate_id,
		);
	}

	/**
	 * Decide whether approval should preserve the original post ID.
	 *
	 * Products are preserved by default to avoid Meta/Google catalog desync.
	 * CPTs to exclude from merge mode can be configured via Settings > Exclude CPTs from Merge Mode (`respira_preserve_id_cpt_slugs`).
	 *
	 * @since 4.0.11
	 * @param WP_Post $original Original post object.
	 * @return bool
	 */
	private static function should_preserve_original_id_on_approve( $original ) {
		if ( ! $original instanceof WP_Post ) {
			return false;
		}

		$enabled = (int) get_option( 'respira_preserve_product_ids_on_approve', 1 );
		if ( 1 !== $enabled ) {
			return false;
		}

		$post_type = (string) $original->post_type;

		// Default to merge mode for all post types to preserve URLs and menu links.
		// Individual CPTs can still opt out via the filter below.
		$should_keep = true;

		// Respect per-CPT exclusion list if configured via Settings > Exclude CPTs from Merge Mode.
		$exclude_csv = (string) get_option( 'respira_preserve_id_cpt_slugs', '' );
		$excluded    = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $exclude_csv ) ) ) );
		if ( in_array( $post_type, $excluded, true ) ) {
			$should_keep = false;
		}

		/**
		 * Filter post types that should preserve original IDs during approve.
		 *
		 * Since 5.0 this defaults to true for ALL post types (merge mode).
		 * Return false to revert to the old swap behavior for specific types.
		 *
		 * @since 4.0.11
		 * @param bool   $should_keep Current decision.
		 * @param string $post_type   Post type being approved.
		 * @param WP_Post $original   Original post object.
		 */
		return (bool) apply_filters( 'respira_preserve_original_id_on_approve', $should_keep, $post_type, $original );
	}

	/**
	 * Apply approved duplicate changes to the original post ID.
	 *
	 * Keeps live ID/permalink stable while preserving duplicate as private backup.
	 *
	 * @since 4.0.11
	 * @param WP_Post  $duplicate Duplicate post object.
	 * @param WP_Post  $original  Original post object.
	 * @param int|null $actor_api_key Actor API key ID.
	 * @return true|WP_Error
	 */
	private static function approve_duplicate_by_merging_into_original( $duplicate, $original, $actor_api_key = null ) {
		$approved_title = self::resolve_approved_duplicate_title( $duplicate, $original );
		$original_id    = (int) $original->ID;
		$duplicate_id   = (int) $duplicate->ID;

		if ( class_exists( 'Respira_Snapshots' ) ) {
			Respira_Snapshots::get_instance()->capture_snapshot(
				$original_id,
				'before_approve_merge',
				array( 'actor_api_key_id' => $actor_api_key )
			);
		}

		$update_result = wp_update_post(
			array(
				'ID'             => $original_id,
				'post_title'     => $approved_title,
				'post_content'   => (string) $duplicate->post_content,
				'post_excerpt'   => (string) $duplicate->post_excerpt,
				'post_author'    => (int) $duplicate->post_author,
				'post_parent'    => (int) $duplicate->post_parent,
				'menu_order'     => (int) $duplicate->menu_order,
				'comment_status' => (string) $duplicate->comment_status,
				'ping_status'    => (string) $duplicate->ping_status,
				'post_status'    => ( 'trash' === $original->post_status ) ? 'publish' : (string) $original->post_status,
			),
			true
		);
		if ( is_wp_error( $update_result ) ) {
			return $update_result;
		}

		$meta_result = self::replace_post_meta_from_duplicate( $duplicate_id, $original_id );
		if ( is_wp_error( $meta_result ) ) {
			return $meta_result;
		}

		$tax_result = self::replace_post_terms_from_duplicate( $duplicate_id, $original_id, (string) $original->post_type );
		if ( is_wp_error( $tax_result ) ) {
			return $tax_result;
		}

		$backup_slug   = self::handle_slug_conflict( $original->post_name . '-respira-backup-' . gmdate( 'YmdHis' ), $duplicate_id );
		$backup_update = wp_update_post(
			array(
				'ID'          => $duplicate_id,
				'post_status' => 'private',
				'post_name'   => $backup_slug,
			),
			true
		);
		if ( is_wp_error( $backup_update ) ) {
			return $backup_update;
		}

		delete_post_meta( $duplicate_id, '_respira_duplicate' );
		delete_post_meta( $duplicate_id, '_respira_original_id' );
		delete_post_meta( $duplicate_id, '_respira_duplicated_at' );
		delete_post_meta( $duplicate_id, '_respira_duplicate_suffix' );

		update_post_meta( $duplicate_id, '_respira_approved_at', current_time( 'mysql' ) );
		update_post_meta( $duplicate_id, '_respira_approved_by', get_current_user_id() );
		update_post_meta( $duplicate_id, '_respira_old_post_id', $original_id );
		update_post_meta( $duplicate_id, '_respira_backup_for_id', $original_id );
		update_post_meta( $duplicate_id, '_respira_approval_mode', 'merge_into_original_id' );
		update_post_meta( $original_id, '_respira_last_approved_duplicate_id', $duplicate_id );
		update_post_meta( $original_id, '_respira_last_approved_at', current_time( 'mysql' ) );

		if ( class_exists( 'Respira_Snapshots' ) ) {
			$after = Respira_Snapshots::get_instance()->capture_snapshot(
				$original_id,
				'after_approve_merge',
				array( 'actor_api_key_id' => $actor_api_key )
			);
			if ( ! is_wp_error( $after ) && ! empty( $after['snapshot_uuid'] ) ) {
				update_post_meta( $duplicate_id, '_respira_snapshot_base_uuid', $after['snapshot_uuid'] );
			}
		}

		return true;
	}

	/**
	 * Replace original post meta with duplicate post meta.
	 *
	 * @since 4.0.11
	 * @param int $from_post_id Source duplicate post ID.
	 * @param int $to_post_id Destination original post ID.
	 * @return true|WP_Error
	 */
	private static function replace_post_meta_from_duplicate( $from_post_id, $to_post_id ) {
		$source_meta = get_post_meta( $from_post_id );
		$target_meta = get_post_meta( $to_post_id );

		foreach ( array_keys( $target_meta ) as $meta_key ) {
			if ( self::should_skip_merge_meta_key( $meta_key ) ) {
				continue;
			}
			delete_post_meta( $to_post_id, $meta_key );
		}

		foreach ( $source_meta as $meta_key => $meta_values ) {
			if ( self::should_skip_merge_meta_key( $meta_key ) ) {
				continue;
			}

			foreach ( $meta_values as $meta_value ) {
				$value = maybe_unserialize( $meta_value );
				add_post_meta( $to_post_id, $meta_key, wp_slash( $value ) );
			}
		}

		// Builder-specific post-merge cache invalidation.
		// Raw meta copy bypasses builder inject_content(), so caches (CSS, HTML)
		// must be cleared explicitly or the frontend serves stale content.
		self::invalidate_builder_caches( $to_post_id );

		return true;
	}

	/**
	 * Invalidate page builder caches after a raw meta merge.
	 *
	 * Each builder stores compiled CSS/HTML that becomes stale when post meta
	 * is replaced via raw add_post_meta(). This method detects the active
	 * builder and triggers the appropriate cache regeneration hooks.
	 *
	 * @since 5.2.0
	 * @param int $post_id Post ID whose caches need clearing.
	 */
	private static function invalidate_builder_caches( $post_id ) {
		// Bricks: clear page cache + regenerate CSS file.
		if ( get_post_meta( $post_id, '_bricks_page_content_2', true ) || get_post_meta( $post_id, '_bricks_page_content', true ) ) {
			if ( function_exists( 'bricks_clear_page_cache' ) ) {
				bricks_clear_page_cache( $post_id );
			}
			do_action( 'bricks/generate_css_file', $post_id );
		}

		// Elementor: clear CSS cache so frontend re-renders.
		if ( class_exists( '\Elementor\Plugin' ) && get_post_meta( $post_id, '_elementor_data', true ) ) {
			if ( method_exists( '\Elementor\Plugin', 'instance' ) ) {
				$elementor = \Elementor\Plugin::instance();
				if ( isset( $elementor->files_manager ) && method_exists( $elementor->files_manager, 'clear_cache' ) ) {
					$elementor->files_manager->clear_cache();
				}
			}
		}

		// Beaver Builder: clear asset cache.
		if ( class_exists( 'FLBuilderModel' ) && get_post_meta( $post_id, '_fl_builder_data', true ) ) {
			if ( method_exists( 'FLBuilderModel', 'delete_asset_cache' ) ) {
				\FLBuilderModel::delete_asset_cache( $post_id );
			}
		}

		// Divi: trigger static CSS regeneration.
		if ( function_exists( 'et_core_page_resource_auto_clear' ) ) {
			et_core_page_resource_auto_clear( $post_id );
		}
	}

	/**
	 * Replace original post terms with duplicate terms.
	 *
	 * @since 4.0.11
	 * @param int    $from_post_id Source duplicate post ID.
	 * @param int    $to_post_id Destination original post ID.
	 * @param string $post_type Post type.
	 * @return true|WP_Error
	 */
	private static function replace_post_terms_from_duplicate( $from_post_id, $to_post_id, $post_type ) {
		$taxonomies = get_object_taxonomies( $post_type );
		foreach ( $taxonomies as $taxonomy ) {
			$terms = wp_get_object_terms(
				$from_post_id,
				$taxonomy,
				array( 'fields' => 'ids' )
			);
			if ( is_wp_error( $terms ) ) {
				return $terms;
			}
			wp_set_object_terms( $to_post_id, $terms, $taxonomy, false );
		}

		return true;
	}

	/**
	 * Skip internal/meta keys that should never be merged back to original.
	 *
	 * @since 4.0.11
	 * @param string $meta_key Meta key.
	 * @return bool
	 */
	private static function should_skip_merge_meta_key( $meta_key ) {
		if ( 0 === strpos( (string) $meta_key, '_respira_' ) ) {
			return true;
		}

		return in_array(
			(string) $meta_key,
			array(
				'_edit_lock',
				'_edit_last',
				'_wp_old_slug',
				'_wp_old_date',
			),
			true
		);
	}

	/**
	 * Resolve the title to use when publishing an approved duplicate.
	 *
	 * Keeps intentional AI title edits, but strips technical duplicate suffixes
	 * that were used by legacy duplicate creation flows.
	 *
	 * @since 4.0.10
	 * @param WP_Post $duplicate Duplicate post object.
	 * @param WP_Post $original Original post object.
	 * @return string
	 */
	private static function resolve_approved_duplicate_title( $duplicate, $original ) {
		$duplicate_title = (string) $duplicate->post_title;
		$original_title  = (string) $original->post_title;

		if ( '' === $duplicate_title ) {
			return $original_title;
		}

		$stored_suffix = (string) get_post_meta( $duplicate->ID, '_respira_duplicate_suffix', true );
		if ( '' !== $stored_suffix && $original_title . $stored_suffix === $duplicate_title ) {
			return $original_title;
		}

		// Legacy format: "<original>_duplicate_<timestamp>".
		if ( preg_match( '/_duplicate_\d+$/', $duplicate_title ) && 0 === strpos( $duplicate_title, $original_title ) ) {
			return $original_title;
		}

		return $duplicate_title;
	}

	/**
	 * Reassign nav menu items from one post to another.
	 *
	 * When a duplicate replaces an original via swap, menu items still reference
	 * the original post ID. This updates them to point to the new live post.
	 *
	 * @since 4.0.12
	 * @param int $old_post_id The original post ID (now private).
	 * @param int $new_post_id The duplicate post ID (now live).
	 */
	private static function reassign_menu_items( $old_post_id, $new_post_id ) {
		$menu_items = get_posts(
			array(
				'post_type'      => 'nav_menu_item',
				'posts_per_page' => -1,
				'meta_key'       => '_menu_item_object_id',
				'meta_value'     => (string) $old_post_id,
				'post_status'    => 'any',
			)
		);

		foreach ( $menu_items as $menu_item ) {
			update_post_meta( $menu_item->ID, '_menu_item_object_id', (string) $new_post_id );
		}
	}

	/**
	 * Reject a duplicate page/post (delete it).
	 *
	 * @since 1.4.2
	 * @param int $duplicate_id The ID of the duplicate post to reject.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function reject_duplicate( $duplicate_id ) {
		// Verify it's a duplicate.
		if ( ! Respira_Duplicator::is_duplicate( $duplicate_id ) ) {
			return new WP_Error(
				'respira_not_duplicate',
				__( 'This page/post is not a Respira duplicate and cannot be rejected.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		// Get the original post ID for logging.
		$original_id = Respira_Duplicator::get_original_id( $duplicate_id );
		
		// Get post object before deletion.
		$duplicate = get_post( $duplicate_id );
		if ( ! $duplicate ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		// Delete the duplicate permanently.
		$result = wp_delete_post( $duplicate_id, true );

		if ( ! $result ) {
			return new WP_Error(
				'respira_delete_failed',
				__( 'Failed to delete the duplicate.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		// Log rejection action.
		if ( class_exists( 'Respira_Auth' ) ) {
			Respira_Auth::log_action(
				null,
				get_current_user_id(),
				'reject_duplicate',
				$duplicate->post_type,
				$duplicate_id,
				array(
					'original_id' => $original_id,
					'title'       => $duplicate->post_title,
				)
			);
		}

		/**
		 * Fires after a duplicate has been rejected.
		 *
		 * @since 1.4.2
		 * @param int $duplicate_id The ID of the rejected duplicate.
		 * @param int $original_id  The ID of the original post.
		 */
		do_action( 'respira_after_reject_duplicate', $duplicate_id, $original_id );

		return true;
	}

	/**
	 * Handle slug conflicts by appending numbers.
	 *
	 * @since 1.2.0
	 * @param string $desired_slug The desired slug.
	 * @param int    $post_id     The post ID to exclude from conflict check.
	 * @return string A unique slug.
	 */
	public static function handle_slug_conflict( $desired_slug, $post_id = 0 ) {
		global $wpdb;

		$slug = $desired_slug;
		$num  = 2;

		// Check if slug exists (excluding current post).
		$check_sql = "SELECT post_name FROM $wpdb->posts WHERE post_name = %s AND ID != %d LIMIT 1";
		$exists    = $wpdb->get_var( $wpdb->prepare( $check_sql, $slug, $post_id ) );

		// If slug exists, append number until unique.
		while ( $exists ) {
			$slug = $desired_slug . '-' . $num;
			$exists = $wpdb->get_var( $wpdb->prepare( $check_sql, $slug, $post_id ) );
			$num++;
		}

		return $slug;
	}

	/**
	 * Get error data for API responses when trying to edit original.
	 *
	 * @since 1.2.0
	 * @param int      $original_id  The original post ID.
	 * @param int|null $duplicate_id Optional. The duplicate post ID if one exists.
	 * @return array Error data array with instructions and links.
	 */
	public static function get_approval_error_data( $original_id, $duplicate_id = null ) {
		$post = get_post( $original_id );
		if ( ! $post ) {
			return array();
		}

		$post_type_label = 'page' === $post->post_type ? __( 'page', 'respira-for-wordpress' ) : __( 'post', 'respira-for-wordpress' );
		$rest_namespace  = RESPIRA_REST_NAMESPACE;
		$rest_namespace_v2 = defined( 'RESPIRA_REST_NAMESPACE_V2' ) ? RESPIRA_REST_NAMESPACE_V2 : 'respira/v2';

		// Check if duplicate exists if not provided.
		if ( null === $duplicate_id ) {
			$duplicates = Respira_Duplicator::get_duplicates( $original_id );
			if ( ! empty( $duplicates ) ) {
				$duplicate_id = $duplicates[0]->ID;
			}
		}

		$error_data = array(
			'status'       => 403,
			'instructions' => array(),
			'links'        => array(
				'approvals_page'  => admin_url( 'admin.php?page=respira-changes' ),
				'settings_page'   => admin_url( 'admin.php?page=respira-settings' ),
				'duplicate_endpoint' => rest_url( $rest_namespace . '/' . $post->post_type . 's/' . $original_id . '/duplicate' ),
				'duplicate_endpoint_v2' => rest_url( $rest_namespace_v2 . '/' . $post->post_type . 's/' . $original_id . '/duplicate' ),
			),
			'original_id'  => $original_id,
			'duplicate_id' => $duplicate_id,
		);

		if ( $duplicate_id ) {
			// Duplicate exists.
			$error_data['instructions'] = array(
				'step1' => sprintf(
					/* translators: 1: post type label, 2: duplicate ID */
					__( 'A duplicate %1$s already exists (ID: %2$d). You can edit it directly.', 'respira-for-wordpress' ),
					$post_type_label,
					$duplicate_id
				),
				'step2' => sprintf(
					/* translators: 1: post type label */
					__( 'Edit the duplicate %1$s: PUT /wp-json/respira/v1/%2$ss/%3$d', 'respira-for-wordpress' ),
					$post_type_label,
					$post->post_type,
					$duplicate_id
				),
				'step3' => __( 'Approve the duplicate in WordPress admin to apply the changes live.', 'respira-for-wordpress' ),
			);
			$error_data['links']['edit_duplicate'] = rest_url( $rest_namespace . '/' . $post->post_type . 's/' . $duplicate_id );
			$error_data['links']['edit_duplicate_v2'] = rest_url( $rest_namespace_v2 . '/' . $post->post_type . 's/' . $duplicate_id );
			$error_data['instructions']['step2_v2'] = sprintf(
				/* translators: 1: post type slug, 2: duplicate ID */
				__( 'V2 fidelity flow: PUT /wp-json/respira/v2/%1$ss/%2$d?include=basic', 'respira-for-wordpress' ),
				$post->post_type,
				$duplicate_id
			);
		} else {
			// No duplicate exists.
			$error_data['instructions'] = array(
				'step1' => sprintf(
					/* translators: 1: post type label */
					__( 'Create a duplicate %1$s: POST /wp-json/respira/v1/%2$ss/%3$d/duplicate', 'respira-for-wordpress' ),
					$post_type_label,
					$post->post_type,
					$original_id
				),
				'step2' => sprintf(
					/* translators: 1: post type label */
					__( 'Edit the duplicate %1$s instead of the original.', 'respira-for-wordpress' ),
					$post_type_label
				),
				'step3' => __( 'Approve the duplicate in WordPress admin to apply the changes live.', 'respira-for-wordpress' ),
			);
			$error_data['instructions']['step1_v2'] = sprintf(
				/* translators: 1: post type slug, 2: original ID */
				__( 'V2 fidelity flow: POST /wp-json/respira/v2/%1$ss/%2$d/duplicate', 'respira-for-wordpress' ),
				$post->post_type,
				$original_id
			);
		}

		// Add setting-related instruction if direct editing is disabled.
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );
		if ( ! $allow_direct_edit ) {
			$error_data['instructions']['setting_note'] = __( 'Note: Direct editing of original pages is disabled in settings. Enable it in Respira → Settings if you want to use force=true and confirm_live_edit=true.', 'respira-for-wordpress' );
		} else {
			$error_data['instructions']['force_note'] = __( 'Alternatively, use force=true with confirm_live_edit=true if direct editing is enabled in settings.', 'respira-for-wordpress' );
		}

		return $error_data;
	}
}
