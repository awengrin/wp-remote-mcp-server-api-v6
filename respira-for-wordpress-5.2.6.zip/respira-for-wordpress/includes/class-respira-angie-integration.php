<?php
/**
 * Angie browser MCP integration.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Registers Respira as an MCP server inside Angie.
 */
class Respira_Angie_Integration {

	/**
	 * Settings option name.
	 */
	const OPTION_ENABLED = 'respira_enable_angie_integration';

	/**
	 * Browser-auth REST namespace.
	 */
	const REST_NAMESPACE = 'respira/browser/v1';

	/**
	 * Singleton instance.
	 *
	 * @var Respira_Angie_Integration|null
	 */
	private static $instance = null;

	/**
	 * Boot singleton.
	 *
	 * @return Respira_Angie_Integration
	 */
	public static function boot() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_filter( 'respira_angie_is_active', '__return_true' );
		add_action( 'admin_enqueue_scripts', array( $this, 'maybe_enqueue_bridge' ), 20 );
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Check if Angie integration is enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return 1 === (int) get_option( self::OPTION_ENABLED, 1 );
	}

	/**
	 * Default Angie tool allowlist.
	 *
	 * @return array<int,string>
	 */
	public static function get_allowed_tools() {
		return array(
			'wordpress_list_pages',
			'wordpress_read_page',
			'wordpress_detect_page_builder',
			'wordpress_create_page_duplicate',
			'wordpress_extract_builder_content',
			'wordpress_inject_builder_content',
			'wordpress_approve_duplicate',
			'wordpress_reject_duplicate',
			'woocommerce_list_products',
			'woocommerce_update_product',
		);
	}

	/**
	 * Determine whether current user can access Angie bridge at all.
	 *
	 * @return bool
	 */
	private function current_user_can_access_bridge() {
		return current_user_can( 'edit_pages' )
			|| current_user_can( 'manage_options' )
			|| current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Enqueue bridge only on eligible wp-admin requests.
	 *
	 * @return void
	 */
	public function maybe_enqueue_bridge() {
		if ( ! is_admin() || ! self::is_enabled() || ! $this->current_user_can_access_bridge() ) {
			return;
		}

		$script_path = RESPIRA_PLUGIN_DIR . 'assets/angie-bridge/dist/angie-bridge.js';
		if ( ! file_exists( $script_path ) ) {
			return;
		}

		$version = (string) filemtime( $script_path );
		wp_enqueue_script(
			'respira-angie-bridge',
			RESPIRA_PLUGIN_URL . 'assets/angie-bridge/dist/angie-bridge.js',
			array( 'wp-api-fetch' ),
			$version,
			true
		);

		wp_localize_script(
			'respira-angie-bridge',
			'respiraAngieBridge',
			array(
				'toolsEndpoint' => rest_url( self::REST_NAMESPACE . '/tools' ),
				'executeBase'   => rest_url( self::REST_NAMESPACE . '/execute/' ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'version'       => RESPIRA_VERSION,
				'serverName'    => 'respira',
				'serverLabel'   => 'Respira',
			)
		);
	}

	/**
	 * Register Angie browser routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/tools',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_tools' ),
				'permission_callback' => array( $this, 'tools_permission_check' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/execute/(?P<tool>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'execute_tool' ),
				'permission_callback' => array( $this, 'execute_permission_check' ),
				'args'                => array(
					'tool' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);
	}

	/**
	 * Tools endpoint permission check.
	 *
	 * @return bool|WP_Error
	 */
	public function tools_permission_check() {
		if ( ! self::is_enabled() ) {
			return new WP_Error(
				'respira_angie_disabled',
				__( 'Angie integration is disabled.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'respira_angie_auth_required',
				__( 'Authentication required.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		if ( ! $this->current_user_can_access_bridge() ) {
			return new WP_Error(
				'respira_angie_forbidden',
				__( 'You do not have permission to use Angie with Respira.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Execute endpoint permission check.
	 *
	 * @return bool|WP_Error
	 */
	public function execute_permission_check() {
		return $this->tools_permission_check();
	}

	/**
	 * Return current-user tool list.
	 *
	 * @return WP_REST_Response
	 */
	public function get_tools() {
		$tools = array();

		foreach ( $this->get_curated_registry() as $entry ) {
			if ( ! $this->user_can_access_tool( $entry ) ) {
				continue;
			}

			$tools[] = array(
				'name'        => $entry['tool'],
				'description' => $entry['description'],
				'inputSchema' => $entry['input_schema'],
				'annotations' => $entry['annotations'],
			);
		}

		return new WP_REST_Response(
			array(
				'tools' => $tools,
			),
			200
		);
	}

	/**
	 * Execute a single Angie tool.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function execute_tool( $request ) {
		$tool    = sanitize_key( (string) $request->get_param( 'tool' ) );
		$entry   = $this->get_registry_entry( $tool );
		$payload = $request->get_json_params();

		if ( ! is_array( $payload ) ) {
			$payload = $request->get_params();
			unset( $payload['tool'] );
		}

		if ( empty( $entry ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'respira_angie_tool_not_found',
					'message' => __( 'Tool not found.', 'respira-for-wordpress' ),
				),
				404
			);
		}

		if ( ! $this->user_can_access_tool( $entry ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'respira_angie_forbidden',
					'message' => __( 'You do not have permission to execute this tool.', 'respira-for-wordpress' ),
				),
				403
			);
		}

		$object_permission = $this->enforce_object_permissions( $tool, $payload );
		if ( is_wp_error( $object_permission ) ) {
			return $this->error_response( $object_permission );
		}

		$integration = new Respira_WebMCP_Integration();
		$result      = $integration->execute_tool( $tool, $payload );
		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		$text = wp_json_encode( $result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( ! is_string( $text ) || '' === $text ) {
			$text = '{}';
		}

		return new WP_REST_Response(
			array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => $text,
					),
				),
				'structuredContent' => $result,
			),
			200
		);
	}

	/**
	 * Build curated registry list from shared WebMCP registry.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_curated_registry() {
		$allowlist = array_flip( self::get_allowed_tools() );
		$registry  = array();

		foreach ( Respira_WebMCP_Integration::get_tool_registry() as $entry ) {
			if ( empty( $entry['tool'] ) || ! isset( $allowlist[ $entry['tool'] ] ) ) {
				continue;
			}

			if ( 0 === strpos( $entry['tool'], 'woocommerce_' ) && ! Respira_WebMCP_Integration::is_woocommerce_addon_available() ) {
				continue;
			}

			$registry[] = $entry;
		}

		return $registry;
	}

	/**
	 * Get a registry entry by tool name.
	 *
	 * @param string $tool Tool name.
	 * @return array<string,mixed>|null
	 */
	private function get_registry_entry( $tool ) {
		foreach ( $this->get_curated_registry() as $entry ) {
			if ( $tool === $entry['tool'] ) {
				return $entry;
			}
		}

		return null;
	}

	/**
	 * Capability check helper.
	 *
	 * @param string|array $capability Capability or any-of list.
	 * @return bool
	 */
	private function user_has_capability( $capability ) {
		if ( is_array( $capability ) ) {
			foreach ( $capability as $single_capability ) {
				if ( current_user_can( $single_capability ) ) {
					return true;
				}
			}

			return false;
		}

		return current_user_can( $capability );
	}

	/**
	 * Determine whether current user should see/use a specific tool.
	 *
	 * @param array<string,mixed> $entry Tool registry entry.
	 * @return bool
	 */
	private function user_can_access_tool( $entry ) {
		if ( empty( $entry['tool'] ) || ! $this->user_has_capability( $entry['capability'] ) ) {
			return false;
		}

		if ( 0 === strpos( $entry['tool'], 'wordpress_' ) ) {
			$page_tools = array(
				'wordpress_list_pages',
				'wordpress_read_page',
				'wordpress_detect_page_builder',
				'wordpress_create_page_duplicate',
				'wordpress_extract_builder_content',
				'wordpress_inject_builder_content',
			);

			if ( in_array( $entry['tool'], $page_tools, true ) && ! current_user_can( 'edit_pages' ) && ! current_user_can( 'manage_options' ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Enforce object-level permissions where a post/product ID is present.
	 *
	 * @param string $tool Tool name.
	 * @param array  $payload Tool payload.
	 * @return true|WP_Error
	 */
	private function enforce_object_permissions( $tool, $payload ) {
		$post_id = 0;

		switch ( $tool ) {
			case 'wordpress_read_page':
			case 'wordpress_detect_page_builder':
				$post_id = isset( $payload['id'] ) ? absint( $payload['id'] ) : 0;
				break;
			case 'wordpress_create_page_duplicate':
				$post_id = isset( $payload['originalId'] ) ? absint( $payload['originalId'] ) : ( isset( $payload['original_id'] ) ? absint( $payload['original_id'] ) : 0 );
				break;
			case 'wordpress_extract_builder_content':
			case 'wordpress_inject_builder_content':
				$post_id = isset( $payload['pageId'] ) ? absint( $payload['pageId'] ) : ( isset( $payload['page_id'] ) ? absint( $payload['page_id'] ) : 0 );
				break;
			case 'woocommerce_update_product':
				$post_id = isset( $payload['id'] ) ? absint( $payload['id'] ) : 0;
				break;
		}

		if ( $post_id > 0 && ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error(
				'respira_angie_object_forbidden',
				__( 'You do not have permission to edit this content item.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Convert a WP_Error into a REST response.
	 *
	 * @param WP_Error $error Error object.
	 * @return WP_REST_Response
	 */
	private function error_response( $error ) {
		$data   = $error->get_error_data();
		$status = 500;
		if ( is_array( $data ) && isset( $data['status'] ) ) {
			$status = (int) $data['status'];
		}

		return new WP_REST_Response(
			array(
				'code'    => $error->get_error_code(),
				'message' => $error->get_error_message(),
				'data'    => is_array( $data ) ? $data : null,
			),
			$status
		);
	}
}
