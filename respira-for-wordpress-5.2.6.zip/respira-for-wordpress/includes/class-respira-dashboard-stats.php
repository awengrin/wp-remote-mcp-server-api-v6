<?php
/**
 * Dashboard statistics — queries audit log for per-site usage metrics.
 *
 * Defines which actions count as "edits" (write operations that modify content).
 * This definition is shared between the pro dashboard (informational) and the
 * lite plugin (enforced limit).
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dashboard stats class.
 *
 * @since 5.2.0
 */
class Respira_Dashboard_Stats {

	/**
	 * Actions that count as "edits" (content-modifying operations).
	 *
	 * This is the canonical list used by both pro (informational) and lite (enforced).
	 *
	 * @since 5.2.0
	 * @var array
	 */
	const EDIT_ACTIONS = array(
		// Page writes.
		'update_page',
		'force_edit_page',
		'inject_builder_content',
		'update_builder_module',
		'build_page',
		// Post writes.
		'update_post',
		'force_edit_post',
		// Element-level writes.
		'update_element',
		'batch_update',
		'move_element',
		'duplicate_element',
		'remove_element',
		'reorder_elements',
		// Bulk operations.
		'bulk_operation',
	);

	/**
	 * Get the audit log table name.
	 *
	 * @since 5.2.0
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'respira_audit_log';
	}

	/**
	 * Check if the audit log table exists.
	 *
	 * @since 5.2.0
	 * @return bool
	 */
	private static function table_exists() {
		global $wpdb;
		$table = self::table();
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
	}

	/**
	 * Get edit count for the current month.
	 *
	 * @since 5.2.0
	 * @return int
	 */
	public static function get_monthly_edit_count() {
		if ( ! self::table_exists() ) {
			return 0;
		}

		global $wpdb;
		$table       = self::table();
		$month_start = gmdate( 'Y-m-01 00:00:00' );
		$placeholders = self::action_placeholders();

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `$table` WHERE action IN ($placeholders) AND created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...array_merge( self::EDIT_ACTIONS, array( $month_start ) )
			)
		);
	}

	/**
	 * Get comprehensive dashboard stats.
	 *
	 * Returns monthly and all-time breakdowns, plus agent stats.
	 *
	 * @since 5.2.0
	 * @return array {
	 *     @type int    $edits_this_month      Total edits this month.
	 *     @type int    $edits_all_time         Total edits ever.
	 *     @type int    $pages_edited_month     Distinct pages edited this month.
	 *     @type int    $posts_edited_month     Distinct posts edited this month.
	 *     @type int    $pages_edited_total     Distinct pages edited ever.
	 *     @type int    $posts_edited_total     Distinct posts edited ever.
	 *     @type int    $total_actions_month    All actions (reads + writes) this month.
	 *     @type int    $total_actions_all_time All actions ever.
	 *     @type array  $top_agents             Top AI agents by usage [{name, count}].
	 *     @type string $month_start            First day of current month.
	 * }
	 */
	public static function get_stats() {
		$empty = array(
			'edits_this_month'      => 0,
			'edits_all_time'        => 0,
			'pages_edited_month'    => 0,
			'posts_edited_month'    => 0,
			'pages_edited_total'    => 0,
			'posts_edited_total'    => 0,
			'total_actions_month'   => 0,
			'total_actions_all_time' => 0,
			'top_agents'            => array(),
			'month_start'           => gmdate( 'Y-m-01' ),
		);

		if ( ! self::table_exists() ) {
			return $empty;
		}

		global $wpdb;
		$table       = self::table();
		$month_start = gmdate( 'Y-m-01 00:00:00' );
		$placeholders = self::action_placeholders();
		$actions      = self::EDIT_ACTIONS;

		// Monthly edits.
		$edits_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `$table` WHERE action IN ($placeholders) AND created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...array_merge( $actions, array( $month_start ) )
			)
		);

		// All-time edits.
		$edits_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `$table` WHERE action IN ($placeholders)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...$actions
			)
		);

		// Distinct pages edited this month.
		$pages_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT resource_id) FROM `$table` WHERE action IN ($placeholders) AND resource_type = 'page' AND resource_id IS NOT NULL AND created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...array_merge( $actions, array( $month_start ) )
			)
		);

		// Distinct posts edited this month.
		$posts_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT resource_id) FROM `$table` WHERE action IN ($placeholders) AND resource_type = 'post' AND resource_id IS NOT NULL AND created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...array_merge( $actions, array( $month_start ) )
			)
		);

		// Distinct pages edited all time.
		$pages_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT resource_id) FROM `$table` WHERE action IN ($placeholders) AND resource_type = 'page' AND resource_id IS NOT NULL", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...$actions
			)
		);

		// Distinct posts edited all time.
		$posts_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT resource_id) FROM `$table` WHERE action IN ($placeholders) AND resource_type = 'post' AND resource_id IS NOT NULL", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...$actions
			)
		);

		// Total actions this month (all types, including reads).
		$total_month = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `$table` WHERE created_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$month_start
			)
		);

		// Total actions all time.
		$total_all = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM `$table`" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		// Top AI agents (normalized from user_agent).
		$agents_raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT user_agent, COUNT(*) as cnt FROM `$table` WHERE action IN ($placeholders) AND user_agent != '' GROUP BY user_agent ORDER BY cnt DESC LIMIT 10", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				...$actions
			)
		);

		$agents = self::normalize_agents( $agents_raw );

		return array(
			'edits_this_month'      => $edits_month,
			'edits_all_time'        => $edits_total,
			'pages_edited_month'    => $pages_month,
			'posts_edited_month'    => $posts_month,
			'pages_edited_total'    => $pages_total,
			'posts_edited_total'    => $posts_total,
			'total_actions_month'   => $total_month,
			'total_actions_all_time' => $total_all,
			'top_agents'            => $agents,
			'month_start'           => gmdate( 'Y-m-01' ),
		);
	}

	/**
	 * Get top API keys ranked by edit count.
	 *
	 * Joins audit log with api_keys table to show which keys are most active.
	 * Returns key name, edit count, total API calls, primary AI agent, and last activity.
	 *
	 * @since 5.2.0
	 * @param string $period 'month' for current month, 'all' for all time.
	 * @param int    $limit  Max number of keys to return.
	 * @return array Array of objects with key_name, key_prefix, edits, total_calls, primary_agent, last_activity, is_active.
	 */
	public static function get_top_api_keys( $period = 'month', $limit = 10 ) {
		if ( ! self::table_exists() ) {
			return array();
		}

		global $wpdb;
		$audit_table = self::table();
		$keys_table  = $wpdb->prefix . 'respira_api_keys';

		// Guard: keys table must exist too.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $keys_table ) ) !== $keys_table ) {
			return array();
		}

		$placeholders = self::action_placeholders();
		$actions      = self::EDIT_ACTIONS;
		$limit        = absint( $limit );

		$date_clause = '';
		$date_params = array();
		if ( 'month' === $period ) {
			$date_clause = 'AND al.created_at >= %s';
			$date_params = array( gmdate( 'Y-m-01 00:00:00' ) );
		}

		// Main query: group by api_key_id, count edits + total calls.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT
				k.id         AS key_id,
				k.name       AS key_name,
				k.key_prefix AS key_prefix,
				k.is_active  AS is_active,
				COUNT(*)     AS total_calls,
				SUM( CASE WHEN al.action IN ($placeholders) THEN 1 ELSE 0 END ) AS edits,
				MAX(al.created_at) AS last_activity
			FROM `$audit_table` al
			INNER JOIN `$keys_table` k ON al.api_key_id = k.id
			WHERE 1=1 $date_clause
			GROUP BY k.id, k.name, k.key_prefix, k.is_active
			ORDER BY edits DESC, total_calls DESC
			LIMIT %d";

		$params = array_merge( $actions, $date_params, array( $limit ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $rows ) {
			return array();
		}

		// Enrich each key with its primary AI agent (most recent user_agent for edits).
		foreach ( $rows as $row ) {
			$row->edits       = (int) $row->edits;
			$row->total_calls = (int) $row->total_calls;

			// Get the most common user_agent for this key's edit actions.
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$agent_raw = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT user_agent FROM `$audit_table`
					 WHERE api_key_id = %d AND action IN ($placeholders) AND user_agent != ''
					 GROUP BY user_agent ORDER BY COUNT(*) DESC LIMIT 1",
					...array_merge( array( (int) $row->key_id ), $actions )
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			$row->primary_agent = $agent_raw ? self::normalize_single_agent( $agent_raw ) : '';
		}

		return $rows;
	}

	/**
	 * Normalize a single user_agent string to a friendly name.
	 *
	 * @since 5.2.0
	 * @param string $user_agent Raw user agent string.
	 * @return string Friendly agent name.
	 */
	private static function normalize_single_agent( $user_agent ) {
		$ua = strtolower( $user_agent );

		if ( false !== strpos( $ua, 'cursor' ) ) {
			return 'Cursor';
		}
		if ( false !== strpos( $ua, 'claude' ) || false !== strpos( $ua, 'anthropic' ) ) {
			return 'Claude Code';
		}
		if ( false !== strpos( $ua, 'codex' ) || false !== strpos( $ua, 'openai' ) ) {
			return 'Codex';
		}
		if ( false !== strpos( $ua, 'windsurf' ) || false !== strpos( $ua, 'codeium' ) ) {
			return 'Windsurf';
		}
		if ( false !== strpos( $ua, 'copilot' ) || false !== strpos( $ua, 'github' ) ) {
			return 'GitHub Copilot';
		}
		if ( false !== strpos( $ua, 'gemini' ) || false !== strpos( $ua, 'google' ) ) {
			return 'Gemini';
		}
		if ( false !== strpos( $ua, 'webmcp' ) ) {
			return 'WebMCP';
		}

		return 'Other';
	}

	/**
	 * Build SQL placeholders string for EDIT_ACTIONS.
	 *
	 * @since 5.2.0
	 * @return string Comma-separated %s placeholders.
	 */
	private static function action_placeholders() {
		return implode( ', ', array_fill( 0, count( self::EDIT_ACTIONS ), '%s' ) );
	}

	/**
	 * Normalize raw user_agent strings into friendly agent names and aggregate.
	 *
	 * @since 5.2.0
	 * @param array $rows Database rows with user_agent and cnt columns.
	 * @return array Array of [{name, count}] sorted by count desc.
	 */
	private static function normalize_agents( $rows ) {
		$map = array();

		foreach ( $rows as $row ) {
			$ua   = strtolower( $row->user_agent );
			$name = 'Other';

			if ( false !== strpos( $ua, 'cursor' ) ) {
				$name = 'Cursor';
			} elseif ( false !== strpos( $ua, 'claude' ) || false !== strpos( $ua, 'anthropic' ) ) {
				$name = 'Claude Code';
			} elseif ( false !== strpos( $ua, 'codex' ) || false !== strpos( $ua, 'openai' ) ) {
				$name = 'Codex';
			} elseif ( false !== strpos( $ua, 'windsurf' ) || false !== strpos( $ua, 'codeium' ) ) {
				$name = 'Windsurf';
			} elseif ( false !== strpos( $ua, 'copilot' ) || false !== strpos( $ua, 'github' ) ) {
				$name = 'GitHub Copilot';
			} elseif ( false !== strpos( $ua, 'gemini' ) || false !== strpos( $ua, 'google' ) ) {
				$name = 'Gemini';
			} elseif ( false !== strpos( $ua, 'webmcp' ) ) {
				$name = 'WebMCP';
			}

			if ( ! isset( $map[ $name ] ) ) {
				$map[ $name ] = 0;
			}
			$map[ $name ] += (int) $row->cnt;
		}

		arsort( $map );

		$result = array();
		foreach ( $map as $name => $count ) {
			$result[] = array(
				'name'  => $name,
				'count' => $count,
			);
		}

		return array_slice( $result, 0, 5 );
	}
}
