<?php
/**
 * Version migration engine.
 *
 * Runs sequential migrations on plugin update to ensure database schema,
 * options, and cron jobs are current. Executes once per version bump.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Handles version migrations on plugin update.
 *
 * @since 5.2.0
 */
class Respira_Upgrader {

	/**
	 * Run migrations if the stored version is older than the current version.
	 *
	 * Hooked to `plugins_loaded` at priority 5 (before most plugin code runs).
	 *
	 * @since 5.2.0
	 */
	public static function maybe_upgrade() {
		$old = get_option( 'respira_version', '0.0.0' );

		if ( version_compare( $old, RESPIRA_VERSION, '>=' ) ) {
			return;
		}

		if ( version_compare( $old, '5.2.0', '<' ) ) {
			self::upgrade_to_520();
		}

		update_option( 'respira_version', RESPIRA_VERSION );
	}

	/**
	 * Migrations for v5.2.0 "Elemental".
	 *
	 * @since 5.2.0
	 */
	private static function upgrade_to_520() {
		// 1. Add new default options for tool governance.
		add_option( 'respira_tool_governance_disabled', '[]' );

		// 2. Schedule snapshot cleanup if missing.
		if ( ! wp_next_scheduled( 'respira_snapshot_cleanup_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'respira_snapshot_cleanup_daily' );
		}

		// 3. Set What's New redirect transient.
		set_transient( 'respira_show_whats_new', '1', DAY_IN_SECONDS * 7 );
	}
}
