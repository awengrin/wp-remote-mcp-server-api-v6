<?php
/**
 * V2 fidelity helpers.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Builds include-gated v2 content contracts and deterministic hashes.
 */
class Respira_Fidelity {

	/**
	 * Supported include tokens.
	 */
	const INCLUDE_TOKENS = array(
		'basic',
		'wp',
		'content.raw',
		'content.rendered',
		'content.clean_html',
		'content.text',
		'builder.payload',
		'builder.extracted',
		'assets',
		'snapshot.current',
		'snapshot.history',
		'meta.allowlisted',
		'meta.all',
	);

	/**
	 * Parse include CSV and normalize to known tokens.
	 *
	 * @param string|array|null $raw_include Raw include value.
	 * @return array
	 */
	public static function parse_include( $raw_include ) {
		if ( empty( $raw_include ) ) {
			return array( 'basic' );
		}

		$tokens = array();
		if ( is_array( $raw_include ) ) {
			foreach ( $raw_include as $chunk ) {
				$tokens = array_merge( $tokens, explode( ',', (string) $chunk ) );
			}
		} else {
			$tokens = explode( ',', (string) $raw_include );
		}

		// Convenience aliases.
		$aliases = array(
			'meta' => 'meta.allowlisted',
		);

		$normalized = array();
		foreach ( $tokens as $token ) {
			$token = trim( strtolower( (string) $token ) );
			if ( '' === $token ) {
				continue;
			}
			if ( isset( $aliases[ $token ] ) ) {
				$token = $aliases[ $token ];
			}
			if ( in_array( $token, self::INCLUDE_TOKENS, true ) ) {
				$normalized[] = $token;
			}
		}

		$normalized = array_values( array_unique( $normalized ) );
		if ( empty( $normalized ) ) {
			return array( 'basic' );
		}

		return $normalized;
	}

	/**
	 * Check include token.
	 *
	 * @param array  $includes Includes list.
	 * @param string $token Token.
	 * @return bool
	 */
	public static function has_include( $includes, $token ) {
		return is_array( $includes ) && in_array( $token, $includes, true );
	}

	/**
	 * Detect builder slug for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function detect_builder_slug( $post_id ) {
		$builder = Respira_Builder_Interface::detect_builder( $post_id );
		if ( ! $builder ) {
			return '';
		}

		$name = strtolower( (string) $builder->get_name() );
		$name = str_replace( ' ', '_', $name );

		return sanitize_key( $name );
	}

	/**
	 * Get default allowlisted post meta keys.
	 *
	 * @return array
	 */
	public static function get_allowlisted_meta_keys() {
		$keys = array(
			'_thumbnail_id',
			'_elementor_data',
			'_elementor_edit_mode',
			'_elementor_template_type',
			'_et_pb_use_builder',
			'_et_pb_custom_css',
			// Divi Theme Builder layout and template meta.
			'_et_pb_built_for_post_type',
			'_et_builder_version',
			'_et_template_type',
			'_et_default_template',
			'_et_header_layout_enabled',
			'_et_pb_header_layout',
			'_et_footer_layout_enabled',
			'_et_pb_footer_layout',
			'_et_template_conditions',
			'_et_pb_page_layout',
			'_bricks_page_content_2',
			'_fl_builder_data',
			'ct_builder_json',
			'ct_builder_shortcodes',
			'brizy',
			'vcv-pageContent',
			'tve_updated_post',
			'_breakdance_data',
		);

		$filtered = apply_filters( 'respira_v2_allowlisted_meta_keys', $keys );
		if ( ! is_array( $filtered ) ) {
			return $keys;
		}

		return array_values( array_unique( array_map( 'sanitize_key', $filtered ) ) );
	}

	/**
	 * Get allowlisted meta values.
	 *
	 * @param int $post_id Post ID.
	 * @return array
	 */
	public static function get_allowlisted_meta( $post_id ) {
		$keys = self::get_allowlisted_meta_keys();
		$meta = array();

		foreach ( $keys as $key ) {
			$values = get_post_meta( $post_id, $key, false );
			if ( empty( $values ) ) {
				continue;
			}
			$meta[ $key ] = array_map( 'maybe_unserialize', $values );
		}

		return $meta;
	}

	/**
	 * Get full post meta.
	 *
	 * @param int $post_id Post ID.
	 * @return array
	 */
	public static function get_all_meta( $post_id ) {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $meta as $key => $values ) {
			$normalized[ $key ] = array_map( 'maybe_unserialize', (array) $values );
		}

		return $normalized;
	}

	/**
	 * Return canonical raw payload source by builder.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $builder_slug Builder slug.
	 * @return mixed
	 */
	public static function get_builder_raw_payload( $post_id, $builder_slug ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return null;
		}

		switch ( $builder_slug ) {
			case 'elementor':
				return get_post_meta( $post_id, '_elementor_data', true );
			case 'divi':
				return array(
					'post_content'        => $post->post_content,
					'_et_pb_use_builder'  => get_post_meta( $post_id, '_et_pb_use_builder', true ),
					'_et_pb_old_content'  => get_post_meta( $post_id, '_et_pb_old_content', true ),
					'_et_pb_custom_css'   => get_post_meta( $post_id, '_et_pb_custom_css', true ),
				);
			case 'gutenberg':
			case 'wpbakery':
				return $post->post_content;
			case 'oxygen':
				$oxygen_json = get_post_meta( $post_id, 'ct_builder_json', true );
				if ( ! empty( $oxygen_json ) ) {
					return $oxygen_json;
				}
				return get_post_meta( $post_id, 'ct_builder_shortcodes', true );
			case 'bricks':
				return get_post_meta( $post_id, '_bricks_page_content_2', true );
			case 'beaver':
				return get_post_meta( $post_id, '_fl_builder_data', true );
			case 'brizy':
				return get_post_meta( $post_id, 'brizy', true );
			case 'visual_composer':
				return get_post_meta( $post_id, 'vcv-pageContent', true );
			case 'thrive':
				return get_post_meta( $post_id, 'tve_updated_post', true );
			case 'breakdance':
				return get_post_meta( $post_id, '_breakdance_data', true );
			default:
				return $post->post_content;
		}
	}

	/**
	 * Extract builder payload and simplified representation.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $builder_slug Builder slug.
	 * @return array
	 */
	public static function get_builder_contract_data( $post_id, $builder_slug ) {
		$raw = self::get_builder_raw_payload( $post_id, $builder_slug );
		$extracted = array();

		if ( ! empty( $builder_slug ) ) {
			$builder = Respira_Builder_Interface::get_builder( $builder_slug );
			if ( ! is_wp_error( $builder ) && method_exists( $builder, 'extract_content' ) ) {
				try {
					$extracted = $builder->extract_content( $post_id );
				} catch ( Exception $e ) {
					$extracted = array();
				}
			}
		}

		return array(
			'payload'   => $raw,
			'extracted' => is_array( $extracted ) ? $extracted : array(),
		);
	}

	/**
	 * Build content section based on includes.
	 *
	 * @param WP_Post $post Post.
	 * @param array   $includes Includes.
	 * @return array
	 */
	public static function get_content_contract( $post, $includes ) {
		$content = array();
		$raw     = $post->post_content;
		$rendered = null;

		if ( self::has_include( $includes, 'content.raw' ) ) {
			$content['raw'] = $raw;
		}

		if ( self::has_include( $includes, 'content.rendered' ) ) {
			$rendered = apply_filters( 'the_content', $raw );

			// Fallback: if post_content is empty (PHP template pages), try server-side render.
			if ( empty( trim( strip_tags( $rendered ) ) ) && $post && get_permalink( $post->ID ) ) {
				$url      = get_permalink( $post->ID );
				$response = wp_remote_get( $url, array(
					'timeout'   => 10,
					'sslverify' => false,
					'headers'   => array( 'X-Respira-Internal' => '1' ),
				) );
				if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
					$html = wp_remote_retrieve_body( $response );
					// Extract the main content area (between <main> or <article> or <div id="content">).
					if ( preg_match( '/<(?:main|article)[^>]*>(.*?)<\/(?:main|article)>/si', $html, $m ) ) {
						$rendered = $m[1];
					} elseif ( preg_match( '/<div[^>]+id=["\']content["\'][^>]*>(.*?)<\/div>/si', $html, $m ) ) {
						$rendered = $m[1];
					} else {
						// Strip head/scripts/styles, return body content.
						$rendered = preg_replace( '/<head\b[^>]*>.*?<\/head>/si', '', $html );
						$rendered = preg_replace( '/<script\b[^>]*>.*?<\/script>/si', '', $rendered );
						$rendered = preg_replace( '/<style\b[^>]*>.*?<\/style>/si', '', $rendered );
						if ( preg_match( '/<body[^>]*>(.*?)<\/body>/si', $rendered, $m ) ) {
							$rendered = $m[1];
						}
					}
					$content['rendered_source'] = 'server_side_fetch';
				}
			}

			$content['rendered'] = $rendered;
		}

		if ( self::has_include( $includes, 'content.clean_html' ) ) {
			if ( null === $rendered ) {
				$rendered = apply_filters( 'the_content', $raw );
			}
			$content['clean_html'] = wp_kses_post( $rendered );
		}

		if ( self::has_include( $includes, 'content.text' ) ) {
			if ( null === $rendered ) {
				$rendered = apply_filters( 'the_content', $raw );
			}
			$content['text'] = trim( wp_strip_all_tags( $rendered ) );
		}

		return $content;
	}

	/**
	 * Extract assets from html.
	 *
	 * @param string $html HTML.
	 * @return array
	 */
	public static function extract_assets( $html ) {
		if ( ! is_string( $html ) || '' === $html ) {
			return array();
		}

		$matches = array();
		$urls = array();

		preg_match_all( '/\b(?:src|href)=["\']([^"\']+)["\']/i', $html, $matches );
		if ( ! empty( $matches[1] ) ) {
			foreach ( $matches[1] as $url ) {
				$url = trim( (string) $url );
				if ( '' === $url ) {
					continue;
				}
				$urls[] = $url;
			}
		}

		return array_values( array_unique( $urls ) );
	}

	/**
	 * Canonicalize value for stable hashing.
	 *
	 * @param mixed $value Value.
	 * @return mixed
	 */
	public static function canonicalize_value( $value ) {
		if ( is_object( $value ) ) {
			$value = (array) $value;
		}

		if ( ! is_array( $value ) ) {
			return $value;
		}

		$is_assoc = array_keys( $value ) !== range( 0, count( $value ) - 1 );
		if ( $is_assoc ) {
			ksort( $value, SORT_STRING );
		}

		foreach ( $value as $key => $item ) {
			$value[ $key ] = self::canonicalize_value( $item );
		}

		return $value;
	}

	/**
	 * Stable SHA256 hash.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function stable_hash( $value ) {
		$canonical = self::canonicalize_value( $value );
		$json      = wp_json_encode( $canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		if ( false === $json ) {
			$json = wp_json_encode( array( 'value' => (string) $value ) );
		}

		return hash( 'sha256', (string) $json );
	}

	/**
	 * Compute fidelity hashes for a post.
	 *
	 * @param int         $post_id Post ID.
	 * @param string|null $builder_slug Optional builder slug.
	 * @return array
	 */
	public static function compute_hashes( $post_id, $builder_slug = null ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array();
		}

		if ( null === $builder_slug ) {
			$builder_slug = self::detect_builder_slug( $post_id );
		}

		$builder_data = self::get_builder_contract_data( $post_id, (string) $builder_slug );

		// Ensure post_content is a string — some theme filters (e.g. Divi 5) crash on null.
		$raw_content = (string) $post->post_content;
		try {
			$rendered = apply_filters( 'the_content', $raw_content );
		} catch ( \Throwable $e ) {
			// Gracefully degrade if a theme filter crashes.
			$rendered = $raw_content;
		}
		$allowlisted  = self::get_allowlisted_meta( $post_id );

		return array(
			'builder_hash'          => self::stable_hash( $builder_data['payload'] ),
			'rendered_hash'         => self::stable_hash( $rendered ),
			'allowlisted_meta_hash' => self::stable_hash( $allowlisted ),
		);
	}

	/**
	 * Build a v2 content envelope for a post.
	 *
	 * @param WP_Post          $post Post.
	 * @param array            $includes Includes.
	 * @param Respira_Snapshots|null $snapshots Snapshot service.
	 * @return array
	 */
	public static function build_v2_post_envelope( $post, $includes, $snapshots = null ) {
		$envelope = array(
			'id'           => $post->ID,
			'post_type'    => $post->post_type,
			'title'        => $post->post_title,
			'slug'         => $post->post_name,
			'status'       => $post->post_status,
			'date'         => $post->post_date,
			'modified'     => $post->post_modified,
			'url'          => get_permalink( $post->ID ),
			'is_duplicate' => (bool) get_post_meta( $post->ID, '_respira_duplicate', true ),
			'original_id'  => (int) get_post_meta( $post->ID, '_respira_original_id', true ),
			'includes'     => $includes,
		);

		if ( self::has_include( $includes, 'wp' ) ) {
			$envelope['wp'] = array(
				'author'       => (int) $post->post_author,
				'date_gmt'     => $post->post_date_gmt,
				'modified_gmt' => $post->post_modified_gmt,
				'excerpt'      => $post->post_excerpt,
				'menu_order'   => (int) $post->menu_order,
				'comment_status' => $post->comment_status,
				'ping_status'  => $post->ping_status,
			);
		}

		$content = self::get_content_contract( $post, $includes );
		if ( ! empty( $content ) ) {
			$envelope['content'] = $content;
		}

		$needs_builder = self::has_include( $includes, 'builder.payload' ) || self::has_include( $includes, 'builder.extracted' );
		$needs_hashes  = $needs_builder || self::has_include( $includes, 'snapshot.current' ) || self::has_include( $includes, 'snapshot.history' );
		$builder_slug  = self::detect_builder_slug( $post->ID );

		if ( $needs_builder || $needs_hashes || self::has_include( $includes, 'assets' ) || self::has_include( $includes, 'meta.allowlisted' ) || self::has_include( $includes, 'meta.all' ) ) {
			$envelope['respira'] = array();
		}

		if ( $needs_builder || $needs_hashes ) {
			$builder_data = self::get_builder_contract_data( $post->ID, $builder_slug );
			$envelope['respira']['builder'] = array(
				'detected' => ! empty( $builder_slug ),
				'name'     => $builder_slug,
			);

			if ( self::has_include( $includes, 'builder.payload' ) ) {
				$envelope['respira']['builder']['payload'] = $builder_data['payload'];
			}
			if ( self::has_include( $includes, 'builder.extracted' ) ) {
				$envelope['respira']['builder']['extracted'] = $builder_data['extracted'];
			}

			if ( $needs_hashes ) {
				$envelope['respira']['fidelity'] = array(
					'hashes' => self::compute_hashes( $post->ID, $builder_slug ),
				);
			}
		}

		if ( self::has_include( $includes, 'assets' ) ) {
			$html = '';
			if ( isset( $envelope['content']['rendered'] ) ) {
				$html = (string) $envelope['content']['rendered'];
			} elseif ( isset( $envelope['content']['raw'] ) ) {
				$html = (string) $envelope['content']['raw'];
			} else {
				$html = (string) $post->post_content;
			}

			$envelope['respira']['assets'] = self::extract_assets( $html );
		}

		if ( self::has_include( $includes, 'meta.allowlisted' ) ) {
			$envelope['respira']['meta']['allowlisted'] = self::get_allowlisted_meta( $post->ID );
		}

		if ( self::has_include( $includes, 'meta.all' ) ) {
			$envelope['respira']['meta']['all'] = self::get_all_meta( $post->ID );
		}

		if ( $snapshots && ( self::has_include( $includes, 'snapshot.current' ) || self::has_include( $includes, 'snapshot.history' ) ) ) {
			$envelope['respira']['snapshot'] = array(
				'current_uuid' => get_post_meta( $post->ID, '_respira_snapshot_current_uuid', true ),
				'base_uuid'    => get_post_meta( $post->ID, '_respira_snapshot_base_uuid', true ),
			);

			if ( self::has_include( $includes, 'snapshot.current' ) ) {
				$current_uuid = $envelope['respira']['snapshot']['current_uuid'];
				if ( ! empty( $current_uuid ) ) {
					$envelope['respira']['snapshot']['current'] = $snapshots->get_snapshot( $current_uuid, false );
				}
			}

			if ( self::has_include( $includes, 'snapshot.history' ) ) {
				$history = $snapshots->list_snapshots(
					array(
						'post_id' => $post->ID,
						'limit'   => 20,
					)
				);
				$envelope['respira']['snapshot']['history'] = $history['items'];
			}
		}

		return $envelope;
	}
}
