<?php
/**
 * WebMCP Abilities integration.
 *
 * Registers Respira MCP tools as WordPress Abilities and routes execution
 * through existing Respira REST callbacks.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * WebMCP integration for Respira abilities.
 */
class Respira_WebMCP_Integration {

	/**
	 * User meta key storing active multisite blog for WebMCP executions.
	 */
	const ACTIVE_SITE_META_KEY = 'respira_webmcp_active_site_id';

	/**
	 * Cached registry.
	 *
	 * @var array<int,array<string,mixed>>|null
	 */
	private static $tool_registry = null;

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( self::is_available() ) {
			$this->init();
		}
	}

	/**
	 * Check whether abilities API functions exist.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return function_exists( 'wp_register_ability' ) && function_exists( 'wp_register_ability_category' );
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_categories' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	/**
	 * Register ability categories.
	 *
	 * @return void
	 */
	public function register_categories() {
		wp_register_ability_category(
			'respira',
			array(
				'label'       => __( 'Respira AI Tools', 'respira-for-wordpress' ),
				'description' => __( 'Complete Respira WebMCP toolkit for WordPress editing, content, media, SEO, admin operations, and automation.', 'respira-for-wordpress' ),
			)
		);

		if ( self::is_woocommerce_addon_available() ) {
			wp_register_ability_category(
				'respira-woocommerce',
				array(
					'label'       => __( 'Respira WooCommerce Tools', 'respira-for-wordpress' ),
					'description' => __( 'Respira WebMCP tools for WooCommerce products, orders, inventory, and reports.', 'respira-for-wordpress' ),
				)
			);
		}
	}

	/**
	 * Register abilities.
	 *
	 * @return void
	 */
	public function register_abilities() {
		$include_woo = self::is_woocommerce_addon_available();

		foreach ( self::get_tool_registry() as $entry ) {
			if ( ! $include_woo && self::is_woocommerce_tool( $entry['tool'] ) ) {
				continue;
			}

			wp_register_ability(
				$entry['ability_id'],
				array(
					'label'               => $entry['label'],
					'description'         => $entry['description'],
					'category'            => $entry['category'],
					'input_schema'        => $entry['input_schema'],
					'output_schema'       => $entry['output_schema'],
					'meta'                => array(
						'show_in_rest'    => true,
						'annotations'     => $entry['ability_annotations'],
						'mcp'             => array(
							'public' => true,
							'type'   => 'tool',
						),
						'wmcp_visibility' => 'public',
						'wmcp_read_only'  => ! empty( $entry['annotations']['readOnlyHint'] ),
					),
					'permission_callback' => function () use ( $entry ) {
						return $this->check_capability( $entry['capability'] );
					},
					'execute_callback'    => function ( $input = array() ) use ( $entry ) {
						$payload = is_array( $input ) ? $input : array();
						return $this->execute_tool( $entry['tool'], $payload );
					},
				)
			);
		}
	}

	/**
	 * Get complete tool registry.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_tool_registry() {
		if ( null === self::$tool_registry ) {
			self::$tool_registry = self::build_tool_registry();
		}

		return self::$tool_registry;
	}

	/**
	 * Get ability IDs for MCP adapter exposure.
	 *
	 * @return array<int,string>
	 */
	public static function get_ability_ids_for_adapter() {
		$ability_ids = array();
		$include_woo = self::is_woocommerce_addon_available();

		foreach ( self::get_tool_registry() as $entry ) {
			if ( ! $include_woo && self::is_woocommerce_tool( $entry['tool'] ) ) {
				continue;
			}
			$ability_ids[] = $entry['ability_id'];
		}

		return $ability_ids;
	}

	/**
	 * Get ability IDs that are safe for default MCP public exposure.
	 *
	 * @return array<int,string>
	 */
	public static function get_public_ability_ids() {
		$ability_ids = array();
		$include_woo = self::is_woocommerce_addon_available();

		foreach ( self::get_tool_registry() as $entry ) {
			if ( ! $include_woo && self::is_woocommerce_tool( $entry['tool'] ) ) {
				continue;
			}
			if ( empty( $entry['mcp_public'] ) ) {
				continue;
			}
			$ability_ids[] = $entry['ability_id'];
		}

		return $ability_ids;
	}

	/**
	 * Execute a tool.
	 *
	 * @param string $tool Tool name.
	 * @param array  $args Tool arguments.
	 * @return mixed
	 */
	public function execute_tool( $tool, $args ) {
		if ( 'wordpress_switch_site' === $tool ) {
			return $this->handle_switch_site( $args );
		}

		if ( self::is_woocommerce_tool( $tool ) && ! self::is_woocommerce_addon_available() ) {
			return new WP_Error(
				'respira_webmcp_woo_unavailable',
				__( 'WooCommerce add-on is not installed and licensed.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		$runner = function () use ( $tool, $args ) {
			return $this->execute_tool_internal( $tool, $args );
		};

		return $this->with_active_site_context( $runner );
	}

	/**
	 * Execute tool internal dispatch.
	 *
	 * @param string $tool Tool name.
	 * @param array  $args Tool args.
	 * @return mixed
	 */
	private function execute_tool_internal( $tool, $args ) {
		$dispatch = self::get_dispatch_config();

		if ( ! isset( $dispatch[ $tool ] ) ) {
			return new WP_Error(
				'respira_webmcp_unknown_tool',
				sprintf( __( 'Unknown tool: %s', 'respira-for-wordpress' ), $tool ),
				array( 'status' => 400 )
			);
		}

		$config = $dispatch[ $tool ];
		$params = $this->normalize_tool_args( $tool, $args, $config );

		if ( ! empty( $config['special'] ) ) {
			if ( 'upload_media' === $config['special'] ) {
				$result = $this->execute_upload_media( $config, $params );
			} elseif ( 'extract_builder_content' === $config['special'] ) {
				$result = $this->execute_extract_builder_content( $config, $params );
			} elseif ( 'detect_page_builder' === $config['special'] ) {
				$result = $this->execute_detect_page_builder( $params );
			} elseif ( 'approve_duplicate' === $config['special'] ) {
				$result = $this->execute_approve_duplicate( $params );
			} elseif ( 'reject_duplicate' === $config['special'] ) {
				$result = $this->execute_reject_duplicate( $params );
			} elseif ( 'find_builder_targets' === $config['special'] ) {
				$result = $this->execute_find_builder_targets( $params );
			} else {
				$result = $this->execute_route_dispatch( $config, $params );
			}
		} else {
			$result = $this->execute_route_dispatch( $config, $params );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->augment_tool_response( $tool, $result );
	}

	/**
	 * Dispatch to a route callback by method/path.
	 *
	 * @param array $config Dispatch config.
	 * @param array $params Params.
	 * @return mixed
	 */
	private function execute_route_dispatch( $config, $params ) {
		$resolved = $this->resolve_path_from_template( $config['path'], $params );
		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		$path   = $resolved['path'];
		$query  = $resolved['params'];
		$method = strtoupper( $config['method'] );

		$result = $this->call_route_callback( $method, $path, $query );

		if ( is_wp_error( $result ) && ! empty( $config['fallback_method'] ) ) {
			$fallback_method = strtoupper( $config['fallback_method'] );
			$result          = $this->call_route_callback( $fallback_method, $path, $query );
		}

		return $result;
	}

	/**
	 * Execute extract builder content with MCP-compatible error payload.
	 *
	 * @param array $config Dispatch config.
	 * @param array $params Params.
	 * @return array<string,mixed>
	 */
	private function execute_extract_builder_content( $config, $params ) {
		$result = $this->execute_route_dispatch( $config, $params );

		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			return array(
				'content'    => array(),
				'diagnostics' => isset( $data['diagnostics'] ) ? $data['diagnostics'] : null,
				'warning'    => $result->get_error_message(),
				'success'    => false,
				'builder'    => isset( $params['builder'] ) ? $params['builder'] : '',
				'error'      => true,
				'errorCode'  => $result->get_error_code(),
				'errorData'  => $data,
				'status'     => isset( $data['status'] ) ? (int) $data['status'] : 500,
			);
		}

		return array(
			'content'     => isset( $result['content'] ) ? $result['content'] : array(),
			'diagnostics' => isset( $result['diagnostics'] ) ? $result['diagnostics'] : null,
			'warning'     => isset( $result['warning'] ) ? $result['warning'] : null,
			'success'     => isset( $result['success'] ) ? (bool) $result['success'] : true,
			'builder'     => isset( $result['builder'] ) ? $result['builder'] : ( isset( $params['builder'] ) ? $params['builder'] : '' ),
		);
	}

	/**
	 * Execute upload media tool.
	 *
	 * @param array $config Dispatch config.
	 * @param array $params Params.
	 * @return mixed
	 */
	private function execute_upload_media( $config, $params ) {
		$file_payload = $this->build_media_upload_file_payload( $params );
		if ( is_wp_error( $file_payload ) ) {
			return $file_payload;
		}

		$tmp_path    = $file_payload['tmp_path'];
		$file_params = array( 'file' => $file_payload['file'] );
		$request_params = array();
		foreach ( array( 'title', 'alt', 'caption' ) as $field ) {
			if ( array_key_exists( $field, $params ) ) {
				$request_params[ $field ] = $params[ $field ];
			}
		}

		try {
			$result = $this->call_route_callback( 'POST', $config['path'], $request_params, $file_params );
		} finally {
			if ( $tmp_path && file_exists( $tmp_path ) ) {
				wp_delete_file( $tmp_path );
			}
		}

		return $result;
	}

	/**
	 * Execute builder detection for a page/post.
	 *
	 * @param array $params Tool params.
	 * @return array<string,mixed>|WP_Error
	 */
	private function execute_detect_page_builder( $params ) {
		$post_id = isset( $params['id'] ) ? absint( $params['id'] ) : 0;
		if ( $post_id <= 0 ) {
			return new WP_Error(
				'respira_webmcp_invalid_post_id',
				__( 'A valid page ID is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error(
				'respira_page_not_found',
				__( 'Page not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$builder      = Respira_Builder_Interface::detect_builder( $post_id );
		$builder_name = $builder ? $builder->get_name() : 'Unknown';
		$original_id  = Respira_Duplicator::is_duplicate( $post_id ) ? Respira_Duplicator::get_original_id( $post_id ) : 0;

		return array(
			'post_id'      => $post_id,
			'post_type'    => (string) $post->post_type,
			'post_status'  => (string) $post->post_status,
			'title'        => (string) $post->post_title,
			'builder'      => $builder_name,
			'is_duplicate' => Respira_Duplicator::is_duplicate( $post_id ),
			'original_id'  => $original_id ? (int) $original_id : null,
		);
	}

	/**
	 * Execute duplicate approval.
	 *
	 * @param array $params Tool params.
	 * @return array<string,mixed>|WP_Error
	 */
	private function execute_approve_duplicate( $params ) {
		$duplicate_id = isset( $params['duplicate_id'] ) ? absint( $params['duplicate_id'] ) : 0;
		if ( $duplicate_id <= 0 ) {
			return new WP_Error(
				'respira_webmcp_invalid_duplicate_id',
				__( 'A valid duplicate ID is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$force  = ! empty( $params['force'] );
		$result = Respira_Approver::approve_duplicate(
			$duplicate_id,
			array(
				'force'       => $force,
				'allow_force' => current_user_can( 'manage_options' ),
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$approval_mode = is_array( $result ) && ! empty( $result['approval_mode'] ) ? (string) $result['approval_mode'] : 'swap_duplicate_live';
		$message       = __( 'Duplicate approved successfully. The duplicate is now live.', 'respira-for-wordpress' );
		if ( 'merge_into_original_id' === $approval_mode ) {
			$message = __( 'Duplicate approved successfully. Changes were merged into the original item and the duplicate was kept as a private backup.', 'respira-for-wordpress' );
		}

		return array_merge(
			array(
				'success' => true,
				'message' => $message,
			),
			is_array( $result ) ? $result : array()
		);
	}

	/**
	 * Execute duplicate rejection.
	 *
	 * @param array $params Tool params.
	 * @return array<string,mixed>|WP_Error
	 */
	private function execute_reject_duplicate( $params ) {
		$duplicate_id = isset( $params['duplicate_id'] ) ? absint( $params['duplicate_id'] ) : 0;
		if ( $duplicate_id <= 0 ) {
			return new WP_Error(
				'respira_webmcp_invalid_duplicate_id',
				__( 'A valid duplicate ID is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$result = Respira_Approver::reject_duplicate( $duplicate_id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success'      => true,
			'duplicate_id' => $duplicate_id,
			'message'      => __( 'Duplicate rejected and deleted successfully.', 'respira-for-wordpress' ),
		);
	}

	/**
	 * Execute find_builder_targets: extract content then filter by query.
	 *
	 * @since 5.2.0
	 * @param array $params Params (builder, pageId, query, limit).
	 * @return array|WP_Error
	 */
	private function execute_find_builder_targets( $params ) {
		$builder = isset( $params['builder'] ) ? sanitize_text_field( $params['builder'] ) : '';
		$page_id = isset( $params['pageId'] ) ? absint( $params['pageId'] ) : 0;
		$query   = isset( $params['query'] ) ? strtolower( trim( sanitize_text_field( $params['query'] ) ) ) : '';
		$limit   = isset( $params['limit'] ) ? min( absint( $params['limit'] ), 50 ) : 10;

		if ( empty( $builder ) || empty( $page_id ) ) {
			return new WP_Error( 'respira_missing_params', __( 'builder and pageId are required.', 'respira-for-wordpress' ), array( 'status' => 400 ) );
		}

		// Extract builder content via REST.
		$extract_config = array(
			'method' => 'GET',
			'path'   => '/respira/v1/builder/{builder}/extract/{page_id}',
		);
		$extract_params = array( 'builder' => $builder, 'page_id' => $page_id );
		$extracted      = $this->execute_route_dispatch( $extract_config, $extract_params );

		if ( is_wp_error( $extracted ) ) {
			return $extracted;
		}

		$content = isset( $extracted['content'] ) ? $extracted['content'] : array();
		$results = array();

		// Walk the tree and collect matching nodes.
		$this->walk_builder_tree( $content, $query, $results, $limit, '' );

		return array(
			'success' => true,
			'targets' => array_slice( $results, 0, $limit ),
			'total'   => count( $results ),
			'builder' => $builder,
			'page_id' => $page_id,
		);
	}

	/**
	 * Recursively walk builder content tree to find targets matching a query.
	 *
	 * @since 5.2.0
	 * @param array  $nodes   Content tree nodes.
	 * @param string $query   Lowercased search query.
	 * @param array  $results Results accumulator (by ref).
	 * @param int    $limit   Max results.
	 * @param string $path    Current tree path.
	 */
	private function walk_builder_tree( $nodes, $query, &$results, $limit, $path ) {
		if ( ! is_array( $nodes ) || count( $results ) >= $limit ) {
			return;
		}

		foreach ( $nodes as $index => $node ) {
			if ( count( $results ) >= $limit ) {
				break;
			}
			if ( ! is_array( $node ) ) {
				continue;
			}

			$node_path = $path . '/' . $index;
			$type      = isset( $node['elType'] ) ? $node['elType'] : ( isset( $node['type'] ) ? $node['type'] : '' );
			$widget    = isset( $node['widgetType'] ) ? $node['widgetType'] : '';
			$label     = isset( $node['settings']['admin_label'] ) ? $node['settings']['admin_label'] : '';
			$id        = isset( $node['id'] ) ? $node['id'] : '';
			$settings  = isset( $node['settings'] ) ? $node['settings'] : array();

			// Build preview text from settings.
			$preview_parts = array();
			foreach ( array( 'title', 'editor', 'text', 'heading', 'button_text' ) as $key ) {
				if ( ! empty( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
					$preview_parts[] = wp_strip_all_tags( substr( $settings[ $key ], 0, 80 ) );
				}
			}
			$preview = implode( ' | ', $preview_parts );

			// Match against query.
			$match = empty( $query );
			if ( ! $match ) {
				$searchable = strtolower( $type . ' ' . $widget . ' ' . $label . ' ' . $preview . ' ' . $id );
				$match      = ( false !== strpos( $searchable, $query ) );
			}

			if ( $match && ( ! empty( $widget ) || ! empty( $type ) ) ) {
				$results[] = array(
					'id'      => $id,
					'type'    => $type,
					'widget'  => $widget,
					'label'   => $label,
					'path'    => $node_path,
					'preview' => $preview,
				);
			}

			// Recurse into children.
			if ( ! empty( $node['elements'] ) ) {
				$this->walk_builder_tree( $node['elements'], $query, $results, $limit, $node_path );
			}
		}
	}

	/**
	 * Build upload file payload from base64, URL, or local path.
	 *
	 * @param array $params Tool params.
	 * @return array<string,mixed>|WP_Error
	 */
	private function build_media_upload_file_payload( $params ) {
		if ( empty( $params['file'] ) || empty( $params['filename'] ) ) {
			return new WP_Error(
				'respira_webmcp_upload_missing_fields',
				__( 'Upload media requires file and filename.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$file_input = (string) $params['file'];
		$filename   = sanitize_file_name( (string) $params['filename'] );
		$mime_type  = isset( $params['mimeType'] ) ? (string) $params['mimeType'] : '';
		$binary     = '';

		if ( preg_match( '/^data:([^;]+);base64,(.+)$/', $file_input, $matches ) ) {
			$mime_type = $matches[1];
			$binary    = base64_decode( $matches[2], true );
			if ( false === $binary ) {
				return new WP_Error(
					'respira_webmcp_upload_invalid_data_url',
					__( 'Invalid base64 data URL payload.', 'respira-for-wordpress' ),
					array( 'status' => 400 )
				);
			}
		} elseif ( preg_match( '/^https?:\/\//i', $file_input ) ) {
			$response = wp_safe_remote_get(
				$file_input,
				array(
					'timeout' => 30,
				)
			);
			if ( is_wp_error( $response ) ) {
				return new WP_Error(
					'respira_webmcp_upload_download_failed',
					$response->get_error_message(),
					array( 'status' => 400 )
				);
			}
			$status_code = (int) wp_remote_retrieve_response_code( $response );
			if ( $status_code < 200 || $status_code >= 300 ) {
				return new WP_Error(
					'respira_webmcp_upload_download_failed',
					sprintf( __( 'Failed to download file (HTTP %d).', 'respira-for-wordpress' ), $status_code ),
					array( 'status' => 400 )
				);
			}
			$binary = wp_remote_retrieve_body( $response );
			if ( empty( $mime_type ) ) {
				$headers = wp_remote_retrieve_headers( $response );
				if ( isset( $headers['content-type'] ) ) {
					$mime_type = (string) $headers['content-type'];
				}
			}
		} elseif ( file_exists( $file_input ) && is_readable( $file_input ) ) {
			$binary = file_get_contents( $file_input );
			if ( '' === $filename ) {
				$filename = sanitize_file_name( basename( $file_input ) );
			}
		} else {
			$decoded = base64_decode( $file_input, true );
			if ( false === $decoded ) {
				return new WP_Error(
					'respira_webmcp_upload_invalid_payload',
					__( 'File input must be a data URL, HTTP URL, local readable path, or base64 string.', 'respira-for-wordpress' ),
					array( 'status' => 400 )
				);
			}
			$binary = $decoded;
		}

		if ( '' === $filename ) {
			$filename = 'respira-upload.bin';
		}

		if ( empty( $mime_type ) ) {
			$file_type = wp_check_filetype( $filename );
			$mime_type = ! empty( $file_type['type'] ) ? $file_type['type'] : 'application/octet-stream';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		$tmp_path = wp_tempnam( $filename );
		if ( empty( $tmp_path ) ) {
			$tmp_path = tempnam( sys_get_temp_dir(), 'respira_' );
		}
		if ( empty( $tmp_path ) ) {
			return new WP_Error(
				'respira_webmcp_upload_temp_failed',
				__( 'Unable to allocate temporary file for upload.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		$written = file_put_contents( $tmp_path, $binary );
		if ( false === $written ) {
			return new WP_Error(
				'respira_webmcp_upload_write_failed',
				__( 'Unable to write upload payload to temporary file.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		return array(
			'tmp_path' => $tmp_path,
			'file'     => array(
				'name'     => $filename,
				'type'     => $mime_type,
				'tmp_name' => $tmp_path,
				'error'    => 0,
				'size'     => (int) filesize( $tmp_path ),
			),
		);
	}

	/**
	 * Call a route callback by method and concrete path.
	 *
	 * @param string $method HTTP method.
	 * @param string $path Route path.
	 * @param array  $params Request params.
	 * @param array  $file_params Uploaded file params.
	 * @return mixed
	 */
	private function call_route_callback( $method, $path, $params = array(), $file_params = array() ) {
		$server = rest_get_server();
		if ( ! $server ) {
			return new WP_Error(
				'respira_webmcp_rest_server_unavailable',
				__( 'WordPress REST server is unavailable.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		$request = new WP_REST_Request( strtoupper( $method ), $path );
		foreach ( $params as $key => $value ) {
			$request->set_param( $key, $value );
		}
		if ( ! empty( $file_params ) ) {
			$request->set_file_params( $file_params );
		}
		$request->set_param( '_respira_key_data', $this->get_synthetic_key_data() );

		foreach ( $server->get_routes() as $route_regex => $handlers ) {
			$regex = '@^' . $route_regex . '$@i';
			if ( ! preg_match( $regex, $path, $matches ) ) {
				continue;
			}

			foreach ( $handlers as $handler ) {
				if ( ! $this->route_handler_supports_method( $handler, $method ) ) {
					continue;
				}

				$url_params = array();
				foreach ( $matches as $match_key => $match_value ) {
					if ( ! is_int( $match_key ) ) {
						$url_params[ $match_key ] = rawurldecode( (string) $match_value );
					}
				}
				foreach ( $url_params as $url_key => $url_value ) {
					$request->set_param( $url_key, $url_value );
				}
				$request->set_url_params( $url_params );
				$request->set_route( $route_regex );
				$request->set_attributes( $handler );

				try {
					$response = call_user_func( $handler['callback'], $request );
				} catch ( Exception $exception ) {
					return new WP_Error(
						'respira_webmcp_callback_exception',
						$exception->getMessage(),
						array( 'status' => 500 )
					);
				}

				return $this->normalize_callback_response( $response );
			}
		}

		return new WP_Error(
			'respira_webmcp_route_not_found',
			sprintf( __( 'Route not found for %1$s %2$s.', 'respira-for-wordpress' ), strtoupper( $method ), $path ),
			array( 'status' => 404 )
		);
	}

	/**
	 * Normalize callback response.
	 *
	 * @param mixed $response Callback response.
	 * @return mixed
	 */
	private function normalize_callback_response( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( $response instanceof WP_REST_Response || $response instanceof WP_HTTP_Response ) {
			return $response->get_data();
		}

		return $response;
	}

	/**
	 * Determine whether a route handler supports a method.
	 *
	 * @param array  $handler Route handler.
	 * @param string $method HTTP method.
	 * @return bool
	 */
	private function route_handler_supports_method( $handler, $method ) {
		$method = strtoupper( $method );
		if ( empty( $handler['methods'] ) ) {
			return false;
		}

		$methods = $handler['methods'];

		if ( is_array( $methods ) ) {
			if ( isset( $methods[ $method ] ) ) {
				return (bool) $methods[ $method ];
			}

			foreach ( $methods as $key => $value ) {
				if ( is_string( $key ) && strtoupper( $key ) === $method && $value ) {
					return true;
				}
				if ( is_string( $value ) && strtoupper( $value ) === $method ) {
					return true;
				}
			}

			return false;
		}

		if ( is_int( $methods ) ) {
			if ( 'GET' === $method && ( $methods & WP_REST_Server::READABLE ) ) {
				return true;
			}
			if ( 'POST' === $method && ( $methods & WP_REST_Server::CREATABLE ) ) {
				return true;
			}
			if ( in_array( $method, array( 'PUT', 'PATCH' ), true ) && ( $methods & WP_REST_Server::EDITABLE ) ) {
				return true;
			}
			if ( 'DELETE' === $method && ( $methods & WP_REST_Server::DELETABLE ) ) {
				return true;
			}

			return false;
		}

		if ( is_string( $methods ) ) {
			$parts = array_map( 'trim', explode( ',', strtoupper( $methods ) ) );
			return in_array( $method, $parts, true );
		}

		return false;
	}

	/**
	 * Resolve path template placeholders.
	 *
	 * @param string $template Path template.
	 * @param array  $params Params.
	 * @return array<string,mixed>|WP_Error
	 */
	private function resolve_path_from_template( $template, $params ) {
		$missing = array();
		$path = preg_replace_callback(
			'/\{([a-zA-Z0-9_]+)\}/',
			function ( $matches ) use ( $params, &$missing ) {
				$key = $matches[1];
				if ( ! array_key_exists( $key, $params ) ) {
					$missing[] = $key;
					return '';
				}
				return rawurlencode( (string) $params[ $key ] );
			},
			$template
		);

		if ( ! empty( $missing ) ) {
			return new WP_Error(
				'respira_webmcp_missing_path_param',
				sprintf(
					__( 'Missing required path parameters: %s', 'respira-for-wordpress' ),
					implode( ', ', $missing )
				),
				array( 'status' => 400 )
			);
		}

		return array(
			'path'   => $path,
			'params' => $params,
		);
	}

	/**
	 * Normalize tool arguments and apply tool-specific mappings.
	 *
	 * @param string $tool Tool name.
	 * @param array  $args Raw args.
	 * @param array  $config Dispatch config.
	 * @return array
	 */
	private function normalize_tool_args( $tool, $args, $config ) {
		$normalized = is_array( $args ) ? $args : array();

		if ( ! empty( $config['arg_map'] ) && is_array( $config['arg_map'] ) ) {
			foreach ( $config['arg_map'] as $from => $to ) {
				if ( array_key_exists( $from, $normalized ) ) {
					if ( ! array_key_exists( $to, $normalized ) ) {
						$normalized[ $to ] = $normalized[ $from ];
					}
					unset( $normalized[ $from ] );
				}
			}
		}

		if ( ! empty( $config['special'] ) && 'normalize_menu_classes' === $config['special'] ) {
			$normalized = $this->normalize_menu_classes( $normalized );
		}

		return $normalized;
	}

	/**
	 * Normalize menu classes from string to array.
	 *
	 * @param array $args Tool args.
	 * @return array
	 */
	private function normalize_menu_classes( $args ) {
		if ( isset( $args['classes'] ) && is_string( $args['classes'] ) ) {
			$classes = preg_split( '/\s+/', trim( $args['classes'] ) );
			$args['classes'] = array_values( array_filter( $classes ) );
		}

		if ( isset( $args['classes'] ) && ! is_array( $args['classes'] ) ) {
			unset( $args['classes'] );
		}

		return $args;
	}

	/**
	 * Add MCP parity metadata to selected tool responses.
	 *
	 * @param string $tool Tool name.
	 * @param mixed  $result Tool result.
	 * @return mixed
	 */
	private function augment_tool_response( $tool, $result ) {
		if ( ! is_array( $result ) ) {
			return $result;
		}

		if ( 'wordpress_list_pages' === $tool && ! empty( $result['pages'] ) && is_array( $result['pages'] ) ) {
			foreach ( $result['pages'] as $index => $page ) {
				if ( empty( $page['id'] ) || ! is_array( $page ) || ! empty( $page['builder'] ) ) {
					continue;
				}

				$builder = Respira_Builder_Interface::detect_builder( (int) $page['id'] );
				if ( $builder ) {
					$result['pages'][ $index ]['builder'] = $builder->get_name();
				}
			}
		}

		$approval_tools = array(
			'wordpress_create_page_duplicate',
			'wordpress_update_page',
			'wordpress_create_post_duplicate',
			'wordpress_update_post',
			'wordpress_inject_builder_content',
			'wordpress_update_module',
		);

		if ( in_array( $tool, $approval_tools, true ) ) {
			$approvals_url = $this->get_approvals_url();
			$result['respira_approvals_url'] = $approvals_url;
			if ( ! empty( $result['duplicate_created'] ) && empty( $result['approval_url'] ) ) {
				$result['approval_url'] = $approvals_url;
			}
		}

		return $result;
	}

	/**
	 * Handle multisite switch tool.
	 *
	 * @param array $args Tool args.
	 * @return array|WP_Error
	 */
	private function handle_switch_site( $args ) {
		if ( ! is_multisite() ) {
			return new WP_Error(
				'respira_webmcp_not_multisite',
				__( 'Site switching requires WordPress multisite.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$site_id = isset( $args['siteId'] ) ? absint( $args['siteId'] ) : 0;
		if ( $site_id <= 0 ) {
			return new WP_Error(
				'respira_webmcp_invalid_site_id',
				__( 'siteId must be a valid multisite blog ID.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$site = get_site( $site_id );
		if ( ! $site ) {
			return new WP_Error(
				'respira_webmcp_site_not_found',
				sprintf( __( 'Site with ID %d was not found.', 'respira-for-wordpress' ), $site_id ),
				array( 'status' => 404 )
			);
		}

		if ( function_exists( 'current_user_can_for_site' ) && ! current_user_can_for_site( $site_id, 'read' ) ) {
			return new WP_Error(
				'respira_webmcp_site_forbidden',
				__( 'Current user cannot access the requested site.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		update_user_meta( get_current_user_id(), self::ACTIVE_SITE_META_KEY, $site_id );

		$site_name = '';
		$details = get_blog_details( $site_id );
		if ( $details && ! empty( $details->blogname ) ) {
			$site_name = (string) $details->blogname;
		}

		return array(
			'success'  => true,
			'message'  => sprintf( __( 'Switched active WebMCP site to blog ID %d.', 'respira-for-wordpress' ), $site_id ),
			'siteId'   => $site_id,
			'siteName' => $site_name,
			'url'      => get_site_url( $site_id ),
		);
	}

	/**
	 * Execute callback with selected multisite context.
	 *
	 * @param callable $callback Callback.
	 * @return mixed
	 */
	private function with_active_site_context( $callback ) {
		if ( ! is_multisite() ) {
			return call_user_func( $callback );
		}

		$site_id = (int) get_user_meta( get_current_user_id(), self::ACTIVE_SITE_META_KEY, true );
		if ( $site_id <= 0 ) {
			return call_user_func( $callback );
		}

		$current = get_current_blog_id();
		if ( $site_id === $current ) {
			return call_user_func( $callback );
		}

		$site = get_site( $site_id );
		if ( ! $site ) {
			delete_user_meta( get_current_user_id(), self::ACTIVE_SITE_META_KEY );
			return call_user_func( $callback );
		}

		if ( function_exists( 'current_user_can_for_site' ) && ! current_user_can_for_site( $site_id, 'read' ) ) {
			return new WP_Error(
				'respira_webmcp_site_forbidden',
				__( 'Current user cannot access the selected WebMCP site.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		switch_to_blog( $site_id );
		try {
			return call_user_func( $callback );
		} finally {
			restore_current_blog();
		}
	}

	/**
	 * Build synthetic key data expected by Respira callbacks.
	 *
	 * @return array<string,mixed>
	 */
	private function get_synthetic_key_data() {
		return array(
			'id'          => 0,
			'user_id'     => get_current_user_id(),
			'name'        => 'webmcp-ability',
			'permissions' => array( 'webmcp' ),
			'license_key' => get_option( 'respira_license_key', '' ),
		);
	}

	/**
	 * Build approvals page URL.
	 *
	 * @return string
	 */
	private function get_approvals_url() {
		return admin_url( 'admin.php?page=respira-changes' );
	}

	/**
	 * Check capability requirement.
	 *
	 * @param string|array $capability Capability or any-of list.
	 * @return bool
	 */
	private function check_capability( $capability ) {
		if ( is_array( $capability ) ) {
			foreach ( $capability as $cap ) {
				if ( current_user_can( $cap ) ) {
					return true;
				}
			}
			return false;
		}

		return current_user_can( $capability );
	}

	/**
	 * Build registry entries from base tool definitions.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function build_tool_registry() {
		$registry = array();
		$dispatch = self::get_dispatch_config();

		foreach ( self::get_tool_definitions() as $definition ) {
			$tool = $definition['tool'];
			if ( ! isset( $dispatch[ $tool ] ) ) {
				continue;
			}

			$handler = 'INTERNAL';
			if ( 'INTERNAL' !== strtoupper( $dispatch[ $tool ]['method'] ) ) {
				$handler = strtoupper( $dispatch[ $tool ]['method'] ) . ' ' . $dispatch[ $tool ]['path'];
			}

			$capability          = self::determine_tool_capability( $tool, $definition );
			$ability_annotations = self::build_ability_annotations( $definition );
			$output_schema       = self::normalize_schema_value( self::determine_output_schema( $tool ) );
			$mcp_public          = self::should_expose_tool_publicly( $tool, $definition, $capability );

			$registry[] = array(
				'tool'                => $tool,
				'ability_id'          => 'respira/' . str_replace( '_', '-', $tool ),
				'label'               => self::build_tool_label( $tool ),
				'description'         => $definition['description'],
				'input_schema'        => self::normalize_schema_value( $definition['input_schema'] ),
				'output_schema'       => $output_schema,
				'category'            => self::is_woocommerce_tool( $tool ) ? 'respira-woocommerce' : 'respira',
				'annotations'         => array(
					'readOnlyHint'    => ! empty( $definition['read_only'] ),
					'destructiveHint' => ! empty( $definition['destructive'] ),
					'idempotentHint'  => ! empty( $definition['idempotent'] ),
				),
				'ability_annotations' => $ability_annotations,
				'mcp_public'          => $mcp_public,
				'capability'          => $capability,
				'handler'             => $handler,
			);
		}

		return $registry;
	}

	/**
	 * Build official WordPress ability annotations from the tool definition.
	 *
	 * @param array<string,mixed> $definition Tool definition.
	 * @return array<string,bool>
	 */
	private static function build_ability_annotations( $definition ) {
		return array(
			'readonly'    => ! empty( $definition['read_only'] ),
			'destructive' => ! empty( $definition['destructive'] ),
			'idempotent'  => ! empty( $definition['idempotent'] ),
		);
	}

	/**
	 * Determine whether a tool should be exposed on the adapter default/public server.
	 *
	 * @param string            $tool Tool name.
	 * @param array<string,mixed> $definition Tool definition.
	 * @param string|array      $capability Capability requirement.
	 * @return bool
	 */
	private static function should_expose_tool_publicly( $tool, $definition, $capability ) {
		if ( empty( $definition['read_only'] ) || ! is_string( $capability ) ) {
			return false;
		}

		$denylist = array(
			'wordpress_list_users',
			'wordpress_get_user',
			'wordpress_list_comments',
			'wordpress_get_comment',
			'wordpress_list_menus',
			'wordpress_get_menu',
			'wordpress_list_menu_locations',
			'wordpress_list_menu_items',
			'wordpress_get_menu_item',
			'wordpress_list_plugins',
			'wordpress_list_options',
			'wordpress_get_option',
			'wordpress_validate_security',
		);

		if ( in_array( $tool, $denylist, true ) ) {
			return false;
		}

		return in_array(
			$capability,
			array(
				'edit_posts',
				'edit_pages',
				'upload_files',
				'manage_categories',
			),
			true
		);
	}

	/**
	 * Normalize schema values so empty property maps remain JSON objects.
	 *
	 * @param mixed       $value Schema value.
	 * @param string|null $key Parent key.
	 * @return mixed
	 */
	private static function normalize_schema_value( $value, $key = null ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		if ( empty( $value ) && 'properties' === $key ) {
			return new stdClass();
		}

		$normalized = array();
		foreach ( $value as $child_key => $child_value ) {
			$normalized[ $child_key ] = self::normalize_schema_value( $child_value, is_string( $child_key ) ? $child_key : null );
		}

		return $normalized;
	}

	/**
	 * Build tool label.
	 *
	 * @param string $tool Tool name.
	 * @return string
	 */
	private static function build_tool_label( $tool ) {
		$label = str_replace( '_', ' ', $tool );
		$label = ucwords( $label );
		$label = str_replace( 'Wordpress', 'WordPress', $label );
		$label = str_replace( 'Woocommerce', 'WooCommerce', $label );
		return $label;
	}

	/**
	 * Determine required capability for a tool.
	 *
	 * @param string $tool Tool name.
	 * @param array  $definition Tool definition.
	 * @return string|array
	 */
	private static function determine_tool_capability( $tool, $definition ) {
		if ( self::is_woocommerce_tool( $tool ) ) {
			return array( 'manage_woocommerce', 'manage_options' );
		}

		$admin_tools = array(
			'wordpress_switch_site',
			'wordpress_validate_security',
			'wordpress_approve_duplicate',
			'wordpress_reject_duplicate',
		);

		if ( in_array( $tool, $admin_tools, true ) ) {
			return 'manage_options';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_plugins' ) ||
			0 === strpos( $tool, 'wordpress_install_plugin' ) ||
			0 === strpos( $tool, 'wordpress_activate_plugin' ) ||
			0 === strpos( $tool, 'wordpress_deactivate_plugin' ) ||
			0 === strpos( $tool, 'wordpress_update_plugin' ) ||
			0 === strpos( $tool, 'wordpress_delete_plugin' ) ||
			0 === strpos( $tool, 'wordpress_list_options' ) ||
			0 === strpos( $tool, 'wordpress_get_option' ) ||
			0 === strpos( $tool, 'wordpress_update_option' ) ||
			0 === strpos( $tool, 'wordpress_delete_option' ) ||
			0 === strpos( $tool, 'wordpress_list_users' ) ||
			0 === strpos( $tool, 'wordpress_get_user' ) ||
			0 === strpos( $tool, 'wordpress_create_user' ) ||
			0 === strpos( $tool, 'wordpress_update_user' ) ||
			0 === strpos( $tool, 'wordpress_delete_user' ) ) {
			return 'manage_options';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_menus' ) ||
			0 === strpos( $tool, 'wordpress_get_menu' ) ||
			0 === strpos( $tool, 'wordpress_create_menu' ) ||
			0 === strpos( $tool, 'wordpress_update_menu' ) ||
			0 === strpos( $tool, 'wordpress_delete_menu' ) ||
			0 === strpos( $tool, 'wordpress_list_menu_locations' ) ||
			0 === strpos( $tool, 'wordpress_assign_menu_location' ) ||
			0 === strpos( $tool, 'wordpress_list_menu_items' ) ||
			0 === strpos( $tool, 'wordpress_create_menu_item' ) ||
			0 === strpos( $tool, 'wordpress_get_menu_item' ) ||
			0 === strpos( $tool, 'wordpress_update_menu_item' ) ||
			0 === strpos( $tool, 'wordpress_delete_menu_item' ) ) {
			return 'edit_theme_options';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_media' ) ||
			0 === strpos( $tool, 'wordpress_get_media' ) ||
			0 === strpos( $tool, 'wordpress_upload_media' ) ||
			0 === strpos( $tool, 'wordpress_update_media' ) ||
			0 === strpos( $tool, 'wordpress_delete_media' ) ) {
			return 'upload_files';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_comments' ) ||
			0 === strpos( $tool, 'wordpress_get_comment' ) ||
			0 === strpos( $tool, 'wordpress_create_comment' ) ||
			0 === strpos( $tool, 'wordpress_update_comment' ) ||
			0 === strpos( $tool, 'wordpress_delete_comment' ) ) {
			return 'moderate_comments';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_taxonomies' ) ||
			0 === strpos( $tool, 'wordpress_get_taxonomy' ) ||
			0 === strpos( $tool, 'wordpress_list_terms' ) ||
			0 === strpos( $tool, 'wordpress_get_term' ) ||
			0 === strpos( $tool, 'wordpress_create_term' ) ||
			0 === strpos( $tool, 'wordpress_update_term' ) ||
			0 === strpos( $tool, 'wordpress_delete_term' ) ) {
			return 'manage_categories';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_pages' ) ||
			0 === strpos( $tool, 'wordpress_read_page' ) ||
			0 === strpos( $tool, 'wordpress_detect_page_builder' ) ||
			0 === strpos( $tool, 'wordpress_create_page_duplicate' ) ||
			0 === strpos( $tool, 'wordpress_update_page' ) ||
			0 === strpos( $tool, 'wordpress_delete_page' ) ||
			0 === strpos( $tool, 'wordpress_extract_builder_content' ) ||
			0 === strpos( $tool, 'wordpress_inject_builder_content' ) ||
			0 === strpos( $tool, 'wordpress_update_module' ) ||
			0 === strpos( $tool, 'wordpress_list_snapshots' ) ||
			0 === strpos( $tool, 'wordpress_get_snapshot' ) ||
			0 === strpos( $tool, 'wordpress_diff_snapshots' ) ||
			0 === strpos( $tool, 'wordpress_restore_snapshot' ) ||
			0 === strpos( $tool, 'wordpress_apply_builder_patch' ) ) {
			return 'edit_pages';
		}

		if ( 0 === strpos( $tool, 'wordpress_list_posts' ) ||
			0 === strpos( $tool, 'wordpress_read_post' ) ||
			0 === strpos( $tool, 'wordpress_create_post_duplicate' ) ||
			0 === strpos( $tool, 'wordpress_update_post' ) ||
			0 === strpos( $tool, 'wordpress_delete_post' ) ||
			0 === strpos( $tool, 'wordpress_list_custom_posts' ) ||
			0 === strpos( $tool, 'wordpress_read_custom_post' ) ||
			0 === strpos( $tool, 'wordpress_get_custom_post' ) ||
			0 === strpos( $tool, 'wordpress_create_custom_post' ) ||
			0 === strpos( $tool, 'wordpress_update_custom_post' ) ||
			0 === strpos( $tool, 'wordpress_delete_custom_post' ) ||
			0 === strpos( $tool, 'wordpress_list_post_types' ) ||
			0 === strpos( $tool, 'wordpress_get_post_type' ) ) {
			return 'edit_posts';
		}

		return ! empty( $definition['read_only'] ) ? 'edit_posts' : 'edit_pages';
	}

	/**
	 * Determine output schema for high-traffic abilities.
	 *
	 * @param string $tool Tool name.
	 * @return array<string,mixed>
	 */
	private static function determine_output_schema( $tool ) {
		$generic_meta = array(
			'type'                 => 'object',
			'additionalProperties' => true,
		);

		$map = array(
			'wordpress_get_site_context' => array(
				'type'       => 'object',
				'properties' => array(
					'site_name'         => array( 'type' => 'string' ),
					'site_url'          => array( 'type' => 'string' ),
					'wordpress_version' => array( 'type' => 'string' ),
					'theme'             => array( 'type' => 'string' ),
					'page_builder'      => array( 'type' => 'string' ),
					'plugins'           => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
			),
			'wordpress_get_builder_info' => array(
				'type'       => 'object',
				'properties' => array(
					'builder' => array( 'type' => 'string' ),
					'version' => array( 'type' => 'string' ),
					'modules' => array(
						'type'  => 'array',
						'items' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
						),
					),
				),
			),
			'wordpress_list_pages' => array(
				'type'       => 'object',
				'properties' => array(
					'pages' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'id'      => array( 'type' => 'integer' ),
								'title'   => array( 'type' => 'string' ),
								'url'     => array( 'type' => 'string' ),
								'status'  => array( 'type' => 'string' ),
								'builder' => array( 'type' => 'string' ),
							),
						),
					),
					'total'      => array( 'type' => 'integer' ),
					'totalPages' => array( 'type' => 'integer' ),
				),
			),
			'wordpress_read_page' => array(
				'type'       => 'object',
				'properties' => array(
					'id'      => array( 'type' => 'integer' ),
					'title'   => array( 'type' => 'string' ),
					'content' => array( 'type' => 'string' ),
					'url'     => array( 'type' => 'string' ),
					'builder' => array( 'type' => 'string' ),
					'meta'    => $generic_meta,
				),
			),
			'wordpress_read_page_v2' => array(
				'type'                 => 'object',
				'additionalProperties' => true,
			),
			'wordpress_list_posts' => array(
				'type'       => 'object',
				'properties' => array(
					'posts' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'id'     => array( 'type' => 'integer' ),
								'title'  => array( 'type' => 'string' ),
								'url'    => array( 'type' => 'string' ),
								'status' => array( 'type' => 'string' ),
							),
						),
					),
					'total'      => array( 'type' => 'integer' ),
					'totalPages' => array( 'type' => 'integer' ),
				),
			),
			'wordpress_read_post' => array(
				'type'       => 'object',
				'properties' => array(
					'id'      => array( 'type' => 'integer' ),
					'title'   => array( 'type' => 'string' ),
					'content' => array( 'type' => 'string' ),
					'url'     => array( 'type' => 'string' ),
					'meta'    => $generic_meta,
				),
			),
			'wordpress_read_post_v2' => array(
				'type'                 => 'object',
				'additionalProperties' => true,
			),
			'wordpress_read_custom_post_v2' => array(
				'type'                 => 'object',
				'additionalProperties' => true,
			),
			'wordpress_list_media' => array(
				'type'       => 'object',
				'properties' => array(
					'media' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'id'   => array( 'type' => 'integer' ),
								'url'  => array( 'type' => 'string' ),
								'type' => array( 'type' => 'string' ),
								'alt'  => array( 'type' => 'string' ),
							),
						),
					),
					'total' => array( 'type' => 'integer' ),
				),
			),
			'wordpress_extract_builder_content' => array(
				'type'       => 'object',
				'properties' => array(
					'content' => array(
						'type'  => 'array',
						'items' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
						),
					),
					'diagnostics' => $generic_meta,
					'warning'     => array( 'type' => 'string' ),
					'success'     => array( 'type' => 'boolean' ),
					'builder'     => array( 'type' => 'string' ),
				),
			),
		);

		return isset( $map[ $tool ] ) ? $map[ $tool ] : array();
	}

	/**
	 * Determine if a tool is WooCommerce scoped.
	 *
	 * @param string $tool Tool name.
	 * @return bool
	 */
	private static function is_woocommerce_tool( $tool ) {
		return 0 === strpos( $tool, 'woocommerce_' );
	}

	/**
	 * Check WooCommerce add-on availability.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_addon_available() {
		$fallback_state = self::get_woocommerce_addon_state_fallback();

		// During early bootstrap (plugins_loaded / WP-CLI bootstrap), avoid
		// full context hydration because it may resolve REST URLs too early.
		if ( ! self::is_bootstrap_ready_for_full_context() || ! class_exists( 'Respira_Context' ) ) {
			return ! empty( $fallback_state['installed'] ) && ! empty( $fallback_state['licensed'] );
		}

		try {
			$context = Respira_Context::get_site_info();
			if ( isset( $context['addons']['woocommerce'] ) ) {
				return ! empty( $context['addons']['woocommerce']['installed'] ) && ! empty( $context['addons']['woocommerce']['licensed'] );
			}
		} catch ( \Throwable $e ) {
			// Fall back to stored add-on state when context bootstrap fails.
		}

		return ! empty( $fallback_state['installed'] ) && ! empty( $fallback_state['licensed'] );
	}

	/**
	 * Check if WP lifecycle is ready for full context hydration.
	 *
	 * @return bool
	 */
	private static function is_bootstrap_ready_for_full_context() {
		return did_action( 'init' ) || doing_action( 'init' ) || did_action( 'wp_loaded' );
	}

	/**
	 * Lightweight Woo add-on status for early bootstrap contexts.
	 *
	 * @return array<string,bool>
	 */
	private static function get_woocommerce_addon_state_fallback() {
		$installed = self::is_plugin_active_by_basename( 'respira-woocommerce-addon/respira-woocommerce-addon.php' );
		if ( ! $installed ) {
			return array(
				'installed' => false,
				'licensed'  => false,
			);
		}

		$status = (string) get_option( 'respira_woo_addon_status', 'inactive' );
		return array(
			'installed' => true,
			'licensed'  => in_array( $status, array( 'active', 'trial', 'network_error' ), true ),
		);
	}

	/**
	 * Frontend-safe plugin active check.
	 *
	 * @param string $plugin_basename Plugin basename.
	 * @return bool
	 */
	private static function is_plugin_active_by_basename( $plugin_basename ) {
		$active_plugins = (array) get_option( 'active_plugins', array() );
		if ( in_array( $plugin_basename, $active_plugins, true ) ) {
			return true;
		}

		if ( is_multisite() ) {
			$network_plugins = array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) );
			if ( in_array( $plugin_basename, $network_plugins, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Base tool definitions extracted from MCP server contract.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function get_tool_definitions() {
		return 
array(
    array(
        'tool' => 'wordpress_get_site_context',
        'description' => 'Get comprehensive information about the WordPress site including version, theme, plugins, custom post types, and page builder.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_theme_docs',
        'description' => 'Get theme documentation and available template files.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_builder_info',
        'description' => 'Get information about the active page builder including available modules/widgets.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_pages',
        'description' => 'List all pages with optional filtering.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array(
                    'type' => 'string',
                    'description' => 'Filter by status (publish, draft, pending)'
                ),
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number for pagination'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Number of items per page'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_read_page',
        'description' => 'Get full content of a specific page including meta data and builder information.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_detect_page_builder',
        'description' => 'Detect which page builder a specific page is using.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_page_duplicate',
        'description' => 'Create a duplicate of an existing page for safe editing. IMPORTANT: Always use this before making changes to an original page. After creating a duplicate, edit the duplicate using wordpress_update_page. The user can then review and approve the duplicate in WordPress admin (Respira → Changes) to apply changes live.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'originalId' => array(
                    'type' => 'number',
                    'description' => 'ID of the original page to duplicate'
                ),
                'suffix' => array(
                    'type' => 'string',
                    'description' => 'Optional suffix for the duplicated page title'
                )
            ),
            'required' => array(
                'originalId'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_approve_duplicate',
        'description' => 'Approve a Respira duplicate and apply it live. Admin-only.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'duplicate_id' => array(
                    'type' => 'number',
                    'description' => 'Duplicate page ID'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => 'Force approval when the live original changed after duplicate creation.'
                )
            ),
            'required' => array(
                'duplicate_id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_reject_duplicate',
        'description' => 'Reject and permanently delete a Respira duplicate. Admin-only.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'duplicate_id' => array(
                    'type' => 'number',
                    'description' => 'Duplicate page ID'
                )
            ),
            'required' => array(
                'duplicate_id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_page',
        'description' => 'Update a page. ⚠️ SAFETY: Respira ALWAYS creates duplicates automatically before editing live pages. If you try to edit an original page, Respira will automatically create a duplicate and edit that instead. After editing, the user must approve the duplicate in WordPress admin (Respira → Approve Edits) to apply changes live. Direct live edits require force=true AND confirmLiveEdit=true, and only work if "Allow Direct Editing" is enabled.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Page ID (Respira automatically creates a duplicate if editing an original page)'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'New page title'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'New page content (HTML)'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'Page status (publish, draft, pending)'
                ),
                'customCss' => array(
                    'type' => 'string',
                    'description' => 'Custom CSS for the page (stored in Divi _et_pb_custom_css meta field). Supports Divi Builder Custom CSS.'
                ),
                'meta' => array(
                    'type' => 'object',
                    'description' => 'Post meta data'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => '⚠️ DANGEROUS: Force direct edit of live page. Requires confirmLiveEdit=true and "Allow Direct Editing" enabled. NOT RECOMMENDED - duplicates are created automatically for safety.'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for direct edits/deletes of live originals when force=true.'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_page',
        'description' => 'Delete a page. IMPORTANT: By default, this only works on Respira-created duplicates. Deleting originals requires force=true + confirmLiveEdit=true and "Allow Direct Editing" enabled.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => 'Force delete even if not a duplicate'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for deleting a live original when force=true.'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_posts',
        'description' => 'List all blog posts with optional filtering.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array(
                    'type' => 'string',
                    'description' => 'Filter by status'
                ),
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_read_post',
        'description' => 'Get full content of a specific post.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_post_duplicate',
        'description' => 'Create a duplicate of an existing post for safe editing. IMPORTANT: Always use this before making changes to an original post. After creating a duplicate, edit the duplicate using wordpress_update_post. The user can then review and approve the duplicate in WordPress admin (Respira → Changes) to apply changes live.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'originalId' => array(
                    'type' => 'number',
                    'description' => 'Original post ID'
                ),
                'suffix' => array(
                    'type' => 'string',
                    'description' => 'Optional suffix'
                )
            ),
            'required' => array(
                'originalId'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_post',
        'description' => 'Update a post. ⚠️ SAFETY: Respira ALWAYS creates duplicates automatically before editing live posts. If you try to edit an original post, Respira will automatically create a duplicate and edit that instead. After editing, the user must approve the duplicate in WordPress admin (Respira → Approve Edits) to apply changes live. Direct live edits require force=true AND confirmLiveEdit=true, and only work if "Allow Direct Editing" is enabled.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID (Respira automatically creates a duplicate if editing an original post)'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'New post title'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'New post content (HTML)'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'Post status (publish, draft, pending)'
                ),
                'customCss' => array(
                    'type' => 'string',
                    'description' => 'Custom CSS for the post (stored in Divi _et_pb_custom_css meta field). Supports Divi Builder Custom CSS.'
                ),
                'meta' => array(
                    'type' => 'object',
                    'description' => 'Post meta data'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => '⚠️ DANGEROUS: Force direct edit of live post. Requires confirmLiveEdit=true and "Allow Direct Editing" enabled. NOT RECOMMENDED - duplicates are created automatically for safety.'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for direct edits/deletes of live originals when force=true.'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_post',
        'description' => 'Delete a post. IMPORTANT: By default, this only works on Respira-created duplicates. Deleting originals requires force=true + confirmLiveEdit=true and "Allow Direct Editing" enabled.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => 'Force delete even if not a duplicate'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for deleting a live original when force=true.'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_media',
        'description' => 'List all media files (images, videos, etc.).',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_upload_media',
        'description' => 'Upload a media file (image, document, video) to WordPress. Supports base64 encoded files, file URLs, or file paths.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'file' => array(
                    'type' => 'string',
                    'description' => 'File content as base64 string, file URL to download, or file path'
                ),
                'filename' => array(
                    'type' => 'string',
                    'description' => 'Filename for the uploaded file'
                ),
                'mimeType' => array(
                    'type' => 'string',
                    'description' => 'MIME type of the file (e.g., image/jpeg, image/png, application/pdf)'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Optional title for the media item'
                ),
                'alt' => array(
                    'type' => 'string',
                    'description' => 'Optional alt text for images'
                ),
                'caption' => array(
                    'type' => 'string',
                    'description' => 'Optional caption for the media item'
                )
            ),
            'required' => array(
                'file',
                'filename'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_extract_builder_content',
        'description' => 'Extract structured content from a page builder (Divi, Elementor, etc.).',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'builder' => array(
                    'type' => 'string',
                    'description' => 'Builder name (gutenberg, divi, elementor, etc.)'
                ),
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                )
            ),
            'required' => array(
                'builder',
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_inject_builder_content',
        'description' => 'Inject structured content into a page builder. For Divi, diviVersion confirmation is required on every inject call ("4" or "5").',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'builder' => array(
                    'type' => 'string',
                    'description' => 'Builder name'
                ),
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                ),
                'content' => array(
                    'type' => 'object',
                    'description' => 'Structured content to inject'
                ),
                'diviVersion' => array(
                    'type' => 'string',
                    'description' => 'Divi generation hint ("4" for shortcode format, "5" for block format). Required for all Divi inject calls.',
                    'enum' => array(
                        '4',
                        '5'
                    )
                )
            ),
            'required' => array(
                'builder',
                'pageId',
                'content'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_update_module',
        'description' => 'Update a specific module within a page builder page. Supports finding modules by admin_label, path, or type. Only updates the specified module while preserving all other content.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'builder' => array(
                    'type' => 'string',
                    'description' => 'Builder name (e.g., divi, elementor)'
                ),
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                ),
                'moduleIdentifier' => array(
                    'type' => 'object',
                    'description' => 'Module identifier - use one of: admin_label, path, or type',
                    'properties' => array(
                        'admin_label' => array(
                            'type' => 'string',
                            'description' => 'Find module by admin_label attribute'
                        ),
                        'path' => array(
                            'type' => 'string',
                            'description' => 'Find module by path (e.g., "sections[0].rows[0].modules[2]")'
                        ),
                        'type' => array(
                            'type' => 'string',
                            'description' => 'Find module by type (e.g., "et_pb_code")'
                        ),
                        'match_content' => array(
                            'type' => 'string',
                            'description' => 'Optional content to match when using type identifier'
                        )
                    )
                ),
                'updates' => array(
                    'type' => 'object',
                    'description' => 'Updates to apply to the module',
                    'properties' => array(
                        'content' => array(
                            'type' => 'string',
                            'description' => 'New content for the module'
                        ),
                        'attributes' => array(
                            'type' => 'object',
                            'description' => 'Attributes to update (merged with existing)'
                        )
                    )
                )
            ),
            'required' => array(
                'builder',
                'pageId',
                'moduleIdentifier',
                'updates'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_validate_security',
        'description' => 'Validate content for security issues before saving.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'content' => array(
                    'type' => 'string',
                    'description' => 'Content to validate'
                )
            ),
            'required' => array(
                'content'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_switch_site',
        'description' => 'Switch to a different WordPress site (for multi-site setups).',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'siteId' => array(
                    'type' => 'string',
                    'description' => 'Site ID from configuration'
                )
            ),
            'required' => array(
                'siteId'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_analyze_performance',
        'description' => 'Analyze page performance metrics including load time, image optimization, CSS/JS optimization, caching, and plugin performance impact.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_core_web_vitals',
        'description' => 'Get Core Web Vitals metrics (LCP, FID, CLS) for a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_analyze_images',
        'description' => 'Analyze image optimization opportunities including missing alt text, large files, and unoptimized formats.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_analyze_seo',
        'description' => 'Comprehensive SEO analysis including meta tags, heading structure, image alt text, internal linking, content quality, and schema markup.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_check_seo_issues',
        'description' => 'Check for common SEO issues and get quick recommendations.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_analyze_readability',
        'description' => 'Analyze content readability including Flesch Reading Ease score, sentence length, and paragraph structure.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_analyze_aeo',
        'description' => 'Analyze content for AI Engine Optimization (optimizing for AI search engines like Perplexity, ChatGPT). Checks structured data, content clarity, semantic HTML, entities, content depth, and FAQ opportunities.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_check_structured_data',
        'description' => 'Check schema markup and structured data (JSON-LD, microdata) for AI parsing.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array(
                    'type' => 'number',
                    'description' => 'Page ID to analyze'
                )
            ),
            'required' => array(
                'pageId'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_plugins',
        'description' => 'List all installed plugins with their status, version, and update availability. Requires plugin management to be enabled in Respira settings.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_install_plugin',
        'description' => 'Install a plugin from WordPress.org or a ZIP URL. Requires plugin management to be enabled in Respira settings. Use with caution.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'slugOrUrl' => array(
                    'type' => 'string',
                    'description' => 'Plugin slug (from WordPress.org) or ZIP file URL'
                ),
                'source' => array(
                    'type' => 'string',
                    'description' => 'Source type: "wordpress.org" or "url"',
                    'enum' => array(
                        'wordpress.org',
                        'url'
                    )
                )
            ),
            'required' => array(
                'slugOrUrl'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_activate_plugin',
        'description' => 'Activate a plugin. Requires plugin management to be enabled in Respira settings. Monitor the site after activation.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Plugin slug'
                )
            ),
            'required' => array(
                'slug'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_deactivate_plugin',
        'description' => 'Deactivate a plugin. Requires plugin management to be enabled in Respira settings.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Plugin slug'
                )
            ),
            'required' => array(
                'slug'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_plugin',
        'description' => 'Update a plugin to the latest version. Requires plugin management to be enabled in Respira settings. Make sure you have backups before updating.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Plugin slug'
                )
            ),
            'required' => array(
                'slug'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_plugin',
        'description' => 'Permanently delete a plugin. Requires plugin management to be enabled in Respira settings. The plugin must be deactivated first.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Plugin slug'
                )
            ),
            'required' => array(
                'slug'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_users',
        'description' => 'List all users with optional filtering by search term.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_user',
        'description' => 'Get user details by ID.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'User ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_user',
        'description' => 'Create a new user.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'username' => array(
                    'type' => 'string',
                    'description' => 'Username'
                ),
                'email' => array(
                    'type' => 'string',
                    'description' => 'Email address'
                ),
                'password' => array(
                    'type' => 'string',
                    'description' => 'Password'
                ),
                'role' => array(
                    'type' => 'string',
                    'description' => 'User role (default: subscriber)'
                )
            ),
            'required' => array(
                'username',
                'email',
                'password'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_user',
        'description' => 'Update user information.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'User ID'
                ),
                'email' => array(
                    'type' => 'string',
                    'description' => 'Email address'
                ),
                'display_name' => array(
                    'type' => 'string',
                    'description' => 'Display name'
                ),
                'password' => array(
                    'type' => 'string',
                    'description' => 'Password'
                ),
                'role' => array(
                    'type' => 'string',
                    'description' => 'User role'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_user',
        'description' => 'Delete a user.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'User ID'
                ),
                'reassign' => array(
                    'type' => 'number',
                    'description' => 'User ID to reassign posts to (optional)'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_comments',
        'description' => 'List all comments with optional filtering.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array(
                    'type' => 'string',
                    'description' => 'Comment status (approve, hold, spam, trash)'
                ),
                'post_id' => array(
                    'type' => 'number',
                    'description' => 'Filter by post ID'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_comment',
        'description' => 'Get comment details by ID.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Comment ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_comment',
        'description' => 'Create a new comment.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'author' => array(
                    'type' => 'string',
                    'description' => 'Author name'
                ),
                'author_email' => array(
                    'type' => 'string',
                    'description' => 'Author email'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'Comment content'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent comment ID (for replies)'
                ),
                'status' => array(
                    'type' => 'number',
                    'description' => 'Comment status (1=approved, 0=hold)'
                )
            ),
            'required' => array(
                'post_id',
                'author',
                'author_email',
                'content'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_comment',
        'description' => 'Update a comment.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Comment ID'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'Comment content'
                ),
                'status' => array(
                    'type' => 'number',
                    'description' => 'Comment status'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_comment',
        'description' => 'Delete a comment.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Comment ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_taxonomies',
        'description' => 'List all registered taxonomies.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_taxonomy',
        'description' => 'Get taxonomy details.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                )
            ),
            'required' => array(
                'taxonomy'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_terms',
        'description' => 'List terms in a taxonomy.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                ),
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            ),
            'required' => array(
                'taxonomy'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_term',
        'description' => 'Get term details.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Term ID'
                )
            ),
            'required' => array(
                'taxonomy',
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_term',
        'description' => 'Create a new term.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Term name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Term slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Term description'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent term ID'
                )
            ),
            'required' => array(
                'taxonomy',
                'name'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_term',
        'description' => 'Update a term.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Term ID'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Term name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Term slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Term description'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent term ID'
                )
            ),
            'required' => array(
                'taxonomy',
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_term',
        'description' => 'Delete a term.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'taxonomy' => array(
                    'type' => 'string',
                    'description' => 'Taxonomy name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Term ID'
                )
            ),
            'required' => array(
                'taxonomy',
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_post_types',
        'description' => 'List all registered post types.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_post_type',
        'description' => 'Get post type details.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                )
            ),
            'required' => array(
                'type'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_custom_posts',
        'description' => 'List posts of a custom post type.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'Post status'
                ),
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                ),
                'perPage' => array(
                    'type' => 'number',
                    'description' => 'Items per page'
                )
            ),
            'required' => array(
                'type'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_custom_post',
        'description' => 'Get custom post details.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                )
            ),
            'required' => array(
                'type',
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_custom_post',
        'description' => 'Create a new custom post.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Post title'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'Post content'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'Post status (default: draft)'
                )
            ),
            'required' => array(
                'type',
                'title'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_custom_post',
        'description' => 'Update a custom post. Uses duplicate-first safety by default. Direct live edits require force=true + confirmLiveEdit=true and "Allow Direct Editing" enabled. Supports meta fields and custom CSS for Divi/Elementor builders.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Post title'
                ),
                'content' => array(
                    'type' => 'string',
                    'description' => 'Post content'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'Post status'
                ),
                'meta' => array(
                    'type' => 'object',
                    'description' => 'Post meta data (e.g., { "_et_pb_custom_css": "/* CSS */" })'
                ),
                'customCss' => array(
                    'type' => 'string',
                    'description' => 'Custom CSS for page builders (Divi/Elementor). Automatically saved to the appropriate meta field based on detected builder.'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => 'Force direct edit of live custom post (requires confirmLiveEdit=true and direct editing enabled).'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for direct edits/deletes of live originals when force=true.'
                )
            ),
            'required' => array(
                'type',
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_custom_post',
        'description' => 'Delete a custom post. Deleting originals requires force=true + confirmLiveEdit=true and "Allow Direct Editing" enabled.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Post type name'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'force' => array(
                    'type' => 'boolean',
                    'description' => 'Force delete even if not a duplicate.'
                ),
                'confirmLiveEdit' => array(
                    'type' => 'boolean',
                    'description' => 'Explicit confirmation required for deleting a live original when force=true.'
                )
            ),
            'required' => array(
                'type',
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_options',
        'description' => 'List WordPress options (with optional search filter).',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search term to filter option names'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_option',
        'description' => 'Get option value by name.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'option' => array(
                    'type' => 'string',
                    'description' => 'Option name'
                )
            ),
            'required' => array(
                'option'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_option',
        'description' => 'Update an option value.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'option' => array(
                    'type' => 'string',
                    'description' => 'Option name'
                ),
                'value' => array(
                    'type' => 'string',
                    'description' => 'Option value'
                )
            ),
            'required' => array(
                'option',
                'value'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_option',
        'description' => 'Delete an option.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'option' => array(
                    'type' => 'string',
                    'description' => 'Option name'
                )
            ),
            'required' => array(
                'option'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_media',
        'description' => 'Get single media item details.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Media ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_media',
        'description' => 'Update media metadata (title, alt text, caption).',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Media ID'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Media title'
                ),
                'alt' => array(
                    'type' => 'string',
                    'description' => 'Alt text'
                ),
                'caption' => array(
                    'type' => 'string',
                    'description' => 'Caption'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_media',
        'description' => 'Delete a media file.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Media ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_menus',
        'description' => 'List all navigation menus. Includes WPML translation info if available.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_menu',
        'description' => 'Get a navigation menu with all its items. Includes WPML translation info if available.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_menu',
        'description' => 'Create a new navigation menu.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'name' => array(
                    'type' => 'string',
                    'description' => 'Menu name'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Menu description'
                )
            ),
            'required' => array(
                'name'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_menu',
        'description' => 'Update a navigation menu.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Menu name'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Menu description'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_menu',
        'description' => 'Delete a navigation menu.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_menu_locations',
        'description' => 'List all registered menu locations and their assigned menus.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_assign_menu_location',
        'description' => 'Assign a menu to a theme location.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'location' => array(
                    'type' => 'string',
                    'description' => 'Location slug (e.g., "primary", "footer")'
                ),
                'menu_id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID to assign (use 0 to unassign)'
                )
            ),
            'required' => array(
                'location',
                'menu_id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_list_menu_items',
        'description' => 'List all items in a menu with their hierarchy.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'menu_id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID'
                )
            ),
            'required' => array(
                'menu_id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_create_menu_item',
        'description' => 'Create a new menu item. Can link to pages, posts, custom URLs, or categories.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'menu_id' => array(
                    'type' => 'number',
                    'description' => 'Menu ID'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Menu item title'
                ),
                'url' => array(
                    'type' => 'string',
                    'description' => 'Custom URL (for custom links)'
                ),
                'object_type' => array(
                    'type' => 'string',
                    'description' => 'Object type: "post", "page", "category", "custom", etc.'
                ),
                'object_id' => array(
                    'type' => 'number',
                    'description' => 'ID of the linked object (post ID, page ID, etc.)'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent menu item ID for nested items'
                ),
                'position' => array(
                    'type' => 'number',
                    'description' => 'Position in menu (1-based)'
                ),
                'target' => array(
                    'type' => 'string',
                    'description' => 'Link target ("_blank" for new window)'
                ),
                'classes' => array(
                    'type' => 'string',
                    'description' => 'CSS classes (space-separated)'
                ),
                'attr_title' => array(
                    'type' => 'string',
                    'description' => 'Title attribute (tooltip)'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Item description'
                )
            ),
            'required' => array(
                'menu_id',
                'title'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_menu_item',
        'description' => 'Get a single menu item by ID.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'item_id' => array(
                    'type' => 'number',
                    'description' => 'Menu item ID'
                )
            ),
            'required' => array(
                'item_id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_menu_item',
        'description' => 'Update a menu item.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'item_id' => array(
                    'type' => 'number',
                    'description' => 'Menu item ID'
                ),
                'title' => array(
                    'type' => 'string',
                    'description' => 'Menu item title'
                ),
                'url' => array(
                    'type' => 'string',
                    'description' => 'Custom URL (for custom links)'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent menu item ID'
                ),
                'position' => array(
                    'type' => 'number',
                    'description' => 'Position in menu'
                ),
                'target' => array(
                    'type' => 'string',
                    'description' => 'Link target'
                ),
                'classes' => array(
                    'type' => 'string',
                    'description' => 'CSS classes'
                ),
                'attr_title' => array(
                    'type' => 'string',
                    'description' => 'Title attribute'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Item description'
                )
            ),
            'required' => array(
                'item_id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_delete_menu_item',
        'description' => 'Delete a menu item.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'item_id' => array(
                    'type' => 'number',
                    'description' => 'Menu item ID'
                )
            ),
            'required' => array(
                'item_id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_list_products',
        'description' => 'List WooCommerce products with status/search/pagination filters.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array(
                    'type' => 'string',
                    'description' => 'publish, draft, pending, any'
                ),
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search by product name'
                ),
                'per_page' => array(
                    'type' => 'number',
                    'description' => 'Products per page (1-100)'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_get_product',
        'description' => 'Get detailed information for a single WooCommerce product.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Product ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_create_product',
        'description' => 'Create a WooCommerce product.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'name' => array(
                    'type' => 'string',
                    'description' => 'Product name'
                ),
                'type' => array(
                    'type' => 'string',
                    'description' => 'simple or variable'
                ),
                'regular_price' => array(
                    'type' => 'string',
                    'description' => 'Regular price'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'draft, pending, publish'
                ),
                'category_ids' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'number'
                    ),
                    'description' => 'Optional category IDs to assign'
                ),
                'tag_ids' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'number'
                    ),
                    'description' => 'Optional tag IDs to assign'
                )
            ),
            'required' => array(
                'name'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_update_product',
        'description' => 'Update an existing WooCommerce product.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Product ID'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Product name'
                ),
                'regular_price' => array(
                    'type' => 'string',
                    'description' => 'Regular price'
                ),
                'sale_price' => array(
                    'type' => 'string',
                    'description' => 'Sale price'
                ),
                'stock_quantity' => array(
                    'type' => 'number',
                    'description' => 'Stock quantity'
                ),
                'stock_status' => array(
                    'type' => 'string',
                    'description' => 'instock, outofstock, onbackorder'
                ),
                'category_ids' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'number'
                    ),
                    'description' => 'Category IDs to assign'
                ),
                'categories' => array(
                    'type' => 'array',
                    'description' => 'Alternative category payload (IDs, names, slugs, or objects with id/name/slug)'
                ),
                'tag_ids' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'number'
                    ),
                    'description' => 'Tag IDs to assign'
                ),
                'tags' => array(
                    'type' => 'array',
                    'description' => 'Alternative tag payload (IDs, names, slugs, or objects with id/name/slug)'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'woocommerce_duplicate_product',
        'description' => 'Duplicate a WooCommerce product to a draft copy.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Product ID to duplicate'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_list_categories',
        'description' => 'List WooCommerce product categories.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search categories by name'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Filter by parent category ID'
                ),
                'hide_empty' => array(
                    'type' => 'boolean',
                    'description' => 'Hide categories without products'
                ),
                'per_page' => array(
                    'type' => 'number',
                    'description' => 'Categories per page (1-100)'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_get_category',
        'description' => 'Get detailed information for a single WooCommerce product category.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Category ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_create_category',
        'description' => 'Create a WooCommerce product category.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'name' => array(
                    'type' => 'string',
                    'description' => 'Category name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Optional URL slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Optional category description'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Optional parent category ID'
                )
            ),
            'required' => array(
                'name'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_update_category',
        'description' => 'Update a WooCommerce product category.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Category ID'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Category name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Optional URL slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Category description'
                ),
                'parent' => array(
                    'type' => 'number',
                    'description' => 'Parent category ID (0 to move to root)'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'woocommerce_delete_category',
        'description' => 'Delete a WooCommerce product category.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Category ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_list_tags',
        'description' => 'List WooCommerce product tags.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array(
                    'type' => 'string',
                    'description' => 'Search tags by name'
                ),
                'hide_empty' => array(
                    'type' => 'boolean',
                    'description' => 'Hide tags without products'
                ),
                'per_page' => array(
                    'type' => 'number',
                    'description' => 'Tags per page (1-100)'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_get_tag',
        'description' => 'Get detailed information for a single WooCommerce product tag.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Tag ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_create_tag',
        'description' => 'Create a WooCommerce product tag.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'name' => array(
                    'type' => 'string',
                    'description' => 'Tag name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Optional URL slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Optional tag description'
                )
            ),
            'required' => array(
                'name'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_update_tag',
        'description' => 'Update a WooCommerce product tag.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Tag ID'
                ),
                'name' => array(
                    'type' => 'string',
                    'description' => 'Tag name'
                ),
                'slug' => array(
                    'type' => 'string',
                    'description' => 'Optional URL slug'
                ),
                'description' => array(
                    'type' => 'string',
                    'description' => 'Tag description'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'woocommerce_delete_tag',
        'description' => 'Delete a WooCommerce product tag.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Tag ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_list_orders',
        'description' => 'List WooCommerce orders.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array(
                    'type' => 'string',
                    'description' => 'pending, processing, completed, cancelled, refunded, failed, any'
                ),
                'per_page' => array(
                    'type' => 'number',
                    'description' => 'Orders per page (1-100)'
                ),
                'page' => array(
                    'type' => 'number',
                    'description' => 'Page number'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_get_order',
        'description' => 'Get detailed information for a single WooCommerce order.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Order ID'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_update_order_status',
        'description' => 'Update WooCommerce order status.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Order ID'
                ),
                'status' => array(
                    'type' => 'string',
                    'description' => 'pending, processing, on-hold, completed, cancelled, refunded, failed'
                )
            ),
            'required' => array(
                'id',
                'status'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'woocommerce_get_stock_status',
        'description' => 'Get inventory overview with low-stock and out-of-stock counts.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'woocommerce_update_stock',
        'description' => 'Update stock quantity or stock status for a product.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Product ID'
                ),
                'stock_quantity' => array(
                    'type' => 'number',
                    'description' => 'Stock quantity'
                ),
                'stock_status' => array(
                    'type' => 'string',
                    'description' => 'instock, outofstock, onbackorder'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'woocommerce_sales_report',
        'description' => 'Get WooCommerce sales report for week/month/year/custom range.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'period' => array(
                    'type' => 'string',
                    'description' => 'week, month, year, custom'
                ),
                'date_min' => array(
                    'type' => 'string',
                    'description' => 'Start date for custom period'
                ),
                'date_max' => array(
                    'type' => 'string',
                    'description' => 'End date for custom period'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_read_page_v2',
        'description' => 'Read a page using Respira v2 include-gated fidelity contract.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Page ID'
                ),
                'include' => array(
                    'type' => 'string',
                    'description' => 'CSV include contract (basic, content.rendered, builder.payload, snapshot.current, etc.)'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_read_post_v2',
        'description' => 'Read a post using Respira v2 include-gated fidelity contract.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'include' => array(
                    'type' => 'string',
                    'description' => 'CSV include contract (basic, content.rendered, builder.payload, snapshot.current, etc.)'
                )
            ),
            'required' => array(
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_read_custom_post_v2',
        'description' => 'Read a custom post type entry using Respira v2 include-gated fidelity contract.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'type' => array(
                    'type' => 'string',
                    'description' => 'Custom post type slug'
                ),
                'id' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'include' => array(
                    'type' => 'string',
                    'description' => 'CSV include contract'
                )
            ),
            'required' => array(
                'type',
                'id'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_list_snapshots',
        'description' => 'List v2 snapshots by post/post type/kind with cursor pagination.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array(
                    'type' => 'number',
                    'description' => 'Optional post ID filter'
                ),
                'post_type' => array(
                    'type' => 'string',
                    'description' => 'Optional post type filter'
                ),
                'kind' => array(
                    'type' => 'string',
                    'description' => 'Optional snapshot kind filter'
                ),
                'limit' => array(
                    'type' => 'number',
                    'description' => 'Result limit'
                ),
                'cursor' => array(
                    'type' => 'number',
                    'description' => 'Pagination cursor'
                )
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_get_snapshot',
        'description' => 'Get a snapshot by snapshot UUID.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'snapshot_uuid' => array(
                    'type' => 'string',
                    'description' => 'Snapshot UUID'
                )
            ),
            'required' => array(
                'snapshot_uuid'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_diff_snapshots',
        'description' => 'Diff two snapshots by UUID and return fidelity hash deltas.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'snapshot_uuid_a' => array(
                    'type' => 'string',
                    'description' => 'First snapshot UUID'
                ),
                'snapshot_uuid_b' => array(
                    'type' => 'string',
                    'description' => 'Second snapshot UUID'
                )
            ),
            'required' => array(
                'snapshot_uuid_a',
                'snapshot_uuid_b'
            )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_restore_snapshot',
        'description' => 'Restore post content/meta from a specific snapshot UUID.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'snapshot_uuid' => array(
                    'type' => 'string',
                    'description' => 'Snapshot UUID'
                )
            ),
            'required' => array(
                'snapshot_uuid'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_apply_builder_patch',
        'description' => 'Apply Respira v2 builder patch operations using id/path/type identifiers.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'builder' => array(
                    'type' => 'string',
                    'description' => 'Builder slug'
                ),
                'postId' => array(
                    'type' => 'number',
                    'description' => 'Post ID'
                ),
                'include' => array(
                    'type' => 'string',
                    'description' => 'Optional v2 include CSV for response payload'
                ),
                'operations' => array(
                    'type' => 'array',
                    'description' => 'Patch operations[]'
                )
            ),
            'required' => array(
                'builder',
                'postId',
                'operations'
            )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    // --- v5.2.0 Elemental: Element Operations ---
    array(
        'tool' => 'wordpress_find_element',
        'description' => 'Find an element within a page by ID, type, or admin label.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'identifier_type' => array( 'type' => 'string', 'description' => 'How to find: id, type, or admin_label', 'enum' => array( 'id', 'type', 'admin_label' ) ),
                'identifier_value' => array( 'type' => 'string', 'description' => 'Value to match' ),
                'match_content' => array( 'type' => 'string', 'description' => 'Optional text content to match' )
            ),
            'required' => array( 'post_id', 'identifier_type', 'identifier_value' )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_update_element',
        'description' => 'Update settings/content of a specific element on a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'identifier_type' => array( 'type' => 'string', 'description' => 'How to find: id, type, or admin_label' ),
                'identifier_value' => array( 'type' => 'string', 'description' => 'Value to match' ),
                'updates' => array( 'type' => 'object', 'description' => 'Settings/content to update' )
            ),
            'required' => array( 'post_id', 'identifier_type', 'identifier_value', 'updates' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_move_element',
        'description' => 'Move an element to a different container or position on a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'element_id_type' => array( 'type' => 'string', 'description' => 'How to find: id, type, or admin_label' ),
                'element_id_value' => array( 'type' => 'string', 'description' => 'Value to match' ),
                'target_container_path' => array( 'type' => 'string', 'description' => 'Path to target container' ),
                'position' => array( 'type' => 'number', 'description' => 'Position in target container (-1 for end)' )
            ),
            'required' => array( 'post_id', 'element_id_type', 'element_id_value', 'target_container_path' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_duplicate_element',
        'description' => 'Duplicate an element on a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'identifier_type' => array( 'type' => 'string', 'description' => 'How to find: id, type, or admin_label' ),
                'identifier_value' => array( 'type' => 'string', 'description' => 'Value to match' )
            ),
            'required' => array( 'post_id', 'identifier_type', 'identifier_value' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_remove_element',
        'description' => 'Remove an element from a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'identifier_type' => array( 'type' => 'string', 'description' => 'How to find: id, type, or admin_label' ),
                'identifier_value' => array( 'type' => 'string', 'description' => 'Value to match' )
            ),
            'required' => array( 'post_id', 'identifier_type', 'identifier_value' )
        ),
        'read_only' => false,
        'destructive' => true,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_batch_update',
        'description' => 'Apply multiple element operations atomically on a single page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'operations' => array( 'type' => 'array', 'description' => 'Array of operations to apply' )
            ),
            'required' => array( 'post_id', 'operations' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    array(
        'tool' => 'wordpress_reorder_elements',
        'description' => 'Reorder children within a container element.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'container_path' => array( 'type' => 'string', 'description' => 'Path to the container' ),
                'new_order' => array( 'type' => 'array', 'description' => 'Ordered array of child identifiers' )
            ),
            'required' => array( 'post_id', 'container_path', 'new_order' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => true
    ),
    // --- v5.2.0 Elemental: Composite Tools ---
    array(
        'tool' => 'wordpress_build_page',
        'description' => 'Create a new page with builder-specific declarative structure.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'title' => array( 'type' => 'string', 'description' => 'Page title' ),
                'structure' => array( 'type' => 'array', 'description' => 'Declarative page structure' ),
                'status' => array( 'type' => 'string', 'description' => 'Page status: draft or publish', 'enum' => array( 'draft', 'publish' ) ),
                'builder' => array( 'type' => 'string', 'description' => 'Builder slug (auto-detect if omitted)' )
            ),
            'required' => array( 'title', 'structure' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_convert_html_to_builder',
        'description' => 'Convert HTML into native builder page with fidelity report.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'html' => array( 'type' => 'string', 'description' => 'HTML content to convert' ),
                'builder' => array( 'type' => 'string', 'description' => 'Target builder (auto-detect if omitted)' ),
                'options' => array( 'type' => 'object', 'description' => 'Conversion options: status, title, preserve_tokens, font_substitution, responsive' )
            ),
            'required' => array( 'html' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_bulk_pages_operation',
        'description' => 'Apply operations across multiple pages with mandatory snapshots.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'page_ids' => array( 'type' => 'array', 'description' => 'Array of page IDs (max 100)' ),
                'operation' => array( 'type' => 'object', 'description' => 'Operation to apply: type + options' ),
                'options' => array( 'type' => 'object', 'description' => 'Options including dry_run' )
            ),
            'required' => array( 'page_ids', 'operation' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    // --- v5.2.0 Elemental: Stock Images ---
    array(
        'tool' => 'wordpress_search_stock_images',
        'description' => 'Search Openverse for free stock images.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'query' => array( 'type' => 'string', 'description' => 'Search query' ),
                'license_type' => array( 'type' => 'string', 'description' => 'License filter' ),
                'source' => array( 'type' => 'string', 'description' => 'Image source filter' ),
                'aspect_ratio' => array( 'type' => 'string', 'description' => 'Aspect ratio filter' ),
                'size' => array( 'type' => 'string', 'description' => 'Size filter' ),
                'category' => array( 'type' => 'string', 'description' => 'Category filter' )
            ),
            'required' => array( 'query' )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_sideload_image',
        'description' => 'Download a stock image and add it to the WordPress Media Library.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'url' => array( 'type' => 'string', 'description' => 'Image URL to sideload' ),
                'title' => array( 'type' => 'string', 'description' => 'Image title' ),
                'alt' => array( 'type' => 'string', 'description' => 'Alt text' ),
                'author' => array( 'type' => 'string', 'description' => 'Author for CC attribution' ),
                'license' => array( 'type' => 'string', 'description' => 'License type' ),
                'source' => array( 'type' => 'string', 'description' => 'Source name' )
            ),
            'required' => array( 'url' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    // --- v5.2.0 Elemental: Builder Intelligence ---
    array(
        'tool' => 'wordpress_find_builder_targets',
        'description' => 'Find editable targets within a page\'s builder content by query.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'builder' => array( 'type' => 'string', 'description' => 'Builder slug' ),
                'pageId' => array( 'type' => 'number', 'description' => 'Page ID' ),
                'query' => array( 'type' => 'string', 'description' => 'Search query for targets' ),
                'limit' => array( 'type' => 'number', 'description' => 'Max results to return' )
            ),
            'required' => array( 'builder', 'pageId' )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    // --- v5.2.0 Elemental: Analysis ---
    array(
        'tool' => 'wordpress_analyze_rankmath',
        'description' => 'Analyze a page using RankMath SEO metrics when RankMath is installed.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'pageId' => array( 'type' => 'number', 'description' => 'Page/post ID to analyze' )
            ),
            'required' => array( 'pageId' )
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    // --- v5.2.0 Elemental: Server ---
    array(
        'tool' => 'wordpress_get_server_compatibility',
        'description' => 'Check plugin/MCP server version compatibility.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array()
        ),
        'read_only' => true,
        'destructive' => false,
        'idempotent' => false
    ),
    // --- v5.2.0 Elemental: Widget Shortcuts ---
    array(
        'tool' => 'wordpress_add_heading',
        'description' => 'Add a heading widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'title' => array( 'type' => 'string', 'description' => 'Heading text' ),
                'tag' => array( 'type' => 'string', 'description' => 'HTML tag: h1-h6' ),
                'alignment' => array( 'type' => 'string', 'description' => 'Text alignment' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_text',
        'description' => 'Add a text editor widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'content' => array( 'type' => 'string', 'description' => 'Text/HTML content' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_button',
        'description' => 'Add a button widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'text' => array( 'type' => 'string', 'description' => 'Button label' ),
                'url' => array( 'type' => 'string', 'description' => 'Button link URL' ),
                'alignment' => array( 'type' => 'string', 'description' => 'Button alignment' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_image',
        'description' => 'Add an image widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'image_id' => array( 'type' => 'number', 'description' => 'Media library image ID' ),
                'image_url' => array( 'type' => 'string', 'description' => 'Image URL' ),
                'alt' => array( 'type' => 'string', 'description' => 'Alt text' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_section',
        'description' => 'Add a new section container to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'layout' => array( 'type' => 'string', 'description' => 'Section layout type' ),
                'columns' => array( 'type' => 'number', 'description' => 'Number of columns' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_video',
        'description' => 'Add a video widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'video_url' => array( 'type' => 'string', 'description' => 'Video URL (YouTube, Vimeo, etc.)' ),
                'video_type' => array( 'type' => 'string', 'description' => 'Video source type' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_divider',
        'description' => 'Add a divider/separator widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'style' => array( 'type' => 'string', 'description' => 'Divider style (solid, dashed, dotted, etc.)' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_spacer',
        'description' => 'Add a spacer widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'height' => array( 'type' => 'number', 'description' => 'Spacer height in pixels' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_icon',
        'description' => 'Add an icon widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'icon' => array( 'type' => 'string', 'description' => 'Icon name/class' ),
                'alignment' => array( 'type' => 'string', 'description' => 'Icon alignment' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_icon_list',
        'description' => 'Add an icon list widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'items' => array( 'type' => 'array', 'description' => 'List items with icon and text' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_social_icons',
        'description' => 'Add social icons widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'icons' => array( 'type' => 'array', 'description' => 'Social network icons and URLs' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_form',
        'description' => 'Add a form widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'form_id' => array( 'type' => 'string', 'description' => 'Form ID or shortcode' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_map',
        'description' => 'Add a Google Maps widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'address' => array( 'type' => 'string', 'description' => 'Map address or location' ),
                'zoom' => array( 'type' => 'number', 'description' => 'Map zoom level' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_counter',
        'description' => 'Add a counter/number widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'starting_number' => array( 'type' => 'number', 'description' => 'Counter start value' ),
                'ending_number' => array( 'type' => 'number', 'description' => 'Counter end value' ),
                'title' => array( 'type' => 'string', 'description' => 'Counter label' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_progress_bar',
        'description' => 'Add a progress bar widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'title' => array( 'type' => 'string', 'description' => 'Progress bar label' ),
                'percent' => array( 'type' => 'number', 'description' => 'Progress percentage (0-100)' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_testimonial',
        'description' => 'Add a testimonial widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'content' => array( 'type' => 'string', 'description' => 'Testimonial text' ),
                'name' => array( 'type' => 'string', 'description' => 'Author name' ),
                'title' => array( 'type' => 'string', 'description' => 'Author title/role' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_tabs',
        'description' => 'Add a tabs widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'tabs' => array( 'type' => 'array', 'description' => 'Tab items with title and content' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_accordion',
        'description' => 'Add an accordion widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'items' => array( 'type' => 'array', 'description' => 'Accordion items with title and content' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_toggle',
        'description' => 'Add a toggle widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'title' => array( 'type' => 'string', 'description' => 'Toggle title' ),
                'content' => array( 'type' => 'string', 'description' => 'Toggle content' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_alert',
        'description' => 'Add an alert/notice widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'title' => array( 'type' => 'string', 'description' => 'Alert title' ),
                'content' => array( 'type' => 'string', 'description' => 'Alert message' ),
                'alert_type' => array( 'type' => 'string', 'description' => 'Alert type (info, success, warning, danger)' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_html',
        'description' => 'Add a custom HTML widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'html' => array( 'type' => 'string', 'description' => 'Raw HTML content' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_menu',
        'description' => 'Add a navigation menu widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'menu_id' => array( 'type' => 'number', 'description' => 'WordPress menu ID' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_sidebar',
        'description' => 'Add a sidebar widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'sidebar_id' => array( 'type' => 'string', 'description' => 'Registered sidebar ID' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_search',
        'description' => 'Add a search form widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'placeholder' => array( 'type' => 'string', 'description' => 'Search placeholder text' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_gallery',
        'description' => 'Add an image gallery widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'images' => array( 'type' => 'array', 'description' => 'Gallery image IDs or URLs' ),
                'columns' => array( 'type' => 'number', 'description' => 'Number of gallery columns' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_slider',
        'description' => 'Add a slider/carousel widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'slides' => array( 'type' => 'array', 'description' => 'Slide items with image and content' ),
                'autoplay' => array( 'type' => 'boolean', 'description' => 'Enable autoplay' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    ),
    array(
        'tool' => 'wordpress_add_pricing_table',
        'description' => 'Add a pricing table widget to a page.',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_id' => array( 'type' => 'number', 'description' => 'Page/post ID' ),
                'title' => array( 'type' => 'string', 'description' => 'Plan name' ),
                'price' => array( 'type' => 'string', 'description' => 'Price amount' ),
                'features' => array( 'type' => 'array', 'description' => 'List of plan features' )
            ),
            'required' => array( 'post_id' )
        ),
        'read_only' => false,
        'destructive' => false,
        'idempotent' => false
    )
)	;
	}

	/**
	 * Dispatch config for all tools.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function get_dispatch_config() {
		return 
array(
    'wordpress_get_site_context' => array(
        'tool' => 'wordpress_get_site_context',
        'method' => 'GET',
        'path' => '/respira/v1/context/site-info'
    ),
    'wordpress_get_theme_docs' => array(
        'tool' => 'wordpress_get_theme_docs',
        'method' => 'GET',
        'path' => '/respira/v1/context/theme-docs'
    ),
    'wordpress_get_builder_info' => array(
        'tool' => 'wordpress_get_builder_info',
        'method' => 'GET',
        'path' => '/respira/v1/context/builder-info'
    ),
    'wordpress_list_pages' => array(
        'tool' => 'wordpress_list_pages',
        'method' => 'GET',
        'path' => '/respira/v1/pages',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_read_page' => array(
        'tool' => 'wordpress_read_page',
        'method' => 'GET',
        'path' => '/respira/v1/pages/{id}'
    ),
    'wordpress_detect_page_builder' => array(
        'tool' => 'wordpress_detect_page_builder',
        'method' => 'INTERNAL',
        'special' => 'detect_page_builder'
    ),
    'wordpress_create_page_duplicate' => array(
        'tool' => 'wordpress_create_page_duplicate',
        'method' => 'POST',
        'path' => '/respira/v1/pages/{id}/duplicate',
        'arg_map' => array(
            'originalId' => 'id'
        )
    ),
    'wordpress_approve_duplicate' => array(
        'tool' => 'wordpress_approve_duplicate',
        'method' => 'INTERNAL',
        'special' => 'approve_duplicate'
    ),
    'wordpress_reject_duplicate' => array(
        'tool' => 'wordpress_reject_duplicate',
        'method' => 'INTERNAL',
        'special' => 'reject_duplicate'
    ),
	    'wordpress_update_page' => array(
	        'tool' => 'wordpress_update_page',
	        'method' => 'PUT',
	        'path' => '/respira/v1/pages/{id}',
	        'arg_map' => array(
	            'customCss' => 'custom_css',
	            'confirmLiveEdit' => 'confirm_live_edit'
	        ),
	        'fallback_method' => 'POST'
	    ),
	    'wordpress_delete_page' => array(
	        'tool' => 'wordpress_delete_page',
	        'method' => 'DELETE',
	        'path' => '/respira/v1/pages/{id}',
	        'arg_map' => array(
	            'confirmLiveEdit' => 'confirm_live_edit'
	        )
	    ),
    'wordpress_list_posts' => array(
        'tool' => 'wordpress_list_posts',
        'method' => 'GET',
        'path' => '/respira/v1/posts',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_read_post' => array(
        'tool' => 'wordpress_read_post',
        'method' => 'GET',
        'path' => '/respira/v1/posts/{id}'
    ),
    'wordpress_create_post_duplicate' => array(
        'tool' => 'wordpress_create_post_duplicate',
        'method' => 'POST',
        'path' => '/respira/v1/posts/{id}/duplicate',
        'arg_map' => array(
            'originalId' => 'id'
        )
    ),
	    'wordpress_update_post' => array(
	        'tool' => 'wordpress_update_post',
	        'method' => 'PUT',
	        'path' => '/respira/v1/posts/{id}',
	        'arg_map' => array(
	            'customCss' => 'custom_css',
	            'confirmLiveEdit' => 'confirm_live_edit'
	        ),
	        'fallback_method' => 'POST'
	    ),
	    'wordpress_delete_post' => array(
	        'tool' => 'wordpress_delete_post',
	        'method' => 'DELETE',
	        'path' => '/respira/v1/posts/{id}',
	        'arg_map' => array(
	            'confirmLiveEdit' => 'confirm_live_edit'
	        )
	    ),
    'wordpress_list_media' => array(
        'tool' => 'wordpress_list_media',
        'method' => 'GET',
        'path' => '/respira/v1/media',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_upload_media' => array(
        'tool' => 'wordpress_upload_media',
        'method' => 'POST',
        'path' => '/respira/v1/media/upload',
        'special' => 'upload_media'
    ),
    'wordpress_extract_builder_content' => array(
        'tool' => 'wordpress_extract_builder_content',
        'method' => 'GET',
        'path' => '/respira/v1/builder/{builder}/extract/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        ),
        'special' => 'extract_builder_content'
    ),
    'wordpress_inject_builder_content' => array(
        'tool' => 'wordpress_inject_builder_content',
        'method' => 'POST',
        'path' => '/respira/v1/builder/{builder}/inject/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_update_module' => array(
        'tool' => 'wordpress_update_module',
        'method' => 'PUT',
        'path' => '/respira/v1/builder/{builder}/modules/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id',
            'moduleIdentifier' => 'module_identifier'
        )
    ),
    'wordpress_validate_security' => array(
        'tool' => 'wordpress_validate_security',
        'method' => 'POST',
        'path' => '/respira/v1/validate/security'
    ),
    'wordpress_switch_site' => array(
        'tool' => 'wordpress_switch_site',
        'method' => 'INTERNAL',
        'path' => ''
    ),
    'wordpress_analyze_performance' => array(
        'tool' => 'wordpress_analyze_performance',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/performance/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_get_core_web_vitals' => array(
        'tool' => 'wordpress_get_core_web_vitals',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/core-web-vitals/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_analyze_images' => array(
        'tool' => 'wordpress_analyze_images',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/images/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_analyze_seo' => array(
        'tool' => 'wordpress_analyze_seo',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/seo/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_check_seo_issues' => array(
        'tool' => 'wordpress_check_seo_issues',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/seo-issues/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_analyze_readability' => array(
        'tool' => 'wordpress_analyze_readability',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/readability/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_analyze_aeo' => array(
        'tool' => 'wordpress_analyze_aeo',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/aeo/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_check_structured_data' => array(
        'tool' => 'wordpress_check_structured_data',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/structured-data/{page_id}',
        'arg_map' => array(
            'pageId' => 'page_id'
        )
    ),
    'wordpress_list_plugins' => array(
        'tool' => 'wordpress_list_plugins',
        'method' => 'GET',
        'path' => '/respira/v1/plugins'
    ),
    'wordpress_install_plugin' => array(
        'tool' => 'wordpress_install_plugin',
        'method' => 'POST',
        'path' => '/respira/v1/plugins/install',
        'arg_map' => array(
            'slugOrUrl' => 'slug_or_url'
        )
    ),
    'wordpress_activate_plugin' => array(
        'tool' => 'wordpress_activate_plugin',
        'method' => 'POST',
        'path' => '/respira/v1/plugins/{slug}/activate'
    ),
    'wordpress_deactivate_plugin' => array(
        'tool' => 'wordpress_deactivate_plugin',
        'method' => 'POST',
        'path' => '/respira/v1/plugins/{slug}/deactivate'
    ),
    'wordpress_update_plugin' => array(
        'tool' => 'wordpress_update_plugin',
        'method' => 'POST',
        'path' => '/respira/v1/plugins/{slug}/update'
    ),
    'wordpress_delete_plugin' => array(
        'tool' => 'wordpress_delete_plugin',
        'method' => 'DELETE',
        'path' => '/respira/v1/plugins/{slug}'
    ),
    'wordpress_list_users' => array(
        'tool' => 'wordpress_list_users',
        'method' => 'GET',
        'path' => '/respira/v1/users',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_get_user' => array(
        'tool' => 'wordpress_get_user',
        'method' => 'GET',
        'path' => '/respira/v1/users/{id}'
    ),
    'wordpress_create_user' => array(
        'tool' => 'wordpress_create_user',
        'method' => 'POST',
        'path' => '/respira/v1/users'
    ),
    'wordpress_update_user' => array(
        'tool' => 'wordpress_update_user',
        'method' => 'PUT',
        'path' => '/respira/v1/users/{id}'
    ),
    'wordpress_delete_user' => array(
        'tool' => 'wordpress_delete_user',
        'method' => 'DELETE',
        'path' => '/respira/v1/users/{id}'
    ),
    'wordpress_list_comments' => array(
        'tool' => 'wordpress_list_comments',
        'method' => 'GET',
        'path' => '/respira/v1/comments',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_get_comment' => array(
        'tool' => 'wordpress_get_comment',
        'method' => 'GET',
        'path' => '/respira/v1/comments/{id}'
    ),
    'wordpress_create_comment' => array(
        'tool' => 'wordpress_create_comment',
        'method' => 'POST',
        'path' => '/respira/v1/comments'
    ),
    'wordpress_update_comment' => array(
        'tool' => 'wordpress_update_comment',
        'method' => 'PUT',
        'path' => '/respira/v1/comments/{id}'
    ),
    'wordpress_delete_comment' => array(
        'tool' => 'wordpress_delete_comment',
        'method' => 'DELETE',
        'path' => '/respira/v1/comments/{id}'
    ),
    'wordpress_list_taxonomies' => array(
        'tool' => 'wordpress_list_taxonomies',
        'method' => 'GET',
        'path' => '/respira/v1/taxonomies'
    ),
    'wordpress_get_taxonomy' => array(
        'tool' => 'wordpress_get_taxonomy',
        'method' => 'GET',
        'path' => '/respira/v1/taxonomies/{taxonomy}'
    ),
    'wordpress_list_terms' => array(
        'tool' => 'wordpress_list_terms',
        'method' => 'GET',
        'path' => '/respira/v1/taxonomies/{taxonomy}/terms',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_get_term' => array(
        'tool' => 'wordpress_get_term',
        'method' => 'GET',
        'path' => '/respira/v1/taxonomies/{taxonomy}/terms/{id}'
    ),
    'wordpress_create_term' => array(
        'tool' => 'wordpress_create_term',
        'method' => 'POST',
        'path' => '/respira/v1/taxonomies/{taxonomy}/terms'
    ),
    'wordpress_update_term' => array(
        'tool' => 'wordpress_update_term',
        'method' => 'PUT',
        'path' => '/respira/v1/taxonomies/{taxonomy}/terms/{id}'
    ),
    'wordpress_delete_term' => array(
        'tool' => 'wordpress_delete_term',
        'method' => 'DELETE',
        'path' => '/respira/v1/taxonomies/{taxonomy}/terms/{id}'
    ),
    'wordpress_list_post_types' => array(
        'tool' => 'wordpress_list_post_types',
        'method' => 'GET',
        'path' => '/respira/v1/post-types'
    ),
    'wordpress_get_post_type' => array(
        'tool' => 'wordpress_get_post_type',
        'method' => 'GET',
        'path' => '/respira/v1/post-types/{type}'
    ),
    'wordpress_list_custom_posts' => array(
        'tool' => 'wordpress_list_custom_posts',
        'method' => 'GET',
        'path' => '/respira/v1/post-types/{type}/posts',
        'arg_map' => array(
            'perPage' => 'per_page'
        )
    ),
    'wordpress_get_custom_post' => array(
        'tool' => 'wordpress_get_custom_post',
        'method' => 'GET',
        'path' => '/respira/v1/post-types/{type}/posts/{id}'
    ),
    'wordpress_create_custom_post' => array(
        'tool' => 'wordpress_create_custom_post',
        'method' => 'POST',
        'path' => '/respira/v1/post-types/{type}/posts'
    ),
	    'wordpress_update_custom_post' => array(
	        'tool' => 'wordpress_update_custom_post',
	        'method' => 'PUT',
	        'path' => '/respira/v1/post-types/{type}/posts/{id}',
	        'arg_map' => array(
	            'customCss' => 'custom_css',
	            'confirmLiveEdit' => 'confirm_live_edit'
	        )
	    ),
	    'wordpress_delete_custom_post' => array(
	        'tool' => 'wordpress_delete_custom_post',
	        'method' => 'DELETE',
	        'path' => '/respira/v1/post-types/{type}/posts/{id}',
	        'arg_map' => array(
	            'confirmLiveEdit' => 'confirm_live_edit'
	        )
	    ),
    'wordpress_list_options' => array(
        'tool' => 'wordpress_list_options',
        'method' => 'GET',
        'path' => '/respira/v1/options'
    ),
    'wordpress_get_option' => array(
        'tool' => 'wordpress_get_option',
        'method' => 'GET',
        'path' => '/respira/v1/options/{option}'
    ),
    'wordpress_update_option' => array(
        'tool' => 'wordpress_update_option',
        'method' => 'POST',
        'path' => '/respira/v1/options/{option}'
    ),
    'wordpress_delete_option' => array(
        'tool' => 'wordpress_delete_option',
        'method' => 'DELETE',
        'path' => '/respira/v1/options/{option}'
    ),
    'wordpress_get_media' => array(
        'tool' => 'wordpress_get_media',
        'method' => 'GET',
        'path' => '/respira/v1/media/{id}'
    ),
    'wordpress_update_media' => array(
        'tool' => 'wordpress_update_media',
        'method' => 'PUT',
        'path' => '/respira/v1/media/{id}'
    ),
    'wordpress_delete_media' => array(
        'tool' => 'wordpress_delete_media',
        'method' => 'DELETE',
        'path' => '/respira/v1/media/{id}'
    ),
    'wordpress_list_menus' => array(
        'tool' => 'wordpress_list_menus',
        'method' => 'GET',
        'path' => '/respira/v1/menus'
    ),
    'wordpress_get_menu' => array(
        'tool' => 'wordpress_get_menu',
        'method' => 'GET',
        'path' => '/respira/v1/menus/{id}'
    ),
    'wordpress_create_menu' => array(
        'tool' => 'wordpress_create_menu',
        'method' => 'POST',
        'path' => '/respira/v1/menus'
    ),
    'wordpress_update_menu' => array(
        'tool' => 'wordpress_update_menu',
        'method' => 'PUT',
        'path' => '/respira/v1/menus/{id}'
    ),
    'wordpress_delete_menu' => array(
        'tool' => 'wordpress_delete_menu',
        'method' => 'DELETE',
        'path' => '/respira/v1/menus/{id}'
    ),
    'wordpress_list_menu_locations' => array(
        'tool' => 'wordpress_list_menu_locations',
        'method' => 'GET',
        'path' => '/respira/v1/menus/locations'
    ),
    'wordpress_assign_menu_location' => array(
        'tool' => 'wordpress_assign_menu_location',
        'method' => 'PUT',
        'path' => '/respira/v1/menus/locations/{location}'
    ),
    'wordpress_list_menu_items' => array(
        'tool' => 'wordpress_list_menu_items',
        'method' => 'GET',
        'path' => '/respira/v1/menus/{menu_id}/items'
    ),
    'wordpress_create_menu_item' => array(
        'tool' => 'wordpress_create_menu_item',
        'method' => 'POST',
        'path' => '/respira/v1/menus/{menu_id}/items',
        'arg_map' => array(
            'parent' => 'parent_id'
        ),
        'special' => 'normalize_menu_classes'
    ),
    'wordpress_get_menu_item' => array(
        'tool' => 'wordpress_get_menu_item',
        'method' => 'GET',
        'path' => '/respira/v1/menus/items/{item_id}'
    ),
    'wordpress_update_menu_item' => array(
        'tool' => 'wordpress_update_menu_item',
        'method' => 'PUT',
        'path' => '/respira/v1/menus/items/{item_id}',
        'arg_map' => array(
            'parent' => 'parent_id'
        ),
        'special' => 'normalize_menu_classes'
    ),
    'wordpress_delete_menu_item' => array(
        'tool' => 'wordpress_delete_menu_item',
        'method' => 'DELETE',
        'path' => '/respira/v1/menus/items/{item_id}'
    ),
    'woocommerce_list_products' => array(
        'tool' => 'woocommerce_list_products',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/products'
    ),
    'woocommerce_get_product' => array(
        'tool' => 'woocommerce_get_product',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/products/{id}'
    ),
    'woocommerce_create_product' => array(
        'tool' => 'woocommerce_create_product',
        'method' => 'POST',
        'path' => '/respira/v1/woocommerce/products'
    ),
    'woocommerce_update_product' => array(
        'tool' => 'woocommerce_update_product',
        'method' => 'PUT',
        'path' => '/respira/v1/woocommerce/products/{id}'
    ),
    'woocommerce_duplicate_product' => array(
        'tool' => 'woocommerce_duplicate_product',
        'method' => 'POST',
        'path' => '/respira/v1/woocommerce/products/{id}/duplicate'
    ),
    'woocommerce_list_categories' => array(
        'tool' => 'woocommerce_list_categories',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/categories'
    ),
    'woocommerce_get_category' => array(
        'tool' => 'woocommerce_get_category',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/categories/{id}'
    ),
    'woocommerce_create_category' => array(
        'tool' => 'woocommerce_create_category',
        'method' => 'POST',
        'path' => '/respira/v1/woocommerce/categories'
    ),
    'woocommerce_update_category' => array(
        'tool' => 'woocommerce_update_category',
        'method' => 'PUT',
        'path' => '/respira/v1/woocommerce/categories/{id}'
    ),
    'woocommerce_delete_category' => array(
        'tool' => 'woocommerce_delete_category',
        'method' => 'DELETE',
        'path' => '/respira/v1/woocommerce/categories/{id}'
    ),
    'woocommerce_list_tags' => array(
        'tool' => 'woocommerce_list_tags',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/tags'
    ),
    'woocommerce_get_tag' => array(
        'tool' => 'woocommerce_get_tag',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/tags/{id}'
    ),
    'woocommerce_create_tag' => array(
        'tool' => 'woocommerce_create_tag',
        'method' => 'POST',
        'path' => '/respira/v1/woocommerce/tags'
    ),
    'woocommerce_update_tag' => array(
        'tool' => 'woocommerce_update_tag',
        'method' => 'PUT',
        'path' => '/respira/v1/woocommerce/tags/{id}'
    ),
    'woocommerce_delete_tag' => array(
        'tool' => 'woocommerce_delete_tag',
        'method' => 'DELETE',
        'path' => '/respira/v1/woocommerce/tags/{id}'
    ),
    'woocommerce_list_orders' => array(
        'tool' => 'woocommerce_list_orders',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/orders'
    ),
    'woocommerce_get_order' => array(
        'tool' => 'woocommerce_get_order',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/orders/{id}'
    ),
    'woocommerce_update_order_status' => array(
        'tool' => 'woocommerce_update_order_status',
        'method' => 'PUT',
        'path' => '/respira/v1/woocommerce/orders/{id}/status'
    ),
    'woocommerce_get_stock_status' => array(
        'tool' => 'woocommerce_get_stock_status',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/inventory/stock-status'
    ),
    'woocommerce_update_stock' => array(
        'tool' => 'woocommerce_update_stock',
        'method' => 'PUT',
        'path' => '/respira/v1/woocommerce/products/{id}/stock'
    ),
    'woocommerce_sales_report' => array(
        'tool' => 'woocommerce_sales_report',
        'method' => 'GET',
        'path' => '/respira/v1/woocommerce/reports/sales'
    ),
    'wordpress_read_page_v2' => array(
        'tool' => 'wordpress_read_page_v2',
        'method' => 'GET',
        'path' => '/respira/v2/pages/{id}'
    ),
    'wordpress_read_post_v2' => array(
        'tool' => 'wordpress_read_post_v2',
        'method' => 'GET',
        'path' => '/respira/v2/posts/{id}'
    ),
    'wordpress_read_custom_post_v2' => array(
        'tool' => 'wordpress_read_custom_post_v2',
        'method' => 'GET',
        'path' => '/respira/v2/post-types/{type}/posts/{id}'
    ),
    'wordpress_list_snapshots' => array(
        'tool' => 'wordpress_list_snapshots',
        'method' => 'GET',
        'path' => '/respira/v2/snapshots'
    ),
    'wordpress_get_snapshot' => array(
        'tool' => 'wordpress_get_snapshot',
        'method' => 'GET',
        'path' => '/respira/v2/snapshots/{snapshot_uuid}'
    ),
    'wordpress_diff_snapshots' => array(
        'tool' => 'wordpress_diff_snapshots',
        'method' => 'POST',
        'path' => '/respira/v2/snapshots/diff'
    ),
    'wordpress_restore_snapshot' => array(
        'tool' => 'wordpress_restore_snapshot',
        'method' => 'POST',
        'path' => '/respira/v2/snapshots/restore'
    ),
    'wordpress_apply_builder_patch' => array(
        'tool' => 'wordpress_apply_builder_patch',
        'method' => 'POST',
        'path' => '/respira/v2/builder/{builder}/patch/{post_id}',
        'arg_map' => array(
            'postId' => 'post_id'
        )
    ),
    // --- v5.2.0 Elemental: Element Operations ---
    'wordpress_find_element' => array(
        'tool' => 'wordpress_find_element',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/find/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_update_element' => array(
        'tool' => 'wordpress_update_element',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/update/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_move_element' => array(
        'tool' => 'wordpress_move_element',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/move/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_duplicate_element' => array(
        'tool' => 'wordpress_duplicate_element',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/duplicate/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_remove_element' => array(
        'tool' => 'wordpress_remove_element',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/remove/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_batch_update' => array(
        'tool' => 'wordpress_batch_update',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/batch/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_reorder_elements' => array(
        'tool' => 'wordpress_reorder_elements',
        'method' => 'POST',
        'path' => '/respira/v2/builder/elements/reorder/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    // --- v5.2.0 Elemental: Composite Tools ---
    'wordpress_build_page' => array(
        'tool' => 'wordpress_build_page',
        'method' => 'POST',
        'path' => '/respira/v2/builder/build'
    ),
    'wordpress_convert_html_to_builder' => array(
        'tool' => 'wordpress_convert_html_to_builder',
        'method' => 'POST',
        'path' => '/respira/v2/builder/convert'
    ),
    'wordpress_bulk_pages_operation' => array(
        'tool' => 'wordpress_bulk_pages_operation',
        'method' => 'POST',
        'path' => '/respira/v2/builder/bulk'
    ),
    // --- v5.2.0 Elemental: Stock Images ---
    'wordpress_search_stock_images' => array(
        'tool' => 'wordpress_search_stock_images',
        'method' => 'GET',
        'path' => '/respira/v2/stock-images/search'
    ),
    'wordpress_sideload_image' => array(
        'tool' => 'wordpress_sideload_image',
        'method' => 'POST',
        'path' => '/respira/v2/stock-images/sideload'
    ),
    // --- v5.2.0 Elemental: Builder Intelligence ---
    'wordpress_find_builder_targets' => array(
        'tool' => 'wordpress_find_builder_targets',
        'method' => 'INTERNAL',
        'special' => 'find_builder_targets'
    ),
    // --- v5.2.0 Elemental: Analysis ---
    'wordpress_analyze_rankmath' => array(
        'tool' => 'wordpress_analyze_rankmath',
        'method' => 'GET',
        'path' => '/respira/v1/analyze/rankmath/{page_id}',
        'arg_map' => array( 'pageId' => 'page_id' )
    ),
    // --- v5.2.0 Elemental: Server ---
    'wordpress_get_server_compatibility' => array(
        'tool' => 'wordpress_get_server_compatibility',
        'method' => 'GET',
        'path' => '/respira/v2/server/compatibility'
    ),
    // --- v5.2.0 Elemental: Widget Shortcuts ---
    'wordpress_add_heading' => array(
        'tool' => 'wordpress_add_heading',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_heading/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_text' => array(
        'tool' => 'wordpress_add_text',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_text/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_button' => array(
        'tool' => 'wordpress_add_button',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_button/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_image' => array(
        'tool' => 'wordpress_add_image',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_image/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_section' => array(
        'tool' => 'wordpress_add_section',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_section/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_video' => array(
        'tool' => 'wordpress_add_video',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_video/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_divider' => array(
        'tool' => 'wordpress_add_divider',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_divider/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_spacer' => array(
        'tool' => 'wordpress_add_spacer',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_spacer/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_icon' => array(
        'tool' => 'wordpress_add_icon',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_icon/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_icon_list' => array(
        'tool' => 'wordpress_add_icon_list',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_icon_list/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_social_icons' => array(
        'tool' => 'wordpress_add_social_icons',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_social_icons/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_form' => array(
        'tool' => 'wordpress_add_form',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_form/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_map' => array(
        'tool' => 'wordpress_add_map',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_map/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_counter' => array(
        'tool' => 'wordpress_add_counter',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_counter/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_progress_bar' => array(
        'tool' => 'wordpress_add_progress_bar',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_progress_bar/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_testimonial' => array(
        'tool' => 'wordpress_add_testimonial',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_testimonial/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_tabs' => array(
        'tool' => 'wordpress_add_tabs',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_tabs/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_accordion' => array(
        'tool' => 'wordpress_add_accordion',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_accordion/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_toggle' => array(
        'tool' => 'wordpress_add_toggle',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_toggle/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_alert' => array(
        'tool' => 'wordpress_add_alert',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_alert/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_html' => array(
        'tool' => 'wordpress_add_html',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_html/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_menu' => array(
        'tool' => 'wordpress_add_menu',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_menu/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_sidebar' => array(
        'tool' => 'wordpress_add_sidebar',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_sidebar/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_search' => array(
        'tool' => 'wordpress_add_search',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_search/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_gallery' => array(
        'tool' => 'wordpress_add_gallery',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_gallery/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_slider' => array(
        'tool' => 'wordpress_add_slider',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_slider/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    ),
    'wordpress_add_pricing_table' => array(
        'tool' => 'wordpress_add_pricing_table',
        'method' => 'POST',
        'path' => '/respira/v2/builder/widget/add_pricing_table/{post_id}',
        'arg_map' => array( 'post_id' => 'post_id' )
    )
)	;
	}
}
