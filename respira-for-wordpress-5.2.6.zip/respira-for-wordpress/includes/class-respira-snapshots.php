<?php
/**
 * V2 snapshots service.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Handles snapshot persistence, retention, diff and restore.
 */
class Respira_Snapshots {

	/**
	 * Cron hook.
	 */
	const CLEANUP_CRON_HOOK = 'respira_snapshot_cleanup_daily';

	/**
	 * Singleton.
	 *
	 * @var Respira_Snapshots|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return Respira_Snapshots
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'ensure_schema' ) );
		add_action( 'init', array( $this, 'ensure_cleanup_schedule' ) );
		add_action( self::CLEANUP_CRON_HOOK, array( $this, 'cleanup_retention' ) );
	}

	/**
	 * Activate default options.
	 *
	 * @return void
	 */
	public static function activate_defaults() {
		add_option( 'respira_snapshot_retention_days', 90 );
		add_option( 'respira_snapshot_max_per_post', 50 );
		add_option( 'respira_snapshot_max_payload_bytes', 5242880 ); // 5MB.
	}

	/**
	 * Unschedule cleanup cron.
	 *
	 * @return void
	 */
	public static function unschedule_cleanup() {
		wp_clear_scheduled_hook( self::CLEANUP_CRON_HOOK );
	}

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'respira_snapshots';
	}

	/**
	 * Ensure DB schema exists.
	 *
	 * @return void
	 */
	public function ensure_schema() {
		global $wpdb;

		$table_name      = $this->table_name();
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			snapshot_uuid varchar(64) NOT NULL,
			post_id bigint(20) unsigned NOT NULL,
			post_type varchar(64) NOT NULL,
			kind varchar(64) NOT NULL,
			builder varchar(64) DEFAULT NULL,
			created_at_gmt datetime NOT NULL,
			actor_api_key_id bigint(20) unsigned DEFAULT NULL,
			payload_gz_b64 longtext NOT NULL,
			payload_bytes bigint(20) unsigned NOT NULL,
			hashes_json longtext NOT NULL,
			pinned tinyint(1) NOT NULL DEFAULT 0,
			label varchar(255) DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY snapshot_uuid (snapshot_uuid),
			KEY post_created (post_id, created_at_gmt),
			KEY post_type_post (post_type, post_id),
			KEY kind (kind)
		) {$charset_collate};";

		dbDelta( $sql );
		$this->maybe_add_pinned_column();
		$this->maybe_add_label_column();
	}

	/**
	 * Add `pinned` column for existing installs upgrading to 5.0+.
	 *
	 * @since 5.0.0
	 * @return void
	 */
	private function maybe_add_pinned_column() {
		global $wpdb;

		$table_name = $this->table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'pinned'",
				$table_name
			)
		);

		if ( null === $col ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
			$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN pinned tinyint(1) NOT NULL DEFAULT 0" );
		}
	}

	/**
	 * Add label column if missing (upgrade path from pre-5.0.7).
	 */
	private function maybe_add_label_column() {
		global $wpdb;

		$table_name = $this->table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'label'",
				$table_name
			)
		);

		if ( null === $col ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
			$wpdb->query( "ALTER TABLE {$table_name} ADD COLUMN label varchar(255) DEFAULT NULL" );
		}
	}

	/**
	 * Pin or unpin a snapshot.
	 *
	 * @since 5.0.0
	 * @param string $snapshot_uuid Snapshot UUID.
	 * @param bool   $pinned        True to pin, false to unpin.
	 * @return bool True on success.
	 */
	public function set_pinned( $snapshot_uuid, $pinned ) {
		global $wpdb;

		$table_name = $this->table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->update(
			$table_name,
			array( 'pinned' => $pinned ? 1 : 0 ),
			array( 'snapshot_uuid' => $snapshot_uuid ),
			array( '%d' ),
			array( '%s' )
		);

		return false !== $updated;
	}

	/**
	 * Get aggregate storage statistics.
	 *
	 * @since 5.0.0
	 * @return array { total_count: int, total_bytes: int, oldest_date: string|null }
	 */
	public function get_storage_stats() {
		global $wpdb;

		$table_name = $this->table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( "SELECT COUNT(*) AS total_count, COALESCE(SUM(payload_bytes), 0) AS total_bytes, MIN(created_at_gmt) AS oldest_date FROM {$table_name}" );

		return array(
			'total_count' => (int) ( $row->total_count ?? 0 ),
			'total_bytes' => (int) ( $row->total_bytes ?? 0 ),
			'oldest_date' => $row->oldest_date ?? null,
		);
	}

	/**
	 * Purge unpinned snapshots older than a given number of days.
	 *
	 * @since 5.0.0
	 * @param int $age_days Delete snapshots older than this many days.
	 * @return array { deleted_count: int, freed_bytes: int }
	 */
	public function purge_old_snapshots( $age_days = 30 ) {
		global $wpdb;

		$table_name = $this->table_name();
		$cutoff     = gmdate( 'Y-m-d H:i:s', time() - ( absint( $age_days ) * DAY_IN_SECONDS ) );

		// Calculate freed bytes before deleting.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS cnt, COALESCE(SUM(payload_bytes), 0) AS bytes FROM {$table_name} WHERE created_at_gmt < %s AND pinned = 0",
				$cutoff
			)
		);

		$count = (int) ( $stats->cnt ?? 0 );
		$bytes = (int) ( $stats->bytes ?? 0 );

		if ( $count > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table_name} WHERE created_at_gmt < %s AND pinned = 0",
					$cutoff
				)
			);
		}

		return array(
			'deleted_count' => $count,
			'freed_bytes'   => $bytes,
		);
	}

	/**
	 * Delete specific snapshots by UUID.
	 *
	 * @since 5.0.0
	 * @param array $uuids Array of snapshot UUIDs.
	 * @return array { deleted_count: int, freed_bytes: int }
	 */
	public function delete_snapshots( $uuids ) {
		global $wpdb;

		if ( empty( $uuids ) ) {
			return array( 'deleted_count' => 0, 'freed_bytes' => 0 );
		}

		$table_name   = $this->table_name();
		$placeholders = implode( ',', array_fill( 0, count( $uuids ), '%s' ) );

		// Calculate freed bytes before deleting.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS cnt, COALESCE(SUM(payload_bytes), 0) AS bytes FROM {$table_name} WHERE snapshot_uuid IN ({$placeholders})",
				...$uuids
			)
		);

		$count = (int) ( $stats->cnt ?? 0 );
		$bytes = (int) ( $stats->bytes ?? 0 );

		if ( $count > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table_name} WHERE snapshot_uuid IN ({$placeholders})",
					...$uuids
				)
			);
		}

		return array(
			'deleted_count' => $count,
			'freed_bytes'   => $bytes,
		);
	}

	/**
	 * Delete all unpinned snapshots for a specific post.
	 *
	 * @since 5.0.5
	 * @param int $post_id Post ID.
	 * @return array { deleted_count: int, freed_bytes: int }
	 */
	public function delete_post_snapshots( $post_id ) {
		global $wpdb;

		$table_name = $this->table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS cnt, COALESCE(SUM(payload_bytes), 0) AS bytes FROM {$table_name} WHERE post_id = %d AND pinned = 0",
				$post_id
			)
		);

		$count = (int) ( $stats->cnt ?? 0 );
		$bytes = (int) ( $stats->bytes ?? 0 );

		if ( $count > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table_name} WHERE post_id = %d AND pinned = 0",
					$post_id
				)
			);
		}

		return array(
			'deleted_count' => $count,
			'freed_bytes'   => $bytes,
		);
	}

	/**
	 * Ensure daily cleanup schedule.
	 *
	 * @return void
	 */
	public function ensure_cleanup_schedule() {
		if ( ! wp_next_scheduled( self::CLEANUP_CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_CRON_HOOK );
		}
	}

	/**
	 * Capture duplicate baseline snapshots and pointers.
	 *
	 * @param int      $original_id Original post ID.
	 * @param int      $duplicate_id Duplicate post ID.
	 * @param int|null $actor_api_key_id Optional actor API key ID.
	 * @return array
	 */
	public function capture_duplicate_baseline( $original_id, $duplicate_id, $actor_api_key_id = null ) {
		$source_snapshot = $this->capture_snapshot(
			$original_id,
			'base',
			array(
				'actor_api_key_id' => $actor_api_key_id,
			)
		);

		$duplicate_snapshot = $this->capture_snapshot(
			$duplicate_id,
			'base',
			array(
				'actor_api_key_id' => $actor_api_key_id,
				'set_base'         => true,
			)
		);

		if ( ! is_wp_error( $source_snapshot ) && ! empty( $source_snapshot['snapshot_uuid'] ) ) {
			update_post_meta( $duplicate_id, '_respira_snapshot_base_uuid', $source_snapshot['snapshot_uuid'] );
		}

		return array(
			'source'    => $source_snapshot,
			'duplicate' => $duplicate_snapshot,
		);
	}

	/**
	 * Capture and store snapshot.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $kind Snapshot kind.
	 * @param array  $args Optional args.
	 * @return array|WP_Error
	 */
	/**
	 * Dedup window in seconds — consecutive edits within this window
	 * collapse into a single before/after pair.
	 */
	const DEDUP_WINDOW_SECONDS = 120;

	public function capture_snapshot( $post_id, $kind = 'manual', $args = array() ) {
		global $wpdb;

		$this->ensure_schema();

		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error(
				'respira_snapshot_post_not_found',
				__( 'Cannot capture snapshot: post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$table_name = $this->table_name();
		$now_gmt    = gmdate( 'Y-m-d H:i:s' );
		$cutoff     = gmdate( 'Y-m-d H:i:s', time() - self::DEDUP_WINDOW_SECONDS );
		$san_kind   = sanitize_key( $kind );

		// ── Dedup: collapse rapid consecutive edits ──
		// For "before_*" kinds: skip if we already have a before snapshot
		// within the dedup window (the first one already captures pre-edit state).
		if ( in_array( $san_kind, array( 'before_edit', 'before_live_edit' ), true ) ) {
			$existing = $wpdb->get_var( $wpdb->prepare(
				"SELECT snapshot_uuid FROM {$table_name}
				 WHERE post_id = %d AND kind = %s AND created_at_gmt >= %s
				 ORDER BY created_at_gmt DESC LIMIT 1",
				$post_id, $san_kind, $cutoff
			) );
			if ( $existing ) {
				return array(
					'snapshot_uuid'  => $existing,
					'post_id'        => (int) $post_id,
					'kind'           => $san_kind,
					'deduplicated'   => true,
				);
			}
		}

		$builder = Respira_Fidelity::detect_builder_slug( $post_id );
		$builder_contract = Respira_Fidelity::get_builder_contract_data( $post_id, $builder );
		$meta_allowlisted = Respira_Fidelity::get_allowlisted_meta( $post_id );
		$hashes = Respira_Fidelity::compute_hashes( $post_id, $builder );

		$payload = array(
			'post' => array(
				'id'           => $post->ID,
				'post_type'    => $post->post_type,
				'title'        => $post->post_title,
				'slug'         => $post->post_name,
				'status'       => $post->post_status,
				'content'      => $post->post_content,
				'excerpt'      => $post->post_excerpt,
				'modified'     => $post->post_modified,
				'modified_gmt' => $post->post_modified_gmt,
			),
			'builder'         => array(
				'name'      => $builder,
				'payload'   => $builder_contract['payload'],
				'extracted' => $builder_contract['extracted'],
			),
			'meta_allowlisted' => $meta_allowlisted,
		);

		$json = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $json ) {
			return new WP_Error(
				'respira_snapshot_encode_failed',
				__( 'Failed to encode snapshot payload.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		$max_payload_bytes = (int) get_option( 'respira_snapshot_max_payload_bytes', 5242880 );
		$payload_bytes = strlen( $json );
		if ( $payload_bytes > $max_payload_bytes ) {
			return new WP_Error(
				'respira_snapshot_payload_too_large',
				__( 'Snapshot payload exceeds configured maximum size.', 'respira-for-wordpress' ),
				array(
					'status'         => 413,
					'payload_bytes'  => $payload_bytes,
					'max_payload'    => $max_payload_bytes,
				)
			);
		}

		$compressed = function_exists( 'gzencode' ) ? gzencode( $json, 6 ) : $json;
		if ( false === $compressed ) {
			$compressed = $json;
		}
		$payload_gz_b64 = base64_encode( $compressed );

		$actor_key_id = isset( $args['actor_api_key_id'] ) ? absint( $args['actor_api_key_id'] ) : null;
		$label        = isset( $args['label'] ) ? sanitize_text_field( substr( $args['label'], 0, 255 ) ) : null;

		// ── Dedup: for "after_*" kinds, update the most recent one in the window
		// instead of creating a new row — keeps only the final state.
		if ( in_array( $san_kind, array( 'after_edit', 'after_live_edit' ), true ) ) {
			$existing_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table_name}
				 WHERE post_id = %d AND kind = %s AND created_at_gmt >= %s
				 ORDER BY created_at_gmt DESC LIMIT 1",
				$post_id, $san_kind, $cutoff
			) );
			if ( $existing_id ) {
				$update_cols = array(
						'created_at_gmt'   => $now_gmt,
						'payload_gz_b64'   => $payload_gz_b64,
						'payload_bytes'    => $payload_bytes,
						'hashes_json'      => wp_json_encode( $hashes ),
						'actor_api_key_id' => $actor_key_id,
					);
				$update_formats = array( '%s', '%s', '%d', '%s', '%d' );
				if ( $label ) {
					$update_cols['label'] = $label;
					$update_formats[]     = '%s';
				}
				$wpdb->update(
					$table_name,
					$update_cols,
					array( 'id' => $existing_id ),
					$update_formats,
					array( '%d' )
				);
				$snapshot_uuid = $wpdb->get_var( $wpdb->prepare(
					"SELECT snapshot_uuid FROM {$table_name} WHERE id = %d", $existing_id
				) );
				update_post_meta( $post->ID, '_respira_snapshot_current_uuid', $snapshot_uuid );
				update_post_meta( $post->ID, '_respira_snapshot_hashes_current', wp_json_encode( $hashes ) );
				return array(
					'snapshot_uuid'  => $snapshot_uuid,
					'post_id'        => $post->ID,
					'post_type'      => $post->post_type,
					'kind'           => $san_kind,
					'builder'        => $builder,
					'created_at_gmt' => $now_gmt,
					'hashes'         => $hashes,
					'payload_bytes'  => $payload_bytes,
					'deduplicated'   => true,
				);
			}
		}

		$snapshot_uuid = wp_generate_uuid4();

		$inserted = $wpdb->insert(
			$table_name,
			array(
				'snapshot_uuid'     => $snapshot_uuid,
				'post_id'           => $post->ID,
				'post_type'         => $post->post_type,
				'kind'              => $san_kind,
				'builder'           => $builder,
				'created_at_gmt'    => $now_gmt,
				'actor_api_key_id'  => $actor_key_id,
				'payload_gz_b64'    => $payload_gz_b64,
				'payload_bytes'     => $payload_bytes,
				'hashes_json'       => wp_json_encode( $hashes ),
				'label'             => $label,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error(
				'respira_snapshot_insert_failed',
				__( 'Failed to persist snapshot.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		update_post_meta( $post->ID, '_respira_snapshot_current_uuid', $snapshot_uuid );
		update_post_meta( $post->ID, '_respira_snapshot_hashes_current', wp_json_encode( $hashes ) );
		if ( ! empty( $args['set_base'] ) ) {
			update_post_meta( $post->ID, '_respira_snapshot_base_uuid', $snapshot_uuid );
		}

		$this->enforce_retention_for_post( $post->ID );

		return array(
			'snapshot_uuid' => $snapshot_uuid,
			'post_id'       => $post->ID,
			'post_type'     => $post->post_type,
			'kind'          => $san_kind,
			'builder'       => $builder,
			'created_at_gmt' => $now_gmt,
			'hashes'        => $hashes,
			'payload_bytes' => $payload_bytes,
		);
	}

	/**
	 * List snapshots.
	 *
	 * @param array $args Query args.
	 * @return array
	 */
	public function list_snapshots( $args = array() ) {
		global $wpdb;

		$this->ensure_schema();
		$table_name = $this->table_name();

		$limit  = isset( $args['limit'] ) ? max( 1, min( 200, (int) $args['limit'] ) ) : 20;
		$cursor = isset( $args['cursor'] ) ? absint( $args['cursor'] ) : 0;

		$where   = array( '1=1' );
		$params  = array();

		if ( ! empty( $args['post_id'] ) ) {
			$where[]  = 'post_id = %d';
			$params[] = absint( $args['post_id'] );
		}
		if ( ! empty( $args['post_type'] ) ) {
			$where[]  = 'post_type = %s';
			$params[] = sanitize_key( (string) $args['post_type'] );
		}
		if ( ! empty( $args['kind'] ) ) {
			$where[]  = 'kind = %s';
			$params[] = sanitize_key( (string) $args['kind'] );
		}
		if ( $cursor > 0 ) {
			$where[]  = 'id < %d';
			$params[] = $cursor;
		}

		$params[] = $limit + 1;

		$sql = "SELECT id, snapshot_uuid, post_id, post_type, kind, builder, created_at_gmt, actor_api_key_id, payload_bytes, hashes_json, label
			FROM {$table_name}
			WHERE " . implode( ' AND ', $where ) . '
			ORDER BY id DESC
			LIMIT %d';

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$has_more   = count( $rows ) > $limit;
		$items      = array_slice( $rows, 0, $limit );
		$next_cursor = null;

		if ( $has_more && ! empty( $items ) ) {
			$last        = end( $items );
			$next_cursor = (int) $last['id'];
		}

		foreach ( $items as &$item ) {
			$item['id']         = (int) $item['id'];
			$item['post_id']    = (int) $item['post_id'];
			$item['payload_bytes'] = (int) $item['payload_bytes'];
			$item['actor_api_key_id'] = null === $item['actor_api_key_id'] ? null : (int) $item['actor_api_key_id'];
			$item['hashes']     = json_decode( (string) $item['hashes_json'], true );
			unset( $item['hashes_json'] );
		}

		return array(
			'items'       => $items,
			'next_cursor' => $next_cursor,
		);
	}

	/**
	 * Get snapshot by UUID.
	 *
	 * @param string $snapshot_uuid Snapshot UUID.
	 * @param bool   $inflate Include payload.
	 * @return array|WP_Error
	 */
	public function get_snapshot( $snapshot_uuid, $inflate = true ) {
		global $wpdb;

		$this->ensure_schema();

		$table_name = $this->table_name();
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE snapshot_uuid = %s LIMIT 1",
				(string) $snapshot_uuid
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return new WP_Error(
				'respira_snapshot_not_found',
				__( 'Snapshot not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$result = array(
			'id'               => (int) $row['id'],
			'snapshot_uuid'    => $row['snapshot_uuid'],
			'post_id'          => (int) $row['post_id'],
			'post_type'        => $row['post_type'],
			'kind'             => $row['kind'],
			'builder'          => $row['builder'],
			'created_at_gmt'   => $row['created_at_gmt'],
			'actor_api_key_id' => null === $row['actor_api_key_id'] ? null : (int) $row['actor_api_key_id'],
			'payload_bytes'    => (int) $row['payload_bytes'],
			'hashes'           => json_decode( (string) $row['hashes_json'], true ),
		);

		if ( $inflate ) {
			$result['payload'] = $this->decode_payload( $row['payload_gz_b64'] );
		}

		return $result;
	}

	/**
	 * Decode payload.
	 *
	 * @param string $payload_gz_b64 Payload.
	 * @return array
	 */
	private function decode_payload( $payload_gz_b64 ) {
		$decoded = base64_decode( (string) $payload_gz_b64, true );
		if ( false === $decoded ) {
			return array();
		}

		$inflated = function_exists( 'gzdecode' ) ? gzdecode( $decoded ) : $decoded;
		if ( false === $inflated ) {
			$inflated = $decoded;
		}

		$data = json_decode( (string) $inflated, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Diff two snapshots.
	 *
	 * @param string $snapshot_a UUID A.
	 * @param string $snapshot_b UUID B.
	 * @return array|WP_Error
	 */
	public function diff_snapshots( $snapshot_a, $snapshot_b ) {
		$a = $this->get_snapshot( $snapshot_a, false );
		$b = $this->get_snapshot( $snapshot_b, false );

		if ( is_wp_error( $a ) ) {
			return $a;
		}
		if ( is_wp_error( $b ) ) {
			return $b;
		}

		$hash_a = is_array( $a['hashes'] ) ? $a['hashes'] : array();
		$hash_b = is_array( $b['hashes'] ) ? $b['hashes'] : array();

		$keys = array( 'builder_hash', 'rendered_hash', 'allowlisted_meta_hash' );
		$deltas = array();
		foreach ( $keys as $key ) {
			$deltas[ $key ] = array(
				'from'    => isset( $hash_a[ $key ] ) ? $hash_a[ $key ] : null,
				'to'      => isset( $hash_b[ $key ] ) ? $hash_b[ $key ] : null,
				'changed' => ( isset( $hash_a[ $key ] ) ? $hash_a[ $key ] : null ) !== ( isset( $hash_b[ $key ] ) ? $hash_b[ $key ] : null ),
			);
		}

		return array(
			'snapshot_a' => $a,
			'snapshot_b' => $b,
			'deltas'     => $deltas,
			'changed'    => (bool) ( $deltas['builder_hash']['changed'] || $deltas['rendered_hash']['changed'] || $deltas['allowlisted_meta_hash']['changed'] ),
		);
	}

	/**
	 * Restore snapshot content and allowlisted meta.
	 *
	 * @param string $snapshot_uuid Snapshot UUID.
	 * @param array  $args Restore args.
	 * @return array|WP_Error
	 */
	public function restore_snapshot( $snapshot_uuid, $args = array() ) {
		$snapshot = $this->get_snapshot( $snapshot_uuid, true );
		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}

		$post_id = (int) $snapshot['post_id'];
		$post    = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error(
				'respira_snapshot_restore_post_not_found',
				__( 'Cannot restore snapshot because post no longer exists.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$payload = isset( $snapshot['payload'] ) && is_array( $snapshot['payload'] ) ? $snapshot['payload'] : array();
		$post_payload = isset( $payload['post'] ) && is_array( $payload['post'] ) ? $payload['post'] : array();
		$builder_payload = isset( $payload['builder'] ) && is_array( $payload['builder'] ) ? $payload['builder'] : array();

		$before = $this->capture_snapshot(
			$post_id,
			'before_restore',
			array(
				'actor_api_key_id' => isset( $args['actor_api_key_id'] ) ? absint( $args['actor_api_key_id'] ) : null,
				'label'            => 'Before restore from snapshot',
			)
		);
		if ( is_wp_error( $before ) ) {
			return $before;
		}

		$update_data = array(
			'ID'           => $post_id,
			'post_title'   => isset( $post_payload['title'] ) ? $post_payload['title'] : $post->post_title,
			'post_content' => isset( $post_payload['content'] ) ? $post_payload['content'] : $post->post_content,
			'post_excerpt' => isset( $post_payload['excerpt'] ) ? $post_payload['excerpt'] : $post->post_excerpt,
			'post_status'  => isset( $post_payload['status'] ) ? $post_payload['status'] : $post->post_status,
		);

		// wp_update_post() internally calls wp_unslash() on all fields (legacy
		// magic-quotes compat). Pre-slash so backslashes (e.g. Divi 5 \u003c
		// Unicode escapes in post_content) round-trip unchanged.
		$result = wp_update_post( wp_slash( $update_data ), true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Restore builder structure when available.
		if ( ! empty( $builder_payload['name'] ) ) {
			$builder = Respira_Builder_Interface::get_builder( $builder_payload['name'] );
			if ( ! is_wp_error( $builder ) && ! empty( $builder_payload['extracted'] ) && is_array( $builder_payload['extracted'] ) ) {
				// Skip structure validation — snapshot content was valid when captured.
				$builder_result = $builder->inject_content( $post_id, $builder_payload['extracted'], true );
				if ( is_wp_error( $builder_result ) ) {
					return $builder_result;
				}
			}
		}

		$allowlisted = isset( $payload['meta_allowlisted'] ) && is_array( $payload['meta_allowlisted'] ) ? $payload['meta_allowlisted'] : array();
		$all_keys    = Respira_Fidelity::get_allowlisted_meta_keys();

		foreach ( $all_keys as $key ) {
			delete_post_meta( $post_id, $key );
		}
		foreach ( $allowlisted as $key => $values ) {
			foreach ( (array) $values as $value ) {
				add_post_meta( $post_id, sanitize_key( $key ), wp_slash( $value ) );
			}
		}

		$after = $this->capture_snapshot(
			$post_id,
			'after_restore',
			array(
				'actor_api_key_id' => isset( $args['actor_api_key_id'] ) ? absint( $args['actor_api_key_id'] ) : null,
				'label'            => 'Restored from snapshot ' . substr( $snapshot_uuid, 0, 8 ),
			)
		);
		if ( is_wp_error( $after ) ) {
			return $after;
		}

		return array(
			'success'      => true,
			'post_id'      => $post_id,
			'snapshot_uuid' => $snapshot_uuid,
			'before'       => $before,
			'after'        => $after,
		);
	}

	/**
	 * Create a temporary draft for visual snapshot preview.
	 *
	 * Applies the snapshot content, meta, and builder data to a hidden draft
	 * so the user can preview the rendered page in a real browser tab.
	 *
	 * @param string $snapshot_uuid Snapshot UUID.
	 * @return array|WP_Error Preview URL and draft ID.
	 */
	public function create_preview_draft( $snapshot_uuid ) {
		$snapshot = $this->get_snapshot( $snapshot_uuid, true );
		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}

		$post_id      = (int) $snapshot['post_id'];
		$payload      = $snapshot['payload'] ?? array();
		$post_payload = $payload['post'] ?? array();
		$builder_data = $payload['builder'] ?? array();

		$original = get_post( $post_id );
		if ( ! $original ) {
			return new WP_Error( 'respira_preview_no_post', 'Original post not found.', array( 'status' => 404 ) );
		}

		// Reuse or create a hidden preview draft.
		$draft_id = (int) get_post_meta( $post_id, '_respira_preview_draft_id', true );
		$draft    = $draft_id ? get_post( $draft_id ) : null;

		$draft_args = array(
			'post_title'   => ( $post_payload['title'] ?? $original->post_title ) . ' — Preview',
			'post_content' => $post_payload['content'] ?? $original->post_content,
			'post_excerpt' => $post_payload['excerpt'] ?? $original->post_excerpt,
			'post_status'  => 'draft',
			'post_type'    => $original->post_type,
			'post_name'    => '_respira_preview_' . $post_id . '_' . time(),
		);

		if ( $draft ) {
			$draft_args['ID'] = $draft->ID;
			wp_update_post( wp_slash( $draft_args ) );
			$draft_id = $draft->ID;
		} else {
			$draft_id = wp_insert_post( wp_slash( $draft_args ) );
			if ( is_wp_error( $draft_id ) ) {
				return $draft_id;
			}
			update_post_meta( $post_id, '_respira_preview_draft_id', $draft_id );
			// Mark as Respira preview so it's excluded from normal queries.
			update_post_meta( $draft_id, '_respira_preview_draft', '1' );
		}

		// Apply allowlisted meta.
		$allowlisted = $payload['meta_allowlisted'] ?? array();
		$all_keys    = Respira_Fidelity::get_allowlisted_meta_keys();
		foreach ( $all_keys as $key ) {
			delete_post_meta( $draft_id, $key );
		}
		foreach ( $allowlisted as $key => $values ) {
			foreach ( (array) $values as $value ) {
				add_post_meta( $draft_id, sanitize_key( $key ), wp_slash( $value ) );
			}
		}

		// Apply builder data.
		if ( ! empty( $builder_data['name'] ) && ! empty( $builder_data['extracted'] ) ) {
			$builder = Respira_Builder_Interface::get_builder( $builder_data['name'] );
			if ( ! is_wp_error( $builder ) && is_array( $builder_data['extracted'] ) ) {
				$builder->inject_content( $draft_id, $builder_data['extracted'], true );
			}
		}

		$preview_url = get_preview_post_link( $draft_id );
		if ( ! $preview_url ) {
			$preview_url = add_query_arg( 'preview', 'true', get_permalink( $draft_id ) );
		}

		return array(
			'preview_url' => $preview_url,
			'draft_id'    => $draft_id,
		);
	}

	/**
	 * Run immediate cleanup for all posts.
	 * Called on version upgrade to prune excess snapshots.
	 *
	 * @return int Number of snapshots deleted.
	 */
	public function cleanup_all_now() {
		global $wpdb;

		$table_name = $this->table_name();
		$count_before = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );

		$post_ids = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$table_name}" );
		if ( is_array( $post_ids ) ) {
			foreach ( $post_ids as $pid ) {
				$this->enforce_retention_for_post( (int) $pid );
			}
		}

		$count_after = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		return $count_before - $count_after;
	}

	/**
	 * Enforce retention for all posts.
	 *
	 * @return void
	 */
	public function cleanup_retention() {
		global $wpdb;

		$table_name = $this->table_name();
		$post_ids = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$table_name}" );
		if ( ! is_array( $post_ids ) ) {
			return;
		}

		foreach ( $post_ids as $post_id ) {
			$this->enforce_retention_for_post( (int) $post_id );
		}
	}

	/**
	 * Enforce retention for one post.
	 * Keep all snapshots newer than configured days OR latest N snapshots.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function enforce_retention_for_post( $post_id ) {
		global $wpdb;

		$table_name = $this->table_name();
		$days       = max( 1, (int) get_option( 'respira_snapshot_retention_days', 90 ) );
		$max_keep   = max( 1, (int) get_option( 'respira_snapshot_max_per_post', 50 ) );
		$cutoff     = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, created_at_gmt, pinned FROM {$table_name} WHERE post_id = %d ORDER BY created_at_gmt DESC, id DESC",
				$post_id
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return;
		}

		$delete_ids = array();
		foreach ( $rows as $index => $row ) {
			// Never auto-delete pinned snapshots.
			if ( ! empty( $row['pinned'] ) ) {
				continue;
			}

			// Keep if within the most recent $max_keep snapshots AND within retention days.
			// Delete if over the max count OR expired by age.
			$within_count = $index < $max_keep;
			$within_age   = (string) $row['created_at_gmt'] >= $cutoff;

			if ( $within_count && $within_age ) {
				continue;
			}

			$delete_ids[] = (int) $row['id'];
		}

		if ( empty( $delete_ids ) ) {
			return;
		}

		$ids_sql = implode( ',', array_map( 'absint', $delete_ids ) );
		$wpdb->query( "DELETE FROM {$table_name} WHERE id IN ({$ids_sql})" );
	}
}
