<?php
/**
 * Respira Accessibility Scanner
 *
 * Core accessibility scanning, auto-fixing, and prompt queue management.
 * Unlocked by the Respira Accessibility Add-on (€49/month).
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Respira_Accessibility
 *
 * Orchestrates WordPress-native WCAG scanning, auto-fixing, and AI prompt generation.
 * This class is loaded and bootstrapped from the main plugin file when the add-on is active.
 *
 * @since 2.2.0
 */
class Respira_Accessibility {

	/**
	 * WCAG standards tested by axe-core.
	 *
	 * @var string[]
	 */
	const AXE_TAGS = array(
		'wcag2a',
		'wcag2aa',
		'wcag21a',
		'wcag21aa',
		'wcag22a',
		'wcag22aa',
		'section508',
	);

	/**
	 * Violation types that can be auto-fixed without AI.
	 * Key = axe-core rule ID, value = fixer method name.
	 *
	 * @var string[]
	 */
	const AUTO_FIXABLE_RULES = array(
		'image-alt'       => 'fix_image_alt',
		'color-contrast'  => 'fix_color_contrast',
		'label'           => 'fix_form_label',
		'heading-order'   => 'fix_heading_order',
		'document-title'  => 'fix_document_title',
		'html-lang-valid' => 'fix_html_lang',
	);

	/**
	 * Option key for storing scan results.
	 */
	const OPTION_SCANS  = 'respira_accessibility_recent_scans';
	const OPTION_QUEUE  = 'respira_accessibility_prompt_queue';
	const OPTION_SCORE  = 'respira_accessibility_last_score';
	const OPTION_ISSUES = 'respira_accessibility_total_issues';
	const OPTION_AUTO   = 'respira_accessibility_autofixable';
	const OPTION_LAST   = 'respira_accessibility_last_scan';

	/**
	 * Initialise hooks.
	 *
	 * @since 2.2.0
	 */
	public function init() {
		// Signal to the admin view that the add-on is active.
		add_filter( 'respira_accessibility_addon_active', '__return_true' );

		// REST API.
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

		// Scheduled scans (weekly).
		add_action( 'respira_accessibility_weekly_scan', array( $this, 'run_scheduled_scan' ) );
		if ( ! wp_next_scheduled( 'respira_accessibility_weekly_scan' ) ) {
			wp_schedule_event( time(), 'weekly', 'respira_accessibility_weekly_scan' );
		}

		// Admin AJAX handlers.
		add_action( 'wp_ajax_respira_run_accessibility_scan', array( $this, 'ajax_run_scan' ) );
		add_action( 'wp_ajax_respira_apply_auto_fixes',       array( $this, 'ajax_apply_fixes' ) );
	}

	/* ════════════════════════════════════════════════════════════
	   REST API ROUTES (registered separately in class-respira-accessibility-rest.php)
	   ════════════════════════════════════════════════════════════ */

	/**
	 * Register REST routes.
	 *
	 * @since 2.2.0
	 */
	public function register_rest_routes() {
		$namespace = 'respira/v1';

		// GET/POST /wp-json/respira/v1/accessibility/scans
		register_rest_route(
			$namespace,
			'/accessibility/scans',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'rest_list_scans' ),
					'permission_callback' => array( $this, 'rest_permission_check' ),
					'args'                => array(
						'page'  => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
						'limit' => array( 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'rest_create_scan' ),
					'permission_callback' => array( $this, 'rest_permission_check' ),
				),
			)
		);

		// GET /wp-json/respira/v1/accessibility/scans/{id}
		register_rest_route(
			$namespace,
			'/accessibility/scans/(?P<id>[\w-]+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_scan' ),
				'permission_callback' => array( $this, 'rest_permission_check' ),
				'args'                => array(
					'id' => array( 'type' => 'string', 'required' => true ),
				),
			)
		);

		// POST /wp-json/respira/v1/accessibility/scan-page
		register_rest_route(
			$namespace,
			'/accessibility/scan-page',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_scan_page' ),
				'permission_callback' => array( $this, 'rest_permission_check' ),
				'args'                => array(
					'url'   => array( 'type' => 'string', 'required' => true, 'format' => 'uri' ),
					'level' => array( 'type' => 'string', 'default' => 'AA', 'enum' => array( 'A', 'AA', 'AAA' ) ),
				),
			)
		);

		// POST /wp-json/respira/v1/accessibility/apply-fixes
		register_rest_route(
			$namespace,
			'/accessibility/apply-fixes',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_apply_fixes' ),
				'permission_callback' => array( $this, 'rest_permission_check' ),
				'args'                => array(
					'scan_id'    => array( 'type' => 'string', 'required' => true ),
					'fix_types'  => array( 'type' => 'array',  'default'  => array() ),
					'dry_run'    => array( 'type' => 'boolean', 'default'  => false ),
				),
			)
		);

		// GET /wp-json/respira/v1/accessibility/prompts
		register_rest_route(
			$namespace,
			'/accessibility/prompts',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_list_prompts' ),
				'permission_callback' => array( $this, 'rest_permission_check' ),
			)
		);
	}

	/**
	 * REST permission check – requires valid Respira API key or administrator cap.
	 *
	 * @param WP_REST_Request $request Incoming request.
	 * @return bool|WP_Error
	 */
	public function rest_permission_check( WP_REST_Request $request ) {
		// Allow administrators via cookie auth.
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		// Allow via Respira API key (same mechanism as the core plugin).
		$api_key = $request->get_header( 'X-Respira-Key' );
		if ( ! empty( $api_key ) ) {
			$stored_key = get_option( 'respira_api_key', '' );
			if ( $stored_key && hash_equals( $stored_key, $api_key ) ) {
				return true;
			}
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'Insufficient permissions. Provide a valid Respira API key.', 'respira-for-wordpress' ),
			array( 'status' => 403 )
		);
	}

	/* ════════════════════════════════════════════════════════════
	   REST CALLBACKS
	   ════════════════════════════════════════════════════════════ */

	/**
	 * List stored scans.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function rest_list_scans( WP_REST_Request $request ) {
		$scans = get_option( self::OPTION_SCANS, array() );
		$page  = (int) $request->get_param( 'page' );
		$limit = (int) $request->get_param( 'limit' );
		$total = count( $scans );
		$items = array_slice( array_reverse( $scans ), ( $page - 1 ) * $limit, $limit );

		return rest_ensure_response( array(
			'scans'      => $items,
			'total'      => $total,
			'page'       => $page,
			'limit'      => $limit,
			'totalPages' => (int) ceil( $total / $limit ),
		) );
	}

	/**
	 * Store a scan result (posted by the Chrome extension or Cursor/Claude).
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_create_scan( WP_REST_Request $request ) {
		$url        = esc_url_raw( $request->get_param( 'url' ) );
		$violations = $request->get_param( 'violations' );
		$prompts    = $request->get_param( 'prompts' );
		$axe_ver    = sanitize_text_field( $request->get_param( 'axeVersion' ) ?? '' );
		$ts         = (int) $request->get_param( 'timestamp' );
		$page_context_raw = $request->get_param( 'pageContext' );
		if ( empty( $page_context_raw ) ) {
			$page_context_raw = $request->get_param( 'page_context' );
		}
		$page_context = $this->sanitize_page_context( $page_context_raw );
		$scan_source  = sanitize_text_field( (string) ( $request->get_param( 'scanSource' ) ?? $request->get_param( 'scan_source' ) ?? '' ) );
		$post_id      = absint( $request->get_param( 'postId' ) ?? $request->get_param( 'post_id' ) ?? 0 );
		$title        = sanitize_text_field( $request->get_param( 'title' ) ?? '' );

		if ( ! $url ) {
			return new WP_Error( 'missing_url', __( 'URL is required.', 'respira-for-wordpress' ), array( 'status' => 400 ) );
		}

		$violations     = is_array( $violations ) ? $violations : array();
		if ( empty( $page_context ) ) {
			$page_context = $this->detect_page_context( $url, $post_id );
		}
		$prompts = $this->ensure_builder_aware_prompts(
			is_array( $prompts ) ? $prompts : array(),
			$violations,
			$url,
			$page_context,
			$post_id,
			$title
		);

		$counts         = $this->count_violations( $violations );
		$total          = array_sum( $counts );
		$score          = max( 0, round( 100 - $total * 2.5 ) );
		$auto_fixable   = count( array_filter( $violations, fn( $v ) => isset( self::AUTO_FIXABLE_RULES[ $v['id'] ?? '' ] ) ) );

		$scan_id = wp_generate_uuid4();
		$scan    = array(
			'id'             => $scan_id,
			'url'            => $url,
			'title'          => $title,
			'violations'     => array_slice( $violations, 0, 500 ),
			'prompts'        => is_array( $prompts ) ? array_slice( $prompts, 0, 100 ) : array(),
			'score'          => $score,
			'violation_count'=> $total,
			'critical_count' => $counts['critical'],
			'serious_count'  => $counts['serious'],
			'moderate_count' => $counts['moderate'],
			'minor_count'    => $counts['minor'],
			'auto_fixable'   => $auto_fixable,
			'axe_version'    => $axe_ver,
			'scanned_at'     => $ts ? gmdate( 'c', $ts / 1000 ) : gmdate( 'c' ),
		);

		if ( ! empty( $page_context ) ) {
			$scan['page_context'] = $page_context;
		}
		if ( ! empty( $scan_source ) ) {
			$scan['scan_source'] = $scan_source;
		}
		if ( $post_id > 0 ) {
			$scan['post_id'] = $post_id;
		}

		// Persist (keep last 100 scans).
		$scans   = get_option( self::OPTION_SCANS, array() );
		$scans[] = $scan;
		$scans   = array_slice( $scans, -100 );
		update_option( self::OPTION_SCANS,  $scans, false );
		update_option( self::OPTION_SCORE,  $score );
		update_option( self::OPTION_ISSUES, $total );
		update_option( self::OPTION_AUTO,   $auto_fixable );
		update_option( self::OPTION_LAST,   gmdate( 'c' ) );

		// Detect AI-prompt queue length.
		$queue = count( is_array( $prompts ) ? $prompts : array() );
		update_option( self::OPTION_QUEUE, $queue );

		return rest_ensure_response( array(
			'scanId' => $scan_id,
			'score'  => $score,
		) );
	}

	/**
	 * Get a single scan by ID.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get_scan( WP_REST_Request $request ) {
		$id    = sanitize_text_field( $request->get_param( 'id' ) );
		$scans = get_option( self::OPTION_SCANS, array() );

		foreach ( $scans as $scan ) {
			if ( isset( $scan['id'] ) && $scan['id'] === $id ) {
				return rest_ensure_response( $scan );
			}
		}

		return new WP_Error( 'not_found', __( 'Scan not found.', 'respira-for-wordpress' ), array( 'status' => 404 ) );
	}

	/**
	 * Trigger a server-side scan of a URL via WordPress HTTP API + axe-core.
	 *
	 * In practice this fires a headless request and parses the response,
	 * or delegates to a Puppeteer/Playwright lambda if configured.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_scan_page( WP_REST_Request $request ) {
		$url   = esc_url_raw( $request->get_param( 'url' ) );
		$level = sanitize_text_field( $request->get_param( 'level' ) );
		$post_id = url_to_postid( $url );

		if ( ! $url ) {
			return new WP_Error( 'missing_url', __( 'URL is required.', 'respira-for-wordpress' ), array( 'status' => 400 ) );
		}

		$scan_mode = strtolower(
			(string) apply_filters(
				'respira_accessibility_scan_mode',
				get_option( 'respira_accessibility_scan_mode', 'local_only' ),
				$url,
				$post_id
			)
		);

		$valid_modes = array( 'cloud_only', 'local_only', 'cloud_with_local_fallback', 'hybrid' );
		if ( ! in_array( $scan_mode, $valid_modes, true ) ) {
			$scan_mode = 'local_only';
		}

		$cloud_result = null;
		$cloud_error  = null;
		$local_result = null;
		$local_error  = null;

		$should_try_cloud = in_array( $scan_mode, array( 'cloud_only', 'cloud_with_local_fallback', 'hybrid' ), true );
		if ( $should_try_cloud ) {
			$cloud_raw = $this->run_cloud_scan( $url, $level );
			if ( is_wp_error( $cloud_raw ) ) {
				$cloud_error = $cloud_raw;
			} else {
				$cloud_result = $this->enrich_scan_result( $cloud_raw, $url, $post_id, 'cloud' );
			}
		}

		$should_try_local = in_array( $scan_mode, array( 'local_only', 'cloud_with_local_fallback', 'hybrid' ), true );
		if ( 'cloud_with_local_fallback' === $scan_mode && ! empty( $cloud_result ) ) {
			$should_try_local = false;
		}

		if ( $should_try_local ) {
			$local_raw = $this->run_local_scan( $url, $level, $post_id );
			if ( is_wp_error( $local_raw ) ) {
				$local_error = $local_raw;
			} else {
				$local_result = $this->enrich_scan_result( $local_raw, $url, $post_id, 'plugin_local' );
			}
		}

		if ( ! empty( $cloud_result ) && ! empty( $local_result ) ) {
			$merged = $this->merge_scan_results( $cloud_result, $local_result, 'hybrid' );
			return rest_ensure_response( $merged );
		}

		if ( ! empty( $cloud_result ) ) {
			return rest_ensure_response( $cloud_result );
		}

		if ( ! empty( $local_result ) ) {
			return rest_ensure_response( $local_result );
		}

		if ( is_wp_error( $local_error ) && ! $should_try_cloud ) {
			return $local_error;
		}

		if ( is_wp_error( $cloud_error ) && ! $should_try_local ) {
			return $cloud_error;
		}

		$messages = array();
		if ( is_wp_error( $cloud_error ) ) {
			$messages[] = $cloud_error->get_error_message();
		}
		if ( is_wp_error( $local_error ) ) {
			$messages[] = $local_error->get_error_message();
		}

		return new WP_Error(
			'scanner_unavailable',
			! empty( $messages ) ? implode( ' ', $messages ) : __( 'Scanner unavailable.', 'respira-for-wordpress' ),
			array( 'status' => 502 )
		);
	}

	/**
	 * Apply auto-fixes for a given scan.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_apply_fixes( WP_REST_Request $request ) {
		$scan_id   = sanitize_text_field( $request->get_param( 'scan_id' ) );
		$fix_types = array_map( 'sanitize_text_field', (array) $request->get_param( 'fix_types' ) );
		$dry_run   = (bool) $request->get_param( 'dry_run' );

		// Look up the scan.
		$scans = get_option( self::OPTION_SCANS, array() );
		$scan  = null;
		foreach ( $scans as $s ) {
			if ( isset( $s['id'] ) && $s['id'] === $scan_id ) {
				$scan = $s;
				break;
			}
		}

		if ( ! $scan ) {
			return new WP_Error( 'not_found', __( 'Scan not found.', 'respira-for-wordpress' ), array( 'status' => 404 ) );
		}

		$violations  = $scan['violations'] ?? array();
		$fixed       = array();
		$skipped     = array();
		$failed      = array();

		foreach ( $violations as $violation ) {
			$rule_id = $violation['id'] ?? '';
			if ( ! isset( self::AUTO_FIXABLE_RULES[ $rule_id ] ) ) {
				$skipped[] = $rule_id;
				continue;
			}
			if ( ! empty( $fix_types ) && ! in_array( $rule_id, $fix_types, true ) ) {
				$skipped[] = $rule_id;
				continue;
			}

			$fixer_method = self::AUTO_FIXABLE_RULES[ $rule_id ];
			if ( method_exists( $this, $fixer_method ) ) {
				$result = $dry_run ? array( 'dry_run' => true ) : $this->$fixer_method( $violation );
				if ( is_wp_error( $result ) ) {
					$failed[] = array( 'rule' => $rule_id, 'error' => $result->get_error_message() );
				} else {
					$fixed[] = array( 'rule' => $rule_id, 'result' => $result );
				}
			}
		}

		return rest_ensure_response( array(
			'scan_id' => $scan_id,
			'dry_run' => $dry_run,
			'fixed'   => $fixed,
			'skipped' => $skipped,
			'failed'  => $failed,
			'summary' => array(
				'fixed'   => count( $fixed ),
				'skipped' => count( $skipped ),
				'failed'  => count( $failed ),
			),
		) );
	}

	/**
	 * List AI fix prompts from the queue.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function rest_list_prompts( WP_REST_Request $request ) {
		$scans   = get_option( self::OPTION_SCANS, array() );
		$prompts = array();

		foreach ( $scans as $scan ) {
			if ( ! empty( $scan['prompts'] ) ) {
				foreach ( $scan['prompts'] as $prompt ) {
					$prompts[] = array_merge( $prompt, array( 'scan_id' => $scan['id'] ?? '' ) );
				}
			}
		}

		return rest_ensure_response( array(
			'prompts' => $prompts,
			'total'   => count( $prompts ),
		) );
	}

	/* ════════════════════════════════════════════════════════════
	   SCANNERS & RESULT ENRICHMENT
	   ════════════════════════════════════════════════════════════ */

	/**
	 * Run cloud scanner endpoint.
	 *
	 * @param string $url   URL to scan.
	 * @param string $level WCAG level.
	 * @return array|WP_Error
	 */
	protected function run_cloud_scan( $url, $level ) {
		$default_endpoint = 'https://respira.press/api/accessibility/scan-page';
		$scanner_endpoint = get_option( 'respira_cloud_scanner_endpoint', $default_endpoint );
		if ( empty( $scanner_endpoint ) ) {
			$scanner_endpoint = $default_endpoint;
		}

		$response = wp_remote_post(
			$scanner_endpoint,
			array(
				'body'    => wp_json_encode( array( 'url' => $url, 'level' => $level ) ),
				'headers' => array( 'Content-Type' => 'application/json' ),
				'timeout' => 60,
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'scanner_error', $response->get_error_message(), array( 'status' => 502 ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 400 ) {
			$msg = is_array( $body ) && ! empty( $body['error'] ) ? $body['error'] : __( 'Cloud scanner unavailable. Plugin-local scanner remains available.', 'respira-for-wordpress' );
			return new WP_Error( 'scanner_not_configured', $msg, array( 'status' => 501 ) );
		}

		return is_array( $body ) ? $body : array();
	}

	/**
	 * Run a plugin-local DOM scan.
	 *
	 * Local scan covers high-confidence rules and complements cloud scans with
	 * WordPress-aware builder context.
	 *
	 * @param string $url     URL to scan.
	 * @param string $level   WCAG level.
	 * @param int    $post_id Optional post ID.
	 * @return array|WP_Error
	 */
	protected function run_local_scan( $url, $level = 'AA', $post_id = 0 ) {
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 45,
				'redirection' => 5,
				'headers'     => array(
					'Accept' => 'text/html,application/xhtml+xml',
				),
				'user-agent'  => 'RespiraAccessibilityScanner/1.0; ' . home_url( '/' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'local_scanner_fetch_failed',
				sprintf(
					/* translators: %s: HTTP error message */
					__( 'Local scanner could not fetch the page: %s', 'respira-for-wordpress' ),
					$response->get_error_message()
				),
				array( 'status' => 502 )
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( $status < 200 || $status >= 400 ) {
			return new WP_Error(
				'local_scanner_http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Local scanner received HTTP %d from the target page.', 'respira-for-wordpress' ),
					$status
				),
				array( 'status' => 502 )
			);
		}

		$html = (string) wp_remote_retrieve_body( $response );
		if ( '' === trim( $html ) ) {
			return new WP_Error(
				'local_scanner_empty_html',
				__( 'Local scanner received an empty HTML response.', 'respira-for-wordpress' ),
				array( 'status' => 502 )
			);
		}

		$dom = $this->parse_html_document( $html );
		if ( is_wp_error( $dom ) ) {
			return $dom;
		}

		$xpath = new DOMXPath( $dom );
		$violations = array();

		$image_alt_violation = $this->detect_image_alt_violations( $xpath );
		if ( ! empty( $image_alt_violation ) ) {
			$violations[] = $image_alt_violation;
		}

		$link_name_violation = $this->detect_empty_link_violations( $xpath );
		if ( ! empty( $link_name_violation ) ) {
			$violations[] = $link_name_violation;
		}

		$form_label_violation = $this->detect_form_label_violations( $xpath );
		if ( ! empty( $form_label_violation ) ) {
			$violations[] = $form_label_violation;
		}

		$heading_violation = $this->detect_heading_order_violations( $xpath );
		if ( ! empty( $heading_violation ) ) {
			$violations[] = $heading_violation;
		}

		$title_violation = $this->detect_document_title_violation( $xpath );
		if ( ! empty( $title_violation ) ) {
			$violations[] = $title_violation;
		}

		$lang_violation = $this->detect_html_lang_violation( $dom );
		if ( ! empty( $lang_violation ) ) {
			$violations[] = $lang_violation;
		}

		$title_nodes = $xpath->query( '/html/head/title' );
		$title = '';
		if ( $title_nodes instanceof DOMNodeList && $title_nodes->length > 0 ) {
			$title = trim( (string) $title_nodes->item( 0 )->textContent );
		}

		return array(
			'violations' => $this->dedupe_violations( $violations ),
			'passes'     => array(),
			'incomplete' => array(),
			'prompts'    => array(),
			'url'        => $url,
			'title'      => $title,
			'axeVersion' => 'respira-local-1.0',
			'timestamp'  => time() * 1000,
			'scanLevel'  => sanitize_text_field( $level ),
			'postId'     => absint( $post_id ),
		);
	}

	/**
	 * Merge cloud and local scan payloads.
	 *
	 * @param array  $primary Primary payload.
	 * @param array  $secondary Secondary payload.
	 * @param string $source Source label.
	 * @return array
	 */
	protected function merge_scan_results( $primary, $secondary, $source = 'hybrid' ) {
		$merged = is_array( $primary ) ? $primary : array();
		$secondary = is_array( $secondary ) ? $secondary : array();

		$merged['violations'] = $this->dedupe_violations(
			array_merge(
				(array) ( $merged['violations'] ?? array() ),
				(array) ( $secondary['violations'] ?? array() )
			)
		);

		$merged_passes = array_merge(
			(array) ( $merged['passes'] ?? array() ),
			(array) ( $secondary['passes'] ?? array() )
		);
		$merged['passes'] = array_values( array_unique( array_map( 'wp_json_encode', $merged_passes ) ) );
		$merged['passes'] = array_map(
			function( $encoded ) {
				$decoded = json_decode( $encoded, true );
				return is_array( $decoded ) ? $decoded : array();
			},
			$merged['passes']
		);

		$merged_incomplete = array_merge(
			(array) ( $merged['incomplete'] ?? array() ),
			(array) ( $secondary['incomplete'] ?? array() )
		);
		$merged['incomplete'] = array_values( array_unique( array_map( 'wp_json_encode', $merged_incomplete ) ) );
		$merged['incomplete'] = array_map(
			function( $encoded ) {
				$decoded = json_decode( $encoded, true );
				return is_array( $decoded ) ? $decoded : array();
			},
			$merged['incomplete']
		);

		$merged_prompts = array_merge(
			(array) ( $merged['prompts'] ?? array() ),
			(array) ( $secondary['prompts'] ?? array() )
		);
		$merged['prompts'] = array_values( array_unique( array_map( 'wp_json_encode', $merged_prompts ) ) );
		$merged['prompts'] = array_map(
			function( $encoded ) {
				$decoded = json_decode( $encoded, true );
				return is_array( $decoded ) ? $decoded : array();
			},
			$merged['prompts']
		);

		$primary_context = $this->sanitize_page_context( $merged['pageContext'] ?? $merged['page_context'] ?? null );
		$secondary_context = $this->sanitize_page_context( $secondary['pageContext'] ?? $secondary['page_context'] ?? null );
		if ( empty( $primary_context ) && ! empty( $secondary_context ) ) {
			$primary_context = $secondary_context;
		} elseif ( ! empty( $secondary_context ) ) {
			$primary_builder = (string) ( $primary_context['builder'] ?? '' );
			$secondary_builder = (string) ( $secondary_context['builder'] ?? '' );
			$primary_specific = ! in_array( $primary_builder, array( '', 'generic', 'wordpress' ), true );
			$secondary_specific = ! in_array( $secondary_builder, array( '', 'generic', 'wordpress' ), true );
			if ( ! $primary_specific && $secondary_specific ) {
				$primary_context = $secondary_context;
			}
		}

		if ( ! empty( $primary_context ) ) {
			$merged['pageContext']  = $primary_context;
			$merged['page_context'] = $primary_context;
		}

		$merged['scanSource']  = sanitize_text_field( $source );
		$merged['scan_source'] = sanitize_text_field( $source );
		$merged['timestamp']   = max(
			(int) ( $merged['timestamp'] ?? 0 ),
			(int) ( $secondary['timestamp'] ?? 0 )
		);

		return $merged;
	}

	/**
	 * Enrich scan payload with WordPress builder context and metadata.
	 *
	 * @param array  $scan   Scan payload.
	 * @param string $url    URL scanned.
	 * @param int    $post_id Optional post ID.
	 * @param string $source Source label.
	 * @return array
	 */
	protected function enrich_scan_result( $scan, $url, $post_id = 0, $source = 'cloud' ) {
		$result = is_array( $scan ) ? $scan : array();

		$result['url']        = esc_url_raw( $result['url'] ?? $url );
		$result['title']      = sanitize_text_field( (string) ( $result['title'] ?? '' ) );
		$result['timestamp']  = (int) ( $result['timestamp'] ?? ( time() * 1000 ) );
		$result['axeVersion'] = sanitize_text_field( (string) ( $result['axeVersion'] ?? 'unknown' ) );
		$result['violations'] = is_array( $result['violations'] ?? null ) ? $result['violations'] : array();
		$result['passes']     = is_array( $result['passes'] ?? null ) ? $result['passes'] : array();
		$result['incomplete'] = is_array( $result['incomplete'] ?? null ) ? $result['incomplete'] : array();
		$result['prompts']    = is_array( $result['prompts'] ?? null ) ? $result['prompts'] : array();

		$page_context = $this->sanitize_page_context( $result['pageContext'] ?? $result['page_context'] ?? null );
		if ( empty( $page_context ) ) {
			$page_context = $this->detect_page_context( $result['url'], $post_id );
		}

		if ( ! empty( $page_context ) ) {
			$result['pageContext']  = $page_context;
			$result['page_context'] = $page_context;
		}

		$post_id = absint( $post_id ?: ( $page_context['postId'] ?? 0 ) );
		if ( $post_id > 0 ) {
			$result['postId']  = $post_id;
			$result['post_id'] = $post_id;
		}

		$result['violations'] = $this->annotate_violations_with_builder_context(
			$this->dedupe_violations( $result['violations'] ),
			$page_context
		);
		$result['prompts'] = $this->ensure_builder_aware_prompts(
			$result['prompts'],
			$result['violations'],
			$result['url'],
			$page_context,
			$post_id,
			$result['title']
		);

		$source = sanitize_text_field( $source );
		$result['scanSource']  = $source;
		$result['scan_source'] = $source;

		return $result;
	}

	/**
	 * Sanitize page-context payload.
	 *
	 * @param mixed $raw Context payload.
	 * @return array|null
	 */
	protected function sanitize_page_context( $raw ) {
		if ( ! is_array( $raw ) ) {
			return null;
		}

		$cms = 'wordpress';
		if ( isset( $raw['cms'] ) && 'generic' === strtolower( (string) $raw['cms'] ) ) {
			$cms = 'generic';
		}

		$builder = $this->normalize_builder_slug( (string) ( $raw['builder'] ?? '' ) );
		if ( '' === $builder ) {
			$builder = 'wordpress' === $cms ? 'wordpress' : 'generic';
		}

		$known_builders = array(
			'elementor',
			'divi',
			'gutenberg',
			'bricks',
			'oxygen',
			'wpbakery',
			'beaver',
			'brizy',
			'visualcomposer',
			'thrivearchitect',
			'breakdance',
			'wordpress',
			'generic',
		);
		if ( ! in_array( $builder, $known_builders, true ) ) {
			$builder = 'wordpress' === $cms ? 'wordpress' : 'generic';
		}

		$builders = array();
		if ( isset( $raw['builders'] ) && is_array( $raw['builders'] ) ) {
			foreach ( $raw['builders'] as $candidate ) {
				$slug = $this->normalize_builder_slug( (string) $candidate );
				if ( '' === $slug || ! in_array( $slug, $known_builders, true ) ) {
					continue;
				}
				if ( ! in_array( $slug, $builders, true ) ) {
					$builders[] = $slug;
				}
			}
		}

		if ( ! in_array( $builder, array( 'wordpress', 'generic' ), true ) && ! in_array( $builder, $builders, true ) ) {
			$builders[] = $builder;
		}

		$context = array(
			'cms'     => $cms,
			'builder' => $builder,
			'builders' => $builders,
		);

		$post_id = absint( $raw['postId'] ?? $raw['post_id'] ?? 0 );
		if ( $post_id > 0 ) {
			$context['postId'] = $post_id;
		}

		if ( ! empty( $raw['theme'] ) ) {
			$context['theme'] = sanitize_text_field( (string) $raw['theme'] );
		}

		if ( ! empty( $raw['builderVersion'] ) ) {
			$context['builderVersion'] = sanitize_text_field( (string) $raw['builderVersion'] );
		}

		return $context;
	}

	/**
	 * Detect WordPress page context for a URL.
	 *
	 * @param string $url URL.
	 * @param int    $post_id Optional post ID.
	 * @return array
	 */
	protected function detect_page_context( $url, $post_id = 0 ) {
		$post_id = absint( $post_id );
		if ( 0 === $post_id && function_exists( 'url_to_postid' ) ) {
			$post_id = absint( url_to_postid( $url ) );
		}

		$context = array(
			'cms'      => 'wordpress',
			'builder'  => 'wordpress',
			'builders' => array(),
		);

		if ( function_exists( 'wp_get_theme' ) ) {
			$context['theme'] = wp_get_theme()->get( 'Name' );
		}

		if ( $post_id > 0 ) {
			$context['postId'] = $post_id;
		}

		if ( class_exists( 'Respira_Builder_Interface' ) ) {
			$builder_instance = Respira_Builder_Interface::detect_builder( $post_id > 0 ? $post_id : null );
			if ( $builder_instance ) {
				$context['builder'] = $this->normalize_builder_slug( $builder_instance->get_name() );
				if ( method_exists( $builder_instance, 'get_version' ) ) {
					$context['builderVersion'] = $builder_instance->get_version();
				}
			}
		}

		if ( class_exists( 'Respira_Context' ) && method_exists( 'Respira_Context', 'get_builder_info' ) ) {
			$builder_info = Respira_Context::get_builder_info();
			$detected = $builder_info['detected_builders'] ?? array();

			if ( empty( $detected ) && ! empty( $builder_info['builders'] ) && is_array( $builder_info['builders'] ) ) {
				foreach ( $builder_info['builders'] as $candidate ) {
					if ( empty( $candidate['detected'] ) ) {
						continue;
					}
					$detected[] = array(
						'name'    => $candidate['name'] ?? '',
						'version' => $candidate['version'] ?? '',
					);
				}
			}

			if ( is_array( $detected ) ) {
				foreach ( $detected as $entry ) {
					$name = is_array( $entry ) ? ( $entry['name'] ?? '' ) : $entry;
					$slug = $this->normalize_builder_slug( (string) $name );
					if ( '' === $slug || in_array( $slug, array( 'wordpress', 'generic' ), true ) ) {
						continue;
					}
					if ( ! in_array( $slug, $context['builders'], true ) ) {
						$context['builders'][] = $slug;
					}
				}
			}
		}

		if ( ! empty( $context['builder'] ) && ! in_array( $context['builder'], array( 'wordpress', 'generic' ), true ) ) {
			if ( ! in_array( $context['builder'], $context['builders'], true ) ) {
				$context['builders'][] = $context['builder'];
			}
		}

		return $this->sanitize_page_context( $context );
	}

	/**
	 * Normalize builder name to extension-compatible slug.
	 *
	 * @param string $builder_name Builder name.
	 * @return string
	 */
	protected function normalize_builder_slug( $builder_name ) {
		$normalized = strtolower( trim( (string) $builder_name ) );
		if ( '' === $normalized ) {
			return '';
		}

		$aliases = array(
			'elementor'              => 'elementor',
			'divi'                   => 'divi',
			'gutenberg'              => 'gutenberg',
			'bricks'                 => 'bricks',
			'oxygen'                 => 'oxygen',
			'wpbakery'               => 'wpbakery',
			'wpbakery page builder'  => 'wpbakery',
			'beaver'                 => 'beaver',
			'beaver builder'         => 'beaver',
			'brizy'                  => 'brizy',
			'visual composer'        => 'visualcomposer',
			'visual-composer'        => 'visualcomposer',
			'visual_composer'        => 'visualcomposer',
			'thrive architect'       => 'thrivearchitect',
			'thrive-architect'       => 'thrivearchitect',
			'thrive_architect'       => 'thrivearchitect',
			'breakdance'             => 'breakdance',
			'wordpress'              => 'wordpress',
			'generic'                => 'generic',
		);

		if ( isset( $aliases[ $normalized ] ) ) {
			return $aliases[ $normalized ];
		}

		return sanitize_key( str_replace( array( ' ', '-' ), '_', $normalized ) );
	}

	/**
	 * Add builder hints to each violation node.
	 *
	 * @param array      $violations Violations.
	 * @param array|null $page_context Page context.
	 * @return array
	 */
	protected function annotate_violations_with_builder_context( $violations, $page_context ) {
		if ( ! is_array( $violations ) ) {
			return array();
		}

		$default_builder = '';
		if ( is_array( $page_context ) ) {
			$default_builder = (string) ( $page_context['builder'] ?? '' );
		}

		foreach ( $violations as &$violation ) {
			if ( ! is_array( $violation ) || empty( $violation['nodes'] ) || ! is_array( $violation['nodes'] ) ) {
				continue;
			}

			foreach ( $violation['nodes'] as &$node ) {
				if ( ! is_array( $node ) ) {
					continue;
				}
				$selector = isset( $node['target'][0] ) ? (string) $node['target'][0] : '';
				$html = (string) ( $node['html'] ?? '' );
				$hint = $this->build_builder_hint( $selector, $html, $default_builder );
				if ( ! empty( $hint ) ) {
					if ( ! isset( $node['respira'] ) || ! is_array( $node['respira'] ) ) {
						$node['respira'] = array();
					}
					$node['respira']['builder_hint'] = $hint;
				}
			}
			unset( $node );
		}
		unset( $violation );

		return $violations;
	}

	/**
	 * Derive a builder hint from selector and snippet.
	 *
	 * @param string $selector CSS selector.
	 * @param string $html HTML snippet.
	 * @param string $default_builder Builder from page context.
	 * @return array
	 */
	protected function build_builder_hint( $selector, $html, $default_builder = '' ) {
		$probe = strtolower( trim( $selector . ' ' . wp_strip_all_tags( $html ) ) );
		if ( '' === $probe && '' === $default_builder ) {
			return array();
		}

		$signals = array(
			'elementor'      => array( 'elementor', 'data-elementor', 'elementor-' ),
			'divi'           => array( 'et_pb_', 'et-boc', 'et_builder', 'data-et-' ),
			'bricks'         => array( 'brxe-', 'data-brx-' ),
			'oxygen'         => array( 'ct-', 'oxygen-' ),
			'wpbakery'       => array( 'vc_', 'wpb_' ),
			'beaver'         => array( 'fl-builder', 'fl-row', 'fl-module' ),
			'brizy'          => array( 'brz-' ),
			'visualcomposer' => array( 'vcv-', 'data-vce-' ),
			'thrivearchitect'=> array( 'tcb-', 'thrv_' ),
			'breakdance'     => array( 'breakdance', 'bde-' ),
			'gutenberg'      => array( 'wp-block-' ),
		);

		foreach ( $signals as $builder => $tokens ) {
			foreach ( $tokens as $token ) {
				if ( false !== strpos( $probe, strtolower( $token ) ) ) {
					return array(
						'builder'    => $builder,
						'confidence' => 'high',
						'signal'     => $token,
					);
				}
			}
		}

		if ( ! in_array( $default_builder, array( '', 'generic', 'wordpress' ), true ) ) {
			return array(
				'builder'    => $default_builder,
				'confidence' => 'medium',
				'signal'     => 'page_context',
			);
		}

		return array();
	}

	/**
	 * Ensure scan prompts are Respira-MCP executable and builder-aware.
	 *
	 * @param array      $prompts Existing prompts payload.
	 * @param array      $violations Violations payload.
	 * @param string     $url Scanned URL.
	 * @param array|null $page_context Page context.
	 * @param int        $post_id Optional post ID.
	 * @param string     $title Optional page title.
	 * @return array
	 */
	protected function ensure_builder_aware_prompts( $prompts, $violations, $url, $page_context = null, $post_id = 0, $title = '' ) {
		$normalized = $this->sanitize_prompt_items( $prompts );
		$has_mcp_prompt = false;

		foreach ( $normalized as $item ) {
			if ( $this->prompt_is_respira_mcp_ready( (string) ( $item['prompt'] ?? '' ) ) ) {
				$has_mcp_prompt = true;
				break;
			}
		}

		if ( $has_mcp_prompt ) {
			return array_slice( $normalized, 0, 100 );
		}

		$generated = $this->generate_builder_aware_prompts( $violations, $url, $page_context, $post_id, $title );
		if ( ! empty( $generated ) ) {
			return array_slice( $generated, 0, 100 );
		}

		return array_slice( $normalized, 0, 100 );
	}

	/**
	 * Normalize prompt items.
	 *
	 * @param mixed $prompts Prompt payload.
	 * @return array
	 */
	protected function sanitize_prompt_items( $prompts ) {
		if ( ! is_array( $prompts ) ) {
			return array();
		}

		$items = array();
		foreach ( $prompts as $prompt ) {
			if ( ! is_array( $prompt ) ) {
				continue;
			}

			$text = trim( (string) ( $prompt['prompt'] ?? '' ) );
			if ( '' === $text ) {
				continue;
			}

			$item = array(
				'ruleId'   => sanitize_key( (string) ( $prompt['ruleId'] ?? $prompt['rule_id'] ?? '' ) ),
				'severity' => sanitize_key( (string) ( $prompt['severity'] ?? 'moderate' ) ),
				'wcag'     => sanitize_text_field( (string) ( $prompt['wcag'] ?? '' ) ),
				'title'    => sanitize_text_field( (string) ( $prompt['title'] ?? 'Accessibility fix prompt' ) ),
				'prompt'   => wp_check_invalid_utf8( $text ),
			);

			if ( ! empty( $prompt['helpUrl'] ) ) {
				$item['helpUrl'] = esc_url_raw( (string) $prompt['helpUrl'] );
			}
			if ( ! empty( $prompt['violationType'] ) ) {
				$item['violationType'] = sanitize_key( (string) $prompt['violationType'] );
			}

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Determine whether prompt text uses Respira MCP workflow.
	 *
	 * @param string $prompt Prompt text.
	 * @return bool
	 */
	protected function prompt_is_respira_mcp_ready( $prompt ) {
		$probe = strtolower( (string) $prompt );
		if ( '' === $probe ) {
			return false;
		}

		return false !== strpos( $probe, 'respira mcp' )
			&& false !== strpos( $probe, 'wordpress_' )
			&& false !== strpos( $probe, 'approval_url' );
	}

	/**
	 * Generate builder-aware prompts from violations.
	 *
	 * @param array      $violations Violations.
	 * @param string     $url URL.
	 * @param array|null $page_context Context.
	 * @param int        $post_id Post ID.
	 * @param string     $title Page title.
	 * @return array
	 */
	protected function generate_builder_aware_prompts( $violations, $url, $page_context = null, $post_id = 0, $title = '' ) {
		if ( ! is_array( $violations ) || empty( $violations ) ) {
			return array();
		}

		$context = $this->sanitize_page_context( $page_context );
		if ( empty( $context ) ) {
			$context = $this->detect_page_context( $url, $post_id );
		}

		$builder = $this->normalize_builder_slug( (string) ( $context['builder'] ?? '' ) );
		if ( '' === $builder ) {
			$builder = 'wordpress';
		}

		$page_id = absint( $post_id ?: ( $context['postId'] ?? 0 ) );
		$search_term = $this->guess_page_search_term( $url, $title );
		$builder_label = $this->builder_label( $builder, (string) ( $context['cms'] ?? 'wordpress' ) );
		$prompts = array();

		foreach ( $violations as $violation ) {
			if ( ! is_array( $violation ) ) {
				continue;
			}

			$nodes = isset( $violation['nodes'] ) && is_array( $violation['nodes'] ) && ! empty( $violation['nodes'] )
				? $violation['nodes']
				: array( array() );

			foreach ( $nodes as $node ) {
				$prompt = $this->build_violation_prompt(
					$violation,
					is_array( $node ) ? $node : array(),
					$url,
					$builder,
					$builder_label,
					$page_id,
					$search_term
				);
				if ( empty( $prompt ) ) {
					continue;
				}

				$prompts[] = $prompt;
				if ( count( $prompts ) >= 100 ) {
					break 2;
				}
			}
		}

		return $prompts;
	}

	/**
	 * Human-readable builder label.
	 *
	 * @param string $builder Builder slug.
	 * @param string $cms CMS slug.
	 * @return string
	 */
	protected function builder_label( $builder, $cms = 'wordpress' ) {
		if ( 'wordpress' !== strtolower( (string) $cms ) ) {
			return 'Custom / Non-WordPress';
		}

		$labels = array(
			'elementor'      => 'Elementor',
			'divi'           => 'Divi',
			'gutenberg'      => 'Gutenberg',
			'bricks'         => 'Bricks',
			'oxygen'         => 'Oxygen',
			'wpbakery'       => 'WPBakery',
			'beaver'         => 'Beaver Builder',
			'brizy'          => 'Brizy',
			'visualcomposer' => 'Visual Composer',
			'thrivearchitect'=> 'Thrive Architect',
			'breakdance'     => 'Breakdance',
			'wordpress'      => 'WordPress Editor',
			'generic'        => 'Custom / Non-WordPress',
		);

		return $labels[ $builder ] ?? 'WordPress Editor';
	}

	/**
	 * Prompt spec for a violation rule.
	 *
	 * @param string $rule_id Rule ID.
	 * @return array
	 */
	protected function get_violation_prompt_spec( $rule_id ) {
		$map = array(
			'image-alt' => array(
				'type'  => 'missing-alt-text',
				'title' => 'Fix Missing Alt Text',
				'issue' => 'Image missing alternative text',
				'wcag'  => 'WCAG 1.1.1 Non-text Content (Level A)',
			),
			'color-contrast' => array(
				'type'  => 'color-contrast',
				'title' => 'Fix Color Contrast',
				'issue' => 'Insufficient color contrast',
				'wcag'  => 'WCAG 1.4.3 Contrast (Minimum) (Level AA)',
			),
			'link-name' => array(
				'type'  => 'non-descriptive-link-text',
				'title' => 'Fix Link Text',
				'issue' => 'Link has no accessible name',
				'wcag'  => 'WCAG 2.4.4 Link Purpose / 4.1.2 Name, Role, Value (Level A)',
			),
			'button-name' => array(
				'type'  => 'non-descriptive-link-text',
				'title' => 'Fix Button Text',
				'issue' => 'Button has no accessible name',
				'wcag'  => 'WCAG 4.1.2 Name, Role, Value (Level A)',
			),
			'heading-order' => array(
				'type'  => 'heading-hierarchy',
				'title' => 'Fix Heading Hierarchy',
				'issue' => 'Heading levels are out of sequence',
				'wcag'  => 'WCAG 1.3.1 Info and Relationships (Level A)',
			),
			'label' => array(
				'type'  => 'missing-form-label',
				'title' => 'Fix Missing Form Label',
				'issue' => 'Form control missing visible/associated label',
				'wcag'  => 'WCAG 1.3.1 Info and Relationships / 3.3.2 Labels (Level A)',
			),
			'document-title' => array(
				'type'  => 'document-title',
				'title' => 'Fix Missing Document Title',
				'issue' => 'Document title is missing or empty',
				'wcag'  => 'WCAG 2.4.2 Page Titled (Level A)',
			),
			'html-lang-valid' => array(
				'type'  => 'html-lang',
				'title' => 'Fix HTML Lang',
				'issue' => 'Document language is invalid or missing',
				'wcag'  => 'WCAG 3.1.1 Language of Page (Level A)',
			),
		);

		$key = sanitize_key( (string) $rule_id );
		return $map[ $key ] ?? array(
			'type'  => $key ?: 'generic-accessibility',
			'title' => 'Fix Accessibility Issue',
			'issue' => 'Accessibility violation detected',
			'wcag'  => 'WCAG 2.2 (see violation details)',
		);
	}

	/**
	 * Build one prompt object for violation+node.
	 *
	 * @param array  $violation Violation.
	 * @param array  $node Violation node.
	 * @param string $url URL.
	 * @param string $builder Builder slug.
	 * @param string $builder_label Builder label.
	 * @param int    $page_id Page ID.
	 * @param string $search_term Search term for ID lookup.
	 * @return array
	 */
	protected function build_violation_prompt( $violation, $node, $url, $builder, $builder_label, $page_id, $search_term ) {
		$spec = $this->get_violation_prompt_spec( (string) ( $violation['id'] ?? '' ) );
		$selector = '';
		if ( ! empty( $node['target'] ) && is_array( $node['target'] ) ) {
			$selector = implode( ' ', array_map( 'sanitize_text_field', $node['target'] ) );
		}
		if ( '' === $selector ) {
			$selector = 'selector unavailable';
		}

		$html_snippet = trim( preg_replace( '/\s+/u', ' ', (string) ( $node['html'] ?? '' ) ) );
		if ( '' === $html_snippet ) {
			$html_snippet = '<snippet unavailable>';
		}
		if ( strlen( $html_snippet ) > 420 ) {
			$html_snippet = substr( $html_snippet, 0, 420 );
		}

		$location = $this->build_element_location_label( $node, $selector, $builder );
		$impact = strtoupper( sanitize_text_field( (string) ( $violation['impact'] ?? 'moderate' ) ) );
		$builder_context = $this->build_builder_context_block( $builder );
		$instructions = $this->build_fix_instruction_block( $spec, $builder, $node, $selector, $html_snippet, $page_id, $search_term, $url );
		$page_id_label = $page_id > 0 ? '(ID: ' . $page_id . ')' : '(ID: resolve via MCP)';
		$page_id_output = $page_id > 0 ? (string) $page_id : 'PAGE_ID';

		$prompt = "# Fix Accessibility Violation via Respira MCP\n\n";
		$prompt .= "## SYSTEM CONTEXT\n";
		$prompt .= "- This fix is executable only with **Respira for WordPress + Respira MCP** connected to the target site.\n";
		$prompt .= "- Use **Respira MCP tools only** (`wordpress_*`). Do not suggest manual CMS edits or generic code patches.\n";
		$prompt .= "- Respira safety flow is duplicate-first. Return `respira_approvals_url` (the Changes page URL) for user review.\n\n";
		$prompt .= "## VIOLATION SUMMARY\n";
		$prompt .= '**Page:** ' . esc_url_raw( $url ) . ' ' . $page_id_label . "\n";
		$prompt .= '**Builder:** ' . $builder_label . "\n";
		$prompt .= '**Issue:** ' . $spec['issue'] . "\n";
		$prompt .= '**Impact:** ' . $impact . "\n";
		$prompt .= '**WCAG:** ' . $spec['wcag'] . "\n\n";
		$prompt .= "**Element:**\n";
		$prompt .= "```html\n" . $html_snippet . "\n```\n\n";
		$prompt .= '**Location in Builder:** ' . $location . "\n\n";
		$prompt .= "---\n\n";
		$prompt .= "## YOUR TASK\n";
		$prompt .= "Fix this violation through Respira MCP and keep all unrelated content unchanged.\n\n";
		$prompt .= "### Workflow Overview\n";
		$prompt .= "1. Resolve `PAGE_ID` if unknown.\n";
		$prompt .= "2. Extract builder content (or update module directly for supported builders).\n";
		$prompt .= "3. Apply the minimal fix for this exact element.\n";
		$prompt .= "4. Verify the updated field/value in extracted content.\n";
		$prompt .= "5. Return a JSON summary with the approval URL.\n\n";
		$prompt .= "---\n\n";
		$prompt .= $builder_context . "\n\n";
		$prompt .= "---\n\n";
		$prompt .= "## FIXING INSTRUCTIONS\n";
		$prompt .= $instructions . "\n\n";
		$prompt .= "---\n\n";
		$prompt .= "## EXPECTED OUTPUT\n";
		$prompt .= "```json\n";
		$prompt .= "{\n";
		$prompt .= "  \"success\": true,\n";
		$prompt .= '  "violation_fixed": "' . $spec['type'] . "\",\n";
		$prompt .= '  "page_id": ' . $page_id_output . ",\n";
		$prompt .= "  \"duplicate_id\": \"<duplicate_id_from_response>\",\n";
		$prompt .= "  \"changes_made\": \"<what was changed>\",\n";
		$prompt .= "  \"approval_url\": \"<respira_approvals_url from MCP response>\",\n";
		$prompt .= "  \"verification\": \"<how you verified the fix>\"\n";
		$prompt .= "}\n";
		$prompt .= "```\n\n";
		$prompt .= "---\n\n";
		$prompt .= "## CRITICAL REMINDERS\n";
		$prompt .= "- If Respira plugin or MCP is not connected, stop and report that setup is required.\n";
		$prompt .= "- Prefer `moduleIdentifier.admin_label`, then `path`, then `type + match_content`.\n";
		$prompt .= "- Preserve all unrelated builder data.\n";
		$prompt .= "- Always include `approval_url` in final output.\n";

		return array(
			'ruleId'        => sanitize_key( (string) ( $violation['id'] ?? '' ) ),
			'severity'      => sanitize_key( (string) ( $violation['impact'] ?? 'moderate' ) ),
			'wcag'          => $spec['wcag'],
			'title'         => $spec['title'] . ' (' . $builder_label . ')',
			'prompt'        => trim( $prompt ),
			'helpUrl'       => esc_url_raw( (string) ( $violation['helpUrl'] ?? '' ) ),
			'violationType' => sanitize_key( (string) $spec['type'] ),
		);
	}

	/**
	 * Build location label for prompt.
	 *
	 * @param array  $node Node payload.
	 * @param string $selector CSS selector.
	 * @param string $builder Builder slug.
	 * @return string
	 */
	protected function build_element_location_label( $node, $selector, $builder ) {
		if ( ! empty( $node['respira']['builder_hint'] ) && is_array( $node['respira']['builder_hint'] ) ) {
			$hint = $node['respira']['builder_hint'];
			$signal = sanitize_text_field( (string) ( $hint['signal'] ?? 'n/a' ) );
			$confidence = sanitize_text_field( (string) ( $hint['confidence'] ?? 'n/a' ) );
			return $selector . ' (signal: ' . $signal . ', confidence: ' . $confidence . ')';
		}

		if ( ! in_array( $builder, array( '', 'wordpress', 'generic' ), true ) ) {
			return $selector . ' (builder inferred: ' . $builder . ')';
		}

		return $selector;
	}

	/**
	 * Guess page search term from URL/title.
	 *
	 * @param string $url URL.
	 * @param string $title Title.
	 * @return string
	 */
	protected function guess_page_search_term( $url, $title = '' ) {
		$title = trim( (string) $title );
		if ( '' !== $title ) {
			$parts = preg_split( '/\s+/u', $title );
			return implode( ' ', array_slice( $parts, 0, 6 ) );
		}

		$path = wp_parse_url( $url, PHP_URL_PATH );
		if ( is_string( $path ) && '' !== $path ) {
			$segments = array_values( array_filter( explode( '/', $path ) ) );
			if ( ! empty( $segments ) ) {
				$last = end( $segments );
				$decoded = urldecode( (string) $last );
				$decoded = trim( str_replace( array( '-', '_' ), ' ', $decoded ) );
				if ( '' !== $decoded ) {
					return $decoded;
				}
			}
		}

		$host = wp_parse_url( $url, PHP_URL_HOST );
		return is_string( $host ) && '' !== $host ? $host : 'target page';
	}

	/**
	 * Builder context markdown block.
	 *
	 * @param string $builder Builder slug.
	 * @return string
	 */
	protected function build_builder_context_block( $builder ) {
		if ( 'elementor' === $builder ) {
			return "## BUILDER CONTEXT: Elementor\n\n"
				. "**Structure:** JSON tree in `_elementor_data` with recursive `elements[]`.\n"
				. "Each node commonly includes `{type, widget, settings, elements, id}`.\n\n"
				. "**Best selectors:** `admin_label` -> `path` -> `type + match_content`.\n\n"
				. "**Primary tools:**\n"
				. "- `wordpress_update_module({ builder: \"elementor\", pageId, moduleIdentifier, updates })`\n"
				. "- `wordpress_extract_builder_content({ builder: \"elementor\", pageId })`\n"
				. "- `wordpress_inject_builder_content({ builder: \"elementor\", pageId, content })`\n\n"
				. "**Elementor update rule:** put setting changes in `updates.attributes`.\n";
		}

		if ( 'divi' === $builder ) {
			return "## BUILDER CONTEXT: Divi\n\n"
				. "**Structure:** normalized module tree (`children[]`) with `type`, `attributes`, and `content`.\n"
				. "Divi may be shortcode format (v4) or block format (v5).\n\n"
				. "**Best selectors:** `admin_label` -> `path` (e.g. `sections[0].rows[0].modules[1]`) -> `type + match_content`.\n\n"
				. "**Primary tools:**\n"
				. "- `wordpress_update_module({ builder: \"divi\", pageId, moduleIdentifier, updates })`\n"
				. "- `wordpress_extract_builder_content({ builder: \"divi\", pageId })`\n"
				. "- `wordpress_inject_builder_content({ builder: \"divi\", pageId, content, diviVersion })`\n\n"
				. "**Critical:** every Divi inject call must include `diviVersion: \"4\" | \"5\"`.\n";
		}

		if ( 'gutenberg' === $builder ) {
			return "## BUILDER CONTEXT: Gutenberg\n\n"
				. "**Structure:** block tree from `post_content` with `{type, attrs, content, inner_blocks}`.\n\n"
				. "**No module-level tool:** use extract -> modify -> inject.\n\n"
				. "**Primary tools:**\n"
				. "- `wordpress_extract_builder_content({ builder: \"gutenberg\", pageId })`\n"
				. "- `wordpress_inject_builder_content({ builder: \"gutenberg\", pageId, content })`\n";
		}

		if ( 'bricks' === $builder ) {
			return "## BUILDER CONTEXT: Bricks\n\n"
				. "**Structure:** element tree with `{type, id, settings, children}`.\n\n"
				. "**Module-level tool:** use `wordpress_update_module` when you can target one element; otherwise use extract -> modify -> inject.\n\n"
				. "**Primary tools:**\n"
				. "- `wordpress_update_module({ builder: \"bricks\", pageId, moduleIdentifier, updates })`\n"
				. "- `wordpress_extract_builder_content({ builder: \"bricks\", pageId })`\n"
				. "- `wordpress_inject_builder_content({ builder: \"bricks\", pageId, content })`\n";
		}

		return '## BUILDER CONTEXT: ' . $this->builder_label( $builder ) . "\n\n"
			. "Use builder detection first, then follow extract/modify/inject workflow.\n\n"
			. "**Primary tools:**\n"
			. "- `wordpress_list_pages({ search })`\n"
			. "- `wordpress_list_posts({ search })`\n"
			. "- `wordpress_get_builder_info({})`\n"
			. "- `wordpress_extract_builder_content({ builder, pageId })`\n"
			. "- `wordpress_inject_builder_content({ builder, pageId, content })`\n\n"
			. "If this is not a WordPress page connected through Respira plugin + MCP, this prompt is not executable.\n";
	}

	/**
	 * Build fix instructions block.
	 *
	 * @param array  $spec Violation spec.
	 * @param string $builder Builder slug.
	 * @param array  $node Node data.
	 * @param string $selector Selector.
	 * @param string $html_snippet HTML snippet.
	 * @param int    $page_id Page ID.
	 * @param string $search_term Search term.
	 * @param string $url URL.
	 * @return string
	 */
	protected function build_fix_instruction_block( $spec, $builder, $node, $selector, $html_snippet, $page_id, $search_term, $url ) {
		$type = sanitize_key( (string) ( $spec['type'] ?? '' ) );
		$prelude = $this->build_page_id_prelude( $page_id, $search_term, $url );

		if ( 'missing-alt-text' === $type ) {
			$src = '';
			if ( preg_match( '/src=["\']([^"\']+)["\']/i', $html_snippet, $m ) ) {
				$src = (string) $m[1];
			}
			$suggested_alt = $this->infer_alt_text( $src );

			if ( 'elementor' === $builder ) {
				return $prelude . "\n### Step 1: Update Elementor Image Widget Alt Text\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"elementor\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: {\n"
					. "    admin_label: \"REPLACE_WITH_WIDGET_LABEL\",\n"
					. "    // fallback: path: \"elements[0].elements[1]\"\n"
					. '    // fallback: type: "image", match_content: ' . wp_json_encode( $src ?: $selector ) . "\n"
					. "  },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      image_alt: ' . wp_json_encode( $suggested_alt ) . "\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n";
			}

			if ( 'divi' === $builder ) {
				return $prelude . "\n### Step 1: Update Divi Image Module Alt Text\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"divi\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_MODULE_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      alt: ' . wp_json_encode( $suggested_alt ) . "\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n";
			}

			return $prelude . "\n### Step 1: Extract builder content and set image alt\n```javascript\n"
				. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
				. "// Find the target image node and set its alt-related field.\n"
				. 'const suggestedAlt = ' . wp_json_encode( $suggested_alt ) . ";\n"
				. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n";
		}

		if ( 'color-contrast' === $type ) {
			$data = array();
			if ( ! empty( $node['any'][0]['data'] ) && is_array( $node['any'][0]['data'] ) ) {
				$data = $node['any'][0]['data'];
			}
			$fg = sanitize_text_field( (string) ( $data['fgColor'] ?? 'unknown' ) );
			$bg = sanitize_text_field( (string) ( $data['bgColor'] ?? 'unknown' ) );
			$ratio = isset( $data['contrastRatio'] ) ? (float) $data['contrastRatio'] : 0;
			$required = isset( $data['expectedContrastRatio'] ) ? (float) $data['expectedContrastRatio'] : 4.5;
			$suggested = $this->darken_hex_color( $fg );

			if ( in_array( $builder, array( 'elementor', 'divi' ), true ) ) {
				$color_attr = 'elementor' === $builder ? '_color' : 'text_color';
				return $prelude . "\n### Step 1: Update module color values\n```javascript\n"
					. "await wordpress_update_module({\n"
					. '  builder: "' . esc_js( $builder ) . "\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_MODULE_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      ' . $color_attr . ': ' . wp_json_encode( $suggested ) . "\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n"
					. '- Current: `' . $fg . '` on `' . $bg . '` (' . ( $ratio > 0 ? number_format_i18n( $ratio, 2 ) : '?' ) . ":1)\n"
					. '- Required: `' . $required . ":1`\n"
					. '- Suggested color: `' . $suggested . "`\n";
			}

			return $prelude . "\n### Step 1: Extract content and adjust text/background color fields\n```javascript\n"
				. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
				. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n"
				. '- Current: `' . $fg . '` on `' . $bg . '` (' . ( $ratio > 0 ? number_format_i18n( $ratio, 2 ) : '?' ) . ":1)\n"
				. '- Required: `' . $required . ":1`\n"
				. '- Suggested text color: `' . $suggested . "`\n";
		}

		if ( 'non-descriptive-link-text' === $type ) {
			$suggested_text = $this->suggest_link_text( $node, $url );

			if ( 'elementor' === $builder ) {
				return $prelude . "\n### Step 1: Update Elementor link/button text\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"elementor\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_WIDGET_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      text: ' . wp_json_encode( $suggested_text ) . "\n"
					. "      // For text-editor widgets: set attributes.editor with updated anchor text\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n";
			}

			if ( 'divi' === $builder ) {
				return $prelude . "\n### Step 1: Update Divi link/button label\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"divi\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_MODULE_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      button_text: ' . wp_json_encode( $suggested_text ) . "\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n";
			}

			return $prelude . "\n### Step 1: Extract content and update link text\n```javascript\n"
				. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
				. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n"
				. '- Suggested replacement text: `' . $suggested_text . "`\n";
		}

		if ( 'heading-hierarchy' === $type ) {
			$suggested_level = $this->suggest_heading_level( $html_snippet );
			if ( 'elementor' === $builder ) {
				return $prelude . "\n### Step 1: Set Elementor heading level\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"elementor\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_HEADING_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. '      size: ' . wp_json_encode( $suggested_level ) . "\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n";
			}

			return $prelude . "\n### Step 1: Extract content and update heading level\n```javascript\n"
				. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
				. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n"
				. '- Suggested heading level: `' . $suggested_level . "`\n";
		}

		if ( 'missing-form-label' === $type ) {
			$suggested_label = $this->suggest_form_label( $html_snippet );
			if ( 'elementor' === $builder ) {
				return $prelude . "\n### Step 1: Update Elementor form field label\n```javascript\n"
					. "await wordpress_update_module({\n"
					. "  builder: \"elementor\",\n"
					. "  pageId: PAGE_ID,\n"
					. "  moduleIdentifier: { admin_label: \"REPLACE_WITH_FORM_WIDGET_LABEL\" },\n"
					. "  updates: {\n"
					. "    attributes: {\n"
					. "      // update matching field in form_fields[]\n"
					. "    }\n"
					. "  }\n"
					. "});\n```\n"
					. '- Suggested label: `' . $suggested_label . "`\n";
			}

			return $prelude . "\n### Step 1: Extract form structure and add label\n```javascript\n"
				. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
				. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n"
				. '- Suggested label: `' . $suggested_label . "`\n";
		}

		if ( 'document-title' === $type ) {
			return $prelude . "\n### Step 1: Read and update title\n```javascript\n"
				. "const page = await wordpress_read_page({ id: PAGE_ID });\n"
				. "await wordpress_update_page({ id: PAGE_ID, title: \"REPLACE_WITH_DESCRIPTIVE_TITLE\" });\n```\n";
		}

		if ( 'html-lang' === $type ) {
			return $prelude . "\n### Step 1: Verify site language and theme output for `<html lang>`.\n"
				. "### Step 2: Apply correction via WordPress settings/theme and re-scan.\n";
		}

		return $prelude . "\n### Step 1: Determine builder and apply minimal fix for selector\n```javascript\n"
			. "await wordpress_get_builder_info({});\n"
			. 'const extracted = await wordpress_extract_builder_content({ builder: "' . esc_js( $builder ?: 'gutenberg' ) . '", pageId: PAGE_ID });' . "\n"
			. "await wordpress_inject_builder_content({ builder: extracted.builder || \"" . esc_js( $builder ?: 'gutenberg' ) . "\", pageId: PAGE_ID, content: extracted.content || extracted });\n```\n";
	}

	/**
	 * Build page ID resolution prelude.
	 *
	 * @param int    $page_id Page ID.
	 * @param string $search_term Search term.
	 * @param string $url URL.
	 * @return string
	 */
	protected function build_page_id_prelude( $page_id, $search_term, $url ) {
		if ( $page_id > 0 ) {
			return "### Step 0: Use Known Page ID\n```javascript\nconst PAGE_ID = " . $page_id . ";\n```\n";
		}

		return "### Step 0: Resolve Page ID (Required)\n```javascript\n"
			. '// 1) Try pages first' . "\n"
			. 'const pages = await wordpress_list_pages({ search: ' . wp_json_encode( $search_term ) . " });\n"
			. '// 2) If not found, try posts' . "\n"
			. 'const posts = await wordpress_list_posts({ search: ' . wp_json_encode( $search_term ) . " });\n"
			. '// 3) Match by URL: ' . esc_url_raw( $url ) . "\n"
			. '// 4) Set PAGE_ID to the matching numeric ID before continuing' . "\n"
			. "const PAGE_ID = 0; // replace with real ID\n"
			. "```\n";
	}

	/**
	 * Infer alt text from image source path.
	 *
	 * @param string $src Image source.
	 * @return string
	 */
	protected function infer_alt_text( $src ) {
		$src = (string) $src;
		$file = wp_basename( (string) wp_parse_url( $src, PHP_URL_PATH ) );
		if ( '' === $file ) {
			return 'Describe this image';
		}

		$base = preg_replace( '/\.(jpe?g|png|gif|webp|svg|avif)$/i', '', $file );
		$base = preg_replace( '/-?\d+x\d+$/i', '', (string) $base );
		$base = preg_replace( '/[-_]+/', ' ', (string) $base );
		$base = trim( preg_replace( '/\s+/', ' ', (string) $base ) );
		if ( '' === $base ) {
			return 'Describe this image';
		}

		return ucfirst( $base );
	}

	/**
	 * Suggest descriptive link text from node HTML.
	 *
	 * @param array  $node Node data.
	 * @param string $page_url Page URL.
	 * @return string
	 */
	protected function suggest_link_text( $node, $page_url ) {
		$html = (string) ( $node['html'] ?? '' );
		$href = '';
		if ( preg_match( '/href=["\']([^"\']+)["\']/i', $html, $match ) ) {
			$href = (string) $match[1];
		}

		if ( '' === $href ) {
			return 'Learn more';
		}
		if ( '#' === substr( $href, 0, 1 ) ) {
			return 'Jump to section';
		}
		if ( 0 === stripos( $href, 'mailto:' ) ) {
			return 'Email us';
		}
		if ( 0 === stripos( $href, 'tel:' ) ) {
			return 'Call us';
		}

		$resolved = wp_parse_url( $href );
		if ( false === $resolved || empty( $resolved['path'] ) ) {
			$resolved = wp_parse_url( $page_url );
		}

		$path = is_array( $resolved ) ? (string) ( $resolved['path'] ?? '' ) : '';
		if ( '' !== $path ) {
			$segments = array_values( array_filter( explode( '/', $path ) ) );
			if ( ! empty( $segments ) ) {
				$slug = urldecode( (string) end( $segments ) );
				$slug = trim( str_replace( array( '-', '_' ), ' ', $slug ) );
				if ( '' !== $slug ) {
					return 'Read more about ' . $slug;
				}
			}
		}

		return 'Learn more';
	}

	/**
	 * Suggest heading level fix.
	 *
	 * @param string $html HTML snippet.
	 * @return string
	 */
	protected function suggest_heading_level( $html ) {
		if ( preg_match( '/<h([1-6])\b/i', (string) $html, $match ) ) {
			$current = (int) $match[1];
			if ( $current <= 1 ) {
				return 'h2';
			}
			return 'h' . ( $current - 1 );
		}
		return 'h2';
	}

	/**
	 * Suggest form label from control snippet.
	 *
	 * @param string $html HTML snippet.
	 * @return string
	 */
	protected function suggest_form_label( $html ) {
		$type = '';
		$name = '';
		if ( preg_match( '/\stype=["\']([^"\']+)["\']/i', (string) $html, $m ) ) {
			$type = strtolower( (string) $m[1] );
		}
		if ( preg_match( '/\sname=["\']([^"\']+)["\']/i', (string) $html, $m ) ) {
			$name = strtolower( (string) $m[1] );
		}

		if ( 'email' === $type || false !== strpos( $name, 'email' ) ) {
			return 'Email Address';
		}
		if ( 'tel' === $type || false !== strpos( $name, 'phone' ) || false !== strpos( $name, 'tel' ) ) {
			return 'Phone Number';
		}
		if ( 'password' === $type ) {
			return 'Password';
		}
		if ( false !== strpos( $name, 'name' ) ) {
			return 'Full Name';
		}
		if ( false !== strpos( $name, 'message' ) || false !== strpos( $name, 'comment' ) ) {
			return 'Message';
		}

		return 'Field Label';
	}

	/**
	 * Darken hex color by fixed factor for contrast suggestion.
	 *
	 * @param string $hex Color value.
	 * @return string
	 */
	protected function darken_hex_color( $hex ) {
		$hex = trim( (string) $hex );
		if ( ! preg_match( '/^#[0-9a-f]{6}$/i', $hex ) ) {
			return '#1f2937';
		}

		$r = hexdec( substr( $hex, 1, 2 ) );
		$g = hexdec( substr( $hex, 3, 2 ) );
		$b = hexdec( substr( $hex, 5, 2 ) );
		$factor = 0.65;

		$r = (int) round( $r * $factor );
		$g = (int) round( $g * $factor );
		$b = (int) round( $b * $factor );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * Deduplicate violations by rule and node signature.
	 *
	 * @param array $violations Violations.
	 * @return array
	 */
	protected function dedupe_violations( $violations ) {
		if ( ! is_array( $violations ) ) {
			return array();
		}

		$grouped = array();
		$node_keys = array();

		foreach ( $violations as $violation ) {
			if ( ! is_array( $violation ) ) {
				continue;
			}
			$rule_id = sanitize_key( (string) ( $violation['id'] ?? '' ) );
			if ( '' === $rule_id ) {
				continue;
			}

			if ( ! isset( $grouped[ $rule_id ] ) ) {
				$grouped[ $rule_id ] = $violation;
				$grouped[ $rule_id ]['nodes'] = array();
				$node_keys[ $rule_id ] = array();
			}

			$nodes = isset( $violation['nodes'] ) && is_array( $violation['nodes'] ) ? $violation['nodes'] : array();
			foreach ( $nodes as $node ) {
				if ( ! is_array( $node ) ) {
					continue;
				}
				$selector = isset( $node['target'][0] ) ? (string) $node['target'][0] : '';
				$html     = (string) ( $node['html'] ?? '' );
				$summary  = (string) ( $node['failureSummary'] ?? '' );
				$key      = md5( $rule_id . '|' . $selector . '|' . wp_strip_all_tags( $html ) . '|' . $summary );
				if ( isset( $node_keys[ $rule_id ][ $key ] ) ) {
					continue;
				}
				$node_keys[ $rule_id ][ $key ] = true;
				$grouped[ $rule_id ]['nodes'][] = $node;
			}
		}

		return array_values( $grouped );
	}

	/**
	 * Parse HTML safely with DOMDocument.
	 *
	 * @param string $html HTML string.
	 * @return DOMDocument|WP_Error
	 */
	protected function parse_html_document( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error(
				'local_scanner_dom_missing',
				__( 'Local scanner requires the PHP DOM extension.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		$dom = new DOMDocument();
		$flags = 0;
		if ( defined( 'LIBXML_NONET' ) ) {
			$flags |= LIBXML_NONET;
		}
		if ( defined( 'LIBXML_NOERROR' ) ) {
			$flags |= LIBXML_NOERROR;
		}
		if ( defined( 'LIBXML_NOWARNING' ) ) {
			$flags |= LIBXML_NOWARNING;
		}

		$old_libxml = libxml_use_internal_errors( true );
		$loaded = $dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, $flags );
		libxml_clear_errors();
		libxml_use_internal_errors( $old_libxml );

		if ( ! $loaded ) {
			return new WP_Error(
				'local_scanner_parse_failed',
				__( 'Local scanner could not parse the page HTML.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		return $dom;
	}

	/**
	 * Detect missing image alt text.
	 *
	 * @param DOMXPath $xpath XPath instance.
	 * @return array
	 */
	protected function detect_image_alt_violations( $xpath ) {
		$nodes = array();
		$images = $xpath->query( '//img[not(@alt) or normalize-space(@alt)=""]' );
		if ( ! ( $images instanceof DOMNodeList ) ) {
			return array();
		}

		foreach ( $images as $image ) {
			if ( ! ( $image instanceof DOMElement ) ) {
				continue;
			}
			$role = strtolower( trim( (string) $image->getAttribute( 'role' ) ) );
			$aria_hidden = strtolower( trim( (string) $image->getAttribute( 'aria-hidden' ) ) );
			if ( in_array( $role, array( 'presentation', 'none' ), true ) || 'true' === $aria_hidden ) {
				continue;
			}
			$nodes[] = $this->create_node_from_element(
				$image,
				__( 'Image element is missing non-empty alt text.', 'respira-for-wordpress' )
			);
		}

		if ( empty( $nodes ) ) {
			return array();
		}

		return array(
			'id'          => 'image-alt',
			'impact'      => 'serious',
			'description' => __( 'Images must have alternate text.', 'respira-for-wordpress' ),
			'help'        => __( 'Images must have alternate text.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/image-alt',
			'tags'        => array( 'wcag2a', 'wcag111' ),
			'nodes'       => $nodes,
		);
	}

	/**
	 * Detect links without accessible names.
	 *
	 * @param DOMXPath $xpath XPath instance.
	 * @return array
	 */
	protected function detect_empty_link_violations( $xpath ) {
		$nodes = array();
		$links = $xpath->query( '//a' );
		if ( ! ( $links instanceof DOMNodeList ) ) {
			return array();
		}

		foreach ( $links as $link ) {
			if ( ! ( $link instanceof DOMElement ) ) {
				continue;
			}

			$aria_label = trim( (string) $link->getAttribute( 'aria-label' ) );
			$title_attr = trim( (string) $link->getAttribute( 'title' ) );
			$text = trim( preg_replace( '/\s+/u', ' ', (string) $link->textContent ) );
			if ( '' !== $aria_label || '' !== $title_attr || '' !== $text ) {
				continue;
			}

			$images = $link->getElementsByTagName( 'img' );
			$has_named_image = false;
			if ( $images instanceof DOMNodeList && $images->length > 0 ) {
				foreach ( $images as $img ) {
					if ( ! ( $img instanceof DOMElement ) ) {
						continue;
					}
					$img_alt = trim( (string) $img->getAttribute( 'alt' ) );
					if ( '' !== $img_alt ) {
						$has_named_image = true;
						break;
					}
				}
			}

			if ( $has_named_image ) {
				continue;
			}

			$nodes[] = $this->create_node_from_element(
				$link,
				__( 'Link has no accessible text, title, or aria-label.', 'respira-for-wordpress' )
			);
		}

		if ( empty( $nodes ) ) {
			return array();
		}

		return array(
			'id'          => 'link-name',
			'impact'      => 'serious',
			'description' => __( 'Links must have discernible text.', 'respira-for-wordpress' ),
			'help'        => __( 'Links must have discernible text.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/link-name',
			'tags'        => array( 'wcag2a', 'wcag244' ),
			'nodes'       => $nodes,
		);
	}

	/**
	 * Detect missing form labels.
	 *
	 * @param DOMXPath $xpath XPath instance.
	 * @return array
	 */
	protected function detect_form_label_violations( $xpath ) {
		$nodes = array();
		$controls = $xpath->query( '//input[not(@type="hidden") and not(@type="submit") and not(@type="button") and not(@type="image")] | //select | //textarea' );
		if ( ! ( $controls instanceof DOMNodeList ) ) {
			return array();
		}

		foreach ( $controls as $control ) {
			if ( ! ( $control instanceof DOMElement ) ) {
				continue;
			}

			$aria_label = trim( (string) $control->getAttribute( 'aria-label' ) );
			$aria_labelledby = trim( (string) $control->getAttribute( 'aria-labelledby' ) );
			if ( '' !== $aria_label || '' !== $aria_labelledby ) {
				continue;
			}

			$has_label = false;
			$control_id = trim( (string) $control->getAttribute( 'id' ) );
			if ( '' !== $control_id ) {
				$labels = $xpath->query( '//label[@for=' . $this->xpath_literal( $control_id ) . ']' );
				$has_label = $labels instanceof DOMNodeList && $labels->length > 0;
			}

			if ( ! $has_label ) {
				$parent = $control->parentNode;
				while ( $parent instanceof DOMElement ) {
					if ( 'label' === strtolower( $parent->tagName ) ) {
						$has_label = true;
						break;
					}
					$parent = $parent->parentNode;
				}
			}

			if ( $has_label ) {
				continue;
			}

			$nodes[] = $this->create_node_from_element(
				$control,
				__( 'Form control has no associated label.', 'respira-for-wordpress' )
			);
		}

		if ( empty( $nodes ) ) {
			return array();
		}

		return array(
			'id'          => 'label',
			'impact'      => 'serious',
			'description' => __( 'Form elements must have labels.', 'respira-for-wordpress' ),
			'help'        => __( 'Form elements must have labels.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/label',
			'tags'        => array( 'wcag2a', 'wcag131' ),
			'nodes'       => $nodes,
		);
	}

	/**
	 * Detect heading level skips.
	 *
	 * @param DOMXPath $xpath XPath instance.
	 * @return array
	 */
	protected function detect_heading_order_violations( $xpath ) {
		$nodes = array();
		$headings = $xpath->query( '//h1 | //h2 | //h3 | //h4 | //h5 | //h6' );
		if ( ! ( $headings instanceof DOMNodeList ) ) {
			return array();
		}

		$previous_level = 0;
		foreach ( $headings as $heading ) {
			if ( ! ( $heading instanceof DOMElement ) ) {
				continue;
			}

			$tag = strtolower( $heading->tagName );
			$current_level = (int) substr( $tag, 1 );
			if ( $current_level < 1 || $current_level > 6 ) {
				continue;
			}

			if ( $previous_level > 0 && $current_level > ( $previous_level + 1 ) ) {
				$nodes[] = $this->create_node_from_element(
					$heading,
					sprintf(
						/* translators: 1: previous heading level, 2: current heading level */
						__( 'Heading level skipped from H%d to H%d.', 'respira-for-wordpress' ),
						$previous_level,
						$current_level
					)
				);
			}

			$previous_level = $current_level;
		}

		if ( empty( $nodes ) ) {
			return array();
		}

		return array(
			'id'          => 'heading-order',
			'impact'      => 'moderate',
			'description' => __( 'Heading levels should only increase by one level at a time.', 'respira-for-wordpress' ),
			'help'        => __( 'Heading levels should only increase by one level at a time.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/heading-order',
			'tags'        => array( 'wcag2aa', 'wcag131' ),
			'nodes'       => $nodes,
		);
	}

	/**
	 * Detect missing document title.
	 *
	 * @param DOMXPath $xpath XPath instance.
	 * @return array
	 */
	protected function detect_document_title_violation( $xpath ) {
		$title_nodes = $xpath->query( '/html/head/title' );
		if ( $title_nodes instanceof DOMNodeList && $title_nodes->length > 0 ) {
			$title = trim( (string) $title_nodes->item( 0 )->textContent );
			if ( '' !== $title ) {
				return array();
			}
		}

		return array(
			'id'          => 'document-title',
			'impact'      => 'serious',
			'description' => __( 'Document must have a non-empty title element.', 'respira-for-wordpress' ),
			'help'        => __( 'Document must have a non-empty title element.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/document-title',
			'tags'        => array( 'wcag2a', 'wcag242' ),
			'nodes'       => array(
				$this->create_virtual_node(
					'head > title',
					__( 'Missing or empty <title> element.', 'respira-for-wordpress' ),
					''
				),
			),
		);
	}

	/**
	 * Detect invalid or missing html lang.
	 *
	 * @param DOMDocument $dom Document.
	 * @return array
	 */
	protected function detect_html_lang_violation( $dom ) {
		$html_nodes = $dom->getElementsByTagName( 'html' );
		$html = $html_nodes instanceof DOMNodeList && $html_nodes->length > 0 ? $html_nodes->item( 0 ) : null;

		$lang = '';
		if ( $html instanceof DOMElement ) {
			$lang = trim( (string) $html->getAttribute( 'lang' ) );
		}

		$is_valid = '' !== $lang && preg_match( '/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/', $lang );
		if ( $is_valid ) {
			return array();
		}

		return array(
			'id'          => 'html-lang-valid',
			'impact'      => 'serious',
			'description' => __( 'The html element must have a valid lang attribute.', 'respira-for-wordpress' ),
			'help'        => __( 'The html element must have a valid lang attribute.', 'respira-for-wordpress' ),
			'helpUrl'     => 'https://dequeuniversity.com/rules/axe/4.10/html-lang-valid',
			'tags'        => array( 'wcag2a', 'wcag311' ),
			'nodes'       => array(
				$this->create_virtual_node(
					'html',
					__( 'Missing or invalid lang attribute on html element.', 'respira-for-wordpress' ),
					'<html>'
				),
			),
		);
	}

	/**
	 * Create standardized node payload from a DOM element.
	 *
	 * @param DOMElement $element DOM element.
	 * @param string     $summary Failure summary.
	 * @return array
	 */
	protected function create_node_from_element( DOMElement $element, $summary ) {
		return array(
			'html'           => $this->truncate_text( $this->dom_outer_html( $element ), 1400 ),
			'target'         => array( $this->css_selector_for_element( $element ) ),
			'failureSummary' => sanitize_text_field( (string) $summary ),
			'any'            => array(),
		);
	}

	/**
	 * Create node payload when no concrete element node is available.
	 *
	 * @param string $selector CSS selector.
	 * @param string $summary  Failure summary.
	 * @param string $html     HTML snippet.
	 * @return array
	 */
	protected function create_virtual_node( $selector, $summary, $html = '' ) {
		return array(
			'html'           => $this->truncate_text( (string) $html, 1400 ),
			'target'         => array( sanitize_text_field( (string) $selector ) ),
			'failureSummary' => sanitize_text_field( (string) $summary ),
			'any'            => array(),
		);
	}

	/**
	 * Build a reasonably stable CSS selector for a DOM element.
	 *
	 * @param DOMElement $element Element.
	 * @return string
	 */
	protected function css_selector_for_element( DOMElement $element ) {
		$id = trim( (string) $element->getAttribute( 'id' ) );
		if ( '' !== $id ) {
			return '#' . sanitize_html_class( $id );
		}

		$parts = array();
		$current = $element;
		$depth = 0;

		while ( $current instanceof DOMElement && $depth < 4 ) {
			$segment = strtolower( $current->tagName );
			$current_id = trim( (string) $current->getAttribute( 'id' ) );

			if ( '' !== $current_id ) {
				$segment = '#' . sanitize_html_class( $current_id );
				array_unshift( $parts, $segment );
				break;
			}

			$class_attr = trim( (string) $current->getAttribute( 'class' ) );
			if ( '' !== $class_attr && $depth < 2 ) {
				$classes = preg_split( '/\s+/', $class_attr );
				$classes = array_values(
					array_filter(
						array_map( 'sanitize_html_class', $classes )
					)
				);
				if ( ! empty( $classes ) ) {
					$segment .= '.' . $classes[0];
				}
			}

			$index = 1;
			$sibling = $current->previousSibling;
			while ( $sibling ) {
				if ( $sibling instanceof DOMElement && strtolower( $sibling->tagName ) === strtolower( $current->tagName ) ) {
					$index++;
				}
				$sibling = $sibling->previousSibling;
			}
			$segment .= ':nth-of-type(' . $index . ')';

			array_unshift( $parts, $segment );
			$current = $current->parentNode;
			$depth++;
		}

		return ! empty( $parts ) ? implode( ' > ', $parts ) : strtolower( $element->tagName );
	}

	/**
	 * Get outer HTML for a DOM element.
	 *
	 * @param DOMElement $element Element.
	 * @return string
	 */
	protected function dom_outer_html( DOMElement $element ) {
		$doc = $element->ownerDocument;
		if ( ! $doc ) {
			return '';
		}
		return trim( (string) $doc->saveHTML( $element ) );
	}

	/**
	 * Escape string literal for XPath expression.
	 *
	 * @param string $value Raw string.
	 * @return string
	 */
	protected function xpath_literal( $value ) {
		$value = (string) $value;
		if ( false === strpos( $value, "'" ) ) {
			return "'" . $value . "'";
		}
		if ( false === strpos( $value, '"' ) ) {
			return '"' . $value . '"';
		}
		$parts = explode( "'", $value );
		return "concat('" . implode( "',\"'\",'", $parts ) . "')";
	}

	/**
	 * Truncate long strings for storage.
	 *
	 * @param string $value Source value.
	 * @param int    $limit Max length.
	 * @return string
	 */
	protected function truncate_text( $value, $limit = 1200 ) {
		$value = (string) $value;
		if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
			if ( mb_strlen( $value ) <= $limit ) {
				return $value;
			}
			return mb_substr( $value, 0, $limit ) . '...';
		}
		if ( strlen( $value ) <= $limit ) {
			return $value;
		}
		return substr( $value, 0, $limit ) . '...';
	}

	/* ════════════════════════════════════════════════════════════
	   AUTO-FIXERS (60% of violations)
	   ════════════════════════════════════════════════════════════ */

	/**
	 * Auto-fix missing alt text on images.
	 * Updates Elementor image widget data in post meta.
	 *
	 * @param array $violation axe-core violation object.
	 * @return array|WP_Error
	 */
	protected function fix_image_alt( array $violation ) {
		$fixed   = 0;
		$details = array();

		foreach ( $violation['nodes'] ?? array() as $node ) {
			// Extract attachment ID from the image HTML.
			preg_match( '/class="[^"]*wp-image-(\d+)/', $node['html'] ?? '', $class_match );
			preg_match( '/src="([^"]+)"/', $node['html'] ?? '', $src_match );

			$attachment_id = ! empty( $class_match[1] ) ? (int) $class_match[1] : 0;
			$src           = $src_match[1] ?? '';

			if ( $attachment_id ) {
				// Infer alt from attachment title.
				$title      = get_the_title( $attachment_id );
				$suggested  = $title ?: $this->infer_alt_from_src( $src );

				// Update attachment alt text.
				$existing = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
				if ( empty( $existing ) ) {
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $suggested ) );
					$fixed++;
					$details[] = array( 'attachment_id' => $attachment_id, 'alt' => $suggested );
				}
			}
		}

		return array( 'fixed' => $fixed, 'details' => $details );
	}

	/**
	 * Auto-fix color contrast by appending CSS overrides to a child theme or custom CSS.
	 *
	 * @param array $violation axe-core violation object.
	 * @return array|WP_Error
	 */
	protected function fix_color_contrast( array $violation ) {
		$css_additions = array();

		foreach ( $violation['nodes'] ?? array() as $node ) {
			$selector = implode( ' ', (array) ( $node['target'][0] ?? '' ) );
			$data     = $node['any'][0]['data'] ?? array();
			$fg       = $data['fgColor']  ?? '';
			$bg       = $data['bgColor']  ?? '';

			if ( ! $selector || ! $fg ) {
				continue;
			}

			// Darken the foreground color by 35% to achieve ≥4.5:1 contrast.
			$adjusted = $this->darken_hex( $fg, 0.65 );
			$css_additions[] = sprintf( '%s { color: %s !important; }', esc_attr( $selector ), esc_attr( $adjusted ) );
		}

		if ( ! empty( $css_additions ) ) {
			$existing = get_option( 'respira_accessibility_custom_css', '' );
			$new_css  = $existing . "\n/* Respira auto-fix: color-contrast */\n" . implode( "\n", $css_additions );
			update_option( 'respira_accessibility_custom_css', $new_css );

			// Apply via wp_add_inline_style if a handle is available.
			add_action( 'wp_head', function() use ( $css_additions ) {
				echo '<style id="respira-a11y-contrast">' . esc_html( implode( "\n", $css_additions ) ) . '</style>';
			} );
		}

		return array( 'fixed' => count( $css_additions ), 'css' => $css_additions );
	}

	/**
	 * Auto-fix form labels by scanning post content and updating Elementor form widget data.
	 *
	 * @param array $violation
	 * @return array
	 */
	protected function fix_form_label( array $violation ) {
		// This is a complex DOM fix – return info for the AI prompt queue.
		return array(
			'fixed'   => 0,
			'message' => __( 'Form label fixes require AI prompt execution. Added to queue.', 'respira-for-wordpress' ),
			'queued'  => count( $violation['nodes'] ?? array() ),
		);
	}

	/**
	 * Fix heading order – removes skip levels in Elementor heading widgets.
	 *
	 * @param array $violation
	 * @return array
	 */
	protected function fix_heading_order( array $violation ) {
		return array(
			'fixed'   => 0,
			'message' => __( 'Heading order fixes require AI prompt execution. Added to queue.', 'respira-for-wordpress' ),
			'queued'  => count( $violation['nodes'] ?? array() ),
		);
	}

	/**
	 * Fix missing document title.
	 *
	 * @param array $violation
	 * @return array
	 */
	protected function fix_document_title( array $violation ) {
		// Ensure WordPress is rendering a title via wp_head.
		// This is usually already handled by themes, but we can ensure it.
		return array( 'fixed' => 0, 'message' => __( 'Document title is managed by your theme/SEO plugin.', 'respira-for-wordpress' ) );
	}

	/**
	 * Fix missing or invalid HTML lang attribute.
	 *
	 * @param array $violation
	 * @return array
	 */
	protected function fix_html_lang( array $violation ) {
		// WordPress sets lang via get_bloginfo('language') – verify.
		$lang = get_bloginfo( 'language' );
		return array( 'fixed' => 0, 'lang_set' => $lang, 'message' => __( 'WordPress manages the HTML lang attribute via Site Language settings.', 'respira-for-wordpress' ) );
	}

	/* ════════════════════════════════════════════════════════════
	   AJAX HANDLERS
	   ════════════════════════════════════════════════════════════ */

	/**
	 * AJAX: Run a scan (plugin-local is default, cloud optional by scan mode).
	 */
	public function ajax_run_scan() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'respira-for-wordpress' ) ), 403 );
		}

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url();
		if ( ! $url ) {
			$url = home_url();
		}

		// Run plugin scan flow (local by default, configurable via scan mode).
		$request = new WP_REST_Request( 'POST' );
		$request->set_param( 'url', $url );
		$request->set_param( 'level', 'AA' );
		$response = $this->rest_scan_page( $request );

		if ( ! is_wp_error( $response ) ) {
			$data = $response->get_data();
			$violations = isset( $data['violations'] ) && is_array( $data['violations'] ) ? $data['violations'] : array();
			$create_req = new WP_REST_Request( 'POST' );
			$create_req->set_param( 'url', $data['url'] ?? $url );
			$create_req->set_param( 'title', $data['title'] ?? '' );
			$create_req->set_param( 'violations', $violations );
			$create_req->set_param( 'prompts', $data['prompts'] ?? array() );
			$create_req->set_param( 'axeVersion', $data['axeVersion'] ?? '' );
			$create_req->set_param( 'timestamp', $data['timestamp'] ?? ( time() * 1000 ) );
			$create_req->set_param( 'pageContext', $data['pageContext'] ?? ( $data['page_context'] ?? null ) );
			$create_req->set_param( 'scanSource', $data['scanSource'] ?? ( $data['scan_source'] ?? '' ) );
			$create_req->set_param( 'postId', $data['postId'] ?? ( $data['post_id'] ?? 0 ) );
			$create_res = $this->rest_create_scan( $create_req );
			if ( ! is_wp_error( $create_res ) ) {
				$stored = $create_res->get_data();
				wp_send_json_success( array(
					'message' => sprintf(
						/* translators: %d: scan score */
						__( 'Scan complete. Score: %d. Results are shown below.', 'respira-for-wordpress' ),
						$stored['score'] ?? 0
					),
					'reload'  => true,
				) );
			}
			wp_send_json_success( array(
				'message' => __( 'Scan complete. Results are shown below.', 'respira-for-wordpress' ),
				'reload'  => true,
			) );
		}

		// Cloud endpoint is optional; plugin-local scanning remains the primary path.
		$code = $response->get_error_code();
		if ( 'scanner_not_configured' === $code ) {
			wp_send_json_success( array(
				'message'  => __( 'Cloud scanner endpoint is not configured. Local in-plugin scanner remains available and is now the default mode.', 'respira-for-wordpress' ),
				'scan_url' => $url,
			) );
		}

		wp_send_json_error( array(
			'message' => $response->get_error_message(),
		) );
	}

	/**
	 * AJAX: Apply auto-fixes.
	 */
	public function ajax_apply_fixes() {
		check_ajax_referer( 'respira_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'respira-for-wordpress' ), 403 );
		}

		$scan_id = isset( $_POST['scan_id'] ) ? sanitize_text_field( wp_unslash( $_POST['scan_id'] ) ) : '';

		if ( ! $scan_id ) {
			wp_send_json_error( __( 'scan_id is required.', 'respira-for-wordpress' ), 400 );
		}

		$request = new WP_REST_Request( 'POST' );
		$request->set_param( 'scan_id', $scan_id );
		$request->set_param( 'dry_run', false );

		$response = $this->rest_apply_fixes( $request );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( $response->get_error_message() );
		}

		wp_send_json_success( $response->get_data() );
	}

	/* ════════════════════════════════════════════════════════════
	   SCHEDULED SCAN
	   ════════════════════════════════════════════════════════════ */

	/**
	 * Run the weekly scheduled scan across key pages.
	 */
	public function run_scheduled_scan() {
		$pages_to_scan = apply_filters( 'respira_accessibility_pages_to_scan', array( home_url() ) );

		foreach ( $pages_to_scan as $url ) {
			// Scheduled execution hook placeholder. Scan orchestration can call
			// rest_scan_page() per URL and persist the returned payload.
			update_option( self::OPTION_LAST, gmdate( 'c' ) );
		}
	}

	/* ════════════════════════════════════════════════════════════
	   UTILITIES
	   ════════════════════════════════════════════════════════════ */

	/**
	 * Count violations by impact level.
	 *
	 * @param array $violations
	 * @return int[]
	 */
	protected function count_violations( array $violations ): array {
		$counts = array( 'critical' => 0, 'serious' => 0, 'moderate' => 0, 'minor' => 0 );

		foreach ( $violations as $v ) {
			$impact = $v['impact'] ?? 'minor';
			if ( isset( $counts[ $impact ] ) ) {
				$counts[ $impact ] += count( $v['nodes'] ?? array( array() ) );
			}
		}

		return $counts;
	}

	/**
	 * Infer alt text from image src URL.
	 *
	 * @param string $src
	 * @return string
	 */
	protected function infer_alt_from_src( string $src ): string {
		$filename = pathinfo( $src, PATHINFO_FILENAME );
		$alt      = preg_replace( '/-?\d+x\d+$/', '', $filename );
		$alt      = str_replace( array( '-', '_' ), ' ', $alt );
		$alt      = preg_replace( '/\s+/', ' ', trim( $alt ) );
		return ucfirst( $alt ) ?: __( 'Image', 'respira-for-wordpress' );
	}

	/**
	 * Darken a hex color by a given factor.
	 *
	 * @param string $hex    Hex color string (e.g. #E53E3E).
	 * @param float  $factor Factor to multiply RGB channels by (0.0–1.0).
	 * @return string Darkened hex color.
	 */
	protected function darken_hex( string $hex, float $factor ): string {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) !== 6 ) {
			return '#' . $hex;
		}
		$r = (int) round( hexdec( substr( $hex, 0, 2 ) ) * $factor );
		$g = (int) round( hexdec( substr( $hex, 2, 2 ) ) * $factor );
		$b = (int) round( hexdec( substr( $hex, 4, 2 ) ) * $factor );
		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}
}
