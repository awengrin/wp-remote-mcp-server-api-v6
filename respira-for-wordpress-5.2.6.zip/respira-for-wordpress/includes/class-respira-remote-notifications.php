<?php
/**
 * Remote notification bridge for Respira admin surfaces.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fetches push-style notifications from respira.press so the plugin can show
 * release notices without shipping another plugin code change each time.
 */
class Respira_Remote_Notifications {

	/**
	 * Cached plugin notifications transient key.
	 *
	 * @since 4.2.2
	 * @var string
	 */
	private const CACHE_KEY = 'respira_remote_plugin_notifications_v1';

	/**
	 * Cache lifetime in seconds.
	 *
	 * @since 4.2.2
	 * @var int
	 */
	private const CACHE_TTL = 1800;

	/**
	 * Base API endpoint used for public notification delivery.
	 *
	 * @since 4.2.2
	 * @var string
	 */
	private const ENDPOINT = 'https://www.respira.press/api/notifications';

	/**
	 * User-meta prefix for dismissed remote notices.
	 *
	 * @since 4.2.2
	 * @var string
	 */
	private const DISMISS_META_PREFIX = 'respira_remote_notice_';

	/**
	 * Get the first active plugin notice for the current user.
	 *
	 * @since 4.2.2
	 * @return array<string,mixed>|null
	 */
	public static function get_current_plugin_notice() {
		$user_id       = get_current_user_id();
		$notifications = self::get_notifications();

		if ( empty( $notifications ) ) {
			return null;
		}

		foreach ( $notifications as $notification ) {
			if ( empty( $notification['notice_key'] ) ) {
				continue;
			}

			if ( $user_id > 0 && self::is_notice_dismissed( $user_id, $notification['notice_key'] ) ) {
				continue;
			}

			return $notification;
		}

		return null;
	}

	/**
	 * Dismiss a remote notice for the current user.
	 *
	 * @since 4.2.2
	 * @param string $notice_key Notice key.
	 * @return bool
	 */
	public static function dismiss_notice_for_current_user( $notice_key ) {
		$user_id    = get_current_user_id();
		$notice_key = self::sanitize_notice_key( $notice_key );

		if ( $user_id <= 0 || '' === $notice_key ) {
			return false;
		}

		return false !== update_user_meta( $user_id, self::get_dismiss_meta_key( $notice_key ), gmdate( 'c' ) );
	}

	/**
	 * Fetch and normalize plugin notifications.
	 *
	 * @since 4.2.2
	 * @return array<int,array<string,mixed>>
	 */
	private static function get_notifications() {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$url = add_query_arg(
			array(
				'channel' => 'plugin',
				'limit'   => 3,
			),
			apply_filters( 'respira_remote_notifications_feed_url', self::ENDPOINT )
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 10,
				'redirection' => 3,
				'user-agent' => 'Respira-WordPress/' . ( defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : 'unknown' ),
				'headers'    => array(
					'Accept' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( $status < 200 || $status >= 300 ) {
			return array();
		}

		$payload = json_decode( wp_remote_retrieve_body( $response ), true );
		$items   = array();

		if ( ! empty( $payload['items'] ) && is_array( $payload['items'] ) ) {
			foreach ( $payload['items'] as $raw_item ) {
				$normalized = self::normalize_notification( $raw_item );
				if ( ! empty( $normalized ) ) {
					$items[] = $normalized;
				}
			}
		}

		set_transient( self::CACHE_KEY, $items, self::CACHE_TTL );

		return $items;
	}

	/**
	 * Normalize a remote notification payload.
	 *
	 * @since 4.2.2
	 * @param mixed $raw_item Raw notification payload.
	 * @return array<string,mixed>|null
	 */
	private static function normalize_notification( $raw_item ) {
		if ( ! is_array( $raw_item ) ) {
			return null;
		}

		$slug       = isset( $raw_item['slug'] ) ? sanitize_title( (string) $raw_item['slug'] ) : '';
		$id         = isset( $raw_item['id'] ) ? sanitize_key( (string) $raw_item['id'] ) : '';
		$notice_key = self::sanitize_notice_key( $slug ? $slug : $id );

		if ( '' === $notice_key ) {
			return null;
		}

		$cta_url = isset( $raw_item['ctaUrl'] ) ? self::normalize_url( (string) $raw_item['ctaUrl'] ) : '';

		return array(
			'notice_key'      => $notice_key,
			'id'              => $id ? $id : $notice_key,
			'slug'            => $slug ? $slug : null,
			'title'           => isset( $raw_item['title'] ) ? sanitize_text_field( (string) $raw_item['title'] ) : '',
			'message'         => isset( $raw_item['message'] ) ? sanitize_textarea_field( (string) $raw_item['message'] ) : '',
			'kind'            => isset( $raw_item['kind'] ) ? sanitize_key( (string) $raw_item['kind'] ) : 'release',
			'cta_label'       => isset( $raw_item['ctaLabel'] ) ? sanitize_text_field( (string) $raw_item['ctaLabel'] ) : __( 'Read update', 'respira-for-wordpress' ),
			'cta_url'         => $cta_url,
			'release_version' => isset( $raw_item['releaseVersion'] ) ? sanitize_text_field( (string) $raw_item['releaseVersion'] ) : '',
			'starts_at'       => isset( $raw_item['startsAt'] ) ? sanitize_text_field( (string) $raw_item['startsAt'] ) : '',
		);
	}

	/**
	 * Convert relative Respira URLs to absolute links for wp-admin.
	 *
	 * @since 4.2.2
	 * @param string $value URL candidate.
	 * @return string
	 */
	private static function normalize_url( $value ) {
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		if ( 0 === strpos( $value, '/' ) ) {
			return 'https://www.respira.press' . $value;
		}

		return esc_url_raw( $value );
	}

	/**
	 * Determine whether a notice was dismissed by the given user.
	 *
	 * @since 4.2.2
	 * @param int    $user_id    User ID.
	 * @param string $notice_key Notice key.
	 * @return bool
	 */
	private static function is_notice_dismissed( $user_id, $notice_key ) {
		return ! empty( get_user_meta( $user_id, self::get_dismiss_meta_key( $notice_key ), true ) );
	}

	/**
	 * Build the dismissal meta-key for a remote notice.
	 *
	 * @since 4.2.2
	 * @param string $notice_key Notice key.
	 * @return string
	 */
	private static function get_dismiss_meta_key( $notice_key ) {
		return self::DISMISS_META_PREFIX . self::sanitize_notice_key( $notice_key );
	}

	/**
	 * Sanitize a notice key for stable storage.
	 *
	 * @since 4.2.2
	 * @param string $value Key candidate.
	 * @return string
	 */
	private static function sanitize_notice_key( $value ) {
		return substr( sanitize_key( (string) $value ), 0, 120 );
	}
}
