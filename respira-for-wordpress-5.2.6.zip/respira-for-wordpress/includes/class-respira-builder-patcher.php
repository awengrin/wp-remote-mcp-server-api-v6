<?php
/**
 * V2 generic builder patch engine.
 *
 * @package Respira_For_WordPress
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Applies targeted builder patch operations using id/path/type matching.
 */
class Respira_Builder_Patcher {

	/**
	 * Apply operations to a builder payload.
	 *
	 * @param string $builder Builder slug/name.
	 * @param int    $post_id Post ID.
	 * @param array  $operations Operations list.
	 * @return array|WP_Error
	 */
	public function apply_patch( $builder, $post_id, $operations ) {
		if ( empty( $operations ) || ! is_array( $operations ) ) {
			return new WP_Error(
				'respira_patch_missing_operations',
				__( 'Patch operations are required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$builder_instance = Respira_Builder_Interface::get_builder( $builder );
		if ( is_wp_error( $builder_instance ) ) {
			return $builder_instance;
		}

		$structure = $builder_instance->extract_content( $post_id );
		if ( ! is_array( $structure ) ) {
			return new WP_Error(
				'respira_patch_invalid_structure',
				__( 'Builder structure could not be extracted.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		$results = array();
		$applied = 0;

		foreach ( $operations as $index => $operation ) {
			$identifier = isset( $operation['identifier'] ) && is_array( $operation['identifier'] ) ? $operation['identifier'] : array();
			$updates    = isset( $operation['updates'] ) && is_array( $operation['updates'] ) ? $operation['updates'] : array();

			if ( empty( $identifier ) || empty( $updates ) ) {
				return new WP_Error(
					'respira_patch_invalid_operation',
					sprintf(
						/* translators: %d: operation index */
						__( 'Operation %d requires identifier and updates.', 'respira-for-wordpress' ),
						$index
					),
					array( 'status' => 400 )
				);
			}

			$specialized = $this->apply_specialized_operation( $builder_instance, $structure, $identifier, $updates );
			if ( ! is_wp_error( $specialized ) ) {
				$structure  = $specialized['structure'];
				$results[]  = $specialized['result'];
				++$applied;
				continue;
			}

			$generic = $this->apply_generic_operation( $structure, $identifier, $updates );
			if ( is_wp_error( $generic ) ) {
				return $generic;
			}

			$structure = $generic['structure'];
			$results[] = $generic['result'];
			++$applied;
		}

		// Skip structure validation — the structure came from extract_content() (already valid)
		// and only targeted module modifications were applied via patch operations.
		$inject_result = $builder_instance->inject_content( $post_id, $structure, true );
		if ( is_wp_error( $inject_result ) ) {
			return $inject_result;
		}

		return array(
			'success'         => true,
			'applied'         => $applied,
			'operation_count' => count( $operations ),
			'operations'      => $results,
		);
	}

	/**
	 * Attempt builder-specific module update for existing implementations.
	 *
	 * @param Respira_Builder_Interface $builder_instance Builder instance.
	 * @param array                     $structure Structure.
	 * @param array                     $identifier Identifier.
	 * @param array                     $updates Updates.
	 * @return array|WP_Error
	 */
	private function apply_specialized_operation( $builder_instance, $structure, $identifier, $updates ) {
		if ( ! method_exists( $builder_instance, 'update_module' ) || ! method_exists( $builder_instance, 'find_module' ) ) {
			return new WP_Error( 'respira_patch_no_specialized', 'No specialized patch method.' );
		}

		$identifier_type  = null;
		$identifier_value = null;
		$match_content    = '';

		if ( isset( $identifier['id'] ) ) {
			$identifier_type  = 'id';
			$identifier_value = (string) $identifier['id'];
		} elseif ( isset( $identifier['path'] ) ) {
			$identifier_type  = 'path';
			$identifier_value = (string) $identifier['path'];
		} elseif ( isset( $identifier['type'] ) ) {
			$identifier_type  = 'type';
			$identifier_value = (string) $identifier['type'];
			$match_content    = isset( $identifier['match_content'] ) ? (string) $identifier['match_content'] : '';
		} elseif ( isset( $identifier['admin_label'] ) ) {
			$identifier_type  = 'admin_label';
			$identifier_value = (string) $identifier['admin_label'];
		} else {
			return new WP_Error( 'respira_patch_no_specialized', 'Unsupported specialized identifier.' );
		}

		if ( 'type' === $identifier_type && '' !== $match_content && ! isset( $updates['match_content'] ) ) {
			$updates['match_content'] = $match_content;
		}

		$updated = $builder_instance->update_module( $structure, $identifier_type, $identifier_value, $updates );
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		$found = $builder_instance->find_module( $updated, $identifier_type, $identifier_value, $match_content );

		return array(
			'structure' => $updated,
			'result'    => array(
				'match' => array(
					'identifier_type'  => $identifier_type,
					'identifier_value' => $identifier_value,
				),
				'target' => ( $found && ! is_wp_error( $found ) ) ? array(
					'path' => isset( $found['path_string'] ) ? $found['path_string'] : null,
					'type' => isset( $found['module']['type'] ) ? $found['module']['type'] : null,
					'id'   => $this->extract_node_id( isset( $found['module'] ) ? $found['module'] : array() ),
				) : null,
			),
		);
	}

	/**
	 * Apply generic operation via id/path/type matcher.
	 *
	 * @param array $structure Structure.
	 * @param array $identifier Identifier.
	 * @param array $updates Updates.
	 * @return array|WP_Error
	 */
	private function apply_generic_operation( $structure, $identifier, $updates ) {
		$found = $this->find_node( $structure, $identifier );
		if ( ! $found ) {
			return new WP_Error(
				'respira_patch_target_not_found',
				__( 'Patch target could not be resolved by id/path/type identifier.', 'respira-for-wordpress' ),
				array( 'status' => 404, 'identifier' => $identifier )
			);
		}

		$path_segments = $found['segments'];
		$target_node   = $found['node'];

		$patched_node = $this->recursive_merge( $target_node, $updates );
		$updated = $this->set_value_by_segments( $structure, $path_segments, $patched_node );

		return array(
			'structure' => $updated,
			'result'    => array(
				'match' => array(
					'identifier_type'  => $found['identifier_type'],
					'identifier_value' => $found['identifier_value'],
				),
				'target' => array(
					'path' => $this->segments_to_path( $path_segments ),
					'type' => isset( $patched_node['type'] ) ? $patched_node['type'] : null,
					'id'   => $this->extract_node_id( $patched_node ),
				),
			),
		);
	}

	/**
	 * Find target node by identifier.
	 *
	 * @param array $structure Structure.
	 * @param array $identifier Identifier.
	 * @return array|null
	 */
	private function find_node( $structure, $identifier ) {
		if ( isset( $identifier['path'] ) ) {
			$segments = $this->parse_path_segments( (string) $identifier['path'] );
			$node = $this->get_value_by_segments( $structure, $segments );
			if ( null !== $node ) {
				return array(
					'node'            => $node,
					'segments'        => $segments,
					'identifier_type' => 'path',
					'identifier_value' => (string) $identifier['path'],
				);
			}
		}

		$matches = $this->flatten_structure( $structure );

		if ( isset( $identifier['id'] ) ) {
			$id = (string) $identifier['id'];
			foreach ( $matches as $match ) {
				$node_id = $this->extract_node_id( $match['node'] );
				if ( null !== $node_id && (string) $node_id === $id ) {
					return array(
						'node'            => $match['node'],
						'segments'        => $match['segments'],
						'identifier_type' => 'id',
						'identifier_value' => $id,
					);
				}
			}
		}

		if ( isset( $identifier['type'] ) ) {
			$type          = (string) $identifier['type'];
			$match_content = isset( $identifier['match_content'] ) ? (string) $identifier['match_content'] : '';
			foreach ( $matches as $match ) {
				$node = $match['node'];
				if ( ! is_array( $node ) || ! isset( $node['type'] ) || (string) $node['type'] !== $type ) {
					continue;
				}
				if ( '' !== $match_content ) {
					$haystack = wp_json_encode( $node );
					if ( false === $haystack || false === strpos( $haystack, $match_content ) ) {
						continue;
					}
				}

				return array(
					'node'             => $node,
					'segments'         => $match['segments'],
					'identifier_type'  => 'type',
					'identifier_value' => $type,
				);
			}
		}

		return null;
	}

	/**
	 * Flatten nested structure into traversable nodes.
	 *
	 * @param mixed $value Value.
	 * @param array $segments Path segments.
	 * @return array
	 */
	private function flatten_structure( $value, $segments = array() ) {
		$matches = array();

		if ( is_array( $value ) ) {
			$matches[] = array(
				'node'     => $value,
				'segments' => $segments,
			);
			foreach ( $value as $key => $child ) {
				$next_segments = $segments;
				$next_segments[] = $key;
				$matches = array_merge( $matches, $this->flatten_structure( $child, $next_segments ) );
			}
		}

		return $matches;
	}

	/**
	 * Extract best-effort ID from node.
	 *
	 * @param mixed $node Node.
	 * @return string|null
	 */
	private function extract_node_id( $node ) {
		if ( ! is_array( $node ) ) {
			return null;
		}

		$id_keys = array( 'id', '_id', 'uid', 'uuid', 'element_id', 'node_id' );
		foreach ( $id_keys as $key ) {
			if ( isset( $node[ $key ] ) && '' !== (string) $node[ $key ] ) {
				return (string) $node[ $key ];
			}
		}

		if ( isset( $node['attributes'] ) && is_array( $node['attributes'] ) ) {
			foreach ( $id_keys as $key ) {
				if ( isset( $node['attributes'][ $key ] ) && '' !== (string) $node['attributes'][ $key ] ) {
					return (string) $node['attributes'][ $key ];
				}
			}
		}

		return null;
	}

	/**
	 * Recursive associative merge.
	 *
	 * @param mixed $base Base.
	 * @param mixed $patch Patch.
	 * @return mixed
	 */
	private function recursive_merge( $base, $patch ) {
		if ( ! is_array( $base ) || ! is_array( $patch ) ) {
			return $patch;
		}

		foreach ( $patch as $key => $value ) {
			if ( isset( $base[ $key ] ) && is_array( $base[ $key ] ) && is_array( $value ) ) {
				$base[ $key ] = $this->recursive_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}

		return $base;
	}

	/**
	 * Parse path into segments.
	 * Supports bracket or slash path notations.
	 *
	 * @param string $path Path.
	 * @return array
	 */
	private function parse_path_segments( $path ) {
		$path = trim( $path );
		if ( '' === $path ) {
			return array();
		}

		if ( false !== strpos( $path, '/' ) && false === strpos( $path, '[' ) ) {
			$parts = array_values( array_filter( explode( '/', $path ), 'strlen' ) );
			return array_map( array( $this, 'normalize_path_segment' ), $parts );
		}

		$normalized = str_replace( ']', '', $path );
		$normalized = str_replace( '[', '.', $normalized );
		$parts      = array_values( array_filter( explode( '.', $normalized ), 'strlen' ) );

		return array_map( array( $this, 'normalize_path_segment' ), $parts );
	}

	/**
	 * Normalize path segment.
	 *
	 * @param string $segment Segment.
	 * @return int|string
	 */
	private function normalize_path_segment( $segment ) {
		if ( preg_match( '/^\d+$/', (string) $segment ) ) {
			return (int) $segment;
		}

		return (string) $segment;
	}

	/**
	 * Get nested value by segments.
	 *
	 * @param mixed $value Value.
	 * @param array $segments Segments.
	 * @return mixed|null
	 */
	private function get_value_by_segments( $value, $segments ) {
		$current = $value;
		foreach ( $segments as $segment ) {
			if ( ! is_array( $current ) || ! array_key_exists( $segment, $current ) ) {
				return null;
			}
			$current = $current[ $segment ];
		}

		return $current;
	}

	/**
	 * Set nested value by segments.
	 *
	 * @param mixed $value Value.
	 * @param array $segments Segments.
	 * @param mixed $new_value New value.
	 * @return mixed
	 */
	private function set_value_by_segments( $value, $segments, $new_value ) {
		if ( empty( $segments ) ) {
			return $new_value;
		}

		$segment = array_shift( $segments );
		if ( ! is_array( $value ) ) {
			$value = array();
		}
		if ( ! array_key_exists( $segment, $value ) ) {
			$value[ $segment ] = array();
		}

		$value[ $segment ] = $this->set_value_by_segments( $value[ $segment ], $segments, $new_value );
		return $value;
	}

	/**
	 * Convert path segments to deterministic path string.
	 *
	 * @param array $segments Segments.
	 * @return string
	 */
	private function segments_to_path( $segments ) {
		$path = '';
		foreach ( $segments as $segment ) {
			if ( is_int( $segment ) ) {
				$path .= '[' . $segment . ']';
			} else {
				$path .= ( '' === $path ? '' : '.' ) . $segment;
			}
		}

		return $path;
	}
}
