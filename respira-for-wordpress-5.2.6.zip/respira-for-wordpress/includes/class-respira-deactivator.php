<?php
/**
 * Fired during plugin deactivation.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since 1.0.0
 */
class Respira_Deactivator {

	/**
	 * Deactivate the plugin.
	 *
	 * @since 1.0.0
	 */
	public static function deactivate() {
		// Flush rewrite rules.
		flush_rewrite_rules();

		// Clear any transients.
		delete_transient( 'respira_builder_info' );
		delete_transient( 'respira_site_context' );

		// Unschedule snapshots cleanup cron.
		wp_clear_scheduled_hook( 'respira_snapshot_cleanup_daily' );
	}
}
