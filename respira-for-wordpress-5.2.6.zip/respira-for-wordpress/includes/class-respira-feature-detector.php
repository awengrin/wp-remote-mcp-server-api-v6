<?php
/**
 * Feature Detection for Respira.
 *
 * Inspired by wp-ai-client patterns: Check capabilities before execution
 * to ensure features are supported before attempting to use them.
 * Provides provider-agnostic abstraction with automatic fallback selection.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      1.9.0
 */

/**
 * Feature Detection class.
 *
 * Provides methods to check if features are supported before execution,
 * following wp-ai-client patterns for provider-agnostic feature detection
 * with automatic fallback selection.
 *
 * @since 1.9.0
 */
class Respira_Feature_Detector {

	/**
	 * Check if page builder is supported and available.
	 *
	 * Uses provider-agnostic pattern: tries preferred builder, falls back
	 * to alternatives if not available (inspired by wp-ai-client).
	 *
	 * @since 1.9.0
	 * @param string|array $builder_preference Builder name or array of preferred builders in order.
	 * @param int          $post_id Optional. Post ID to check builder usage. Default 0.
	 * @return string|false Builder name if supported and available, false otherwise.
	 */
	public static function is_builder_supported( $builder_preference, $post_id = 0 ) {
		// If array provided, try each in order (automatic fallback pattern).
		if ( is_array( $builder_preference ) ) {
			foreach ( $builder_preference as $builder ) {
				$result = self::is_builder_supported( $builder, $post_id );
				if ( false !== $result ) {
					return $result;
				}
			}
			return false;
		}

		// Check if builder class exists.
		$builder_class = 'Respira_Builder_' . ucfirst( $builder_preference );
		if ( ! class_exists( $builder_class ) ) {
			return false;
		}

		// Check if builder is detected/active.
		$builder_instance = new $builder_class();
		if ( ! method_exists( $builder_instance, 'detect' ) || ! $builder_instance->detect() ) {
			return false;
		}

		// If post ID provided, check if builder is used for that post.
		if ( $post_id > 0 && method_exists( $builder_instance, 'is_builder_used' ) ) {
			if ( ! $builder_instance->is_builder_used( $post_id ) ) {
				return false;
			}
		}

		return $builder_preference;
	}

	/**
	 * Get available builders with automatic fallback order.
	 *
	 * Returns builders in order of preference, useful for automatic selection.
	 *
	 * @since 1.9.0
	 * @param int $post_id Optional. Post ID to check. Default 0.
	 * @return array Array of available builder names in preference order.
	 */
	public static function get_available_builders( $post_id = 0 ) {
		$all_builders = array(
			'elementor',
			'divi',
			'bricks',
			'oxygen',
			'thrive',
			'beaver',
			'brizy',
			'visual-composer',
			'wpbakery',
			'gutenberg',
		);

		$available = array();
		foreach ( $all_builders as $builder ) {
			if ( self::is_builder_supported( $builder, $post_id ) ) {
				$available[] = $builder;
			}
		}

		return $available;
	}

	/**
	 * Check if analysis feature is supported.
	 *
	 * @since 1.9.0
	 * @param string $analysis_type Analysis type (e.g., 'seo', 'performance', 'aeo').
	 * @return bool True if supported, false otherwise.
	 */
	public static function is_analysis_supported( $analysis_type ) {
		$supported_analyzers = array(
			'seo'           => 'Respira_SEO_Analyzer',
			'performance'   => 'Respira_Performance_Analyzer',
			'aeo'           => 'Respira_AEO_Analyzer',
		);

		if ( ! isset( $supported_analyzers[ $analysis_type ] ) ) {
			return false;
		}

		return class_exists( $supported_analyzers[ $analysis_type ] );
	}

	/**
	 * Check if operation is supported with feature detection.
	 *
	 * @since 1.9.0
	 * @param string $operation Operation type (e.g., 'update_page', 'duplicate_page').
	 * @param array  $context Optional. Context data for the operation.
	 * @return bool|WP_Error True if supported, WP_Error if not supported.
	 */
	public static function is_operation_supported( $operation, $context = array() ) {
		// All operations are supported in full version.
		$supported_operations = array(
			'update_page',
			'update_post',
			'get_page',
			'get_post',
			'list_pages',
			'list_posts',
			'duplicate_page',
			'duplicate_post',
			'delete_page',
			'delete_post',
			'upload_media',
			'extract_builder_content',
			'inject_builder_content',
			'update_module',
		);

		if ( in_array( $operation, $supported_operations, true ) ) {
			return true;
		}

		return new WP_Error(
			'respira_operation_not_supported',
			/* translators: %s: Operation name */
			sprintf( __( 'Operation "%s" is not supported.', 'respira-for-wordpress' ), $operation ),
			array(
				'operation' => $operation,
				'context'  => $context,
			)
		);
	}

	/**
	 * Get list of supported features.
	 *
	 * @since 1.9.0
	 * @return array Array of supported feature names.
	 */
	public static function get_supported_features() {
		return array(
			'all_page_builders',
			'page_management',
			'post_management',
			'media_upload',
			'duplicate_before_edit',
			'seo_analysis',
			'performance_analysis',
			'aeo_analysis',
			'extended_audit_log',
			'builder_intelligence',
		);
	}
}
