<?php
/**
 * Trial Status Helper
 * Fetches and displays trial status for WordPress plugin
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trial Status Helper Class
 */
class Respira_Trial_Status {

	/**
	 * Get trial status from API
	 * Uses WordPress transients for caching (12 hours)
	 *
	 * @return array|false Trial status data or false on error
	 */
	public static function get_trial_status() {
		$license_key = get_option( 'respira_license_key', '' );
		
		if ( empty( $license_key ) ) {
			return false;
		}

		// Check cache first
		$cache_key = 'respira_trial_status_' . md5( $license_key );
		$cached = get_transient( $cache_key );
		
		if ( $cached !== false ) {
			return $cached;
		}

		// Fetch from API
		$api_url = 'https://respira.press/api/user/trial-status';
		$response = wp_remote_get(
			$api_url,
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $license_key,
				),
				'timeout' => 10,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! $data || ! isset( $data['success'] ) || ! $data['success'] ) {
			return false;
		}

		$trial_status = array(
			'is_trial'      => isset( $data['is_trial'] ) ? (bool) $data['is_trial'] : false,
			'is_paid'       => isset( $data['is_paid'] ) ? (bool) $data['is_paid'] : false,
			'days_remaining' => isset( $data['days_remaining'] ) ? (int) $data['days_remaining'] : null,
			'trial_ends_at' => isset( $data['trial_ends_at'] ) ? $data['trial_ends_at'] : null,
			'status'        => isset( $data['status'] ) ? $data['status'] : 'unknown',
		);

		// Cache for 12 hours
		set_transient( $cache_key, $trial_status, 12 * HOUR_IN_SECONDS );

		return $trial_status;
	}

	/**
	 * Render trial badge HTML
	 *
	 * @return string HTML for trial badge
	 */
	public static function render_trial_badge() {
		$trial_status = self::get_trial_status();

		if ( ! $trial_status ) {
			return '';
		}

		// Hide for paid users
		if ( $trial_status['is_paid'] || ! $trial_status['is_trial'] ) {
			return '';
		}

		$days_remaining = $trial_status['days_remaining'];
		
		if ( $days_remaining === null ) {
			return '';
		}

		$dashboard_url = 'https://respira.press/dashboard?ref=plugin-trial';
		$days_text = $days_remaining === 1 ? 'day' : 'days';

		ob_start();
		?>
		<span class="respira-trial-badge">
			<span class="respira-trial-badge-text">
				Trial: <?php echo esc_html( $days_remaining ); ?> <?php echo esc_html( $days_text ); ?> left
			</span>
			<a href="<?php echo esc_url( $dashboard_url ); ?>" target="_blank" class="respira-trial-badge-link">
				Extend →
			</a>
		</span>
		<?php
		return ob_get_clean();
	}

	/**
	 * Clear trial status cache
	 * Call this when license status might have changed
	 */
	public static function clear_cache() {
		$license_key = get_option( 'respira_license_key', '' );
		if ( ! empty( $license_key ) ) {
			$cache_key = 'respira_trial_status_' . md5( $license_key );
			delete_transient( $cache_key );
		}
	}
}

