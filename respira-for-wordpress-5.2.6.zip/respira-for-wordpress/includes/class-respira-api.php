<?php
/**
 * REST API endpoints.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * REST API endpoints.
 *
 * Registers and handles all REST API endpoints for the plugin.
 *
 * @since 1.0.0
 */
class Respira_API {

	/**
	 * Format Respira-branded message.
	 *
	 * @since 1.9.0
	 * @param string $message The message to format.
	 * @param string $type Optional. Message type: 'success', 'error', 'info', 'warning'. Default 'info'.
	 * @return string The formatted message with "Respira says:" prefix.
	 */
	private function format_respira_message( $message, $type = 'info' ) {
		$prefix = __( 'Respira says:', 'respira-for-wordpress' );
		
		// Add emoji based on type
		$emoji = '';
		switch ( $type ) {
			case 'success':
				$emoji = '✅';
				break;
			case 'error':
				$emoji = '⚠️';
				break;
			case 'warning':
				$emoji = '🛡️';
				break;
			case 'info':
			default:
				$emoji = '💬';
				break;
		}
		
		return sprintf( '%s %s %s', $prefix, $emoji, $message );
	}

	/**
	 * Create a Respira-branded WP_Error.
	 *
	 * @since 1.9.0
	 * @param string $code Error code.
	 * @param string $message Error message (will be formatted with Respira branding).
	 * @param array  $data Optional. Error data.
	 * @param string $type Optional. Message type: 'error', 'warning', 'info'. Default 'error'.
	 * @return WP_Error The formatted error.
	 */
	private function respira_error( $code, $message, $data = array(), $type = 'error' ) {
		$formatted_message = $this->format_respira_message( $message, $type );
		$data['respira_message'] = $formatted_message;
		
		// Add helpful hints for common errors.
		if ( 'respira_page_not_found' === $code || 'respira_post_not_found' === $code ) {
			$data['hint'] = $this->format_respira_message( __( 'Double-check the ID? Use GET /pages or GET /posts to list available items.', 'respira-for-wordpress' ), 'info' );
		}
		
		return new WP_Error( $code, $formatted_message, $data );
	}

	/**
	 * Add footer to success messages.
	 *
	 * @since 1.8.0
	 * @param string $message The original success message.
	 * @return string The message with footer appended.
	 */
	private function add_success_footer( $message ) {
		$footer = __( 'Thank you for using Respira for WordPress | respira.press', 'respira-for-wordpress' );
		return $message . "\n\n" . $footer;
	}

	/**
	 * Get byte length for any payload without hard mbstring dependency.
	 *
	 * @since 4.0.3
	 * @param mixed $value Payload value.
	 * @return int
	 */
	private function get_payload_byte_length( $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			$value = wp_json_encode( $value );
		}

		if ( ! is_string( $value ) ) {
			$value = (string) $value;
		}

		if ( function_exists( 'mb_strlen' ) ) {
			return (int) mb_strlen( $value, '8bit' );
		}

		return (int) strlen( $value );
	}

	/**
	 * Run wp_update_post() with Respira API content-filter guards and exception handling.
	 *
	 * Some hosts/plugins throw uncaught exceptions during save_post, cache invalidation,
	 * or usage hooks when post_content changes. Convert those into structured WP errors
	 * so MCP clients get actionable diagnostics instead of a generic critical-error page.
	 *
	 * @since 4.2.1
	 * @param array  $update_data   Post update payload.
	 * @param string $action_type   Action label for diagnostics.
	 * @param string $resource_type Resource type label.
	 * @param int    $resource_id   Resource ID.
	 * @return int|WP_Error
	 */
	private function guarded_wp_update_post( $update_data, $action_type, $resource_type, $resource_id ) {
		$diagnostics = array(
			'action'         => (string) $action_type,
			'resource_type'  => (string) $resource_type,
			'resource_id'    => (int) $resource_id,
			'has_content'    => array_key_exists( 'post_content', $update_data ),
			'content_length' => array_key_exists( 'post_content', $update_data ) ? $this->get_payload_byte_length( $update_data['post_content'] ) : 0,
			'post_status'    => isset( $update_data['post_status'] ) ? (string) $update_data['post_status'] : '',
		);

		Respira_Content_Filter::set_api_update_context( true );
		$removed_filters    = Respira_Content_Filter::remove_content_filters();
		$removed_save_hooks = $this->remove_third_party_save_hooks();

		// Suppress WordPress auto-revision during this update.
		// Respira captures its own before/after snapshots, so WP revisions are
		// redundant. More importantly, the revision's wp_insert_post() fires
		// save_post on the revision post, which can crash builder hooks (e.g.
		// Beaver Builder's save_revision tries to access layout settings as an
		// array when they're stdClass objects from post meta).
		$suppress_revisions = static function () { return 0; };
		add_filter( 'wp_revisions_to_keep', $suppress_revisions, PHP_INT_MAX );

		// wp_update_post() internally calls wp_unslash() on all fields (legacy
		// magic-quotes compat). Pre-slash the data so backslashes round-trip
		// correctly — without this, Divi 5 \u003c escapes lose their backslash.
		$slashed_data = wp_slash( $update_data );

		try {
			$result = wp_update_post( $slashed_data, true );
		} catch ( Throwable $e ) {
			error_log(
				sprintf(
					'Respira guarded_wp_update_post fatal: action=%s resource=%s id=%d exception=%s message=%s trace=%s',
					(string) $action_type,
					(string) $resource_type,
					(int) $resource_id,
					get_class( $e ),
					$e->getMessage(),
					$e->getTraceAsString()
				)
			);

			return $this->respira_error(
				'respira_post_update_exception',
				__( 'A server exception interrupted the save operation.', 'respira-for-wordpress' ),
				array_merge(
					$diagnostics,
					array(
						'status'            => 500,
						'exception_type'    => get_class( $e ),
						'exception_message' => $e->getMessage(),
						'hint'              => __( 'Enable WP_DEBUG_LOG and inspect save_post/cache hooks if this persists. Third-party cache, security, or builder hooks can throw during wp_update_post().', 'respira-for-wordpress' ),
					)
				),
				'error'
			);
		} finally {
			remove_filter( 'wp_revisions_to_keep', $suppress_revisions, PHP_INT_MAX );
			$this->restore_third_party_save_hooks( $removed_save_hooks );
			Respira_Content_Filter::restore_content_filters( $removed_filters );
			Respira_Content_Filter::set_api_update_context( false );
		}

		if ( is_wp_error( $result ) ) {
			$error_code = $result->get_error_code();
			$error_data = $error_code ? $result->get_error_data( $error_code ) : null;
			$result->add_data(
				array_merge(
					is_array( $error_data ) ? $error_data : array(),
					$diagnostics
				),
				$error_code
			);
			return $result;
		}

		if ( ! $result ) {
			return $this->respira_error(
				'respira_post_update_failed',
				__( 'WordPress did not confirm the save operation.', 'respira-for-wordpress' ),
				array_merge( $diagnostics, array( 'status' => 500 ) ),
				'error'
			);
		}

		// Verify the write actually persisted to the database.
		$post_id = (int) $update_data['ID'];
		$verify_error = $this->verify_post_write( $post_id, $update_data, $diagnostics );
		if ( is_wp_error( $verify_error ) ) {
			return $verify_error;
		}

		return $result;
	}

	/**
	 * Build a human-readable snapshot label from a REST request.
	 *
	 * @since 5.0.7
	 * @param WP_REST_Request $request REST request.
	 * @return string|null Label or null if nothing meaningful.
	 */
	private function build_snapshot_label( $request ) {
		$parts = array();

		if ( $request->get_param( 'title' ) ) {
			$parts[] = 'title';
		}
		if ( $request->get_param( 'content' ) ) {
			$parts[] = 'content';
		}
		if ( $request->get_param( 'status' ) ) {
			$parts[] = 'status → ' . sanitize_text_field( $request->get_param( 'status' ) );
		}
		if ( $request->get_param( 'slug' ) ) {
			$parts[] = 'slug';
		}
		if ( $request->get_param( 'excerpt' ) ) {
			$parts[] = 'excerpt';
		}
		if ( $request->get_param( 'meta' ) ) {
			$parts[] = 'meta';
		}
		if ( $request->has_param( 'custom_css' ) ) {
			$parts[] = 'custom CSS';
		}
		if ( $request->has_param( 'seo' ) ) {
			$seo = $request->get_param( 'seo' );
			if ( is_array( $seo ) && ! empty( $seo ) ) {
				$parts[] = 'SEO';
			}
		}
		if ( $request->has_param( 'featured_image' ) ) {
			$parts[] = 'featured image';
		}

		if ( empty( $parts ) ) {
			return null;
		}

		return 'Updated ' . implode( ', ', $parts );
	}

	/**
	 * Remove third-party save_post and wp_insert_post_data hooks during API writes.
	 *
	 * Prevents page builders (Elementor, Divi, etc.) and other plugins from
	 * reverting content during wp_update_post(). Hooks are identified by class
	 * name — only Respira's own hooks and WordPress core hooks are preserved.
	 *
	 * @since 4.0.6
	 * @return array Removed hooks for later restoration.
	 */
	private function remove_third_party_save_hooks() {
		global $wp_filter;

		$removed = array();
		$hooks_to_clean = array(
			'save_post',
			'wp_insert_post_data',
			'wp_insert_post',
			'post_updated',
			'pre_post_update',
			'edit_post',
			'transition_post_status',
		);

		// Also remove post-type-specific save hooks (save_post_page, save_post_post, etc.).
		foreach ( array( 'page', 'post', 'product', 'revision' ) as $pt ) {
			$hooks_to_clean[] = 'save_post_' . $pt;
			$hooks_to_clean[] = 'edit_post_' . $pt;
		}

		$safe_prefixes = array( 'Respira_', 'respira_' );

		foreach ( $hooks_to_clean as $hook_name ) {
			if ( ! isset( $wp_filter[ $hook_name ] ) ) {
				continue;
			}

			foreach ( $wp_filter[ $hook_name ]->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $id => $callback ) {
					$func = $callback['function'];

					// Keep WordPress core callbacks (strings like 'wp_save_post_revision').
					if ( is_string( $func ) ) {
						continue;
					}

					// Keep Respira callbacks.
					if ( is_array( $func ) && isset( $func[0] ) ) {
						$class_name = is_object( $func[0] ) ? get_class( $func[0] ) : (string) $func[0];
						$is_respira = false;
						foreach ( $safe_prefixes as $prefix ) {
							if ( 0 === strpos( $class_name, $prefix ) ) {
								$is_respira = true;
								break;
							}
						}
						if ( $is_respira ) {
							continue;
						}
					}

					if ( remove_action( $hook_name, $func, $priority ) ) {
						$removed[] = array(
							'hook'     => $hook_name,
							'function' => $func,
							'priority' => $priority,
							'args'     => $callback['accepted_args'] ?? 1,
						);
					}
				}
			}
		}

		return $removed;
	}

	/**
	 * Restore third-party save hooks removed by remove_third_party_save_hooks().
	 *
	 * @since 4.0.6
	 * @param array $removed Hooks previously removed.
	 * @return void
	 */
	private function restore_third_party_save_hooks( $removed ) {
		foreach ( $removed as $hook ) {
			add_action(
				$hook['hook'],
				$hook['function'],
				$hook['priority'],
				$hook['args']
			);
		}
	}

	/**
	 * Verify that a post write actually persisted to the database.
	 *
	 * Reads directly from $wpdb to bypass object cache and confirm the
	 * database contains the expected data. Returns WP_Error if the write
	 * was silently reverted (e.g. by a save_post hook or DB issue).
	 *
	 * @since 4.0.6
	 * @param int   $post_id     Post ID.
	 * @param array $update_data Data that was passed to wp_update_post.
	 * @param array $diagnostics Diagnostic context for error reporting.
	 * @return null|WP_Error Null on success, WP_Error if verification fails.
	 */
	private function verify_post_write( $post_id, $update_data, $diagnostics ) {
		global $wpdb;

		$db_row = $wpdb->get_row(
			$wpdb->prepare( "SELECT post_title, post_content, post_status, post_modified FROM {$wpdb->posts} WHERE ID = %d", $post_id )
		);

		if ( ! $db_row ) {
			return $this->respira_error(
				'respira_post_write_verify_missing',
				__( 'Post not found in database after update.', 'respira-for-wordpress' ),
				array_merge( $diagnostics, array( 'status' => 500 ) ),
				'error'
			);
		}

		$mismatches = array();

		if ( isset( $update_data['post_title'] ) && $db_row->post_title !== $update_data['post_title'] ) {
			$mismatches['post_title'] = array(
				'expected_length' => strlen( $update_data['post_title'] ),
				'actual_length'   => strlen( $db_row->post_title ),
			);
		}

		if ( isset( $update_data['post_content'] ) ) {
			// We pre-slash before wp_update_post, so DB should match the original value.
			$expected = $update_data['post_content'];
			if ( $db_row->post_content !== $expected ) {
				$mismatches['post_content'] = array(
					'expected_length' => strlen( $expected ),
					'actual_length'   => strlen( $db_row->post_content ),
				);
			}
		}

		if ( isset( $update_data['post_status'] ) && $db_row->post_status !== $update_data['post_status'] ) {
			$mismatches['post_status'] = array(
				'expected' => $update_data['post_status'],
				'actual'   => $db_row->post_status,
			);
		}

		if ( ! empty( $mismatches ) ) {
			error_log(
				sprintf(
					'Respira write verification failed: post_id=%d action=%s mismatches=%s',
					$post_id,
					$diagnostics['action'] ?? 'unknown',
					wp_json_encode( $mismatches )
				)
			);

			return $this->respira_error(
				'respira_post_write_silently_reverted',
				__( 'The update appeared to succeed but the changes were not persisted. A third-party plugin (e.g. Elementor, a caching plugin, or a security plugin) may have reverted the write via a save_post hook.', 'respira-for-wordpress' ),
				array_merge(
					$diagnostics,
					array(
						'status'     => 500,
						'mismatches' => $mismatches,
						'hint'       => __( 'Check WP_DEBUG_LOG for details. Common causes: Elementor regenerating post_content from _elementor_data, object cache returning stale data, or a security plugin blocking writes to duplicate pages.', 'respira-for-wordpress' ),
					)
				),
				'error'
			);
		}

		// Ensure the object cache reflects the verified DB state.
		clean_post_cache( $post_id );

		return null;
	}

	/**
	 * Track usage without letting telemetry failures break a user write.
	 *
	 * @since 4.2.1
	 * @param string $action_type   Usage action.
	 * @param string $resource_type Resource type.
	 * @param int    $resource_id   Resource ID.
	 * @param mixed  $content       Optional content for line-count estimation.
	 * @param string $license_key   Optional license key.
	 * @return void
	 */
	private function track_usage_safe( $action_type, $resource_type, $resource_id, $content = null, $license_key = null, $extra = array() ) {
		try {
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-usage-tracker.php';
			Respira_Usage_Tracker::track( $action_type, $resource_type, $resource_id, $content, $license_key, $extra );
		} catch ( Throwable $e ) {
			error_log(
				sprintf(
					'Respira usage tracking failed: action=%s resource=%s id=%d exception=%s message=%s',
					(string) $action_type,
					(string) $resource_type,
					(int) $resource_id,
					get_class( $e ),
					$e->getMessage()
				)
			);
		}
	}

	/**
	 * Register REST API routes.
	 *
	 * @since 1.0.0
	 */
	public function register_routes() {
		// Force UTF-8 passthrough in REST JSON responses so multibyte characters
		// (Chinese, Japanese, Arabic, etc.) are returned as readable text instead
		// of \uXXXX escape sequences. Without this, the MCP server double-escapes
		// them, making the content unreadable for users.
		add_filter( 'rest_pre_serve_request', array( $this, 'serve_utf8_json' ), 10, 4 );

		// Purge frontend caches when a duplicate is approved (content goes live).
		add_action( 'respira_after_approve_duplicate', array( $this, 'on_duplicate_approved_purge_caches' ), 10, 2 );

		// Governance + per-key access enforcement for REST API routes (single chokepoint).
		add_filter( 'rest_pre_dispatch', array( $this, 'enforce_tool_governance' ), 10, 3 );

		// Authentication endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/auth/generate-key',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'generate_api_key' ),
				'permission_callback' => array( $this, 'admin_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/auth/validate-key',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'validate_api_key' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/auth/revoke-key/(?P<key_id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'revoke_api_key' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Site context endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/context/site-info',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_site_info' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/context/theme-docs',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_theme_docs' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/context/builder-info',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_builder_info' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Page endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_pages' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_page' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_page' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'suffix' => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Register PUT method for page updates
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_page' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title'              => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'content'            => array(
						'type' => 'string',
					),
					'status'             => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'custom_css'         => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_custom_css' ),
						'description'       => 'Custom CSS for the page (stored in Divi _et_pb_custom_css or Elementor _elementor_page_settings.custom_css)',
					),
					'seo'                => array(
						'type'        => 'object',
						'description' => 'SEO meta tags (title, description, OG tags, Twitter cards, etc.)',
					),
					'featured_image'     => array(
						'type'        => 'object',
						'description' => 'Featured image data (url or id, plus alt and title)',
					),
					'meta'               => array(
						'type' => 'object',
					),
					'force'              => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'skip_security_check' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		// Register POST method for page updates (compatibility with WordPress REST API)
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'update_page' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title'              => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'content'            => array(
						'type' => 'string',
					),
					'status'             => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'custom_css'         => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_custom_css' ),
						'description'       => 'Custom CSS for the page (stored in Divi _et_pb_custom_css or Elementor _elementor_page_settings.custom_css)',
					),
					'seo'                => array(
						'type'        => 'object',
						'description' => 'SEO meta tags (title, description, OG tags, Twitter cards, etc.)',
					),
					'featured_image'     => array(
						'type'        => 'object',
						'description' => 'Featured image data (url or id, plus alt and title)',
					),
					'meta'               => array(
						'type' => 'object',
					),
					'force'              => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'skip_security_check' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/pages/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_page' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Post endpoints (similar to pages).
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_posts' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Register PUT method for post updates
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title'              => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'content'            => array(
						'type' => 'string',
					),
					'status'             => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'custom_css'         => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_custom_css' ),
						'description'       => 'Custom CSS for the post (stored in Divi _et_pb_custom_css or Elementor _elementor_page_settings.custom_css)',
					),
					'seo'                => array(
						'type'        => 'object',
						'description' => 'SEO meta tags (title, description, OG tags, Twitter cards, etc.)',
					),
					'featured_image'     => array(
						'type'        => 'object',
						'description' => 'Featured image data (url or id, plus alt and title)',
					),
					'meta'               => array(
						'type' => 'object',
					),
					'force'              => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'skip_security_check' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		// Register POST method for post updates (compatibility with WordPress REST API)
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'update_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title'              => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'content'            => array(
						'type' => 'string',
					),
					'status'             => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'custom_css'         => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_custom_css' ),
						'description'       => 'Custom CSS for the post (stored in Divi _et_pb_custom_css or Elementor _elementor_page_settings.custom_css)',
					),
					'seo'                => array(
						'type'        => 'object',
						'description' => 'SEO meta tags (title, description, OG tags, Twitter cards, etc.)',
					),
					'featured_image'     => array(
						'type'        => 'object',
						'description' => 'Featured image data (url or id, plus alt and title)',
					),
					'meta'               => array(
						'type' => 'object',
					),
					'force'              => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'skip_security_check' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/posts/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Media endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_media' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media/upload',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'upload_media' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Page builder endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/builder/(?P<builder>[a-zA-Z0-9_-]+)/extract/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'extract_builder_content' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/builder/(?P<builder>[a-zA-Z0-9_-]+)/inject/(?P<page_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'inject_builder_content' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/builder/(?P<builder>[a-zA-Z0-9_-]+)/modules/(?P<page_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_builder_module' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Validation endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/validate/security',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'validate_security' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Audit log endpoint.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/audit/logs',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_audit_logs' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		// Page Speed Analysis endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/performance/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_performance' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/core-web-vitals/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_core_web_vitals' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/images/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_images' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// SEO Analysis endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/seo/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_seo' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/seo-issues/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'check_seo_issues' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/readability/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_readability' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/rankmath/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_rankmath' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// AEO Analysis endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/aeo/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'analyze_aeo' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/analyze/structured-data/(?P<page_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'check_structured_data' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Plugin Management endpoints (Experimental).
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_plugins' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins/install',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'install_plugin' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'slug_or_url' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'source'      => array(
						'required' => false,
						'type'     => 'string',
						'default'  => 'wordpress.org',
						'enum'     => array( 'wordpress.org', 'url' ),
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins/(?P<slug>[a-zA-Z0-9_-]+)/activate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'activate_plugin' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins/(?P<slug>[a-zA-Z0-9_-]+)/deactivate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'deactivate_plugin' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins/(?P<slug>[a-zA-Z0-9_-]+)/update',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'update_plugin' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/plugins/(?P<slug>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_plugin' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Users Management endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/users',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_users' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/users/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_user' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/users',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_user' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/users/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_user' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/users/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_user' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Comments endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/comments',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_comments' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/comments/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_comment' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/comments',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_comment' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/comments/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_comment' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/comments/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_comment' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Taxonomies endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_taxonomies' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_taxonomy' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_terms' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_term' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_term' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_term' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/taxonomies/(?P<taxonomy>[a-zA-Z0-9_-]+)/terms/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_term' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Custom Post Types endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_post_types' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_post_type' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_custom_posts' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => $this->get_list_args(),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_custom_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_custom_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_custom_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_custom_post' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Options/Settings endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/options',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_options' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/options/(?P<option>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_option' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/options/(?P<option>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'update_option' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/options/(?P<option>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_option' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Media enhancements endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_media' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_media' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_media' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/media/batch',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_media_batch' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Menu Management endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_menus' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_menu' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_menu' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'name' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'description' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_menu' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'name' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'description' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_menu' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Menu Locations endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/locations',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_menu_locations' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/locations/(?P<location>[a-zA-Z0-9_-]+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'assign_menu_to_location' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'menu_id' => array(
						'required' => true,
						'type'     => 'integer',
					),
				),
			)
		);

		// Menu Items endpoints.
		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/(?P<menu_id>\d+)/items',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_menu_items' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/(?P<menu_id>\d+)/items',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_menu_item' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'url' => array(
						'type'              => 'string',
						'sanitize_callback' => 'esc_url_raw',
					),
					'object_type' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Type: custom, post_type, taxonomy',
					),
					'object' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Object: page, post, category, etc.',
					),
					'object_id' => array(
						'type' => 'integer',
					),
					'parent_id' => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'position' => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'target' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => '_blank for new window',
					),
					'classes' => array(
						'type' => 'array',
					),
					'attr_title' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'description' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/items/(?P<item_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_menu_item' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/items/(?P<item_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_menu_item' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'title' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'url' => array(
						'type'              => 'string',
						'sanitize_callback' => 'esc_url_raw',
					),
					'parent_id' => array(
						'type' => 'integer',
					),
					'position' => array(
						'type' => 'integer',
					),
					'target' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'classes' => array(
						'type' => 'array',
					),
					'attr_title' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'description' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE,
			'/menus/items/(?P<item_id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_menu_item' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		// Register v2 fidelity/snapshot routes (v1 remains unchanged).
		$this->register_v2_routes();

		// Register v2 element-level operations (WS1/WS4 — Elemental).
		$this->register_element_ops_routes();

		// Register _et_pb_custom_css meta field for standard WordPress REST API.
		// This allows updating custom CSS via /wp-json/wp/v2/pages/{id} with meta._et_pb_custom_css.
		$this->register_custom_css_rest_field();
	}

	/**
	 * Register _et_pb_custom_css meta field for WordPress REST API.
	 *
	 * This enables updating Divi's custom CSS field via the standard
	 * WordPress REST API at /wp-json/wp/v2/pages/{id} and /wp-json/wp/v2/posts/{id}
	 * using BOTH:
	 * 1. meta._et_pb_custom_css parameter (standard WordPress meta approach)
	 * 2. _et_pb_custom_css as top-level field (for convenience)
	 *
	 * @since 1.8.43
	 */
	private function register_custom_css_rest_field() {
		$post_types = array( 'page', 'post' );

		foreach ( $post_types as $post_type ) {
			// Register as post meta (enables meta._et_pb_custom_css in REST API).
			register_post_meta(
				$post_type,
				'_et_pb_custom_css',
				array(
					'type'              => 'string',
					'description'       => __( 'Divi Builder Custom CSS', 'respira-for-wordpress' ),
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => array( $this, 'sanitize_custom_css' ),
					'auth_callback'     => function( $allowed, $meta_key, $post_id ) {
						return current_user_can( 'edit_post', $post_id );
					},
				)
			);

			// Also register as top-level field (for convenience).
			register_rest_field(
				$post_type,
				'_et_pb_custom_css',
				array(
					'get_callback'    => array( $this, 'get_custom_css_field' ),
					'update_callback' => array( $this, 'update_custom_css_field' ),
					'schema'          => array(
						'type'        => 'string',
						'description' => __( 'Divi Builder Custom CSS. Can also be updated via Respira API with custom_css parameter.', 'respira-for-wordpress' ),
						'context'     => array( 'view', 'edit' ),
					),
				)
			);
		}
	}

	/**
	 * Get callback for _et_pb_custom_css REST field.
	 *
	 * @since 1.8.43
	 * @param array $post Post data array.
	 * @return string Custom CSS content.
	 */
	public function get_custom_css_field( $post ) {
		return get_post_meta( $post['id'], '_et_pb_custom_css', true ) ?: '';
	}

	/**
	 * Update callback for _et_pb_custom_css REST field.
	 *
	 * @since 1.8.43
	 * @param string  $value   The new CSS value.
	 * @param WP_Post $post    The post object.
	 * @param string  $field   The field name.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function update_custom_css_field( $value, $post, $field ) {
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to edit this post.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		// Sanitize the CSS.
		$sanitized_css = $this->sanitize_custom_css( $value );

		// Update the meta field.
		update_post_meta( $post->ID, '_et_pb_custom_css', $sanitized_css );

		// Also update Elementor's CSS field if Elementor is active.
		if ( defined( 'ELEMENTOR_VERSION' ) || class_exists( '\Elementor\Plugin' ) ) {
			update_post_meta( $post->ID, '_elementor_css', $sanitized_css );
		}

		return true;
	}

	/**
	 * Permission callback for admin users.
	 *
	 * @since 1.0.0
	 * @return bool True if user can manage options.
	 */
	public function admin_permission_check() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Permission callback that validates API key from header.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return bool|WP_Error True if valid, WP_Error otherwise.
	 */
	public function api_key_permission_check( $request ) {
		$api_key = $request->get_header( 'X-Respira-API-Key' );

		// Also check Authorization header (Bearer token format).
		if ( empty( $api_key ) ) {
			$auth_header = $request->get_header( 'Authorization' );
			if ( ! empty( $auth_header ) && preg_match( '/Bearer\s+(.*)$/i', $auth_header, $matches ) ) {
				$api_key = $matches[1];
			}
		}

		$validation = Respira_Auth::validate_api_key( $api_key );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		if ( ! is_array( $validation ) ) {
			$validation = array();
		}

		$sanitize_header_token = static function ( $value, $pattern = '/[^a-zA-Z0-9\.\-\+_]/' ) {
			if ( ! is_string( $value ) ) {
				return '';
			}
			$value = trim( $value );
			$value = preg_replace( $pattern, '', $value );
			return substr( (string) $value, 0, 64 );
		};

		$mcp_version = $sanitize_header_token( $request->get_header( 'X-Respira-MCP-Version' ) );
		if ( ! empty( $mcp_version ) ) {
			$validation['mcp_version'] = $mcp_version;
		}

		$agent_client = strtolower(
			$sanitize_header_token(
				$request->get_header( 'X-Respira-Agent-Client' ),
				'/[^a-zA-Z0-9\.\-\+_\/]/'
			)
		);
		if ( ! empty( $agent_client ) ) {
			$validation['agent_client'] = $agent_client;
		}

		$agent_version = $sanitize_header_token( $request->get_header( 'X-Respira-Agent-Version' ) );
		if ( ! empty( $agent_version ) ) {
			$validation['agent_version'] = $agent_version;
		}

		$agent_transport = strtolower(
			$sanitize_header_token(
				$request->get_header( 'X-Respira-Agent-Transport' ),
				'/[^a-zA-Z0-9\.\-\+_]/'
			)
		);
		if ( ! empty( $agent_transport ) ) {
			$validation['agent_transport'] = $agent_transport;
		}

		$agent_source = strtolower(
			$sanitize_header_token(
				$request->get_header( 'X-Respira-Agent-Source' ),
				'/[^a-zA-Z0-9\.\-\+_]/'
			)
		);
		if ( ! empty( $agent_source ) ) {
			$validation['agent_source'] = $agent_source;
		}

		// Authenticate the WordPress user associated with this API key.
		// This ensures current_user_can() checks pass for REST API requests,
		// which fixes 'rest_forbidden' errors on non-public post types like
		// elementor_library when security plugins or WordPress core enforce
		// capability checks before the endpoint handler runs.
		if ( ! empty( $validation['user_id'] ) ) {
			wp_set_current_user( $validation['user_id'] );
		}

		// Store key data in request for later use.
		$request->set_param( '_respira_key_data', $validation );

		// Mirror request key metadata in global query vars for legacy tracker lookups.
		global $wp;
		if ( isset( $wp ) && is_object( $wp ) ) {
			if ( ! isset( $wp->query_vars ) || ! is_array( $wp->query_vars ) ) {
				$wp->query_vars = array();
			}
			$wp->query_vars['_respira_key_data'] = $validation;
		}

		return true;
	}

	/**
	 * Check site-wide governance AND per-key access profile for a tool.
	 *
	 * Call this at the start of every endpoint handler to enforce both layers:
	 * 1. Governance: site-wide kill switch (blocks for ALL keys).
	 * 2. Per-key scope: access profile assigned at key generation time.
	 *
	 * Returns null if allowed, or a WP_Error if denied.
	 *
	 * @since 5.2.0
	 * @param string          $tool_name Canonical tool name (e.g. 'list_pages').
	 * @param WP_REST_Request $request   The request object (must have _respira_key_data set).
	 * @return null|WP_Error Null if access granted, WP_Error if denied.
	 */
	public function check_tool_access( $tool_name, $request ) {
		// 1. Site-wide governance check.
		if ( class_exists( 'Respira_Tool_Governance' ) && ! Respira_Tool_Governance::is_tool_allowed( $tool_name ) ) {
			return new WP_Error(
				'respira_governance_denied',
				sprintf(
					/* translators: %s: tool name */
					__( 'The "%s" tool has been disabled by the site administrator via Governance rules.', 'respira-for-wordpress' ),
					$tool_name
				),
				array( 'status' => 403 )
			);
		}

		// 2. Per-key access profile check.
		$key_data = $request->get_param( '_respira_key_data' );
		if ( $key_data && class_exists( 'Respira_Tool_Governance' ) ) {
			$allowed_tools = Respira_Auth::get_allowed_tools( $key_data );
			if ( ! Respira_Tool_Governance::is_tool_allowed_for_key( $tool_name, $allowed_tools ) ) {
				return new WP_Error(
					'respira_key_scope_denied',
					sprintf(
						/* translators: %s: tool name */
						__( 'This API key does not have access to the "%s" tool. Generate a new key with a broader access profile.', 'respira-for-wordpress' ),
						$tool_name
					),
					array( 'status' => 403 )
				);
			}
		}

		return null;
	}

	/**
	 * Map REST route pattern + HTTP method to a governance tool name.
	 *
	 * Returns the canonical tool name used in Respira_Tool_Governance,
	 * or null if the route is not governed (e.g. auth endpoints).
	 *
	 * @since 5.2.0
	 * @return array Route-method => canonical tool name.
	 */
	private static function get_route_tool_map() {
		static $map = null;
		if ( null !== $map ) {
			return $map;
		}

		$map = array(
			// Context.
			'GET:/context/site-info'     => 'get_site_context',
			'GET:/context/theme-docs'    => 'get_theme_docs',
			'GET:/context/builder-info'  => 'get_builder_info',

			// Pages.
			'GET:/pages'                 => 'list_pages',
			'GET:/pages/{id}'            => 'read_page',
			'POST:/pages/{id}/duplicate' => 'create_page_duplicate',
			'PUT:/pages/{id}'            => 'update_page',
			'POST:/pages/{id}'           => 'update_page',
			'DELETE:/pages/{id}'         => 'delete_page',

			// Posts.
			'GET:/posts'                 => 'list_posts',
			'GET:/posts/{id}'            => 'read_post',
			'POST:/posts/{id}/duplicate' => 'create_post_duplicate',
			'PUT:/posts/{id}'            => 'update_post',
			'POST:/posts/{id}'           => 'update_post',
			'DELETE:/posts/{id}'         => 'delete_post',

			// Media.
			'GET:/media'                 => 'list_media',
			'POST:/media/upload'         => 'upload_media',
			'GET:/media/{id}'            => 'get_media',
			'PUT:/media/{id}'            => 'update_media',
			'DELETE:/media/{id}'         => 'delete_media',

			// Builder.
			'GET:/builder/{b}/extract/{id}'  => 'extract_builder_content',
			'POST:/builder/{b}/inject/{id}'  => 'inject_builder_content',
			'PUT:/builder/{b}/modules/{id}'  => 'update_module',

			// Validation.
			'POST:/validate/security'    => 'validate_security',

			// Analysis.
			'GET:/analyze/performance/{id}'     => 'analyze_performance',
			'GET:/analyze/core-web-vitals/{id}' => 'get_core_web_vitals',
			'GET:/analyze/images/{id}'          => 'analyze_images',
			'GET:/analyze/seo/{id}'             => 'analyze_seo',
			'GET:/analyze/seo-issues/{id}'      => 'check_seo_issues',
			'GET:/analyze/readability/{id}'     => 'analyze_readability',
			'GET:/analyze/rankmath/{id}'        => 'analyze_readability',
			'GET:/analyze/aeo/{id}'             => 'analyze_aeo',
			'GET:/analyze/structured-data/{id}' => 'check_structured_data',

			// Plugins.
			'GET:/plugins'                       => 'list_plugins',
			'POST:/plugins/install'              => 'install_plugin',
			'POST:/plugins/{slug}/activate'      => 'activate_plugin',
			'POST:/plugins/{slug}/deactivate'    => 'deactivate_plugin',
			'POST:/plugins/{slug}/update'        => 'update_plugin',
			'DELETE:/plugins/{slug}'             => 'delete_plugin',

			// Users.
			'GET:/users'                 => 'list_users',
			'GET:/users/{id}'            => 'get_user',
			'POST:/users'                => 'create_user',
			'PUT:/users/{id}'            => 'update_user',
			'DELETE:/users/{id}'         => 'delete_user',

			// Menus.
			'GET:/menus'                 => 'list_menus',
			'GET:/menus/{id}'            => 'get_menu',
			'POST:/menus'                => 'create_menu',
			'PUT:/menus/{id}'            => 'update_menu',
			'DELETE:/menus/{id}'         => 'delete_menu',
			'GET:/menus/locations'       => 'list_menu_locations',
			'PUT:/menus/locations/{loc}' => 'assign_menu_location',
			'GET:/menus/{id}/items'      => 'list_menu_items',
			'POST:/menus/{id}/items'     => 'create_menu_item',
			'GET:/menus/items/{id}'      => 'get_menu_item',
			'PUT:/menus/items/{id}'      => 'update_menu_item',
			'DELETE:/menus/items/{id}'   => 'delete_menu_item',

			// Element-level operations (v2).
			'POST:/builder/elements/find/{id}'      => 'find_element',
			'POST:/builder/elements/update/{id}'    => 'update_element',
			'POST:/builder/elements/move/{id}'      => 'move_element',
			'POST:/builder/elements/duplicate/{id}' => 'duplicate_element',
			'POST:/builder/elements/remove/{id}'    => 'remove_element',
			'POST:/builder/elements/batch/{id}'     => 'batch_update',
			'POST:/builder/elements/reorder/{id}'   => 'reorder_elements',
			'POST:/builder/build'                   => 'build_page',

			// Stock images (v2).
			'GET:/stock-images/search'    => 'search_stock_images',
			'POST:/stock-images/sideload' => 'sideload_image',

			// Snapshots (v2).
			'GET:/snapshots'              => 'list_snapshots',
			'GET:/snapshots/{id}'         => 'get_snapshot',
			'POST:/snapshots/diff'        => 'diff_snapshots',
			'POST:/snapshots/restore'     => 'restore_snapshot',
		);

		return $map;
	}

	/**
	 * Normalize a REST route by replacing numeric/slug segments with placeholders.
	 *
	 * @since 5.2.0
	 * @param string $route  The REST route (e.g. '/respira/v1/pages/42').
	 * @return string Normalized route (e.g. '/pages/{id}').
	 */
	private static function normalize_route( $route ) {
		// Strip the namespace prefix.
		$route = preg_replace( '#^/respira/v[12]#', '', $route );

		// Replace snapshot UUIDs before numeric replacement (UUIDs contain hex digits).
		$route = preg_replace( '#/snapshots/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}#', '/snapshots/{id}', $route );

		// Replace numeric segments with {id}.
		$route = preg_replace( '#/\d+#', '/{id}', $route );

		// Replace slug segments in known positions (plugins, builder, taxonomies, etc.).
		// Builder: /builder/{builder_name}/extract/{id}
		$route = preg_replace( '#^/builder/[^/]+/([^/]+)#', '/builder/{b}/$1', $route );

		// Plugins: /plugins/{slug}/action.
		$route = preg_replace( '#^/plugins/[a-zA-Z0-9_-]+/(activate|deactivate|update)$#', '/plugins/{slug}/$1', $route );
		$route = preg_replace( '#^/plugins/[a-zA-Z0-9_-]+$#', '/plugins/{slug}', $route );

		// Menu locations: /menus/locations/{location}.
		$route = preg_replace( '#^/menus/locations/[a-zA-Z0-9_-]+$#', '/menus/locations/{loc}', $route );

		return $route;
	}

	/**
	 * REST pre-dispatch filter: enforce governance + per-key access on all Respira routes.
	 *
	 * Runs AFTER the permission callback (api_key_permission_check) but BEFORE
	 * the endpoint handler. This is the single chokepoint for the REST API path.
	 *
	 * @since 5.2.0
	 * @param mixed           $result  Response to replace the requested response with, or null.
	 * @param WP_REST_Server  $server  Server instance.
	 * @param WP_REST_Request $request Current request.
	 * @return mixed|WP_Error Null to continue, WP_Error to short-circuit.
	 */
	public function enforce_tool_governance( $result, $server, $request ) {
		// Only intercept Respira namespace routes.
		$route = $request->get_route();
		if ( 0 !== strpos( $route, '/respira/v' ) ) {
			return $result;
		}

		// Already short-circuited by another filter.
		if ( null !== $result ) {
			return $result;
		}

		$method          = $request->get_method();
		$normalized      = self::normalize_route( $route );
		$map             = self::get_route_tool_map();
		$lookup          = $method . ':' . $normalized;
		$tool_name       = isset( $map[ $lookup ] ) ? $map[ $lookup ] : null;

		// Route not in governance map — allow (e.g. auth endpoints, audit logs).
		if ( ! $tool_name ) {
			return $result;
		}

		$access_error = $this->check_tool_access( $tool_name, $request );
		if ( is_wp_error( $access_error ) ) {
			return $access_error;
		}

		return $result;
	}

	/**
	 * Generate API key endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function generate_api_key( $request ) {
		$name = $request->get_param( 'name' );
		$api_key = Respira_Auth::generate_api_key( get_current_user_id(), $name );

		if ( is_wp_error( $api_key ) ) {
			return $api_key;
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'api_key' => $api_key,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'API key generated successfully! Save this key securely - it won\'t be shown again.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Validate API key endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function validate_api_key( $request ) {
		$api_key    = $request->get_param( 'api_key' );
		$validation = Respira_Auth::validate_api_key( $api_key );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'valid'   => true,
				'message' => __( 'API key is valid.', 'respira-for-wordpress' ),
			),
			200
		);
	}

	/**
	 * Revoke API key endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function revoke_api_key( $request ) {
		$key_id = $request->get_param( 'key_id' );
		$result = Respira_Auth::revoke_api_key( $key_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

			return new WP_REST_Response(
				array(
					'success' => true,
					'message' => $this->add_success_footer( $this->format_respira_message( __( 'API key revoked successfully. That key is now inactive.', 'respira-for-wordpress' ), 'success' ) ),
				),
				200
			);
	}

	/**
	 * Get site information endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function get_site_info( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_site_info', 'context', null );

		$context = Respira_Context::get_site_info();

		return new WP_REST_Response( $context, 200 );
	}

	/**
	 * Get theme documentation endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function get_theme_docs( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_theme_docs', 'context', null );

		$docs = Respira_Context::get_theme_docs();

		return new WP_REST_Response( $docs, 200 );
	}

	/**
	 * Get page builder information endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function get_builder_info( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_builder_info', 'context', null );

		$builder_info = Respira_Context::get_builder_info();

		return new WP_REST_Response( $builder_info, 200 );
	}

	/**
	 * List pages endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_pages( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$args = array(
			'post_type'      => 'page',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending' ),
			'posts_per_page' => $request->get_param( 'per_page' ) ?? 20,
			'paged'          => $request->get_param( 'page' ) ?? 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'suppress_filters' => false, // Allow filters but we'll control them.
		);

		// Temporarily disable WPML's query modifications to ensure we get actual pages.
		$wpml_filter_removed = false;
		if ( has_filter( 'pre_get_posts', 'WPML_Query_Filter' ) || class_exists( 'SitePress' ) ) {
			// WPML modifies queries - ensure post_type stays as 'page'.
			add_filter( 'pre_get_posts', array( $this, 'force_page_post_type' ), 999 );
			$wpml_filter_removed = true;
		}

		$query = new WP_Query( $args );

		// Remove our temporary filter.
		if ( $wpml_filter_removed ) {
			remove_filter( 'pre_get_posts', array( $this, 'force_page_post_type' ), 999 );
		}
		$pages = array();

		foreach ( $query->posts as $post ) {
			$pages[] = $this->format_post_response( $post );
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_pages', 'page', null );

		return new WP_REST_Response(
			array(
				'pages'       => $pages,
				'total'       => $query->found_posts,
				'total_pages' => $query->max_num_pages,
			),
			200
		);
	}

	/**
	 * Get single page endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_page( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$page_id  = $request->get_param( 'id' );

		$post = get_post( $page_id );

		if ( ! $post || 'page' !== $post->post_type ) {
			return $this->respira_error(
				'respira_page_not_found',
				__( 'Oops! That page doesn\'t exist. Double-check the ID?', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_page', 'page', $page_id );

		return new WP_REST_Response( $this->format_post_response( $post, true ), 200 );
	}

	/**
	 * Duplicate page endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function duplicate_page( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$page_id  = $request->get_param( 'id' );
		$suffix   = $request->get_param( 'suffix' ) ?? '_duplicate_' . time();

		$duplicate_id = Respira_Duplicator::duplicate_post( $page_id, $suffix );

		if ( is_wp_error( $duplicate_id ) ) {
			return $duplicate_id;
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'duplicate_page', 'page', $duplicate_id );

		$duplicate_post = get_post( $duplicate_id );

		return new WP_REST_Response(
			array(
				'success'   => true,
				'duplicate'    => $this->format_post_response( $duplicate_post, true ),
				'message'      => $this->add_success_footer( $this->format_respira_message( __( 'Page duplicated successfully! You can now edit the duplicate safely. When ready, approve it in Respira → Changes.', 'respira-for-wordpress' ), 'success' ) ),
				'approval_url' => admin_url( 'admin.php?page=respira-changes' ),
			),
			201
		);
	}

	/**
	 * Update page endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_page( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$page_id  = $request->get_param( 'id' );
		$content  = $request->get_param( 'content' );

		// Security check: ensure this is a duplicate page.
		$post = get_post( $page_id );
		if ( ! $post ) {
			return new WP_Error(
				'respira_page_not_found',
				__( 'Page not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		// Check if page was created by Respira (has duplicate marker in meta).
		$is_duplicate = get_post_meta( $page_id, '_respira_duplicate', true );
		$force        = $request->get_param( 'force' );
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );
		$post_type_label = 'page' === $post->post_type ? __( 'page', 'respira-for-wordpress' ) : __( 'post', 'respira-for-wordpress' );
		$auto_duplicate_created = false;
		$original_id = $page_id;

		// If not a duplicate, ALWAYS create a duplicate first (safety requirement).
		if ( ! $is_duplicate ) {
			// Check if a duplicate already exists.
			$existing_duplicates = Respira_Duplicator::get_duplicates( $page_id );
			
			if ( ! empty( $existing_duplicates ) ) {
				// Use the first existing duplicate.
				$duplicate_id = $existing_duplicates[0]->ID;
				$error_data = Respira_Approver::get_approval_error_data( $page_id );
				return new WP_Error(
					'respira_duplicate_exists',
					sprintf(
						/* translators: 1: post type label, 2: page ID, 3: duplicate ID */
						__( 'Cannot edit original %1$s (ID: %2$d). A duplicate already exists (ID: %3$d). Please edit the duplicate instead.', 'respira-for-wordpress' ),
						$post_type_label,
						$page_id,
						$duplicate_id
					),
					array_merge( $error_data, array(
						'duplicate_id' => $duplicate_id,
						'instructions' => array(
							sprintf(
								/* translators: 1: duplicate ID */
								__( 'Edit the duplicate %1$s (ID: %2$d) instead of the original.', 'respira-for-wordpress' ),
								$post_type_label,
								$duplicate_id
							),
								__( 'After editing, approve the duplicate in WordPress admin to apply the changes live.', 'respira-for-wordpress' ),
						),
					) )
				);
			}

				$auto_duplicate = get_option( 'respira_auto_duplicate', 1 );

				// Direct edit mode: allow_direct_edit=1 AND auto_duplicate=0.
				// Writes go straight to the original without creating a duplicate.
				if ( $allow_direct_edit && ! $auto_duplicate ) {
					Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'direct_edit_page', 'page', $page_id );
				} elseif ( $force && $allow_direct_edit ) {
					// If force=true is requested, require explicit confirm_live_edit intent.
					if ( ! $this->has_live_edit_confirmation( $request ) ) {
						$error_data = Respira_Approver::get_approval_error_data( $page_id );
						return new WP_Error(
							'respira_live_edit_confirmation_required',
							sprintf(
								/* translators: 1: post type label, 2: page ID */
								__( 'Directly editing live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true, or edit the duplicate instead.', 'respira-for-wordpress' ),
								$post_type_label,
								$page_id
							),
							array_merge(
								$error_data,
								array(
									'confirm_live_edit_required' => true,
									'instructions'               => array(
										__( 'You are targeting live content directly.', 'respira-for-wordpress' ),
										__( 'To continue, call the same endpoint with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
										__( 'Recommended: edit the duplicate instead for safe review and approval.', 'respira-for-wordpress' ),
									),
								)
							)
						);
					}
					Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'force_edit_page', 'page', $page_id );
				} else {
				// Auto-duplicate mode - create duplicate and queue for approval.
				$suffix = '_duplicate_' . time();
				$duplicate_id = Respira_Duplicator::duplicate_post( $page_id, $suffix );

				if ( is_wp_error( $duplicate_id ) ) {
					return $duplicate_id;
				}

				// Log the automatic duplication.
				Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'auto_duplicate_page', 'page', $duplicate_id );

				// Switch to editing the duplicate instead of the original.
				$page_id = $duplicate_id;
				$post = get_post( $page_id );
				$is_duplicate = true;
				$auto_duplicate_created = true;

				// Continue with the update below - we'll add a note in the response.
			}
		}

		// Validate content if security checks are enabled and not skipped.
		$skip_security = $request->get_param( 'skip_security_check' );
		if ( get_option( 'respira_security_checks', 1 ) && ! $skip_security ) {
			if ( $content ) {
				$security_check = Respira_Security::validate_content( $content );
				if ( is_wp_error( $security_check ) ) {
					return $security_check;
				}
			}
		}

		// Update core post fields only when they are explicitly provided.
		// This avoids triggering save_post for meta-only updates.
		$update_data = array(
			'ID' => $page_id,
		);
		$has_core_updates = false;

		if ( $request->get_param( 'title' ) ) {
			$update_data['post_title'] = sanitize_text_field( $request->get_param( 'title' ) );
			$has_core_updates          = true;
		}

		if ( $request->get_param( 'content' ) ) {
			if ( $skip_security ) {
				// Explicit opt-out for advanced builder workflows.
				$update_data['post_content'] = (string) $request->get_param( 'content' );
			} else {
				// Use API-specific sanitization that allows scripts and modern web features.
				$update_data['post_content'] = $this->sanitize_api_content( $request->get_param( 'content' ) );
			}
			$has_core_updates            = true;
		}

		if ( $request->get_param( 'status' ) ) {
			$update_data['post_status'] = sanitize_text_field( $request->get_param( 'status' ) );
			$has_core_updates           = true;
		}

		if ( $request->get_param( 'slug' ) ) {
			$update_data['post_name'] = sanitize_title( $request->get_param( 'slug' ) );
			$has_core_updates         = true;
		}

		// Capture WP revision and Respira snapshot before edit.
		if ( $has_core_updates ) {
			if ( ! $is_duplicate && function_exists( 'wp_save_post_revision' ) ) {
				wp_save_post_revision( $page_id );
			}
			if ( class_exists( 'Respira_Snapshots' ) ) {
				$snap_kind = $is_duplicate ? 'before_edit' : 'before_live_edit';
				Respira_Snapshots::get_instance()->capture_snapshot(
					$page_id,
					$snap_kind,
					array( 'actor_api_key_id' => $key_data['id'] ?? null )
				);
			}
		}

		if ( $has_core_updates ) {
			$result = $this->guarded_wp_update_post( $update_data, 'update_page', 'page', $page_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		// Update meta if provided.
		$meta_updated = false;
		if ( $request->get_param( 'meta' ) ) {
			$meta_updated = $this->update_post_meta_fields( $page_id, $request->get_param( 'meta' ) );
		}

		// Elementor can invalidate per-post CSS in save_post flows; clear stale cache
		// after API meta writes so CSS can be regenerated cleanly.
		if ( $meta_updated ) {
			$this->maybe_clear_elementor_css_cache_for_post( $page_id );
		}

		// Update custom CSS if provided (Divi Builder and Elementor support).
		if ( $request->has_param( 'custom_css' ) ) {
			$custom_css = $request->get_param( 'custom_css' );

			// Detect which page builder is being used.
			$builder = Respira_Builder_Interface::detect_builder( $page_id );
			$builder_name = $builder ? $builder->get_name() : '';

			if ( 'Elementor' === $builder_name ) {
				// Elementor stores custom CSS in _elementor_page_settings.custom_css.
				$this->save_elementor_custom_css( $page_id, $custom_css );
			} elseif ( '' === $custom_css ) {
				// Clear CSS for Divi.
				delete_post_meta( $page_id, '_et_pb_custom_css' );
			} else {
				// Default to Divi's meta field.
				update_post_meta( $page_id, '_et_pb_custom_css', $custom_css );
			}
		}

		// Update SEO meta if provided.
		if ( $request->has_param( 'seo' ) ) {
			$seo_data = $request->get_param( 'seo' );
			if ( is_array( $seo_data ) && ! empty( $seo_data ) ) {
				$this->update_seo_meta( $page_id, $seo_data );
			}
		}

		// Update featured image if provided.
		if ( $request->has_param( 'featured_image' ) ) {
			$image_data = $request->get_param( 'featured_image' );
			if ( is_array( $image_data ) && ! empty( $image_data ) ) {
				$this->update_featured_image( $page_id, $image_data );
			}
		}

		// Capture after-edit snapshot with label.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind  = $is_duplicate ? 'after_edit' : 'after_live_edit';
			$snap_label = $this->build_snapshot_label( $request );
			Respira_Snapshots::get_instance()->capture_snapshot(
				$page_id,
				$snap_kind,
				array(
					'actor_api_key_id' => $key_data['id'] ?? null,
					'label'            => $snap_label,
				)
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_page', 'page', $page_id );

		// Track usage stat (non-blocking).
		// PRIVACY: Only aggregate statistics are sent - actual content is NEVER transmitted.
		// See class-respira-usage-tracker.php for detailed privacy documentation.
		// Pass license key from API key data if available.
		$license_key = $key_data['license_key'] ?? null;
		$this->track_usage_safe( 'update_page', 'page', $page_id, $content, $license_key );

		clean_post_cache( $page_id );

		// Purge frontend page caches on live edits so visitors see changes immediately.
		if ( ! $is_duplicate ) {
			$this->purge_frontend_caches( $page_id );
		}

		$updated_post = get_post( $page_id );
		$approvals_url = admin_url( 'admin.php?page=respira-changes' );

		$response_data = array(
			'success' => true,
			'page'    => $this->format_post_response( $updated_post, true ),
			'message' => $this->add_success_footer( $this->format_respira_message( __( 'Page updated successfully! Your changes are safe and sound.', 'respira-for-wordpress' ), 'success' ) ),
		);
		
		// Add note if duplicate was auto-created.
		if ( $auto_duplicate_created ) {
			$response_data['duplicate_created'] = true;
			$response_data['duplicate_id'] = $page_id;
			$response_data['original_id'] = $original_id;
			$response_data['approval_url'] = $approvals_url;
			$response_data['message'] = $this->add_success_footer( $this->format_respira_message( sprintf(
				/* translators: 1: post type label, 2: duplicate ID */
				__( 'I created a duplicate %1$s for safety (ID: %2$d). Review it in WordPress admin before approving to make it live.', 'respira-for-wordpress' ),
				$post_type_label,
				$page_id
			), 'warning' ) );
			$response_data['instructions'] = array(
				$this->format_respira_message( __( 'A duplicate was automatically created for safety.', 'respira-for-wordpress' ), 'warning' ),
				sprintf(
					/* translators: 1: post type label, 2: duplicate ID, 3: original ID */
					__( '📋 Duplicate %1$s ID: %2$d | Original ID: %3$d', 'respira-for-wordpress' ),
					$post_type_label,
					$page_id,
					$original_id
				),
				sprintf(
					/* translators: 1: approvals URL */
					__( '👀 Review and approve: %1$s', 'respira-for-wordpress' ),
					$approvals_url
				),
				__( '💡 Tip: Changes are on the duplicate. Approve it to make them live.', 'respira-for-wordpress' ),
			);
		}

		$response = new WP_REST_Response( $response_data, 200 );
		
		// Add response headers for better debugging.
		if ( $auto_duplicate_created ) {
			$response->header( 'X-Respira-Duplicate-Created', 'true' );
			$response->header( 'X-Respira-Duplicate-ID', (string) $page_id );
			$response->header( 'X-Respira-Original-ID', (string) $original_id );
			$response->header( 'X-Respira-Approval-URL', $approvals_url );
		} else {
			$response->header( 'X-Respira-Duplicate-Created', 'false' );
		}

		return $response;
	}

	/**
	 * Delete page endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_page( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$page_id  = $request->get_param( 'id' );

		// Only allow deletion of Respira duplicates unless forced.
		$is_duplicate = get_post_meta( $page_id, '_respira_duplicate', true );
		$force        = $request->get_param( 'force' );
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );

			// If not a duplicate, check if we can delete it.
			if ( ! $is_duplicate ) {
				// If force is requested but direct editing is disabled, return error with instructions.
				if ( $force && ! $allow_direct_edit ) {
					$error_data = Respira_Approver::get_approval_error_data( $page_id );
					$post       = get_post( $page_id );
					return new WP_Error(
						'respira_direct_edit_disabled',
						sprintf(
							/* translators: 1: post type label */
							__( 'Cannot delete original %1$s. Direct editing of original pages is disabled in settings. Only Respira duplicates can be deleted.', 'respira-for-wordpress' ),
							$post && 'page' === $post->post_type ? __( 'page', 'respira-for-wordpress' ) : __( 'post', 'respira-for-wordpress' )
						),
						$error_data
					);
				}

				// Direct delete of originals requires explicit confirmation when enabled.
				if ( $force && $allow_direct_edit && ! $this->has_live_edit_confirmation( $request ) ) {
					$error_data = Respira_Approver::get_approval_error_data( $page_id );
					$post       = get_post( $page_id );
					return new WP_Error(
						'respira_live_edit_confirmation_required',
						sprintf(
							/* translators: 1: post type label, 2: page ID */
							__( 'Directly deleting live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
							$post && 'page' === $post->post_type ? __( 'page', 'respira-for-wordpress' ) : __( 'post', 'respira-for-wordpress' ),
							$page_id
						),
						array_merge(
							$error_data,
							array(
								'confirm_live_edit_required' => true,
								'instructions'               => array(
									__( 'This action will delete the original live item.', 'respira-for-wordpress' ),
									__( 'To continue, call the same endpoint with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
								),
							)
						)
					);
				}

				// If force is not requested, return error with instructions.
				if ( ! $force ) {
				$error_data = Respira_Approver::get_approval_error_data( $page_id );
				$post = get_post( $page_id );
				$message = sprintf(
					/* translators: 1: post type label, 2: page ID */
					__( 'Cannot delete original %1$s (ID: %2$d). Only Respira duplicates can be deleted.', 'respira-for-wordpress' ),
					$post && 'page' === $post->post_type ? __( 'page', 'respira-for-wordpress' ) : __( 'post', 'respira-for-wordpress' ),
					$page_id
				);

				return new WP_Error(
					'respira_not_duplicate',
					$message,
					$error_data
				);
			}
		}

		$result = wp_delete_post( $page_id, true );

		if ( ! $result ) {
			return new WP_Error(
				'respira_delete_failed',
				__( 'Failed to delete page.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_page', 'page', $page_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Page deleted successfully. It\'s gone for good!', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List posts endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_posts( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$args = array(
			'post_type'      => 'post',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending' ),
			'posts_per_page' => $request->get_param( 'per_page' ) ?? 20,
			'paged'          => $request->get_param( 'page' ) ?? 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'suppress_filters' => false, // Allow filters but we'll control them.
		);

		// Temporarily disable WPML's query modifications to ensure we get actual posts.
		$wpml_filter_removed = false;
		if ( has_filter( 'pre_get_posts', 'WPML_Query_Filter' ) || class_exists( 'SitePress' ) ) {
			// WPML modifies queries - ensure post_type stays as 'post'.
			add_filter( 'pre_get_posts', array( $this, 'force_post_post_type' ), 999 );
			$wpml_filter_removed = true;
		}

		$query = new WP_Query( $args );

		// Remove our temporary filter.
		if ( $wpml_filter_removed ) {
			remove_filter( 'pre_get_posts', array( $this, 'force_post_post_type' ), 999 );
		}

		$posts = array();

		foreach ( $query->posts as $post ) {
			$posts[] = $this->format_post_response( $post );
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_posts', 'post', null );

		return new WP_REST_Response(
			array(
				'posts'       => $posts,
				'total'       => $query->found_posts,
				'total_pages' => $query->max_num_pages,
			),
			200
		);
	}

	/**
	 * Get single post endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id  = $request->get_param( 'id' );

		$post = get_post( $post_id );

		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_post', 'post', $post_id );

		return new WP_REST_Response( $this->format_post_response( $post, true ), 200 );
	}

	/**
	 * Duplicate post endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function duplicate_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id  = $request->get_param( 'id' );
		$suffix   = $request->get_param( 'suffix' ) ?? '_duplicate_' . time();

		$duplicate_id = Respira_Duplicator::duplicate_post( $post_id, $suffix );

		if ( is_wp_error( $duplicate_id ) ) {
			return $duplicate_id;
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'duplicate_post', 'post', $duplicate_id );

		$duplicate_post = get_post( $duplicate_id );

		return new WP_REST_Response(
			array(
				'success'   => true,
				'duplicate'    => $this->format_post_response( $duplicate_post, true ),
				'message'      => $this->add_success_footer( $this->format_respira_message( __( 'Post duplicated successfully! You can now edit the duplicate safely. When ready, approve it in Respira → Changes.', 'respira-for-wordpress' ), 'success' ) ),
				'approval_url' => admin_url( 'admin.php?page=respira-changes' ),
			),
			201
		);
	}

	/**
	 * Update post endpoint.
	 *
	 * @since 1.2.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id  = $request->get_param( 'id' );
		$content  = $request->get_param( 'content' );

		// Security check: ensure this is a duplicate post.
		$post = get_post( $post_id );
		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		// Check if post was created by Respira (has duplicate marker in meta).
		$is_duplicate = get_post_meta( $post_id, '_respira_duplicate', true );
		$force        = $request->get_param( 'force' );
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );
		$post_type_label = __( 'post', 'respira-for-wordpress' );
		$auto_duplicate_created = false;
		$original_id = $post_id;

		// If not a duplicate, ALWAYS create a duplicate first (safety requirement).
		if ( ! $is_duplicate ) {
			// Check if a duplicate already exists.
			$existing_duplicates = Respira_Duplicator::get_duplicates( $post_id );
			
			if ( ! empty( $existing_duplicates ) ) {
				// Use the first existing duplicate.
				$duplicate_id = $existing_duplicates[0]->ID;
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_duplicate_exists',
					sprintf(
						/* translators: 1: post type label, 2: post ID, 3: duplicate ID */
						__( 'Cannot edit original %1$s (ID: %2$d). A duplicate already exists (ID: %3$d). Please edit the duplicate instead.', 'respira-for-wordpress' ),
						$post_type_label,
						$post_id,
						$duplicate_id
					),
					array_merge( $error_data, array(
						'duplicate_id' => $duplicate_id,
						'instructions' => array(
							sprintf(
								/* translators: 1: duplicate ID */
								__( 'Edit the duplicate %1$s (ID: %2$d) instead of the original.', 'respira-for-wordpress' ),
								$post_type_label,
								$duplicate_id
							),
								__( 'After editing, approve the duplicate in WordPress admin to apply the changes live.', 'respira-for-wordpress' ),
						),
					) )
				);
			}

				$auto_duplicate = get_option( 'respira_auto_duplicate', 1 );

				// Direct edit mode: allow_direct_edit=1 AND auto_duplicate=0.
				if ( $allow_direct_edit && ! $auto_duplicate ) {
					Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'direct_edit_post', 'post', $post_id );
				} elseif ( $force && $allow_direct_edit ) {
					// If force=true is requested, require explicit confirm_live_edit intent.
					if ( ! $this->has_live_edit_confirmation( $request ) ) {
						$error_data = Respira_Approver::get_approval_error_data( $post_id );
						return new WP_Error(
							'respira_live_edit_confirmation_required',
							sprintf(
								/* translators: 1: post type label, 2: post ID */
								__( 'Directly editing live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true, or edit the duplicate instead.', 'respira-for-wordpress' ),
								$post_type_label,
								$post_id
							),
							array_merge(
								$error_data,
								array(
									'confirm_live_edit_required' => true,
									'instructions'               => array(
										__( 'You are targeting live content directly.', 'respira-for-wordpress' ),
										__( 'To continue, call the same endpoint with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
										__( 'Recommended: edit the duplicate instead for safe review and approval.', 'respira-for-wordpress' ),
									),
								)
							)
						);
					}
					Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'force_edit_post', 'post', $post_id );
				} else {
				// Auto-duplicate mode - create duplicate and queue for approval.
				$suffix = '_duplicate_' . time();
				$duplicate_id = Respira_Duplicator::duplicate_post( $post_id, $suffix );
				
				if ( is_wp_error( $duplicate_id ) ) {
					return $duplicate_id;
				}
				
				// Log the automatic duplication.
				Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'auto_duplicate_post', 'post', $duplicate_id );
				
				// Switch to editing the duplicate instead of the original.
				$post_id = $duplicate_id;
				$post = get_post( $post_id );
				$is_duplicate = true;
				$auto_duplicate_created = true;
				
				// Continue with the update below - we'll add a note in the response.
			}
		}

		// Validate content if security checks are enabled and not skipped.
		$skip_security = $request->get_param( 'skip_security_check' );
		if ( get_option( 'respira_security_checks', 1 ) && ! $skip_security ) {
			if ( $content ) {
				$security_check = Respira_Security::validate_content( $content );
				if ( is_wp_error( $security_check ) ) {
					return $security_check;
				}
			}
		}

		// Update core post fields only when they are explicitly provided.
		// This avoids triggering save_post for meta-only updates.
		$update_data = array(
			'ID' => $post_id,
		);
		$has_core_updates = false;

		if ( $request->get_param( 'title' ) ) {
			$update_data['post_title'] = sanitize_text_field( $request->get_param( 'title' ) );
			$has_core_updates          = true;
		}

		if ( $request->get_param( 'content' ) ) {
			if ( $skip_security ) {
				// Explicit opt-out for advanced builder workflows.
				$update_data['post_content'] = (string) $request->get_param( 'content' );
			} else {
				// Use API-specific sanitization that allows scripts and modern web features.
				$update_data['post_content'] = $this->sanitize_api_content( $request->get_param( 'content' ) );
			}
			$has_core_updates            = true;
		}

		if ( $request->get_param( 'status' ) ) {
			$update_data['post_status'] = sanitize_text_field( $request->get_param( 'status' ) );
			$has_core_updates           = true;
		}

		if ( $request->get_param( 'slug' ) ) {
			$update_data['post_name'] = sanitize_title( $request->get_param( 'slug' ) );
			$has_core_updates         = true;
		}

		// Capture WP revision and Respira snapshot before edit.
		if ( $has_core_updates ) {
			if ( ! $is_duplicate && function_exists( 'wp_save_post_revision' ) ) {
				wp_save_post_revision( $post_id );
			}
			if ( class_exists( 'Respira_Snapshots' ) ) {
				$snap_kind = $is_duplicate ? 'before_edit' : 'before_live_edit';
				Respira_Snapshots::get_instance()->capture_snapshot(
					$post_id,
					$snap_kind,
					array( 'actor_api_key_id' => $key_data['id'] ?? null )
				);
			}
		}

		if ( $has_core_updates ) {
			$result = $this->guarded_wp_update_post( $update_data, 'update_post', 'post', $post_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		// Update meta if provided.
		$meta_updated = false;
		if ( $request->get_param( 'meta' ) ) {
			$meta_updated = $this->update_post_meta_fields( $post_id, $request->get_param( 'meta' ) );
		}

		// Elementor can invalidate per-post CSS in save_post flows; clear stale cache
		// after API meta writes so CSS can be regenerated cleanly.
		if ( $meta_updated ) {
			$this->maybe_clear_elementor_css_cache_for_post( $post_id );
		}

		// Update custom CSS if provided (Divi Builder and Elementor support).
		if ( $request->has_param( 'custom_css' ) ) {
			$custom_css = $request->get_param( 'custom_css' );

			// Detect which page builder is being used.
			$builder = Respira_Builder_Interface::detect_builder( $post_id );
			$builder_name = $builder ? $builder->get_name() : '';

			if ( 'Elementor' === $builder_name ) {
				// Elementor stores custom CSS in _elementor_page_settings.custom_css.
				$this->save_elementor_custom_css( $post_id, $custom_css );
			} elseif ( '' === $custom_css ) {
				// Clear CSS for Divi.
				delete_post_meta( $post_id, '_et_pb_custom_css' );
			} else {
				// Default to Divi's meta field.
				update_post_meta( $post_id, '_et_pb_custom_css', $custom_css );
			}
		}

		// Update SEO meta if provided.
		if ( $request->has_param( 'seo' ) ) {
			$seo_data = $request->get_param( 'seo' );
			if ( is_array( $seo_data ) && ! empty( $seo_data ) ) {
				$this->update_seo_meta( $post_id, $seo_data );
			}
		}

		// Update featured image if provided.
		if ( $request->has_param( 'featured_image' ) ) {
			$image_data = $request->get_param( 'featured_image' );
			if ( is_array( $image_data ) && ! empty( $image_data ) ) {
				$this->update_featured_image( $post_id, $image_data );
			}
		}

		// Capture after-edit snapshot with label.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind  = $is_duplicate ? 'after_edit' : 'after_live_edit';
			$snap_label = $this->build_snapshot_label( $request );
			Respira_Snapshots::get_instance()->capture_snapshot(
				$post_id,
				$snap_kind,
				array(
					'actor_api_key_id' => $key_data['id'] ?? null,
					'label'            => $snap_label,
				)
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_post', 'post', $post_id );

		// Track usage stat (non-blocking).
		// PRIVACY: Only aggregate statistics are sent - actual content is NEVER transmitted.
		// See class-respira-usage-tracker.php for detailed privacy documentation.
		// Pass license key from API key data if available.
		$license_key = $key_data['license_key'] ?? null;
		$this->track_usage_safe( 'update_post', 'post', $post_id, $content, $license_key );

		clean_post_cache( $post_id );

		// Purge frontend page caches on live edits so visitors see changes immediately.
		if ( ! $is_duplicate ) {
			$this->purge_frontend_caches( $post_id );
		}

		$updated_post = get_post( $post_id );
		$approvals_url = admin_url( 'admin.php?page=respira-changes' );

		$response_data = array(
			'success' => true,
			'post'    => $this->format_post_response( $updated_post, true ),
			'message' => $this->add_success_footer( $this->format_respira_message( __( 'Post updated successfully! Your changes are safe and sound.', 'respira-for-wordpress' ), 'success' ) ),
		);
		
		// Add note if duplicate was auto-created.
		if ( $auto_duplicate_created ) {
			$response_data['duplicate_created'] = true;
			$response_data['duplicate_id'] = $post_id;
			$response_data['original_id'] = $original_id;
			$response_data['approval_url'] = $approvals_url;
			$response_data['message'] = $this->add_success_footer( $this->format_respira_message( sprintf(
				/* translators: 1: post type label, 2: duplicate ID */
				__( 'I created a duplicate %1$s for safety (ID: %2$d). Review it in WordPress admin before approving to make it live.', 'respira-for-wordpress' ),
				$post_type_label,
				$post_id
			), 'warning' ) );
			$response_data['instructions'] = array(
				$this->format_respira_message( __( 'A duplicate was automatically created for safety.', 'respira-for-wordpress' ), 'warning' ),
				sprintf(
					/* translators: 1: post type label, 2: duplicate ID, 3: original ID */
					__( '📋 Duplicate %1$s ID: %2$d | Original ID: %3$d', 'respira-for-wordpress' ),
					$post_type_label,
					$post_id,
					$original_id
				),
				sprintf(
					/* translators: 1: approvals URL */
					__( '👀 Review and approve: %1$s', 'respira-for-wordpress' ),
					$approvals_url
				),
				__( '💡 Tip: Changes are on the duplicate. Approve it to make them live.', 'respira-for-wordpress' ),
			);
		}

		$response = new WP_REST_Response( $response_data, 200 );
		
		// Add response headers for better debugging.
		if ( $auto_duplicate_created ) {
			$response->header( 'X-Respira-Duplicate-Created', 'true' );
			$response->header( 'X-Respira-Duplicate-ID', (string) $post_id );
			$response->header( 'X-Respira-Original-ID', (string) $original_id );
			$response->header( 'X-Respira-Approval-URL', $approvals_url );
		} else {
			$response->header( 'X-Respira-Duplicate-Created', 'false' );
		}

		return $response;
	}

	/**
	 * Delete post endpoint.
	 *
	 * @since 1.2.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id  = $request->get_param( 'id' );

		$post = get_post( $post_id );
		if ( ! $post || 'post' !== $post->post_type ) {
			return new WP_Error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		// Only allow deletion of Respira duplicates unless forced.
		$is_duplicate = get_post_meta( $post_id, '_respira_duplicate', true );
		$force        = $request->get_param( 'force' );
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );
		$post_type_label = __( 'post', 'respira-for-wordpress' );

		// If not a duplicate, check if we can delete it.
			if ( ! $is_duplicate ) {
				// If force is requested but direct editing is disabled, return error with instructions.
				if ( $force && ! $allow_direct_edit ) {
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_direct_edit_disabled',
					sprintf(
						/* translators: 1: post type label */
						__( 'Cannot delete original %1$s. Direct editing of original pages is disabled in settings. Only Respira duplicates can be deleted.', 'respira-for-wordpress' ),
						$post_type_label
					),
					$error_data
					);
				}

				if ( $force && $allow_direct_edit && ! $this->has_live_edit_confirmation( $request ) ) {
					$error_data = Respira_Approver::get_approval_error_data( $post_id );
					return new WP_Error(
						'respira_live_edit_confirmation_required',
						sprintf(
							/* translators: 1: post type label, 2: post ID */
							__( 'Directly deleting live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
							$post_type_label,
							$post_id
						),
						array_merge(
							$error_data,
							array(
								'confirm_live_edit_required' => true,
								'instructions'               => array(
									__( 'This action will delete the original live item.', 'respira-for-wordpress' ),
									__( 'To continue, call the same endpoint with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
								),
							)
						)
					);
				}

				// If force is not requested, return error with instructions.
				if ( ! $force ) {
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				$message = sprintf(
					/* translators: 1: post type label, 2: post ID */
					__( 'Cannot delete original %1$s (ID: %2$d). Only Respira duplicates can be deleted.', 'respira-for-wordpress' ),
					$post_type_label,
					$post_id
				);

				return new WP_Error(
					'respira_not_duplicate',
					$message,
					$error_data
				);
			}
		}

		$result = wp_delete_post( $post_id, true );

		if ( ! $result ) {
			return new WP_Error(
				'respira_delete_failed',
				__( 'Failed to delete post.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_post', 'post', $post_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( __( 'Post deleted successfully.', 'respira-for-wordpress' ) ),
			),
			200
		);
	}

	/**
	 * List media endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_media( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => $request->get_param( 'per_page' ) ?? 20,
			'paged'          => $request->get_param( 'page' ) ?? 1,
			's'              => $request->get_param( 'search' ) ?? '',
		);

		// Disable WPML language filtering to get all media.
		$wpml_filter_removed = false;
		if ( has_filter( 'pre_get_posts', 'WPML_Query_Filter' ) || class_exists( 'SitePress' ) ) {
			add_filter( 'pre_get_posts', array( $this, 'force_attachment_post_type' ), 999 );
			$wpml_filter_removed = true;

			// Also try to suppress WPML's language filtering for attachments.
			if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
				$args['suppress_filters'] = true;
			}
		}

		$query = new WP_Query( $args );

		// Remove our temporary filter.
		if ( $wpml_filter_removed ) {
			remove_filter( 'pre_get_posts', array( $this, 'force_attachment_post_type' ), 999 );
		}

		$media = array();

		foreach ( $query->posts as $post ) {
			$file_path = get_attached_file( $post->ID );
			$file_size = 0;
			if ( $file_path && file_exists( $file_path ) ) {
				$file_size = filesize( $file_path );
			}

			$media[] = array(
				'id'         => $post->ID,
				'title'      => $post->post_title,
				'url'        => wp_get_attachment_url( $post->ID ),
				'mime_type'  => $post->post_mime_type,
				'uploaded'   => $post->post_date,
				'file_size'  => $file_size,
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_media', 'media', null );

		return new WP_REST_Response(
			array(
				'media'       => $media,
				'total'       => $query->found_posts,
				'total_pages' => $query->max_num_pages,
			),
			200
		);
	}

	/**
	 * Upload media endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function upload_media( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		// Handle file upload.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$file = $request->get_file_params();

		if ( empty( $file['file'] ) ) {
			return $this->respira_error(
				'respira_no_file',
				__( 'No file provided. Please include a file in your request.', 'respira-for-wordpress' ),
				array( 'status' => 400 ),
				'error'
			);
		}

		$attachment_id = media_handle_upload( 'file', 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		// Update media metadata if provided
		$title   = $request->get_param( 'title' );
		$alt     = $request->get_param( 'alt' );
		$caption = $request->get_param( 'caption' );

		if ( $title || $alt || $caption ) {
			$update_data = array();
			if ( $title ) {
				$update_data['post_title'] = sanitize_text_field( $title );
			}
			if ( $caption ) {
				$update_data['post_excerpt'] = sanitize_textarea_field( $caption );
			}

			if ( ! empty( $update_data ) ) {
				$update_data['ID'] = $attachment_id;
				wp_update_post( wp_slash( $update_data ) );
			}

			if ( $alt ) {
				update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
			}
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'upload_media', 'media', $attachment_id );

		// Get full media details
		$media_data = array(
			'id'        => $attachment_id,
			'url'       => wp_get_attachment_url( $attachment_id ),
			'type'      => get_post_mime_type( $attachment_id ),
			'title'     => get_the_title( $attachment_id ),
			'alt'       => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
			'caption'   => wp_get_attachment_caption( $attachment_id ),
			'file_size' => filesize( get_attached_file( $attachment_id ) ),
		);

		return new WP_REST_Response(
			array(
				'success' => true,
				'media'   => $media_data,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Media uploaded successfully! Your file is ready to use.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Extract page builder content endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function extract_builder_content( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$builder  = $request->get_param( 'builder' );
		$page_id  = $request->get_param( 'page_id' );

		// Handle multisite context - switch to correct site if needed.
		$switched = false;
		$original_site_id = get_current_blog_id();
		$site_id = $original_site_id;
		
		if ( is_multisite() ) {
			// Find which site this post belongs to by checking all sites.
			$site_id = $this->find_post_site_id( $page_id );
			
			if ( $site_id && $site_id != $original_site_id ) {
				switch_to_blog( $site_id );
				$switched = true;
			}
		}

		// Now get the post in the correct site context.
		$post = get_post( $page_id );
		if ( ! $post ) {
			if ( $switched ) {
				restore_current_blog();
			}
			return $this->respira_error(
				'respira_post_not_found',
				sprintf(
					/* translators: %d: page ID */
					__( 'Page %d not found.', 'respira-for-wordpress' ),
					$page_id
				),
				array(
					'status' => 404,
					'page_id' => $page_id,
					'site_id' => $site_id,
					'multisite' => is_multisite(),
				),
				'error'
			);
		}

		// Initialize Divi builder elements if Divi is being used.
		if ( 'divi' === strtolower( $builder ) || 'Divi' === $builder ) {
			if ( function_exists( 'et_builder_add_main_elements' ) ) {
				// Only initialize once to avoid conflicts.
				if ( ! did_action( 'et_builder_ready' ) ) {
					et_builder_add_main_elements();
				}
			}
		}

		$builder_instance = Respira_Builder_Interface::get_builder( $builder );

		if ( is_wp_error( $builder_instance ) ) {
			if ( $switched ) {
				restore_current_blog();
			}
			return $builder_instance;
		}

		// Check if builder is actually used on this page.
		if ( ! $builder_instance->is_builder_used( $page_id ) ) {
			if ( $switched ) {
				restore_current_blog();
			}
			return $this->respira_error(
				'respira_builder_not_used',
				sprintf(
					/* translators: 1: builder name, 2: page ID */
					__( 'Page %2$d does not use %1$s builder. Please ensure the page was created/edited with %1$s.', 'respira-for-wordpress' ),
					$builder,
					$page_id
				),
				array(
					'status' => 400,
					'builder' => $builder,
					'page_id' => $page_id,
					'site_id' => $site_id,
					'suggestions' => array(
						'Verify the page ID is correct',
						'Ensure the page was created/edited with ' . $builder . ' builder',
						'Check if the builder is active on your site',
					),
				),
				'warning'
			);
		}

		$content = $builder_instance->extract_content( $page_id );

		// Get diagnostics if available (for Divi builder).
		$diagnostics = null;
		if ( method_exists( $builder_instance, 'get_last_extraction_diagnostics' ) ) {
			$diagnostics = $builder_instance->get_last_extraction_diagnostics();
		}

		// Restore original site context if we switched.
		if ( $switched ) {
			restore_current_blog();
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'extract_builder_content', 'page', $page_id );

		$response_data = array(
				'success' => true,
				'builder' => $builder,
				'content' => $content,
		);

		// Add compatibility-mode warning signals for Divi mixed structures.
		if ( 'divi' === strtolower( (string) $builder ) && is_array( $content ) ) {
			$signals = $this->analyze_divi_structure_signals( $content );
			$response_data['divi_signals'] = $signals;

			if ( ! empty( $signals['mixed_structure'] ) || ! empty( $signals['legacy_wrapper_nodes'] ) ) {
				$response_data['warning'] = __( 'Legacy Divi modules detected. Compatibility mode may apply. Treat legacy wrappers as opaque and run extra QA.', 'respira-for-wordpress' );
			}
		}

		// Always include diagnostics if available (for debugging).
		if ( $diagnostics && ! empty( $diagnostics ) ) {
			$response_data['diagnostics'] = $diagnostics;
			
			// If extraction failed, include error information.
			if ( empty( $content ) && isset( $diagnostics['error'] ) ) {
				$response_data['warning'] = $diagnostics['error'];
				if ( isset( $diagnostics['warning'] ) ) {
					$response_data['warning'] .= '. ' . $diagnostics['warning'];
				}
			}
		} elseif ( empty( $content ) ) {
			// Even if no diagnostics, add basic diagnostic info when content is empty
			$response_data['diagnostics'] = array(
				'error' => 'Content extraction returned empty result',
				'content_source_used' => 'none',
				'content_length' => 0,
				'modules_found' => 0,
			);
		}

		// If content is empty but builder is detected, include detailed diagnostics and return error.
		if ( empty( $content ) && is_array( $content ) ) {
			$error_message = __( 'Content extraction returned empty result. Builder was detected but no content could be extracted.', 'respira-for-wordpress' );
			if ( isset( $diagnostics['error'] ) ) {
				$error_message = $diagnostics['error'];
			} elseif ( isset( $diagnostics['warning'] ) ) {
				$error_message = $diagnostics['warning'];
			}
			
			// Include full diagnostics in error response for debugging.
			$error_data = array(
				'status' => 500,
				'builder' => $builder,
				'page_id' => $page_id,
				'site_id' => $site_id,
			);
			
			if ( $diagnostics ) {
				$error_data['diagnostics'] = $diagnostics;
			}
			
			return $this->respira_error(
				'respira_extraction_empty',
				$error_message,
				$error_data,
				'error'
			);
		}

		return new WP_REST_Response( $response_data, 200 );
	}

	/**
	 * Analyze Divi content structure for mixed/legacy signals.
	 *
	 * @since 2.0.7
	 * @param array $nodes Content nodes.
	 * @return array
	 */
	private function analyze_divi_structure_signals( $nodes ) {
		$signals = array(
			'has_divi4_modules'    => false,
			'has_divi5_blocks'     => false,
			'legacy_wrapper_nodes' => 0,
			'mixed_structure'      => false,
		);

		$walk = function( $items ) use ( &$walk, &$signals ) {
			if ( ! is_array( $items ) ) {
				return;
			}

			foreach ( $items as $node ) {
				if ( ! is_array( $node ) ) {
					continue;
				}

				$type = (string) ( $node['type'] ?? '' );
				$content = (string) ( $node['content'] ?? '' );

				if ( 0 === strpos( $type, 'et_pb_' ) ) {
					$signals['has_divi4_modules'] = true;
				}
				if ( 0 === strpos( $type, 'divi/' ) ) {
					$signals['has_divi5_blocks'] = true;
				}
				if ( 'core/shortcode' === $type || strpos( $type, 'legacy' ) !== false || strpos( $type, 'shortcode' ) !== false || strpos( $content, '[et_pb_' ) !== false ) {
					$signals['legacy_wrapper_nodes']++;
				}

				if ( ! empty( $node['children'] ) ) {
					$walk( $node['children'] );
				}
			}
		};

		$walk( $nodes );
		$signals['mixed_structure'] = $signals['has_divi4_modules'] && $signals['has_divi5_blocks'];

		return $signals;
	}

	/**
	 * Inject page builder content endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function inject_builder_content( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$builder  = $request->get_param( 'builder' );
		$page_id  = absint( $request->get_param( 'page_id' ) );
		$content  = $request->get_param( 'content' );
		$mode     = $request->get_param( 'mode' ) ?? 'replace';
		$post     = get_post( $page_id );

		if ( ! in_array( $mode, array( 'replace', 'append' ), true ) ) {
			$mode = 'replace';
		}

		if ( ! $post ) {
			return $this->respira_error(
				'respira_page_not_found',
				__( 'Page not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		// Validate builder BEFORE the confirmation preflight so we don't
		// show a confirmation prompt for an operation that will fail.
		$builder_instance = Respira_Builder_Interface::get_builder( $builder );

		if ( is_wp_error( $builder_instance ) ) {
			return $builder_instance;
		}

		$target_info = $this->resolve_mutation_target( $request, $page_id, $post->post_type );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}
		$page_id = (int) $target_info['target_id'];
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );

		// Capture before-edit snapshot for builder injection.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind = ! empty( $target_info['is_duplicate'] ) ? 'before_edit' : 'before_live_edit';
			Respira_Snapshots::get_instance()->capture_snapshot(
				$page_id,
				$snap_kind,
				array( 'actor_api_key_id' => $key_data['id'] ?? null )
			);
		}

		// Check for existing content to warn about replacement or support append mode.
		$existing_content   = $builder_instance->extract_content( $page_id );
		$existing_count     = is_array( $existing_content ) ? count( $existing_content ) : 0;
		$had_existing       = $existing_count > 0;

		// In append mode, merge new content with existing content.
		if ( 'append' === $mode && $had_existing ) {
			if ( is_string( $content ) ) {
				$decoded = json_decode( $content, true );
				if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
					$content = $decoded;
				}
			}
			// Normalize wrapper shapes like {elements: [...]} or {sections: [...]}.
			if ( is_array( $content ) && ! empty( $content ) ) {
				if ( isset( $content['elements'] ) ) {
					$content = $content['elements'];
				} elseif ( isset( $content['sections'] ) ) {
					$content = $content['sections'];
				} elseif ( isset( $content['modules'] ) ) {
					$content = $content['modules'];
				}
			}
			$content = array_merge( $existing_content, is_array( $content ) ? $content : array() );
		}

		// Capture before-edit snapshot for builder injection.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind = ! empty( $target_info['is_duplicate'] ) ? 'before_edit' : 'before_live_edit';
			Respira_Snapshots::get_instance()->capture_snapshot(
				$page_id,
				$snap_kind,
				array( 'actor_api_key_id' => $key_data['id'] ?? null )
			);
		}

		try {
			$result = $this->inject_builder_content_with_api_context( $builder_instance, $page_id, $content );
		} catch ( Throwable $e ) {
			error_log(
				sprintf(
					'Respira inject_builder_content fatal: builder=%s page_id=%d exception=%s message=%s',
					(string) $builder,
					(int) $page_id,
					get_class( $e ),
					$e->getMessage()
				)
			);

			return $this->respira_error(
				'respira_inject_failed',
				__( 'Failed to inject builder content due to a server exception.', 'respira-for-wordpress' ),
				array(
					'status'            => 500,
					'builder'           => $builder,
					'page_id'           => $page_id,
					'exception_type'    => get_class( $e ),
					'exception_message' => $e->getMessage(),
					'hint'              => __( 'Enable WP_DEBUG_LOG and check wp-content/debug.log for full stack trace.', 'respira-for-wordpress' ),
				),
				'error'
			);
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Capture after-edit snapshot for builder injection.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind = ! empty( $target_info['is_duplicate'] ) ? 'after_edit' : 'after_live_edit';
			Respira_Snapshots::get_instance()->capture_snapshot(
				$page_id,
				$snap_kind,
				array(
					'actor_api_key_id' => $key_data['id'] ?? null,
					'label'            => 'Injected builder content',
				)
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'inject_builder_content', 'page', $page_id );

		// Purge frontend caches on live edits.
		if ( empty( $target_info['is_duplicate'] ) ) {
			$this->purge_frontend_caches( $page_id );
		}

		// Track usage stat (non-blocking).
		// PRIVACY: Only aggregate statistics are sent - actual content is NEVER transmitted.
		try {
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-usage-tracker.php';
			// Pass license key from API key data if available.
			$license_key = $key_data['license_key'] ?? null;
			Respira_Usage_Tracker::track( 'inject_builder_content', 'page', $page_id, $content, $license_key );
		} catch ( Throwable $e ) {
			error_log( 'Respira inject_builder_content usage tracking failed: ' . $e->getMessage() );
		}

		// Build success message with replacement/append context.
		if ( 'append' === $mode && $had_existing ) {
			$msg = sprintf(
				/* translators: %d: number of existing elements */
				__( 'Content appended successfully. %d existing elements preserved, new content added after them.', 'respira-for-wordpress' ),
				$existing_count
			);
		} elseif ( $had_existing ) {
			$msg = sprintf(
				/* translators: %d: number of replaced elements */
				__( 'Content replaced successfully. Previous structure (%d top-level elements) was overwritten. Use mode:"append" to add content without replacing. A snapshot was captured before the change.', 'respira-for-wordpress' ),
				$existing_count
			);
		} else {
			$msg = __( 'Content injected successfully! Your page builder content is now updated.', 'respira-for-wordpress' );
		}

		$response_data = array(
			'success' => true,
			'message' => $this->add_success_footer( $this->format_respira_message( $msg, 'success' ) ),
			'mode'    => $mode,
		);

		if ( $had_existing && 'replace' === $mode ) {
			$response_data['replaced_element_count'] = $existing_count;
		}

		if ( 'duplicate' === $target_info['edit_target'] && (int) $target_info['target_id'] !== (int) $target_info['original_id'] ) {
			$response_data['duplicate_id']      = (int) $target_info['target_id'];
			$response_data['original_id']       = (int) $target_info['original_id'];
			$response_data['duplicate_created'] = ! empty( $target_info['duplicate_created'] );
			$response_data['approval_url']      = admin_url( 'admin.php?page=respira-changes' );
		}
		if ( $is_live_original ) {
			$response_data['edit_target'] = 'live';
			$response_data['rollback']    = array(
				'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
				'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
			);
		}

		return new WP_REST_Response( $response_data, 200 );
	}

	/**
	 * Update a specific builder module endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_builder_module( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$builder  = $request->get_param( 'builder' );
		$page_id  = absint( $request->get_param( 'page_id' ) );
		$module_identifier = $request->get_param( 'module_identifier' );
		$updates  = $request->get_param( 'updates' );
		$post     = get_post( $page_id );

		if ( ! $post ) {
			return $this->respira_error(
				'respira_page_not_found',
				__( 'Page not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$target_info = $this->resolve_mutation_target( $request, $page_id, $post->post_type );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}
		$page_id = (int) $target_info['target_id'];
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );

		// Capture before-edit snapshot for module update.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind = ! empty( $target_info['is_duplicate'] ) ? 'before_edit' : 'before_live_edit';
			Respira_Snapshots::get_instance()->capture_snapshot(
				$page_id,
				$snap_kind,
				array( 'actor_api_key_id' => $key_data['id'] ?? null )
			);
		}

		try {
			if ( empty( $module_identifier ) || empty( $updates ) ) {
				return $this->respira_error(
					'respira_missing_params',
					__( 'module_identifier and updates are required.', 'respira-for-wordpress' ),
					array( 'status' => 400 ),
					'error'
				);
			}

			if ( ! is_array( $module_identifier ) || ! is_array( $updates ) ) {
				return $this->respira_error(
					'respira_invalid_payload',
					__( 'module_identifier and updates must be JSON objects.', 'respira-for-wordpress' ),
					array( 'status' => 400 ),
					'error'
				);
			}

			// Validate content size before processing.
			if ( array_key_exists( 'content', $updates ) ) {
				$content_size = $this->get_payload_byte_length( $updates['content'] );
				$max_size     = apply_filters( 'respira_module_content_max_size', 512000 ); // 500KB default

				if ( $content_size > $max_size ) {
					return $this->respira_error(
						'respira_content_too_large',
						sprintf(
							/* translators: 1: content size, 2: max allowed size */
							__( 'Content size (%s) exceeds maximum allowed (%s).', 'respira-for-wordpress' ),
							size_format( $content_size ),
							size_format( $max_size )
						),
						array(
							'status'         => 400,
							'content_length' => $content_size,
							'max_allowed'    => $max_size,
							'suggestion'     => __( 'Consider splitting content into multiple modules or reducing content size.', 'respira-for-wordpress' ),
						),
						'error'
					);
				}
			}

			$builder_instance = Respira_Builder_Interface::get_builder( $builder );

			if ( is_wp_error( $builder_instance ) ) {
				return $builder_instance;
			}

			// Check if builder supports module updates.
			if ( ! method_exists( $builder_instance, 'update_module' ) ) {
				return $this->respira_error(
					'respira_module_update_not_supported',
					sprintf(
						/* translators: 1: builder name */
						__( '%1$s builder does not support module-level updates.', 'respira-for-wordpress' ),
						$builder
					),
					array(
						'status'      => 400,
						'page_id'     => $page_id,
						'builder'     => $builder,
						'diagnostics' => array(
							'content_length' => array_key_exists( 'content', $updates ) ? $this->get_payload_byte_length( $updates['content'] ) : 0,
						),
					),
					'error'
				);
			}

			// Log content size for debugging.
			if ( array_key_exists( 'content', $updates ) ) {
				$content_size = $this->get_payload_byte_length( $updates['content'] );
				error_log(
					sprintf(
						/* translators: 1: page ID, 2: content size in bytes */
						'Respira: Module update - Page ID %d, Content size: %d bytes',
						$page_id,
						$content_size
					)
				);
			}

			// Extract current structure.
			$structure = $builder_instance->extract_content( $page_id );

			// Determine identifier type and value.
			$identifier_type  = 'admin_label';
			$identifier_value = '';
			$match_content    = $module_identifier['match_content'] ?? '';

			if ( isset( $module_identifier['id'] ) ) {
				$identifier_type  = 'id';
				$identifier_value = $module_identifier['id'];
			} elseif ( isset( $module_identifier['admin_label'] ) ) {
				$identifier_type  = 'admin_label';
				$identifier_value = $module_identifier['admin_label'];
			} elseif ( isset( $module_identifier['path'] ) ) {
				$identifier_type  = 'path';
				$identifier_value = $module_identifier['path'];
			} elseif ( isset( $module_identifier['type'] ) ) {
				$identifier_type  = 'type';
				$identifier_value = $module_identifier['type'];
			} else {
				return $this->respira_error(
					'respira_invalid_identifier',
					__( 'module_identifier must contain id, admin_label, path, or type.', 'respira-for-wordpress' ),
					array(
						'status'            => 400,
						'page_id'           => $page_id,
						'builder'           => $builder,
						'module_identifier' => $module_identifier,
						'diagnostics'       => array(
							'content_length' => array_key_exists( 'content', $updates ) ? $this->get_payload_byte_length( $updates['content'] ) : 0,
						),
					),
					'error'
				);
			}

			// Beaver Builder direct-update path: modify _fl_builder_data in-place
			// to avoid the simplify→complexify round-trip that corrupts BB's
			// stdClass/array format and crashes pages.
			if ( $builder_instance instanceof Respira_Builder_Beaver && 'id' === $identifier_type ) {
				// First verify the module exists in the simplified structure.
				$found = $builder_instance->find_module( $structure, $identifier_type, $identifier_value, $match_content );
				if ( ! $found ) {
					return $this->respira_error(
						'respira_module_not_found',
						sprintf( __( 'Module not found with %1$s: %2$s', 'respira-for-wordpress' ), $identifier_type, $identifier_value ),
						array(
							'status'            => 404,
							'identifier_type'   => $identifier_type,
							'identifier_value'  => $identifier_value,
							'page_id'           => $page_id,
							'builder'           => $builder,
						),
						'error'
					);
				}

				$direct_result = $builder_instance->update_module_direct( $page_id, $identifier_value, $updates );
				if ( is_wp_error( $direct_result ) ) {
					return $direct_result;
				}

				// Re-extract for response (find_module uses simplified structure).
				$updated_structure = $builder_instance->extract_content( $page_id );
				$found_after = $builder_instance->find_module( $updated_structure, $identifier_type, $identifier_value, '' );

				return rest_ensure_response( array(
					'success' => true,
					'message' => __( 'Module updated successfully.', 'respira-for-wordpress' ),
					'module'  => $found_after ? $found_after['module'] : null,
					'path'    => $found_after ? $found_after['path_string'] : ( $found['path_string'] ?? '' ),
				) );
			}

			// Find and update the module.
			// Pass match_content in updates so update_module can use it for ambiguity detection.
			$updates_with_match = $updates;
			if ( ! empty( $match_content ) ) {
				$updates_with_match['match_content'] = $match_content;
			}
			$updated_structure = $builder_instance->update_module( $structure, $identifier_type, $identifier_value, $updates_with_match );

			if ( is_wp_error( $updated_structure ) ) {
				// Enhance error with diagnostics.
				$error_data = $updated_structure->get_error_data();
				if ( ! is_array( $error_data ) ) {
					$error_data = array();
				}
				$error_data['diagnostics'] = array_merge(
					$error_data['diagnostics'] ?? array(),
					array(
						'content_length'   => array_key_exists( 'content', $updates ) ? $this->get_payload_byte_length( $updates['content'] ) : 0,
						'identifier_type'  => $identifier_type,
						'identifier_value' => $identifier_value,
						'page_id'          => $page_id,
						'builder'          => $builder,
					)
				);
				$updated_structure->add_data( $error_data );
				return $updated_structure;
			}

			// Inject updated structure back.
			// Skip structural validation for module updates — only content/attributes changed,
			// the overall nesting structure is unchanged from the previously-valid extracted state.
			try {
				$result = $this->inject_builder_content_with_api_context( $builder_instance, $page_id, $updated_structure, true );
			} catch ( Throwable $e ) {
				// Catch any exceptions and convert to WP_Error.
				return $this->respira_error(
					'respira_inject_failed',
					sprintf(
						/* translators: 1: error message */
						__( 'Failed to inject updated content: %s', 'respira-for-wordpress' ),
						$e->getMessage()
					),
					array(
						'status'         => 500,
						'exception_type' => get_class( $e ),
						'page_id'        => $page_id,
						'builder'        => $builder,
					),
					'error'
				);
			}

			if ( is_wp_error( $result ) ) {
				// Enhance error with diagnostics.
				$error_data = $result->get_error_data();
				if ( ! is_array( $error_data ) ) {
					$error_data = array();
				}
				$error_data['diagnostics'] = array_merge(
					$error_data['diagnostics'] ?? array(),
					array(
						'content_length'   => array_key_exists( 'content', $updates ) ? $this->get_payload_byte_length( $updates['content'] ) : 0,
						'identifier_type'  => $identifier_type,
						'identifier_value' => $identifier_value,
						'page_id'          => $page_id,
						'builder'          => $builder,
					)
				);
				$result->add_data( $error_data );
				return $result;
			}

			// Verify content was saved correctly (check for truncation).
			if ( array_key_exists( 'content', $updates ) ) {
				$expected_size = $this->get_payload_byte_length( $updates['content'] );
				$saved_content = $builder_instance->extract_content( $page_id );

				// After a content update, find the module using the NEW content
				// (the original match_content no longer exists). Use a substring of
				// the new HTML — find_module uses strpos() on raw content.
				$verify_match = mb_substr( $updates['content'], 0, 60 );

				// For path-based: re-use the same path (positional, not content-dependent).
				if ( 'path' === $identifier_type ) {
					$verify_match = '';
				}

				$saved_module = $builder_instance->find_module( $saved_content, $identifier_type, $identifier_value, $verify_match );

				if ( ! is_wp_error( $saved_module ) && $saved_module && isset( $saved_module['module']['content'] ) ) {
					$saved_size = $this->get_payload_byte_length( $saved_module['module']['content'] );

					if ( $saved_size !== $expected_size ) {
						// Content was truncated.
						return $this->respira_error(
							'respira_content_truncated',
							sprintf(
								/* translators: 1: expected size, 2: saved size */
								__( 'Content was truncated during save. Expected %d bytes, saved %d bytes.', 'respira-for-wordpress' ),
								$expected_size,
								$saved_size
							),
							array(
								'status'       => 500,
								'expected_size' => $expected_size,
								'saved_size'   => $saved_size,
								'truncated_by' => $expected_size - $saved_size,
								'suggestion'   => __( 'Content may exceed database field limits. Check PHP/WordPress configuration.', 'respira-for-wordpress' ),
								'diagnostics'  => array(
									'content_length'   => $expected_size,
									'identifier_type'  => $identifier_type,
									'identifier_value' => $identifier_value,
									'page_id'          => $page_id,
									'builder'          => $builder,
								),
							),
							'error'
						);
					}
				}
			}

			// Get the updated module info — search the UPDATED structure with the NEW content
			// (not the original match_content, which no longer exists after the update).
			$new_match = isset( $updates['content'] ) ? '' : $match_content;
			$found = $builder_instance->find_module( $updated_structure, $identifier_type, $identifier_value, $new_match );

			// Capture after-edit snapshot for module update.
			if ( class_exists( 'Respira_Snapshots' ) ) {
				$snap_kind = ! empty( $target_info['is_duplicate'] ) ? 'after_edit' : 'after_live_edit';
				Respira_Snapshots::get_instance()->capture_snapshot(
					$page_id,
					$snap_kind,
					array(
						'actor_api_key_id' => $key_data['id'] ?? null,
						'label'            => 'Updated builder module',
					)
				);
			}

			Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_builder_module', 'page', $page_id );

			// Track usage stat (non-blocking).
			// PRIVACY: Only aggregate statistics are sent - actual content is NEVER transmitted.
			// See class-respira-usage-tracker.php for detailed privacy documentation.
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-usage-tracker.php';
			$updates_content = is_array( $updates ) ? wp_json_encode( $updates ) : (string) $updates;
			// Pass license key from API key data if available.
			$license_key = $key_data['license_key'] ?? null;
			Respira_Usage_Tracker::track( 'inject_builder_content', 'page', $page_id, $updates_content, $license_key );

			// Purge frontend caches on live edits.
			if ( empty( $target_info['is_duplicate'] ) ) {
				$this->purge_frontend_caches( $page_id );
			}

			$response_data = array(
				'success' => true,
				'module'  => ( $found && ! is_wp_error( $found ) ) ? array(
					'path'        => $found['path_string'],
					'type'        => $found['module']['type'] ?? '',
					'admin_label' => $found['module']['admin_label'] ?? $found['module']['attributes']['admin_label'] ?? '',
				) : null,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Module updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			);

			// Propagate any warnings from the inject (e.g. <script> tags in divi/text).
			if ( is_array( $result ) && ! empty( $result['warnings'] ) ) {
				$response_data['warnings'] = $result['warnings'];
			}

			if ( 'duplicate' === $target_info['edit_target'] && (int) $target_info['target_id'] !== (int) $target_info['original_id'] ) {
				$response_data['duplicate_id']      = (int) $target_info['target_id'];
				$response_data['original_id']       = (int) $target_info['original_id'];
				$response_data['duplicate_created'] = ! empty( $target_info['duplicate_created'] );
				$response_data['approval_url']      = admin_url( 'admin.php?page=respira-changes' );
			}
			if ( $is_live_original ) {
				$response_data['edit_target'] = 'live';
				$response_data['rollback']    = array(
					'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
					'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
				);
			}

			return new WP_REST_Response( $response_data, 200 );
		} catch ( Throwable $e ) {
			error_log(
				sprintf(
					'Respira update_builder_module fatal: builder=%s page_id=%d exception=%s message=%s',
					(string) $builder,
					(int) $page_id,
					get_class( $e ),
					$e->getMessage()
				)
			);

			return $this->respira_error(
				'respira_module_update_failed',
				__( 'Module update failed due to a server exception.', 'respira-for-wordpress' ),
				array(
					'status'            => 500,
					'builder'           => $builder,
					'page_id'           => $page_id,
					'exception_type'    => get_class( $e ),
					'exception_message' => $e->getMessage(),
					'hint'              => __( 'Enable WP_DEBUG_LOG and check wp-content/debug.log for full stack trace.', 'respira-for-wordpress' ),
				),
				'error'
			);
		}
	}

	/**
	 * Inject builder content while preserving script/style content.
	 *
	 * Builder inject flows previously relied on raw wp_update_post calls inside
	 * builder implementations. In API-key context, WordPress content filters can
	 * strip inline styles and <style> tags. This wrapper aligns builder inject
	 * behavior with update_page/update_post by temporarily removing those filters.
	 *
	 * @since 2.0.19
	 * @param Respira_Builder_Interface $builder_instance Builder instance.
	 * @param int                       $page_id          Page ID.
	 * @param array                     $content          Builder content.
	 * @return bool|WP_Error
	 */
	private function inject_builder_content_with_api_context( $builder_instance, $page_id, $content, $skip_structure_validation = false ) {
		Respira_Content_Filter::set_api_update_context( true );
		$removed_filters    = Respira_Content_Filter::remove_content_filters();
		$removed_save_hooks = $this->remove_third_party_save_hooks();

		try {
			return $builder_instance->inject_content( $page_id, $content, $skip_structure_validation );
		} finally {
			$this->restore_third_party_save_hooks( $removed_save_hooks );
			Respira_Content_Filter::restore_content_filters( $removed_filters );
			Respira_Content_Filter::set_api_update_context( false );
		}
	}

	/**
	 * Validate security endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function validate_security( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$content  = $request->get_param( 'content' );

		$validation = Respira_Security::validate_content( $content );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'validate_security', 'validation', null );

		if ( is_wp_error( $validation ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'valid'   => false,
					'issues'  => $validation->get_error_messages(),
				),
				200
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'valid'   => true,
				'message' => $this->format_respira_message( __( 'Content passed security validation. Looks good to go!', 'respira-for-wordpress' ), 'success' ),
			),
			200
		);
	}

	/**
	 * Get audit logs endpoint.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function get_audit_logs( $request ) {
		global $wpdb;

		$key_data = $request->get_param( '_respira_key_data' );
		if ( ! $key_data ) {
			return new WP_Error(
				'respira_unauthorized',
				__( 'API key required.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		$table_name = $wpdb->prefix . 'respira_audit_log';
		$per_page   = $request->get_param( 'per_page' ) ?? 20;
		$page       = $request->get_param( 'page' ) ?? 1;
		$offset     = ( $page - 1 ) * $per_page;

		// Filter logs by API key ID (users can only see their own logs)
		$logs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE api_key_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
				$key_data['id'],
				$per_page,
				$offset
			)
		);

		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE api_key_id = %d",
				$key_data['id']
			)
		);

		return new WP_REST_Response(
			array(
				'logs'        => $logs,
				'total'       => $total,
				'total_pages' => ceil( $total / $per_page ),
			),
			200
		);
	}

	/**
	 * Find which site a post belongs to in multisite.
	 *
	 * @since  1.0.0
	 * @param  int $post_id Post ID.
	 * @return int|false Site ID or false if not found.
	 */
	private function find_post_site_id( $post_id ) {
		if ( ! is_multisite() ) {
			return get_current_blog_id();
		}

		// First, check current site.
		$post = get_post( $post_id );
		if ( $post ) {
			return get_current_blog_id();
		}

		// If not found, search all sites.
		global $wpdb;
		$sites = get_sites( array( 'number' => 0 ) );
		
		foreach ( $sites as $site ) {
			switch_to_blog( $site->blog_id );
			$post = get_post( $post_id );
			if ( $post ) {
				restore_current_blog();
				return $site->blog_id;
			}
			restore_current_blog();
		}

		return false;
	}

	/**
	 * Format post response.
	 *
	 * @since  1.0.0
	 * @param  WP_Post $post      The post object.
	 * @param  bool    $full_data Whether to include full data including meta.
	 * @return array   Formatted post data.
	 */
	private function format_post_response( $post, $full_data = false ) {
		$data = array(
			'id'             => $post->ID,
			'title'          => $post->post_title,
			'slug'           => $post->post_name,
			'status'         => $post->post_status,
			'type'           => $post->post_type,
			'author'         => $post->post_author,
			'date'           => $post->post_date,
			'modified'       => $post->post_modified,
			'url'            => get_permalink( $post->ID ),
			'is_duplicate'   => (bool) get_post_meta( $post->ID, '_respira_duplicate', true ),
			'original_id'    => get_post_meta( $post->ID, '_respira_original_id', true ),
		);

		if ( $full_data ) {
			$data['content'] = $post->post_content;
			$data['excerpt'] = $post->post_excerpt;
			$data['meta']    = $this->get_post_meta_for_response( $post->ID );

			// Include custom CSS if it exists (Divi Builder or Elementor).
			$custom_css = get_post_meta( $post->ID, '_et_pb_custom_css', true );
			if ( ! $custom_css ) {
				// Try Elementor's custom CSS field if Divi's is empty.
				$custom_css = get_post_meta( $post->ID, '_elementor_css', true );
			}
			if ( $custom_css ) {
				$data['custom_css'] = $custom_css;
			}

			// Include SEO meta data.
			$seo_meta = $this->get_seo_meta( $post->ID );
			if ( ! empty( array_filter( $seo_meta ) ) ) {
				$data['seo'] = $seo_meta;
			}

			// Include featured image data.
			$thumbnail_id = get_post_thumbnail_id( $post->ID );
			if ( $thumbnail_id ) {
				$data['featured_image'] = array(
					'id'  => $thumbnail_id,
					'url' => wp_get_attachment_url( $thumbnail_id ),
					'alt' => get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true ),
				);
			}

			// Detect page builder.
			$builder = Respira_Builder_Interface::detect_builder( $post->ID );
			if ( $builder ) {
				$data['builder'] = $builder->get_name();

				// Add builder-specific schema for Divi.
				if ( 'Divi' === $builder->get_name() && method_exists( $builder, 'get_builder_schema' ) ) {
					// Extract module names from content to get relevant schemas.
					$modules_used = array();
					if ( ! empty( $post->post_content ) && preg_match_all( '/\[et_pb_(\w+)/', $post->post_content, $matches ) ) {
						$modules_used = array_unique( array_map( function( $name ) {
							return 'et_pb_' . $name;
						}, $matches[1] ) );
					}

					$data['builder_data'] = $builder->get_builder_schema( $modules_used );
				}
			}
		}

		return $data;
	}

	/**
	 * Check whether the request explicitly confirms direct editing/deleting of live originals.
	 *
	 * @since 4.0.11
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	private function has_live_edit_confirmation( $request ) {
		$value = $request->get_param( 'confirm_live_edit' );
		if ( null === $value ) {
			$value = $request->get_param( 'confirmLiveEdit' );
		}
		// AI agents sometimes send "confirmed: true" instead of the canonical param name.
		if ( null === $value ) {
			$value = $request->get_param( 'confirmed' );
		}

		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return 1 === (int) $value;
		}

		if ( is_string( $value ) ) {
			$normalized = strtolower( trim( $value ) );
			return in_array( $normalized, array( '1', 'true', 'yes', 'confirm' ), true );
		}

		return false;
	}

	/**
	 * Normalize edit target mode for original content mutations.
	 *
	 * @since 4.2.0
	 * @param WP_REST_Request $request Request.
	 * @return string
	 */
	private function get_edit_target_mode( $request ) {
		$target = $request->get_param( 'editTarget' );
		if ( null === $target ) {
			$target = $request->get_param( 'edit_target' );
		}

		if ( is_string( $target ) ) {
			$target = sanitize_key( $target );
			if ( in_array( $target, array( 'ask', 'live', 'duplicate' ), true ) ) {
				return $target;
			}
		}

		if ( $request->get_param( 'force' ) || $this->has_live_edit_confirmation( $request ) ) {
			return 'live';
		}

		return 'ask';
	}

	/**
	 * Resolve or create the working duplicate for a post mutation.
	 *
	 * @since 4.2.0
	 * @param int $post_id Original post ID.
	 * @return array|WP_Error
	 */
	private function resolve_duplicate_target_for_edit( $post_id, $create_if_missing = true ) {
		$result = array(
			'original_id'             => (int) $post_id,
			'target_id'               => (int) $post_id,
			'duplicate_created'       => false,
			'used_existing_duplicate' => false,
			'would_create_duplicate'  => false,
		);

		if ( Respira_Duplicator::is_duplicate( $post_id ) ) {
			return $result;
		}

		$duplicates = Respira_Duplicator::get_duplicates( $post_id );
		if ( ! empty( $duplicates ) ) {
			$result['target_id']               = (int) $duplicates[0]->ID;
			$result['used_existing_duplicate'] = true;
			return $result;
		}

		if ( ! $create_if_missing ) {
			$result['target_id']              = 0;
			$result['would_create_duplicate'] = true;
			return $result;
		}

		$new_duplicate = Respira_Duplicator::duplicate_post( $post_id, '_duplicate_' . time() );
		if ( is_wp_error( $new_duplicate ) ) {
			return $new_duplicate;
		}

		$result['target_id']         = (int) $new_duplicate;
		$result['duplicate_created'] = true;
		return $result;
	}

	/**
	 * Build live-edit confirmation payload for original content.
	 *
	 * @since 4.2.0
	 * @param WP_Post $post Original post.
	 * @param array   $duplicate_target Duplicate target info.
	 * @return WP_REST_Response
	 */
	private function build_live_edit_confirmation_response( $post, $duplicate_target ) {
		$post_type_object = get_post_type_object( $post->post_type );
		$post_type_label  = ( $post_type_object && ! empty( $post_type_object->labels->singular_name ) ) ? $post_type_object->labels->singular_name : ucfirst( $post->post_type );
		$edit_url         = admin_url( 'post.php?post=' . $post->ID . '&action=edit' );
		$duplicate_id     = ! empty( $duplicate_target['target_id'] ) && (int) $duplicate_target['target_id'] !== (int) $post->ID ? (int) $duplicate_target['target_id'] : null;
		$will_create      = ! empty( $duplicate_target['would_create_duplicate'] );

		return new WP_REST_Response(
			array(
				'status'  => 'confirmation_required',
				'message' => sprintf(
					/* translators: 1: post type label, 2: post title */
					__( 'Respira is about to edit the original live %1$s "%2$s". Choose whether to update the original or work on a duplicate instead.', 'respira-for-wordpress' ),
					$post_type_label,
					$post->post_title
				),
				'target'  => array(
					'id'        => (int) $post->ID,
					'post_type' => $post->post_type,
					'title'     => $post->post_title,
					'status'    => $post->post_status,
					'url'       => get_permalink( $post->ID ),
				),
				'choices' => array(
					'live'      => array(
						'label'       => __( 'Update original', 'respira-for-wordpress' ),
						'description' => __( 'Respira will write to the original post/page now and keep a pre-edit snapshot for rollback.', 'respira-for-wordpress' ),
					),
					'duplicate' => array(
						'label'         => __( 'Use duplicate', 'respira-for-wordpress' ),
						'description'   => $will_create
							? __( 'Respira will create a working copy when you confirm the duplicate path, instead of editing the live original directly.', 'respira-for-wordpress' )
							: __( 'Respira will reuse the current working copy instead of editing the live original directly.', 'respira-for-wordpress' ),
						'duplicate_id'  => $duplicate_id,
						'duplicate_url' => $duplicate_id ? get_edit_post_link( $duplicate_id, 'raw' ) : null,
						'will_create'   => $will_create,
					),
				),
				'rollback' => array(
					'wordpress_revisions' => __( 'If something goes wrong, open the WordPress edit screen and restore a previous revision.', 'respira-for-wordpress' ),
					'edit_screen_url'     => $edit_url,
					'respira_snapshot'    => __( 'Respira also captures a pre-edit snapshot before live updates.', 'respira-for-wordpress' ),
				),
				'next_call_examples' => array(
					'live'      => array(
						'editTarget'        => 'live',
						'confirm_live_edit' => true,
					),
					'duplicate' => array(
						'editTarget' => 'duplicate',
					),
				),
			),
			200
		);
	}

	/**
	 * Resolve how a mutation should target original vs duplicate content.
	 *
	 * @since 4.2.0
	 * @param WP_REST_Request $request Request.
	 * @param int             $post_id Target post ID.
	 * @param string          $post_type Expected post type.
	 * @return array|WP_REST_Response|WP_Error
	 */
	private function resolve_mutation_target( $request, $post_id, $post_type ) {
		$post = get_post( $post_id );
		if ( ! $post || $post->post_type !== $post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$result = array(
			'original_id'             => (int) $post_id,
			'target_id'               => (int) $post_id,
			'duplicate_created'       => false,
			'used_existing_duplicate' => false,
			'edit_target'             => 'duplicate',
			'is_duplicate'            => Respira_Duplicator::is_duplicate( $post_id ),
		);

		if ( $result['is_duplicate'] ) {
			$result['edit_target'] = 'live';
			return $result;
		}

		$allow_direct_edit = (bool) get_option( 'respira_allow_direct_edit', 0 );
		$edit_target       = $this->get_edit_target_mode( $request );

		if ( ! $allow_direct_edit ) {
			if ( 'live' === $edit_target ) {
				return new WP_Error(
					'respira_direct_edit_disabled',
					__( 'Direct editing of live originals is disabled in Respira settings.', 'respira-for-wordpress' ),
					array( 'status' => 403 )
				);
			}

			$duplicate_result = $this->resolve_duplicate_target_for_edit( $post_id );
			if ( is_wp_error( $duplicate_result ) ) {
				return $duplicate_result;
			}

			$duplicate_result['edit_target'] = 'duplicate';
			return $duplicate_result;
		}

		if ( 'live' === $edit_target ) {
			$result['edit_target'] = 'live';
			return $result;
		}

		if ( 'duplicate' === $edit_target ) {
			$duplicate_result = $this->resolve_duplicate_target_for_edit( $post_id );
			if ( is_wp_error( $duplicate_result ) ) {
				return $duplicate_result;
			}

			$duplicate_result['edit_target'] = 'duplicate';
			return $duplicate_result;
		}

		// Draft pages that are not linked to any original have nothing to protect.
		// Skip the confirmation dialog and edit them directly.
		if ( 'draft' === $post->post_status && ! $result['is_duplicate'] ) {
			$original_meta = (int) get_post_meta( $post_id, '_respira_original_id', true );
			if ( 0 === $original_meta ) {
				$result['edit_target'] = 'live';
				return $result;
			}
		}

		$duplicate_preview = $this->resolve_duplicate_target_for_edit( $post_id, false );
		if ( is_wp_error( $duplicate_preview ) ) {
			return $duplicate_preview;
		}

		return $this->build_live_edit_confirmation_response( $post, $duplicate_preview );
	}

	/**
	 * Update post meta fields while preserving slashes for JSON-like values.
	 *
	 * @since 2.0.8
	 * @param int   $post_id Post ID.
	 * @param array $meta    Meta values to update.
	 * @return bool True when at least one meta field was updated.
	 */
	private function update_post_meta_fields( $post_id, $meta ) {
		if ( ! is_array( $meta ) ) {
			return false;
		}

		$updated = false;

		foreach ( $meta as $key => $value ) {
			$meta_key = sanitize_key( $key );
			if ( '' === $meta_key ) {
				continue;
			}

			$value = $this->normalize_meta_value_for_storage( $meta_key, $value );

			// update_post_meta() runs stripslashes() before saving; wp_slash()
			// preserves literal backslashes in JSON and builder payloads.
			update_post_meta( $post_id, $meta_key, wp_slash( $value ) );
			$updated = true;
		}

		return $updated;
	}

	/**
	 * Normalize meta values before persistence.
	 *
	 * @since 4.0.4
	 * @param string $meta_key Meta key.
	 * @param mixed  $value    Meta value.
	 * @return mixed
	 */
	private function normalize_meta_value_for_storage( $meta_key, $value ) {
		if ( '_elementor_data' === $meta_key ) {
			return $this->normalize_elementor_meta_for_storage( $value );
		}

		return $value;
	}

	/**
	 * Normalize Elementor payloads to canonical JSON strings.
	 *
	 * Elementor expects `_elementor_data` in post meta as a JSON string that
	 * decodes to an array of elements. Clients often send one of these forms:
	 * - Raw element array/object
	 * - JSON string
	 * - Single-item wrapper arrays from `get_post_meta()` style responses
	 * - Nested JSON-string wrappers after prior bad writes
	 *
	 * This normalizer unwraps those variants and always stores one clean JSON
	 * string, preventing progressive double-serialization corruption.
	 *
	 * @since 4.0.4
	 * @param mixed $value Incoming `_elementor_data` value.
	 * @return string
	 */
	private function normalize_elementor_meta_for_storage( $value ) {
		// Unwrap get_post_meta-like wrappers: [ "<json>" ].
		$guard = 0;
		while ( is_array( $value ) && 1 === count( $value ) && $guard < 5 ) {
			$value = reset( $value );
			$guard++;
		}

		if ( is_array( $value ) ) {
			$json = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return is_string( $json ) ? $json : '[]';
		}

		if ( is_object( $value ) ) {
			$json = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return is_string( $json ) ? $json : '[]';
		}

		if ( is_string( $value ) ) {
			$decoded = $this->decode_nested_json_string( wp_unslash( $value ), 5 );
			if ( is_array( $decoded ) ) {
				$json = wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				return is_string( $json ) ? $json : '[]';
			}

			// Preserve non-JSON strings exactly as provided.
			return (string) wp_unslash( $value );
		}

		return (string) $value;
	}

	/**
	 * Decode nested JSON wrappers while the decoded value is another JSON string.
	 *
	 * @since 4.0.4
	 * @param mixed $value     Value to decode.
	 * @param int   $max_depth Maximum unwrap depth.
	 * @return mixed
	 */
	private function decode_nested_json_string( $value, $max_depth = 4 ) {
		$current = $value;
		$depth   = 0;

		while ( $depth < $max_depth && is_string( $current ) ) {
			$trimmed = trim( $current );
			if ( '' === $trimmed ) {
				break;
			}

			$first = substr( $trimmed, 0, 1 );
			if ( '[' !== $first && '{' !== $first && '"' !== $first ) {
				break;
			}

			$decoded = json_decode( $trimmed, true );
			if ( JSON_ERROR_NONE !== json_last_error() ) {
				break;
			}

			$current = $decoded;
			$depth++;

			if ( ! is_string( $current ) ) {
				break;
			}
		}

		return $current;
	}

	/**
	 * Clear Elementor CSS cache for a specific post when Elementor is in use.
	 *
	 * @since 2.0.8
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private function maybe_clear_elementor_css_cache_for_post( $post_id ) {
		if ( ! $this->is_elementor_post( $post_id ) || ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		$plugin = \Elementor\Plugin::$instance;
		if ( ! $plugin ) {
			return;
		}

		if ( isset( $plugin->posts_css_manager ) && method_exists( $plugin->posts_css_manager, 'clear_cache' ) ) {
			$plugin->posts_css_manager->clear_cache( $post_id );
			return;
		}

		if ( isset( $plugin->files_manager ) && method_exists( $plugin->files_manager, 'clear_cache' ) ) {
			$plugin->files_manager->clear_cache();
		}
	}

	/**
	 * Check whether a post is built with Elementor.
	 *
	 * @since 2.0.8
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function is_elementor_post( $post_id ) {
		if ( get_post_meta( $post_id, '_elementor_edit_mode', true ) ) {
			return true;
		}

		$builder = Respira_Builder_Interface::detect_builder( $post_id );

		return $builder && 'Elementor' === $builder->get_name();
	}

	/**
	 * Serve REST responses with JSON_UNESCAPED_UNICODE so multibyte characters
	 * (CJK, Arabic, Cyrillic, etc.) are returned as readable UTF-8 text.
	 *
	 * WordPress core uses wp_json_encode() without this flag, which converts
	 * every non-ASCII character to \uXXXX escape sequences. When the MCP server
	 * wraps the response in JSON.stringify(), these become double-escaped and
	 * unreadable for end users.
	 *
	 * Only intercepts requests to the Respira namespace to avoid side-effects
	 * on other REST endpoints.
	 *
	 * @since 5.2.0
	 * @param bool             $served  Whether the request has already been served.
	 * @param WP_HTTP_Response $result  Response object.
	 * @param WP_REST_Request  $request Request object.
	 * @param WP_REST_Server   $server  REST server instance.
	 * @return bool True if served, false to let WP handle it.
	 */
	public function serve_utf8_json( $served, $result, $request, $server ) {
		if ( $served ) {
			return $served;
		}

		$route = $request->get_route();
		if ( 0 !== strpos( $route, '/' . RESPIRA_REST_NAMESPACE ) ) {
			return false; // Not our namespace — let WP handle it.
		}

		// Build the response envelope the same way WP_REST_Server::serve_request() does.
		$response = $server->response_to_data( $result, $request['_embed'] ?? false );
		$json     = wp_json_encode( $response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		if ( false === $json ) {
			return false; // Encoding failed — fall back to WP default.
		}

		if ( ! headers_sent() ) {
			$server->send_header( 'Content-Type', 'application/json; charset=UTF-8' );
			$result_headers = $result instanceof WP_REST_Response ? $result->get_headers() : array();
			foreach ( $result_headers as $header => $value ) {
				$server->send_header( $header, $value );
			}
			$server->send_header( 'X-Respira-UTF8', '1' );
		}

		echo $json;

		return true; // We served it.
	}

	/**
	 * Purge frontend page caches after a post is updated.
	 *
	 * Fires hooks for the most common caching plugins so that visitors
	 * see the updated content immediately after a direct (live) edit.
	 *
	 * @since 5.2.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private function purge_frontend_caches( $post_id ) {
		// WordPress object cache (already called elsewhere, but ensure it runs).
		clean_post_cache( $post_id );

		// WP Super Cache.
		if ( function_exists( 'wp_cache_post_change' ) ) {
			wp_cache_post_change( $post_id );
		}

		// W3 Total Cache.
		if ( function_exists( 'w3tc_flush_post' ) ) {
			w3tc_flush_post( $post_id );
		}

		// WP Fastest Cache.
		if ( function_exists( 'wpfc_clear_post_cache_by_id' ) ) {
			wpfc_clear_post_cache_by_id( $post_id );
		} elseif ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'singleDeleteCache' ) ) {
			$GLOBALS['wp_fastest_cache']->singleDeleteCache( false, $post_id );
		}

		// LiteSpeed Cache.
		if ( class_exists( 'LiteSpeed\Purge' ) ) {
			do_action( 'litespeed_purge_post', $post_id );
		}

		// Autoptimize.
		if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
			autoptimizeCache::clearall();
		}

		// SG Optimizer (SiteGround).
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache( get_permalink( $post_id ) );
		}

		// WP-Optimize.
		if ( class_exists( 'WP_Optimize' ) && function_exists( 'wpo_cache_flush' ) ) {
			wpo_cache_flush();
		}

		// Kinsta Cache (MU plugin).
		if ( class_exists( 'Developer\KinstaMU\Cache\CachePurge' ) ) {
			wp_remote_get(
				admin_url( 'admin-ajax.php?action=kinsta-clear-cache-all' ),
				array( 'timeout' => 5, 'blocking' => false )
			);
		}

		// Cloudflare (via official plugin).
		if ( class_exists( '\CF\WordPress\Hooks' ) ) {
			do_action( 'cloudflare_purge_by_url', get_permalink( $post_id ) );
		}

		// Generic hook — third-party plugins can hook into this.
		do_action( 'respira_after_cache_purge', $post_id );
	}

	/**
	 * Purge frontend caches when a duplicate is approved and goes live.
	 *
	 * @since 5.2.0
	 * @param int $duplicate_id The approved duplicate post ID.
	 * @param int $original_id  The original post ID.
	 * @return void
	 */
	public function on_duplicate_approved_purge_caches( $duplicate_id, $original_id ) {
		$this->purge_frontend_caches( $duplicate_id );
		if ( $original_id && $original_id !== $duplicate_id ) {
			$this->purge_frontend_caches( $original_id );
		}
	}

	/**
	 * Get post meta for API responses with raw Elementor JSON preserved.
	 *
	 * @since 2.0.8
	 * @param int $post_id Post ID.
	 * @return array
	 */
	private function get_post_meta_for_response( $post_id ) {
		$meta = get_post_meta( $post_id );

		if ( isset( $meta['_elementor_data'] ) ) {
			$raw_values = $this->get_raw_post_meta_values( $post_id, '_elementor_data' );
			if ( ! empty( $raw_values ) ) {
				$meta['_elementor_data'] = array_map( array( $this, 'repair_bare_unicode_escapes' ), $raw_values );
			}
		}

		return $meta;
	}

	/**
	 * Get raw postmeta rows without WP value normalization.
	 *
	 * @since 2.0.8
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key.
	 * @return array
	 */
	private function get_raw_post_meta_values( $post_id, $meta_key ) {
		global $wpdb;

		$raw_values = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s",
				$post_id,
				$meta_key
			)
		);

		return is_array( $raw_values ) ? $raw_values : array();
	}

	/**
	 * Repair broken unicode escape sequences (uXXXX -> \uXXXX) in JSON strings.
	 *
	 * @since 2.0.8
	 * @param mixed $value Meta value.
	 * @return mixed
	 */
	private function repair_bare_unicode_escapes( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/u[0-9a-fA-F]{4}/', $value ) ) {
			return $value;
		}

		json_decode( $value, true );
		if ( JSON_ERROR_NONE === json_last_error() ) {
			return $value;
		}

		$repaired = preg_replace( '/(?<!\\\\)u([0-9a-fA-F]{4})/', '\\\\u$1', $value );
		if ( ! is_string( $repaired ) || $repaired === $value ) {
			return $value;
		}

		json_decode( $repaired, true );

		return ( JSON_ERROR_NONE === json_last_error() ) ? $repaired : $value;
	}

	/**
	 * Get allowed HTML tags for API content.
	 *
	 * Returns an array of allowed HTML tags and attributes for content
	 * submitted via the Respira API. Extends wp_kses_post to allow:
	 * - Script tags (for third-party embeds, analytics, etc.)
	 * - Data attributes (for modern JavaScript frameworks)
	 * - SVG elements (for scalable graphics)
	 * - Modern web components
	 *
	 * @since  1.0.3
	 * @return array Allowed HTML tags and attributes.
	 */
	private function get_allowed_html_for_api() {
		// Start with WordPress post allowed tags.
		$allowed = wp_kses_allowed_html( 'post' );

		// Allow script tags for third-party embeds (Cal.com, analytics, etc.).
		$allowed['script'] = array(
			'type'            => true,
			'src'             => true,
			'async'           => true,
			'defer'           => true,
			'charset'         => true,
			'crossorigin'     => true,
			'integrity'       => true,
			'nomodule'        => true,
			'nonce'           => true,
			'referrerpolicy'  => true,
		);

		// Allow style tags for inline CSS blocks (critical for builder code modules).
		$allowed['style'] = array(
			'type'   => true,
			'media'  => true,
			'scoped' => true,
			'nonce'  => true,
			'id'     => true,
			'class'  => true,
			'title'  => true,
		);

		// Allow iframe for embeds (videos, maps, etc.).
		$allowed['iframe'] = array(
			'src'             => true,
			'width'           => true,
			'height'          => true,
			'frameborder'     => true,
			'allowfullscreen' => true,
			'allow'           => true,
			'loading'         => true,
			'title'           => true,
			'name'            => true,
			'sandbox'         => true,
		);

		// Allow data attributes on all tags for modern JavaScript.
		foreach ( $allowed as $tag => $attributes ) {
			if ( is_array( $attributes ) ) {
				// Preserve inline styles for layout fidelity (e.g. display:flex).
				$allowed[ $tag ]['style'] = true;
				// Allow all data-* attributes.
				$allowed[ $tag ]['data-*'] = true;
				// Common data attributes.
				$allowed[ $tag ]['data-parallax']       = true;
				$allowed[ $tag ]['data-parallax-speed'] = true;
				$allowed[ $tag ]['data-aos']            = true;
				$allowed[ $tag ]['data-aos-delay']      = true;
				$allowed[ $tag ]['data-sal']            = true;
				$allowed[ $tag ]['data-scroll']         = true;
			}
		}

		// Allow SVG elements for scalable graphics.
		$svg_args = array(
			'class'           => true,
			'aria-hidden'     => true,
			'aria-labelledby' => true,
			'role'            => true,
			'xmlns'           => true,
			'width'           => true,
			'height'          => true,
			'viewbox'         => true,
			'fill'            => true,
			'stroke'          => true,
			'stroke-width'    => true,
			'stroke-linecap'  => true,
			'stroke-linejoin' => true,
		);

		$allowed['svg']   = $svg_args;
		$allowed['g']     = $svg_args;
		$allowed['title'] = array( 'title' => true );
		$allowed['path']  = $svg_args + array(
			'd'          => true,
			'fill-rule'  => true,
			'clip-rule'  => true,
		);
		$allowed['circle']   = $svg_args + array( 'cx' => true, 'cy' => true, 'r' => true );
		$allowed['rect']     = $svg_args + array( 'x' => true, 'y' => true, 'rx' => true, 'ry' => true );
		$allowed['line']     = $svg_args + array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true );
		$allowed['polygon']  = $svg_args + array( 'points' => true );
		$allowed['polyline'] = $svg_args + array( 'points' => true );

		return $allowed;
	}

	/**
	 * Preserve script tags in Divi HTML content and code blocks.
	 *
	 * Divi's et_pb_html_content and et_pb_code blocks may contain JavaScript.
	 * This method decodes any HTML entities in these blocks to preserve scripts.
	 *
	 * @since  1.0.3
	 * @param  string $content Content to process.
	 * @return string Content with decoded scripts in Divi blocks.
	 */
	private function preserve_divi_scripts( $content ) {
		// Preserve scripts in et_pb_html_content blocks.
		$content = preg_replace_callback(
			'/\[et_pb_html_content([^\]]*)\](.*?)\[\/et_pb_html_content\]/s',
			function( $matches ) {
				$attributes   = $matches[1];
				$html_content = $matches[2];

				// If it contains script tags (even encoded), decode them.
				if ( stripos( $html_content, 'script' ) !== false ) {
					$html_content = html_entity_decode( $html_content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				}

				return '[et_pb_html_content' . $attributes . ']' . $html_content . '[/et_pb_html_content]';
			},
			$content
		);

		// Preserve scripts in et_pb_code blocks.
		$content = preg_replace_callback(
			'/\[et_pb_code([^\]]*)\](.*?)\[\/et_pb_code\]/s',
			function( $matches ) {
				$attributes   = $matches[1];
				$code_content = $matches[2];

				// If it contains script tags (even encoded), decode them.
				if ( stripos( $code_content, 'script' ) !== false ) {
					$code_content = html_entity_decode( $code_content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				}

				return '[et_pb_code' . $attributes . ']' . $code_content . '[/et_pb_code]';
			},
			$content
		);

		return $content;
	}

	/**
	 * Sanitize content for API updates.
	 *
	 * Sanitizes HTML content while preserving script tags, modern web features,
	 * and Divi Builder shortcodes. This is more permissive than wp_kses_post
	 * but still secure for authenticated API requests.
	 *
	 * @since  1.0.3
	 * @param  string $content Content to sanitize.
	 * @return string Sanitized content.
	 */
	private function sanitize_api_content( $content ) {
		// If the current user has unfiltered_html capability (admins), skip wp_kses
		// entirely. This preserves <style> tags and their contents, which wp_kses
		// corrupts by treating CSS selectors as HTML. The API already requires
		// authentication, so this is safe for admin-level requests.
		if ( current_user_can( 'unfiltered_html' ) ) {
			// Still preserve/decode scripts in Divi blocks for consistency.
			return $this->preserve_divi_scripts( $content );
		}

		// First, preserve and decode scripts in Divi blocks.
		$content = $this->preserve_divi_scripts( $content );

		// Allow the full set of HTML tags for API content.
		$allowed_html = $this->get_allowed_html_for_api();

		// Sanitize with extended allowed tags.
		$sanitized = wp_kses( $content, $allowed_html );

		// Preserve Divi shortcodes - they may contain encoded content.
		// This ensures et_pb_html_content and et_pb_code blocks work correctly.
		return $sanitized;
	}

	/**
	 * Sanitize custom CSS.
	 *
	 * Sanitizes CSS while preserving CSS syntax. Removes potentially
	 * dangerous content but keeps valid CSS. Supports Divi Builder
	 * custom CSS meta field (_et_pb_custom_css for Divi or _elementor_page_settings.custom_css for Elementor).
	 *
	 * @since  1.0.1
	 * @param  string $css CSS content to sanitize.
	 * @return string Sanitized CSS.
	 */
	public function sanitize_custom_css( $css ) {
		// Allow empty string to clear custom CSS.
		if ( '' === $css ) {
			return '';
		}

		// Remove any HTML/PHP tags while preserving CSS.
		$css = wp_strip_all_tags( $css );

		// Remove any null bytes.
		$css = str_replace( chr( 0 ), '', $css );

		// Trim whitespace.
		$css = trim( $css );

		// Optional: Add size limit (50KB recommended).
		$max_size = apply_filters( 'respira_custom_css_max_size', 51200 ); // 50KB default.
		if ( strlen( $css ) > $max_size ) {
			return new WP_Error(
				'respira_css_too_large',
				sprintf(
					/* translators: %s: Maximum size in KB */
					__( 'Custom CSS exceeds maximum size of %s KB.', 'respira-for-wordpress' ),
					number_format( $max_size / 1024, 0 )
				),
				array( 'status' => 400 )
			);
		}

		return $css;
	}

	/**
	 * Save custom CSS to Elementor's page settings.
	 *
	 * Elementor stores per-page custom CSS in _elementor_page_settings meta
	 * under the 'custom_css' key, NOT in _elementor_css (which is cache data).
	 *
	 * @since  1.9.5
	 * @param  int    $post_id Post ID.
	 * @param  string $css     CSS content (empty string to clear).
	 * @return void
	 */
	private function save_elementor_custom_css( $post_id, $css ) {
		// Read existing page settings (preserve other settings like padding, etc.).
		$page_settings = get_post_meta( $post_id, '_elementor_page_settings', true );
		if ( ! is_array( $page_settings ) ) {
			$page_settings = array();
		}

		if ( '' === $css ) {
			unset( $page_settings['custom_css'] );
		} else {
			$page_settings['custom_css'] = $css;
		}

		update_post_meta( $post_id, '_elementor_page_settings', $page_settings );

		// Clear Elementor's per-post CSS cache so it regenerates with the new CSS.
		$this->maybe_clear_elementor_css_cache_for_post( $post_id );
	}

	/**
	 * Get common list args for pagination.
	 *
	 * @since  1.0.0
	 * @return array Args array.
	 */
	private function get_list_args() {
		return array(
			'page'     => array(
				'required'          => false,
				'type'              => 'integer',
				'default'           => 1,
				'sanitize_callback' => 'absint',
			),
			'per_page' => array(
				'required'          => false,
				'type'              => 'integer',
				'default'           => 20,
				'sanitize_callback' => 'absint',
			),
			'search'   => array(
				'required'          => false,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'status'   => array(
				'required' => false,
				'type'     => 'string',
			),
		);
	}

	/**
	 * Detect active SEO plugin.
	 *
	 * @since  1.0.1
	 * @return string SEO plugin identifier ('yoast', 'rank_math', 'aioseo', 'core').
	 */
	private function detect_seo_plugin() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) || defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		} elseif ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) || defined( 'RANK_MATH_VERSION' ) ) {
			return 'rank_math';
		} elseif ( is_plugin_active( 'all-in-one-seo-pack/all_in_one_seo_pack.php' ) || defined( 'AIOSEOP_VERSION' ) ) {
			return 'aioseo';
		}

		return 'core';
	}

	/**
	 * Update SEO meta fields.
	 *
	 * @since  1.0.1
	 * @param  int   $post_id  Post ID.
	 * @param  array $seo_data SEO data array.
	 * @return bool  True on success.
	 */
	private function update_seo_meta( $post_id, $seo_data ) {
		$seo_plugin = $this->detect_seo_plugin();

		switch ( $seo_plugin ) {
			case 'yoast':
				return $this->update_yoast_seo( $post_id, $seo_data );
			case 'rank_math':
				return $this->update_rank_math_seo( $post_id, $seo_data );
			case 'aioseo':
				return $this->update_aioseo_seo( $post_id, $seo_data );
			default:
				return $this->update_core_seo( $post_id, $seo_data );
		}
	}

	/**
	 * Update Yoast SEO meta fields.
	 *
	 * @since  1.0.1
	 * @param  int   $post_id  Post ID.
	 * @param  array $seo_data SEO data array.
	 * @return bool  True on success.
	 */
	private function update_yoast_seo( $post_id, $seo_data ) {
		$mapping = array(
			'title'              => '_yoast_wpseo_title',
			'description'        => '_yoast_wpseo_metadesc',
			'focus_keyword'      => '_yoast_wpseo_focuskw',
			'og_title'           => '_yoast_wpseo_opengraph-title',
			'og_description'     => '_yoast_wpseo_opengraph-description',
			'og_image'           => '_yoast_wpseo_opengraph-image',
			'twitter_title'      => '_yoast_wpseo_twitter-title',
			'twitter_description' => '_yoast_wpseo_twitter-description',
			'twitter_image'      => '_yoast_wpseo_twitter-image',
			'canonical_url'      => '_yoast_wpseo_canonical',
		);

		foreach ( $mapping as $key => $meta_key ) {
			if ( isset( $seo_data[ $key ] ) ) {
				$value = $this->sanitize_seo_field( $key, $seo_data[ $key ] );
				update_post_meta( $post_id, $meta_key, $value );
			}
		}

		// Handle robots directives.
		if ( isset( $seo_data['robots'] ) ) {
			$this->update_yoast_robots( $post_id, $seo_data['robots'] );
		}

		return true;
	}

	/**
	 * Update Yoast robots directives.
	 *
	 * @since  1.0.1
	 * @param  int    $post_id Post ID.
	 * @param  string $robots  Robots directives string.
	 * @return void
	 */
	private function update_yoast_robots( $post_id, $robots ) {
		$robots = strtolower( $robots );

		// Parse robots string (e.g., "index, follow" or "noindex, nofollow").
		$no_index  = strpos( $robots, 'noindex' ) !== false ? 1 : 0;
		$no_follow = strpos( $robots, 'nofollow' ) !== false ? 1 : 0;

		update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', $no_index );
		update_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', $no_follow );

		// Advanced directives (noodp, noimageindex, noarchive, nosnippet).
		$advanced = array();
		if ( strpos( $robots, 'noodp' ) !== false ) {
			$advanced[] = 'noodp';
		}
		if ( strpos( $robots, 'noimageindex' ) !== false ) {
			$advanced[] = 'noimageindex';
		}
		if ( strpos( $robots, 'noarchive' ) !== false ) {
			$advanced[] = 'noarchive';
		}
		if ( strpos( $robots, 'nosnippet' ) !== false ) {
			$advanced[] = 'nosnippet';
		}

		if ( ! empty( $advanced ) ) {
			update_post_meta( $post_id, '_yoast_wpseo_meta-robots-adv', implode( ',', $advanced ) );
		}
	}

	/**
	 * Update Rank Math SEO meta fields.
	 *
	 * @since  1.0.1
	 * @param  int   $post_id  Post ID.
	 * @param  array $seo_data SEO data array.
	 * @return bool  True on success.
	 */
	private function update_rank_math_seo( $post_id, $seo_data ) {
		$mapping = array(
			'title'              => 'rank_math_title',
			'description'        => 'rank_math_description',
			'focus_keyword'      => 'rank_math_focus_keyword',
			'og_title'           => 'rank_math_facebook_title',
			'og_description'     => 'rank_math_facebook_description',
			'twitter_title'      => 'rank_math_twitter_title',
			'twitter_description' => 'rank_math_twitter_description',
			'canonical_url'      => 'rank_math_canonical_url',
		);

		foreach ( $mapping as $key => $meta_key ) {
			if ( isset( $seo_data[ $key ] ) ) {
				$value = $this->sanitize_seo_field( $key, $seo_data[ $key ] );
				update_post_meta( $post_id, $meta_key, $value );
			}
		}

		// Handle OG/Twitter images (Rank Math uses attachment IDs).
		if ( isset( $seo_data['og_image'] ) ) {
			$image_id = $this->get_or_create_attachment( $seo_data['og_image'], $post_id );
			if ( $image_id ) {
				update_post_meta( $post_id, 'rank_math_facebook_image', $image_id );
				update_post_meta( $post_id, 'rank_math_facebook_image_id', $image_id );
			}
		}

		if ( isset( $seo_data['twitter_image'] ) ) {
			$image_id = $this->get_or_create_attachment( $seo_data['twitter_image'], $post_id );
			if ( $image_id ) {
				update_post_meta( $post_id, 'rank_math_twitter_image', $image_id );
				update_post_meta( $post_id, 'rank_math_twitter_image_id', $image_id );
			}
		}

		// Handle robots directives.
		if ( isset( $seo_data['robots'] ) ) {
			$robots_array = array_map( 'trim', explode( ',', strtolower( $seo_data['robots'] ) ) );
			update_post_meta( $post_id, 'rank_math_robots', $robots_array );
		}

		return true;
	}

	/**
	 * Update All in One SEO meta fields.
	 *
	 * @since  1.0.1
	 * @param  int   $post_id  Post ID.
	 * @param  array $seo_data SEO data array.
	 * @return bool  True on success.
	 */
	private function update_aioseo_seo( $post_id, $seo_data ) {
		$mapping = array(
			'title'         => '_aioseop_title',
			'description'   => '_aioseop_description',
			'og_title'      => '_aioseop_opengraph_settings',
			'og_description' => '_aioseop_opengraph_settings',
			'og_image'      => '_aioseop_opengraph_settings',
			'canonical_url' => '_aioseop_custom_link',
		);

		// AIOSEO stores some data in a serialized array.
		$opengraph_settings = get_post_meta( $post_id, '_aioseop_opengraph_settings', true );
		if ( ! is_array( $opengraph_settings ) ) {
			$opengraph_settings = array();
		}

		if ( isset( $seo_data['title'] ) ) {
			update_post_meta( $post_id, '_aioseop_title', sanitize_text_field( $seo_data['title'] ) );
		}

		if ( isset( $seo_data['description'] ) ) {
			update_post_meta( $post_id, '_aioseop_description', sanitize_text_field( $seo_data['description'] ) );
		}

		if ( isset( $seo_data['og_title'] ) ) {
			$opengraph_settings['aioseop_opengraph_settings_title'] = sanitize_text_field( $seo_data['og_title'] );
		}

		if ( isset( $seo_data['og_description'] ) ) {
			$opengraph_settings['aioseop_opengraph_settings_desc'] = sanitize_text_field( $seo_data['og_description'] );
		}

		if ( isset( $seo_data['og_image'] ) ) {
			$opengraph_settings['aioseop_opengraph_settings_image'] = esc_url_raw( $seo_data['og_image'] );
		}

		update_post_meta( $post_id, '_aioseop_opengraph_settings', $opengraph_settings );

		if ( isset( $seo_data['canonical_url'] ) ) {
			update_post_meta( $post_id, '_aioseop_custom_link', esc_url_raw( $seo_data['canonical_url'] ) );
		}

		return true;
	}

	/**
	 * Update core WordPress SEO fields (fallback).
	 *
	 * @since  1.0.1
	 * @param  int   $post_id  Post ID.
	 * @param  array $seo_data SEO data array.
	 * @return bool  True on success.
	 */
	private function update_core_seo( $post_id, $seo_data ) {
		// Use post excerpt for description if no SEO plugin.
		if ( isset( $seo_data['description'] ) ) {
			wp_update_post(
				wp_slash(
					array(
						'ID'           => $post_id,
						'post_excerpt' => sanitize_text_field( $seo_data['description'] ),
					)
				)
			);
		}

		// Store basic SEO data in custom meta fields.
		if ( isset( $seo_data['title'] ) ) {
			update_post_meta( $post_id, '_seo_title', sanitize_text_field( $seo_data['title'] ) );
		}

		if ( isset( $seo_data['og_title'] ) ) {
			update_post_meta( $post_id, '_og_title', sanitize_text_field( $seo_data['og_title'] ) );
		}

		if ( isset( $seo_data['og_description'] ) ) {
			update_post_meta( $post_id, '_og_description', sanitize_text_field( $seo_data['og_description'] ) );
		}

		if ( isset( $seo_data['og_image'] ) ) {
			update_post_meta( $post_id, '_og_image', esc_url_raw( $seo_data['og_image'] ) );
		}

		return true;
	}

	/**
	 * Sanitize SEO field.
	 *
	 * @since  1.0.1
	 * @param  string $field Field name.
	 * @param  mixed  $value Field value.
	 * @return mixed  Sanitized value.
	 */
	private function sanitize_seo_field( $field, $value ) {
		// URL fields.
		if ( in_array( $field, array( 'og_image', 'twitter_image', 'canonical_url' ), true ) ) {
			return esc_url_raw( $value );
		}

		// Text fields.
		return sanitize_text_field( $value );
	}

	/**
	 * Update featured image.
	 *
	 * @since  1.0.1
	 * @param  int   $post_id    Post ID.
	 * @param  array $image_data Image data array.
	 * @return int|false Attachment ID on success, false on failure.
	 */
	private function update_featured_image( $post_id, $image_data ) {
		// If attachment ID provided, use it directly.
		if ( isset( $image_data['id'] ) && is_numeric( $image_data['id'] ) ) {
			$attachment_id = intval( $image_data['id'] );
			if ( get_post( $attachment_id ) && 'attachment' === get_post_type( $attachment_id ) ) {
				set_post_thumbnail( $post_id, $attachment_id );

				// Update alt text if provided.
				if ( isset( $image_data['alt'] ) ) {
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $image_data['alt'] ) );
				}

				return $attachment_id;
			}
		}

		// If URL provided, download and create attachment.
		if ( isset( $image_data['url'] ) ) {
			$attachment_id = $this->get_or_create_attachment( $image_data['url'], $post_id );
			if ( $attachment_id ) {
				set_post_thumbnail( $post_id, $attachment_id );

				// Update attachment metadata.
				if ( isset( $image_data['alt'] ) ) {
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $image_data['alt'] ) );
				}

				if ( isset( $image_data['title'] ) ) {
					wp_update_post(
						wp_slash(
							array(
								'ID'         => $attachment_id,
								'post_title' => sanitize_text_field( $image_data['title'] ),
							)
						)
					);
				}

				return $attachment_id;
			}
		}

		return false;
	}

	/**
	 * Get or create attachment from URL.
	 *
	 * @since  1.0.1
	 * @param  string $image_url Image URL.
	 * @param  int    $post_id   Post ID to attach image to.
	 * @return int|false Attachment ID on success, false on failure.
	 */
	private function get_or_create_attachment( $image_url, $post_id = 0 ) {
		// Check if URL is valid.
		if ( ! filter_var( $image_url, FILTER_VALIDATE_URL ) ) {
			return false;
		}

		// Check if attachment already exists by URL.
		$existing_attachment = $this->get_attachment_by_url( $image_url );
		if ( $existing_attachment ) {
			return $existing_attachment;
		}

		// Download and create attachment.
		return $this->download_and_create_attachment( $image_url, $post_id );
	}

	/**
	 * Get attachment ID by URL.
	 *
	 * @since  1.0.1
	 * @param  string $url Image URL.
	 * @return int|false Attachment ID if found, false otherwise.
	 */
	private function get_attachment_by_url( $url ) {
		global $wpdb;

		$attachment = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE guid = %s AND post_type = 'attachment'",
				$url
			)
		);

		return $attachment ? intval( $attachment ) : false;
	}

	/**
	 * Download image and create attachment.
	 *
	 * @since  1.0.1
	 * @param  string $image_url Image URL.
	 * @param  int    $post_id   Post ID to attach image to.
	 * @return int|false Attachment ID on success, false on failure.
	 */
	private function download_and_create_attachment( $image_url, $post_id = 0 ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Validate URL.
		if ( ! filter_var( $image_url, FILTER_VALIDATE_URL ) ) {
			return false;
		}

		// Download image.
		$tmp = download_url( $image_url, 300 ); // 5 minute timeout.

		if ( is_wp_error( $tmp ) ) {
			return false;
		}

		// Get file extension and validate.
		$file_array = array(
			'name'     => basename( wp_parse_url( $image_url, PHP_URL_PATH ) ),
			'tmp_name' => $tmp,
		);

		// Ensure file has a name.
		if ( empty( $file_array['name'] ) ) {
			$file_array['name'] = 'image-' . time() . '.jpg';
		}

		// Validate file type.
		$file_type = wp_check_filetype( $file_array['name'] );
		$allowed_types = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml' );

		if ( ! in_array( $file_type['type'], $allowed_types, true ) ) {
			@unlink( $tmp );
			return false;
		}

		// Check file size (max 10MB).
		$max_size = apply_filters( 'respira_max_image_size', 10485760 ); // 10MB default.
		if ( filesize( $tmp ) > $max_size ) {
			@unlink( $tmp );
			return false;
		}

		// Create attachment.
		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp );
			return false;
		}

		return $attachment_id;
	}

	/**
	 * Get SEO meta data for a post.
	 *
	 * @since  1.0.1
	 * @param  int $post_id Post ID.
	 * @return array SEO meta data.
	 */
	private function get_seo_meta( $post_id ) {
		$seo_plugin = $this->detect_seo_plugin();
		$seo_data   = array();

		switch ( $seo_plugin ) {
			case 'yoast':
				$seo_data = $this->get_yoast_seo( $post_id );
				break;
			case 'rank_math':
				$seo_data = $this->get_rank_math_seo( $post_id );
				break;
			case 'aioseo':
				$seo_data = $this->get_aioseo_seo( $post_id );
				break;
			default:
				$seo_data = $this->get_core_seo( $post_id );
		}

		// Add SEO plugin info.
		$seo_data['seo_plugin'] = $seo_plugin;

		return $seo_data;
	}

	/**
	 * Get Yoast SEO meta data.
	 *
	 * @since  1.0.1
	 * @param  int $post_id Post ID.
	 * @return array SEO meta data.
	 */
	private function get_yoast_seo( $post_id ) {
		return array(
			'title'              => get_post_meta( $post_id, '_yoast_wpseo_title', true ),
			'description'        => get_post_meta( $post_id, '_yoast_wpseo_metadesc', true ),
			'focus_keyword'      => get_post_meta( $post_id, '_yoast_wpseo_focuskw', true ),
			'og_title'           => get_post_meta( $post_id, '_yoast_wpseo_opengraph-title', true ),
			'og_description'     => get_post_meta( $post_id, '_yoast_wpseo_opengraph-description', true ),
			'og_image'           => get_post_meta( $post_id, '_yoast_wpseo_opengraph-image', true ),
			'twitter_title'      => get_post_meta( $post_id, '_yoast_wpseo_twitter-title', true ),
			'twitter_description' => get_post_meta( $post_id, '_yoast_wpseo_twitter-description', true ),
			'twitter_image'      => get_post_meta( $post_id, '_yoast_wpseo_twitter-image', true ),
			'canonical_url'      => get_post_meta( $post_id, '_yoast_wpseo_canonical', true ),
		);
	}

	/**
	 * Get Rank Math SEO meta data.
	 *
	 * @since  1.0.1
	 * @param  int $post_id Post ID.
	 * @return array SEO meta data.
	 */
	private function get_rank_math_seo( $post_id ) {
		$og_image_id      = get_post_meta( $post_id, 'rank_math_facebook_image_id', true );
		$twitter_image_id = get_post_meta( $post_id, 'rank_math_twitter_image_id', true );

		return array(
			'title'              => get_post_meta( $post_id, 'rank_math_title', true ),
			'description'        => get_post_meta( $post_id, 'rank_math_description', true ),
			'focus_keyword'      => get_post_meta( $post_id, 'rank_math_focus_keyword', true ),
			'og_title'           => get_post_meta( $post_id, 'rank_math_facebook_title', true ),
			'og_description'     => get_post_meta( $post_id, 'rank_math_facebook_description', true ),
			'og_image'           => $og_image_id ? wp_get_attachment_url( $og_image_id ) : '',
			'twitter_title'      => get_post_meta( $post_id, 'rank_math_twitter_title', true ),
			'twitter_description' => get_post_meta( $post_id, 'rank_math_twitter_description', true ),
			'twitter_image'      => $twitter_image_id ? wp_get_attachment_url( $twitter_image_id ) : '',
			'canonical_url'      => get_post_meta( $post_id, 'rank_math_canonical_url', true ),
		);
	}

	/**
	 * Get All in One SEO meta data.
	 *
	 * @since  1.0.1
	 * @param  int $post_id Post ID.
	 * @return array SEO meta data.
	 */
	private function get_aioseo_seo( $post_id ) {
		$opengraph_settings = get_post_meta( $post_id, '_aioseop_opengraph_settings', true );
		if ( ! is_array( $opengraph_settings ) ) {
			$opengraph_settings = array();
		}

		return array(
			'title'         => get_post_meta( $post_id, '_aioseop_title', true ),
			'description'   => get_post_meta( $post_id, '_aioseop_description', true ),
			'og_title'      => isset( $opengraph_settings['aioseop_opengraph_settings_title'] ) ? $opengraph_settings['aioseop_opengraph_settings_title'] : '',
			'og_description' => isset( $opengraph_settings['aioseop_opengraph_settings_desc'] ) ? $opengraph_settings['aioseop_opengraph_settings_desc'] : '',
			'og_image'      => isset( $opengraph_settings['aioseop_opengraph_settings_image'] ) ? $opengraph_settings['aioseop_opengraph_settings_image'] : '',
			'canonical_url' => get_post_meta( $post_id, '_aioseop_custom_link', true ),
		);
	}

	/**
	 * Get core WordPress SEO data (fallback).
	 *
	 * @since  1.0.1
	 * @param  int $post_id Post ID.
	 * @return array SEO meta data.
	 */
	private function get_core_seo( $post_id ) {
		$post = get_post( $post_id );

		return array(
			'title'         => get_post_meta( $post_id, '_seo_title', true ),
			'description'   => $post ? $post->post_excerpt : '',
			'og_title'      => get_post_meta( $post_id, '_og_title', true ),
			'og_description' => get_post_meta( $post_id, '_og_description', true ),
			'og_image'      => get_post_meta( $post_id, '_og_image', true ),
		);
	}

	/**
	 * Output custom CSS to page head.
	 *
	 * Outputs custom CSS stored in the _et_pb_custom_css (Divi) or
	 * _elementor_page_settings.custom_css (Elementor) meta field to the page's
	 * <head> section when the page is rendered on the frontend.
	 * This ensures that custom CSS set via the API is actually applied to the page.
	 *
	 * @since  1.0.2
	 * @return void
	 */
	public function output_page_custom_css() {
		// Only output on single page views.
		if ( ! is_singular( 'page' ) ) {
			return;
		}

		global $post;
		if ( ! $post || ! isset( $post->ID ) ) {
			return;
		}

		// Get custom CSS from meta field (try Divi first, then Elementor page settings).
		$custom_css = get_post_meta( $post->ID, '_et_pb_custom_css', true );
		if ( ! $custom_css ) {
			$page_settings = get_post_meta( $post->ID, '_elementor_page_settings', true );
			if ( is_array( $page_settings ) && ! empty( $page_settings['custom_css'] ) ) {
				$custom_css = $page_settings['custom_css'];
			}
		}

		// If CSS exists and is not empty, output it.
		if ( ! empty( $custom_css ) ) {
			// Sanitize one more time for safety (remove any HTML tags).
			$sanitized_css = wp_strip_all_tags( $custom_css );

			// Output CSS in style tag.
			echo "\n<!-- Respira Custom CSS -->\n";
			echo '<style id="respira-page-custom-css" type="text/css">' . "\n";
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS is sanitized above with wp_strip_all_tags.
			echo $sanitized_css . "\n";
			echo '</style>' . "\n";
		}
	}

	/**
	 * Add approval links to analysis response.
	 *
	 * @since  1.7.2
	 * @param  array $result Analysis result array.
	 * @param  int   $page_id Page ID being analyzed.
	 * @return array Modified result array with links.
	 */
	private function add_approval_links_to_response( $result, $page_id ) {
		if ( ! is_array( $result ) ) {
			return $result;
		}

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-duplicator.php';

		// Check if this page has duplicates.
		$duplicates = Respira_Duplicator::get_duplicates( $page_id );
		$has_duplicates = ! empty( $duplicates );

		// Get approvals page URL.
		$approvals_url = admin_url( 'admin.php?page=respira-changes' );

		// Initialize links array if it doesn't exist.
		if ( ! isset( $result['links'] ) ) {
			$result['links'] = array();
		}

		// Always include the approvals page URL.
		$result['links']['approve_edits'] = $approvals_url;

		// Add next steps if duplicates exist.
		if ( $has_duplicates ) {
			if ( ! isset( $result['next_steps'] ) ) {
				$result['next_steps'] = array();
			}

			$duplicate_count = count( $duplicates );
			$result['next_steps'][] = sprintf(
				/* translators: 1: number of duplicates, 2: approvals page URL */
				__( 'Review and approve %1$d duplicate page(s) in WordPress admin: %2$s', 'respira-for-wordpress' ),
				$duplicate_count,
				$approvals_url
			);

			// Add duplicate IDs for reference.
			$result['duplicate_ids'] = array_map(
				function( $duplicate ) {
					return $duplicate->ID;
				},
				$duplicates
			);
		}

		return $result;
	}

	/**
	 * Analyze page performance.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_performance( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-performance-analyzer.php';
		$analyzer = new Respira_Performance_Analyzer();
		$result   = $analyzer->analyze_performance( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Get Core Web Vitals.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_core_web_vitals( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-performance-analyzer.php';
		$analyzer = new Respira_Performance_Analyzer();
		$result   = $analyzer->get_core_web_vitals( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Analyze images on a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_images( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-performance-analyzer.php';
		$analyzer = new Respira_Performance_Analyzer();
		$result   = $analyzer->analyze_images( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Analyze SEO for a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_seo( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-seo-analyzer.php';
		$analyzer = new Respira_SEO_Analyzer();
		$result   = $analyzer->analyze_seo( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Check SEO issues for a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function check_seo_issues( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-seo-analyzer.php';
		$analyzer = new Respira_SEO_Analyzer();
		$result   = $analyzer->check_seo_issues( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Analyze readability for a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_readability( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-seo-analyzer.php';
		$analyzer = new Respira_SEO_Analyzer();
		$result   = $analyzer->analyze_readability( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Analyze Rank Math SEO score and checks for a post.
	 *
	 * @since  4.3.2
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_rankmath( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-seo-analyzer.php';
		$analyzer = new Respira_SEO_Analyzer();
		$result   = $analyzer->analyze_rankmath( $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Analyze AEO for a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function analyze_aeo( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-aeo-analyzer.php';
		$analyzer = new Respira_AEO_Analyzer();
		$result   = $analyzer->analyze_aeo( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Check structured data for a page.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function check_structured_data( $request ) {
		$page_id = $request->get_param( 'page_id' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/analyzers/class-respira-aeo-analyzer.php';
		$analyzer = new Respira_AEO_Analyzer();
		$result   = $analyzer->check_structured_data( $page_id );

		// Add approval links to response.
		$result = $this->add_approval_links_to_response( $result, $page_id );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * List all plugins.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function list_plugins( $request ) {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->list_plugins();

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Install a plugin.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function install_plugin( $request ) {
		$slug_or_url = $request->get_param( 'slug_or_url' );
		$source      = $request->get_param( 'source' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->install_plugin( $slug_or_url, $source );

		return new WP_REST_Response( $result, $result['success'] ? 200 : 400 );
	}

	/**
	 * Activate a plugin.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function activate_plugin( $request ) {
		$slug = $request->get_param( 'slug' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->activate_plugin( $slug );

		return new WP_REST_Response( $result, $result['success'] ? 200 : 400 );
	}

	/**
	 * Deactivate a plugin.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function deactivate_plugin( $request ) {
		$slug = $request->get_param( 'slug' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->deactivate_plugin( $slug );

		return new WP_REST_Response( $result, $result['success'] ? 200 : 400 );
	}

	/**
	 * Update a plugin.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function update_plugin( $request ) {
		$slug = $request->get_param( 'slug' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->update_plugin( $slug );

		return new WP_REST_Response( $result, $result['success'] ? 200 : 400 );
	}

	/**
	 * Delete a plugin.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function delete_plugin( $request ) {
		$slug = $request->get_param( 'slug' );

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-respira-plugin-manager.php';
		$manager = new Respira_Plugin_Manager();
		$result  = $manager->delete_plugin( $slug );

		return new WP_REST_Response( $result, $result['success'] ? 200 : 400 );
	}

	/**
	 * List users endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_users( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$args = array(
			'number'     => $request->get_param( 'per_page' ) ?? 20,
			'offset'     => ( ( $request->get_param( 'page' ) ?? 1 ) - 1 ) * ( $request->get_param( 'per_page' ) ?? 20 ),
			'search'     => $request->get_param( 'search' ) ?? '',
			'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
		);

		$user_query = new WP_User_Query( $args );
		$users = array();

		foreach ( $user_query->get_results() as $user ) {
			$users[] = array(
				'id'           => $user->ID,
				'username'     => $user->user_login,
				'email'        => $user->user_email,
				'display_name' => $user->display_name,
				'roles'        => $user->roles,
				'registered'   => $user->user_registered,
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_users', 'user', null );

		return new WP_REST_Response(
			array(
				'users'       => $users,
				'total'       => $user_query->get_total(),
				'total_pages' => ceil( $user_query->get_total() / ( $request->get_param( 'per_page' ) ?? 20 ) ),
			),
			200
		);
	}

	/**
	 * Get user endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_user( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$user_id  = $request->get_param( 'id' );

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return $this->respira_error(
				'respira_user_not_found',
				__( 'User not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_user', 'user', $user_id );

		return new WP_REST_Response(
			array(
				'id'           => $user->ID,
				'username'     => $user->user_login,
				'email'        => $user->user_email,
				'display_name' => $user->display_name,
				'roles'        => $user->roles,
				'registered'   => $user->user_registered,
				'url'          => get_author_posts_url( $user->ID ),
			),
			200
		);
	}

	/**
	 * Create user endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_user( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$username = $request->get_param( 'username' );
		$email    = $request->get_param( 'email' );
		$password = $request->get_param( 'password' );
		$role     = $request->get_param( 'role' ) ?? 'subscriber';

		if ( empty( $username ) || empty( $email ) || empty( $password ) ) {
			return $this->respira_error(
				'respira_missing_fields',
				__( 'Username, email, and password are required.', 'respira-for-wordpress' ),
				array( 'status' => 400 ),
				'error'
			);
		}

		$user_id = wp_create_user( $username, $password, $email );

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		$user = new WP_User( $user_id );
		$user->set_role( $role );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_user', 'user', $user_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'user'    => array(
					'id'           => $user->ID,
					'username'     => $user->user_login,
					'email'        => $user->user_email,
					'display_name' => $user->display_name,
					'roles'        => $user->roles,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'User created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Update user endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_user( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$user_id  = $request->get_param( 'id' );

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return $this->respira_error(
				'respira_user_not_found',
				__( 'User not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$update_data = array( 'ID' => $user_id );

		if ( $request->get_param( 'email' ) ) {
			$update_data['user_email'] = sanitize_email( $request->get_param( 'email' ) );
		}

		if ( $request->get_param( 'display_name' ) ) {
			$update_data['display_name'] = sanitize_text_field( $request->get_param( 'display_name' ) );
		}

		if ( $request->get_param( 'password' ) ) {
			$update_data['user_pass'] = $request->get_param( 'password' );
		}

		if ( $request->get_param( 'role' ) ) {
			$user->set_role( $request->get_param( 'role' ) );
		}

		$result = wp_update_user( $update_data );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$updated_user = get_userdata( $user_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_user', 'user', $user_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'user'    => array(
					'id'           => $updated_user->ID,
					'username'     => $updated_user->user_login,
					'email'        => $updated_user->user_email,
					'display_name' => $updated_user->display_name,
					'roles'        => $updated_user->roles,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'User updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete user endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_user( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$user_id  = $request->get_param( 'id' );

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return $this->respira_error(
				'respira_user_not_found',
				__( 'User not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$reassign = $request->get_param( 'reassign' );

		require_once ABSPATH . 'wp-admin/includes/user.php';
		$result = wp_delete_user( $user_id, $reassign );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_delete_failed',
				__( 'Failed to delete user.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_user', 'user', $user_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'User deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List comments endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_comments( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$args = array(
			'number'  => $request->get_param( 'per_page' ) ?? 20,
			'offset'  => ( ( $request->get_param( 'page' ) ?? 1 ) - 1 ) * ( $request->get_param( 'per_page' ) ?? 20 ),
			'status'  => $request->get_param( 'status' ) ?? 'approve',
			'post_id' => $request->get_param( 'post_id' ),
		);

		$comments = get_comments( $args );
		$formatted_comments = array();

		foreach ( $comments as $comment ) {
			$formatted_comments[] = array(
				'id'           => $comment->comment_ID,
				'post_id'      => $comment->comment_post_ID,
				'author'       => $comment->comment_author,
				'author_email' => $comment->comment_author_email,
				'content'      => $comment->comment_content,
				'date'         => $comment->comment_date,
				'status'       => $comment->comment_approved,
				'parent'       => $comment->comment_parent,
			);
		}

		$total = get_comments( array_merge( $args, array( 'count' => true ) ) );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_comments', 'comment', null );

		return new WP_REST_Response(
			array(
				'comments'    => $formatted_comments,
				'total'       => $total,
				'total_pages' => ceil( $total / ( $request->get_param( 'per_page' ) ?? 20 ) ),
			),
			200
		);
	}

	/**
	 * Get comment endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_comment( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$comment_id = $request->get_param( 'id' );

		$comment = get_comment( $comment_id );

		if ( ! $comment ) {
			return $this->respira_error(
				'respira_comment_not_found',
				__( 'Comment not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_comment', 'comment', $comment_id );

		return new WP_REST_Response(
			array(
				'id'           => $comment->comment_ID,
				'post_id'      => $comment->comment_post_ID,
				'author'       => $comment->comment_author,
				'author_email' => $comment->comment_author_email,
				'content'      => $comment->comment_content,
				'date'         => $comment->comment_date,
				'status'       => $comment->comment_approved,
				'parent'       => $comment->comment_parent,
			),
			200
		);
	}

	/**
	 * Create comment endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_comment( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$comment_data = array(
			'comment_post_ID'      => $request->get_param( 'post_id' ),
			'comment_author'       => $request->get_param( 'author' ),
			'comment_author_email' => sanitize_email( $request->get_param( 'author_email' ) ),
			'comment_content'      => $request->get_param( 'content' ),
			'comment_parent'       => $request->get_param( 'parent' ) ?? 0,
			'comment_approved'     => $request->get_param( 'status' ) ?? 1,
		);

		$comment_id = wp_insert_comment( $comment_data );

		if ( is_wp_error( $comment_id ) || ! $comment_id ) {
			return $this->respira_error(
				'respira_comment_create_failed',
				__( 'Failed to create comment.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		$comment = get_comment( $comment_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_comment', 'comment', $comment_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'comment' => array(
					'id'           => $comment->comment_ID,
					'post_id'      => $comment->comment_post_ID,
					'author'       => $comment->comment_author,
					'author_email' => $comment->comment_author_email,
					'content'      => $comment->comment_content,
					'date'         => $comment->comment_date,
					'status'       => $comment->comment_approved,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Comment created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Update comment endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_comment( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$comment_id = $request->get_param( 'id' );

		$comment = get_comment( $comment_id );

		if ( ! $comment ) {
			return $this->respira_error(
				'respira_comment_not_found',
				__( 'Comment not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$update_data = array( 'comment_ID' => $comment_id );

		if ( $request->get_param( 'content' ) ) {
			$update_data['comment_content'] = $request->get_param( 'content' );
		}

		if ( $request->get_param( 'status' ) ) {
			$update_data['comment_approved'] = $request->get_param( 'status' );
		}

		$result = wp_update_comment( $update_data );

		if ( is_wp_error( $result ) || ! $result ) {
			return $this->respira_error(
				'respira_comment_update_failed',
				__( 'Failed to update comment.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		$updated_comment = get_comment( $comment_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_comment', 'comment', $comment_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'comment' => array(
					'id'           => $updated_comment->comment_ID,
					'post_id'      => $updated_comment->comment_post_ID,
					'author'       => $updated_comment->comment_author,
					'content'      => $updated_comment->comment_content,
					'status'       => $updated_comment->comment_approved,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Comment updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete comment endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_comment( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$comment_id = $request->get_param( 'id' );

		$result = wp_delete_comment( $comment_id, true );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_comment_delete_failed',
				__( 'Failed to delete comment.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_comment', 'comment', $comment_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Comment deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List taxonomies endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_taxonomies( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$taxonomies = get_taxonomies( array(), 'objects' );
		$formatted_taxonomies = array();

		foreach ( $taxonomies as $taxonomy ) {
			$formatted_taxonomies[] = array(
				'name'         => $taxonomy->name,
				'label'        => $taxonomy->label,
				'description'  => $taxonomy->description,
				'object_types' => $taxonomy->object_type,
				'hierarchical' => $taxonomy->hierarchical,
				'public'       => $taxonomy->public,
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_taxonomies', 'taxonomy', null );

		return new WP_REST_Response(
			array(
				'taxonomies' => $formatted_taxonomies,
			),
			200
		);
	}

	/**
	 * Get taxonomy endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_taxonomy( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$taxonomy_name = $request->get_param( 'taxonomy' );

		$taxonomy = get_taxonomy( $taxonomy_name );

		if ( ! $taxonomy ) {
			return $this->respira_error(
				'respira_taxonomy_not_found',
				__( 'Taxonomy not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_taxonomy', 'taxonomy', $taxonomy_name );

		return new WP_REST_Response(
			array(
				'name'         => $taxonomy->name,
				'label'        => $taxonomy->label,
				'description'  => $taxonomy->description,
				'object_types' => $taxonomy->object_type,
				'hierarchical' => $taxonomy->hierarchical,
				'public'       => $taxonomy->public,
			),
			200
		);
	}

	/**
	 * List terms endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function list_terms( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$taxonomy = $request->get_param( 'taxonomy' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $this->respira_error(
				'respira_taxonomy_not_found',
				__( 'Taxonomy not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$args = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => $request->get_param( 'per_page' ) ?? 20,
			'offset'     => ( ( $request->get_param( 'page' ) ?? 1 ) - 1 ) * ( $request->get_param( 'per_page' ) ?? 20 ),
			'search'     => $request->get_param( 'search' ) ?? '',
		);

		$terms = get_terms( $args );
		$formatted_terms = array();

		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$formatted_terms[] = array(
					'id'          => $term->term_id,
					'name'        => $term->name,
					'slug'        => $term->slug,
					'description' => $term->description,
					'parent'      => $term->parent,
					'count'       => $term->count,
				);
			}
		}

		$total = wp_count_terms( array( 'taxonomy' => $taxonomy ) );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_terms', 'term', null );

		return new WP_REST_Response(
			array(
				'terms'       => $formatted_terms,
				'total'       => is_numeric( $total ) ? $total : 0,
				'total_pages' => ceil( ( is_numeric( $total ) ? $total : 0 ) / ( $request->get_param( 'per_page' ) ?? 20 ) ),
			),
			200
		);
	}

	/**
	 * Get term endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_term( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$term_id = $request->get_param( 'id' );
		$taxonomy = $request->get_param( 'taxonomy' );

		$term = get_term( $term_id, $taxonomy );

		if ( is_wp_error( $term ) || ! $term ) {
			return $this->respira_error(
				'respira_term_not_found',
				__( 'Term not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_term', 'term', $term_id );

		return new WP_REST_Response(
			array(
				'id'          => $term->term_id,
				'name'        => $term->name,
				'slug'        => $term->slug,
				'description' => $term->description,
				'parent'      => $term->parent,
				'count'       => $term->count,
			),
			200
		);
	}

	/**
	 * Create term endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_term( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$taxonomy = $request->get_param( 'taxonomy' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $this->respira_error(
				'respira_taxonomy_not_found',
				__( 'Taxonomy not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$term_data = array(
			'name'        => $request->get_param( 'name' ),
			'slug'        => $request->get_param( 'slug' ),
			'description' => $request->get_param( 'description' ) ?? '',
			'parent'      => $request->get_param( 'parent' ) ?? 0,
		);

		$result = wp_insert_term( $term_data['name'], $taxonomy, $term_data );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$term = get_term( $result['term_id'], $taxonomy );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_term', 'term', $result['term_id'] );

		return new WP_REST_Response(
			array(
				'success' => true,
				'term'    => array(
					'id'          => $term->term_id,
					'name'        => $term->name,
					'slug'        => $term->slug,
					'description' => $term->description,
					'parent'      => $term->parent,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Term created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Update term endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_term( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$term_id = $request->get_param( 'id' );
		$taxonomy = $request->get_param( 'taxonomy' );

		$term = get_term( $term_id, $taxonomy );

		if ( is_wp_error( $term ) || ! $term ) {
			return $this->respira_error(
				'respira_term_not_found',
				__( 'Term not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$update_data = array();

		if ( $request->get_param( 'name' ) ) {
			$update_data['name'] = $request->get_param( 'name' );
		}

		if ( $request->get_param( 'slug' ) ) {
			$update_data['slug'] = $request->get_param( 'slug' );
		}

		if ( $request->get_param( 'description' ) ) {
			$update_data['description'] = $request->get_param( 'description' );
		}

		if ( $request->get_param( 'parent' ) !== null ) {
			$update_data['parent'] = $request->get_param( 'parent' );
		}

		$result = wp_update_term( $term_id, $taxonomy, $update_data );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$updated_term = get_term( $result['term_id'], $taxonomy );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_term', 'term', $term_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'term'    => array(
					'id'          => $updated_term->term_id,
					'name'        => $updated_term->name,
					'slug'        => $updated_term->slug,
					'description' => $updated_term->description,
					'parent'      => $updated_term->parent,
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Term updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete term endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_term( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$term_id = $request->get_param( 'id' );
		$taxonomy = $request->get_param( 'taxonomy' );

		$result = wp_delete_term( $term_id, $taxonomy );

		if ( is_wp_error( $result ) || ! $result ) {
			return $this->respira_error(
				'respira_term_delete_failed',
				__( 'Failed to delete term.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_term', 'term', $term_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Term deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List post types endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_post_types( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$post_types = get_post_types( array(), 'objects' );
		$formatted_post_types = array();

		foreach ( $post_types as $post_type ) {
			$formatted_post_types[] = array(
				'name'         => $post_type->name,
				'label'        => $post_type->label,
				'description'  => $post_type->description,
				'public'       => $post_type->public,
				'supports'     => $post_type->supports,
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_post_types', 'post_type', null );

		return new WP_REST_Response(
			array(
				'post_types' => $formatted_post_types,
			),
			200
		);
	}

	/**
	 * Get post type endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_post_type( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_type_name = $request->get_param( 'type' );

		$post_type = get_post_type_object( $post_type_name );

		if ( ! $post_type ) {
			return $this->respira_error(
				'respira_post_type_not_found',
				__( 'Post type not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_post_type', 'post_type', $post_type_name );

		return new WP_REST_Response(
			array(
				'name'        => $post_type->name,
				'label'       => $post_type->label,
				'description' => $post_type->description,
				'public'      => $post_type->public,
				'supports'    => $post_type->supports,
			),
			200
		);
	}

	/**
	 * List custom posts endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function list_custom_posts( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_type = $request->get_param( 'type' );

		if ( ! post_type_exists( $post_type ) ) {
			return $this->respira_error(
				'respira_post_type_not_found',
				__( 'Post type not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$args = array(
			'post_type'      => $post_type,
			'posts_per_page' => $request->get_param( 'per_page' ) ?? 20,
			'paged'          => $request->get_param( 'page' ) ?? 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending', 'private' ),
		);

		$query = new WP_Query( $args );
		$posts = array();

		foreach ( $query->posts as $post ) {
			$posts[] = array(
				'id'      => $post->ID,
				'title'   => $post->post_title,
				'slug'    => $post->post_name,
				'status'  => $post->post_status,
				'date'    => $post->post_date,
				'modified' => $post->post_modified,
				'url'     => get_permalink( $post->ID ),
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_custom_posts', $post_type, null );

		return new WP_REST_Response(
			array(
				'posts'       => $posts,
				'total'       => $query->found_posts,
				'total_pages' => $query->max_num_pages,
			),
			200
		);
	}

	/**
	 * Get custom post endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_custom_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id = $request->get_param( 'id' );
		$post_type = $request->get_param( 'type' );

		$post = get_post( $post_id );

		if ( ! $post || $post->post_type !== $post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_custom_post', $post_type, $post_id );

		return new WP_REST_Response(
			array(
				'id'       => $post->ID,
				'title'    => $post->post_title,
				'slug'     => $post->post_name,
				'status'   => $post->post_status,
				'content'  => $post->post_content,
				'excerpt'  => $post->post_excerpt,
				'date'     => $post->post_date,
				'modified' => $post->post_modified,
				'url'      => get_permalink( $post->ID ),
			),
			200
		);
	}

	/**
	 * Create custom post endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_custom_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_type = $request->get_param( 'type' );

		if ( ! post_type_exists( $post_type ) ) {
			return $this->respira_error(
				'respira_post_type_not_found',
				__( 'Post type not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$post_data = array(
			'post_type'    => $post_type,
			'post_title'   => $request->get_param( 'title' ),
			'post_content' => $request->get_param( 'content' ) ?? '',
			'post_status'  => $request->get_param( 'status' ) ?? 'draft',
		);

		$post_id = wp_insert_post( wp_slash( $post_data ) );

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return $this->respira_error(
				'respira_post_create_failed',
				__( 'Failed to create post.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		$post = get_post( $post_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_custom_post', $post_type, $post_id );

		// Track usage stat (non-blocking) for generic post creation endpoints too.
		// This ensures create actions done through custom-post routes are reflected in usage dashboards.
		$license_key = $key_data['license_key'] ?? null;
		$usage_action_type = ( 'page' === $post_type ) ? 'create_page' : ( ( 'post' === $post_type ) ? 'create_post' : 'create_custom_post' );
		$this->track_usage_safe( $usage_action_type, $post_type, $post_id, $post_data['post_content'], $license_key );

		return new WP_REST_Response(
			array(
				'success' => true,
				'post'    => array(
					'id'      => $post->ID,
					'title'   => $post->post_title,
					'slug'    => $post->post_name,
					'status'  => $post->post_status,
					'url'     => get_permalink( $post->ID ),
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Post created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Update custom post endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_custom_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id  = $request->get_param( 'id' );
		$content  = $request->get_param( 'content' );
		$post_type = sanitize_key( (string) $request->get_param( 'type' ) );

		$post = get_post( $post_id );
		if ( ! $post || $post->post_type !== $post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$is_duplicate          = get_post_meta( $post_id, '_respira_duplicate', true );
		$force                 = $request->get_param( 'force' );
		$allow_direct_edit     = get_option( 'respira_allow_direct_edit', 0 );
		$auto_duplicate_created = false;
		$original_id           = $post_id;
		$post_type_object      = get_post_type_object( $post_type );
		$post_type_label       = ( $post_type_object && ! empty( $post_type_object->labels->singular_name ) ) ? $post_type_object->labels->singular_name : ucfirst( $post_type );

		if ( ! $is_duplicate ) {
			$existing_duplicates = Respira_Duplicator::get_duplicates( $post_id );
			if ( ! empty( $existing_duplicates ) ) {
				$duplicate_id = $existing_duplicates[0]->ID;
				$error_data   = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_duplicate_exists',
					sprintf(
						/* translators: 1: post type label, 2: original ID, 3: duplicate ID */
						__( 'Cannot edit original %1$s (ID: %2$d). A duplicate already exists (ID: %3$d). Please edit the duplicate instead.', 'respira-for-wordpress' ),
						$post_type_label,
						$post_id,
						$duplicate_id
					),
					array_merge(
						$error_data,
						array(
							'duplicate_id' => $duplicate_id,
							'instructions' => array(
								sprintf(
									/* translators: 1: post type label, 2: duplicate ID */
									__( 'Edit the duplicate %1$s (ID: %2$d) instead of the original.', 'respira-for-wordpress' ),
									$post_type_label,
									$duplicate_id
								),
								__( 'After editing, approve the duplicate in WordPress admin to apply the changes live.', 'respira-for-wordpress' ),
							),
						)
					)
				);
			}

			if ( $force && $allow_direct_edit ) {
				if ( ! $this->has_live_edit_confirmation( $request ) ) {
					$error_data = Respira_Approver::get_approval_error_data( $post_id );
					return new WP_Error(
						'respira_live_edit_confirmation_required',
						sprintf(
							/* translators: 1: post type label, 2: original ID */
							__( 'Directly editing live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true, or edit a duplicate instead.', 'respira-for-wordpress' ),
							$post_type_label,
							$post_id
						),
						array_merge(
							$error_data,
							array(
								'confirm_live_edit_required' => true,
								'instructions'               => array(
									__( 'You are targeting live content directly.', 'respira-for-wordpress' ),
									__( 'To continue, call the same endpoint with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
									__( 'Recommended: edit a duplicate first and approve when ready.', 'respira-for-wordpress' ),
								),
							)
						)
					);
				}
				Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'force_edit_custom_post', $post_type, $post_id );
			} else {
				$suffix       = '_duplicate_' . time();
				$duplicate_id = Respira_Duplicator::duplicate_post( $post_id, $suffix );
				if ( is_wp_error( $duplicate_id ) ) {
					return $duplicate_id;
				}

				Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'auto_duplicate_custom_post', $post_type, $duplicate_id );
				$post_id                = $duplicate_id;
				$post                   = get_post( $post_id );
				$is_duplicate           = true;
				$auto_duplicate_created = true;
			}
		}

		$skip_security = $request->get_param( 'skip_security_check' );
		if ( get_option( 'respira_security_checks', 1 ) && ! $skip_security && $content ) {
			$security_check = Respira_Security::validate_content( $content );
			if ( is_wp_error( $security_check ) ) {
				return $security_check;
			}
		}

		$update_data       = array( 'ID' => $post_id );
		$has_core_updates = false;

		if ( $request->get_param( 'title' ) ) {
			$update_data['post_title'] = sanitize_text_field( $request->get_param( 'title' ) );
			$has_core_updates          = true;
		}

		if ( $request->get_param( 'content' ) ) {
			if ( $skip_security ) {
				$update_data['post_content'] = (string) $request->get_param( 'content' );
			} else {
				$update_data['post_content'] = $this->sanitize_api_content( $request->get_param( 'content' ) );
			}
			$has_core_updates            = true;
		}

		if ( $request->get_param( 'status' ) ) {
			$update_data['post_status'] = sanitize_text_field( $request->get_param( 'status' ) );
			$has_core_updates           = true;
		}

		if ( $request->get_param( 'slug' ) ) {
			$update_data['post_name'] = sanitize_title( $request->get_param( 'slug' ) );
			$has_core_updates         = true;
		}

		// Capture WP revision and Respira snapshot before edit.
		if ( $has_core_updates ) {
			if ( ! $is_duplicate && function_exists( 'wp_save_post_revision' ) ) {
				wp_save_post_revision( $post_id );
			}
			if ( class_exists( 'Respira_Snapshots' ) ) {
				$snap_kind = $is_duplicate ? 'before_edit' : 'before_live_edit';
				Respira_Snapshots::get_instance()->capture_snapshot(
					$post_id,
					$snap_kind,
					array( 'actor_api_key_id' => $key_data['id'] ?? null )
				);
			}
		}

		if ( $has_core_updates ) {
			$guarded_action = ( 'page' === $post_type ) ? 'update_page' : ( ( 'post' === $post_type ) ? 'update_post' : 'update_custom_post' );
			$result         = $this->guarded_wp_update_post( $update_data, $guarded_action, $post_type, $post_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		// Update meta if provided.
		$meta_updated = false;
		if ( $request->get_param( 'meta' ) ) {
			$meta_updated = $this->update_post_meta_fields( $post_id, $request->get_param( 'meta' ) );
		}

		if ( $meta_updated ) {
			$this->maybe_clear_elementor_css_cache_for_post( $post_id );
		}

		// Update custom CSS if provided (Divi Builder and Elementor support).
		if ( $request->has_param( 'custom_css' ) ) {
			$custom_css = $request->get_param( 'custom_css' );

			// Detect which page builder is being used.
			$builder = Respira_Builder_Interface::detect_builder( $post_id );
			$builder_name = $builder ? $builder->get_name() : '';

			if ( 'Elementor' === $builder_name ) {
				// Elementor stores custom CSS in _elementor_page_settings.custom_css.
				$this->save_elementor_custom_css( $post_id, $custom_css );
			} elseif ( '' === $custom_css ) {
				// Clear CSS for Divi.
				delete_post_meta( $post_id, '_et_pb_custom_css' );
			} else {
				// Default to Divi's meta field.
				update_post_meta( $post_id, '_et_pb_custom_css', $custom_css );
			}
		}

		// Capture after-edit snapshot with label.
		if ( class_exists( 'Respira_Snapshots' ) ) {
			$snap_kind  = $is_duplicate ? 'after_edit' : 'after_live_edit';
			$snap_label = $this->build_snapshot_label( $request );
			Respira_Snapshots::get_instance()->capture_snapshot(
				$post_id,
				$snap_kind,
				array(
					'actor_api_key_id' => $key_data['id'] ?? null,
					'label'            => $snap_label,
				)
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_custom_post', $post_type, $post_id );

		// Track usage stat (non-blocking) for generic post update endpoints too.
		$license_key = $key_data['license_key'] ?? null;
		$usage_action_type = ( 'page' === $post_type ) ? 'update_page' : ( ( 'post' === $post_type ) ? 'update_post' : 'update_custom_post' );
		$usage_content = $content ? $content : null;
		$this->track_usage_safe( $usage_action_type, $post_type, $post_id, $usage_content, $license_key );

		clean_post_cache( $post_id );

		// Purge frontend page caches on live edits so visitors see changes immediately.
		if ( ! $is_duplicate ) {
			$this->purge_frontend_caches( $post_id );
		}

		$updated_post   = get_post( $post_id );
		$approvals_url  = admin_url( 'admin.php?page=respira-changes' );
		$response_data  = array(
			'success' => true,
			'post'    => array(
				'id'      => $updated_post->ID,
				'title'   => $updated_post->post_title,
				'slug'    => $updated_post->post_name,
				'status'  => $updated_post->post_status,
				'url'     => get_permalink( $updated_post->ID ),
			),
			'message' => $this->add_success_footer( $this->format_respira_message( __( 'Post updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
		);

		if ( $auto_duplicate_created ) {
			$response_data['duplicate_created'] = true;
			$response_data['duplicate_id']      = $post_id;
			$response_data['original_id']       = $original_id;
			$response_data['approval_url']      = $approvals_url;
			$response_data['message']           = $this->add_success_footer(
				$this->format_respira_message(
					sprintf(
						/* translators: 1: post type label, 2: duplicate ID */
						__( 'I created a duplicate %1$s for safety (ID: %2$d). Review it in WordPress admin before approving to make it live.', 'respira-for-wordpress' ),
						$post_type_label,
						$post_id
					),
					'warning'
				)
			);
			$response_data['instructions'] = array(
				$this->format_respira_message( __( 'A duplicate was automatically created for safety.', 'respira-for-wordpress' ), 'warning' ),
				sprintf(
					/* translators: 1: post type label, 2: duplicate ID, 3: original ID */
					__( '📋 Duplicate %1$s ID: %2$d | Original ID: %3$d', 'respira-for-wordpress' ),
					$post_type_label,
					$post_id,
					$original_id
				),
				sprintf(
					/* translators: 1: approvals URL */
					__( '👀 Review and approve: %1$s', 'respira-for-wordpress' ),
					$approvals_url
				),
				__( '💡 Tip: Changes are on the duplicate. Approve it to make them live.', 'respira-for-wordpress' ),
			);
		}

		$response = new WP_REST_Response( $response_data, 200 );
		if ( $auto_duplicate_created ) {
			$response->header( 'X-Respira-Duplicate-Created', 'true' );
			$response->header( 'X-Respira-Duplicate-ID', (string) $post_id );
			$response->header( 'X-Respira-Original-ID', (string) $original_id );
			$response->header( 'X-Respira-Approval-URL', $approvals_url );
		} else {
			$response->header( 'X-Respira-Duplicate-Created', 'false' );
		}

		return $response;
	}

	/**
	 * Delete custom post endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_custom_post( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$post_id = $request->get_param( 'id' );
		$post_type = sanitize_key( (string) $request->get_param( 'type' ) );

		$post = get_post( $post_id );

		if ( ! $post || $post->post_type !== $post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$is_duplicate      = get_post_meta( $post_id, '_respira_duplicate', true );
		$force             = $request->get_param( 'force' );
		$allow_direct_edit = get_option( 'respira_allow_direct_edit', 0 );
		$post_type_object  = get_post_type_object( $post_type );
		$post_type_label   = ( $post_type_object && ! empty( $post_type_object->labels->singular_name ) ) ? $post_type_object->labels->singular_name : ucfirst( $post_type );

		if ( ! $is_duplicate ) {
			if ( $force && ! $allow_direct_edit ) {
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_direct_edit_disabled',
					sprintf(
						/* translators: 1: post type label */
						__( 'Cannot delete original %1$s. Direct editing of originals is disabled in settings.', 'respira-for-wordpress' ),
						$post_type_label
					),
					$error_data
				);
			}

			if ( $force && $allow_direct_edit && ! $this->has_live_edit_confirmation( $request ) ) {
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_live_edit_confirmation_required',
					sprintf(
						/* translators: 1: post type label, 2: post ID */
						__( 'Directly deleting live %1$s (ID: %2$d) requires explicit confirmation. Re-send with force=true and confirm_live_edit=true.', 'respira-for-wordpress' ),
						$post_type_label,
						$post_id
					),
					array_merge(
						$error_data,
						array(
							'confirm_live_edit_required' => true,
						)
					)
				);
			}

			if ( ! $force ) {
				$error_data = Respira_Approver::get_approval_error_data( $post_id );
				return new WP_Error(
					'respira_not_duplicate',
					sprintf(
						/* translators: 1: post type label, 2: post ID */
						__( 'Cannot delete original %1$s (ID: %2$d). Only Respira duplicates can be deleted.', 'respira-for-wordpress' ),
						$post_type_label,
						$post_id
					),
					$error_data
				);
			}
		}

		$result = wp_delete_post( $post_id, true );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_post_delete_failed',
				__( 'Failed to delete post.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_custom_post', $post_type, $post_id );

		// Track usage stat for delete actions.
		$license_key = $key_data['license_key'] ?? null;
		$usage_action_type = ( 'page' === $post_type ) ? 'delete_page' : ( ( 'post' === $post_type ) ? 'delete_post' : 'delete_custom_post' );
		$this->track_usage_safe( $usage_action_type, $post_type, $post_id, null, $license_key );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Post deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List options endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_options( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$search = $request->get_param( 'search' ) ?? '';

		global $wpdb;
		$options = array();

		if ( ! empty( $search ) ) {
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name LIMIT 100",
					'%' . $wpdb->esc_like( $search ) . '%'
				)
			);
		} else {
			$results = $wpdb->get_results(
				"SELECT option_name, option_value FROM {$wpdb->options} ORDER BY option_name LIMIT 100"
			);
		}

		foreach ( $results as $option ) {
			$options[] = array(
				'name'  => $option->option_name,
				'value' => maybe_unserialize( $option->option_value ),
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_options', 'option', null );

		return new WP_REST_Response(
			array(
				'options' => $options,
			),
			200
		);
	}

	/**
	 * Get option endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_option( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$option_name = $request->get_param( 'option' );

		$value = get_option( $option_name );

		if ( false === $value ) {
			return $this->respira_error(
				'respira_option_not_found',
				__( 'Option not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_option', 'option', $option_name );

		return new WP_REST_Response(
			array(
				'name'  => $option_name,
				'value' => $value,
			),
			200
		);
	}

	/**
	 * Update option endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_option( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$option_name = $request->get_param( 'option' );
		$value = $request->get_param( 'value' );

		if ( null === $value ) {
			return $this->respira_error(
				'respira_missing_value',
				__( 'Value is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 ),
				'error'
			);
		}

		$result = update_option( $option_name, $value );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_option_update_failed',
				__( 'Failed to update option.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_option', 'option', $option_name );

		return new WP_REST_Response(
			array(
				'success' => true,
				'option'  => array(
					'name'  => $option_name,
					'value' => get_option( $option_name ),
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Option updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete option endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_option( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$option_name = $request->get_param( 'option' );

		$result = delete_option( $option_name );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_option_delete_failed',
				__( 'Failed to delete option.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_option', 'option', $option_name );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Option deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Get media endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_media( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$media_id = $request->get_param( 'id' );

		$attachment = get_post( $media_id );

		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return $this->respira_error(
				'respira_media_not_found',
				__( 'Media not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_media', 'media', $media_id );

		return new WP_REST_Response(
			array(
				'id'        => $attachment->ID,
				'title'     => $attachment->post_title,
				'url'       => wp_get_attachment_url( $attachment->ID ),
				'mime_type' => $attachment->post_mime_type,
				'uploaded'  => $attachment->post_date,
				'file_size' => filesize( get_attached_file( $attachment->ID ) ),
				'alt'       => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
				'caption'   => wp_get_attachment_caption( $attachment->ID ),
			),
			200
		);
	}

	/**
	 * Update media endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_media( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$media_id = $request->get_param( 'id' );

		$attachment = get_post( $media_id );

		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return $this->respira_error(
				'respira_media_not_found',
				__( 'Media not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$update_data = array( 'ID' => $media_id );

		if ( $request->get_param( 'title' ) ) {
			$update_data['post_title'] = sanitize_text_field( $request->get_param( 'title' ) );
		}

		if ( $request->get_param( 'caption' ) ) {
			$update_data['post_excerpt'] = sanitize_textarea_field( $request->get_param( 'caption' ) );
		}

		if ( ! empty( $update_data ) ) {
			wp_update_post( wp_slash( $update_data ) );
		}

		if ( $request->get_param( 'alt' ) ) {
			update_post_meta( $media_id, '_wp_attachment_image_alt', sanitize_text_field( $request->get_param( 'alt' ) ) );
		}

		$updated_attachment = get_post( $media_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_media', 'media', $media_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'media'   => array(
					'id'        => $updated_attachment->ID,
					'title'     => $updated_attachment->post_title,
					'url'       => wp_get_attachment_url( $updated_attachment->ID ),
					'mime_type' => $updated_attachment->post_mime_type,
					'alt'       => get_post_meta( $updated_attachment->ID, '_wp_attachment_image_alt', true ),
					'caption'   => wp_get_attachment_caption( $updated_attachment->ID ),
				),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Media updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Batch update media items (alt text, title, caption).
	 *
	 * @since 5.2.5
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_media_batch( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$items    = $request->get_param( 'items' );

		if ( empty( $items ) || ! is_array( $items ) ) {
			return $this->respira_error(
				'respira_invalid_batch',
				__( 'items array is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 ),
				'error'
			);
		}

		if ( count( $items ) > 50 ) {
			return $this->respira_error(
				'respira_batch_too_large',
				__( 'Maximum 50 items per batch.', 'respira-for-wordpress' ),
				array( 'status' => 400 ),
				'error'
			);
		}

		$results = array();
		$updated = 0;
		$failed  = 0;

		foreach ( $items as $item ) {
			$id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
			if ( ! $id ) {
				$results[] = array( 'id' => $id, 'success' => false, 'error' => 'Missing or invalid ID.' );
				$failed++;
				continue;
			}

			$attachment = get_post( $id );
			if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
				$results[] = array( 'id' => $id, 'success' => false, 'error' => 'Attachment not found.' );
				$failed++;
				continue;
			}

			$update_data = array( 'ID' => $id );
			$has_update  = false;

			if ( isset( $item['title'] ) ) {
				$update_data['post_title'] = sanitize_text_field( $item['title'] );
				$has_update = true;
			}
			if ( isset( $item['caption'] ) ) {
				$update_data['post_excerpt'] = sanitize_textarea_field( $item['caption'] );
				$has_update = true;
			}

			if ( $has_update ) {
				$result = wp_update_post( wp_slash( $update_data ) );
				if ( is_wp_error( $result ) ) {
					$results[] = array( 'id' => $id, 'success' => false, 'error' => $result->get_error_message() );
					$failed++;
					continue;
				}
			}

			if ( isset( $item['alt'] ) ) {
				update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $item['alt'] ) );
				$has_update = true;
			}

			if ( ! $has_update ) {
				$results[] = array( 'id' => $id, 'success' => false, 'error' => 'No fields to update.' );
				$failed++;
				continue;
			}

			$results[] = array( 'id' => $id, 'success' => true );
			$updated++;
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_media_batch', null, null );

		return new WP_REST_Response(
			array(
				'success' => $failed === 0,
				'updated' => $updated,
				'failed'  => $failed,
				'results' => $results,
			),
			200
		);
	}

	/**
	 * Delete media endpoint.
	 *
	 * @since  1.0.0
	 * @param  WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_media( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$media_id = $request->get_param( 'id' );

		$attachment = get_post( $media_id );

		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return $this->respira_error(
				'respira_media_not_found',
				__( 'Media not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$result = wp_delete_attachment( $media_id, true );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_media_delete_failed',
				__( 'Failed to delete media.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_media', 'media', $media_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Media deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List all navigation menus.
	 *
	 * Returns all registered nav menus with WPML language information if available.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_menus( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$menus = wp_get_nav_menus();
		$formatted_menus = array();

		foreach ( $menus as $menu ) {
			$formatted_menus[] = $this->format_menu_response( $menu );
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_menus', 'menu', null );

		$response_data = array(
			'menus' => $formatted_menus,
			'total' => count( $formatted_menus ),
		);

		if ( empty( $formatted_menus ) ) {
			$response_data['hint'] = __( 'No custom WordPress menus found. Your theme may be using auto-generated page navigation (Settings → Reading) or a hardcoded menu in the theme template.', 'respira-for-wordpress' );
		}

		return new WP_REST_Response( $response_data, 200 );
	}

	/**
	 * Get a single menu with its items.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_menu( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$menu_id  = (int) $request->get_param( 'id' );

		$menu = wp_get_nav_menu_object( $menu_id );

		if ( ! $menu ) {
			return $this->respira_error(
				'respira_menu_not_found',
				__( 'Menu not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$menu_data = $this->format_menu_response( $menu, true );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_menu', 'menu', $menu_id );

		return new WP_REST_Response( $menu_data, 200 );
	}

	/**
	 * Create a new menu.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_menu( $request ) {
		$key_data    = $request->get_param( '_respira_key_data' );
		$name        = $request->get_param( 'name' );
		$description = $request->get_param( 'description' ) ?? '';

		$menu_id = wp_create_nav_menu( $name );

		if ( is_wp_error( $menu_id ) ) {
			return $this->respira_error(
				'respira_menu_create_failed',
				$menu_id->get_error_message(),
				array( 'status' => 400 ),
				'error'
			);
		}

		// Update description if provided.
		if ( $description ) {
			wp_update_term( $menu_id, 'nav_menu', array( 'description' => $description ) );
		}

		$menu = wp_get_nav_menu_object( $menu_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_menu', 'menu', $menu_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'menu'    => $this->format_menu_response( $menu ),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Update a menu.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_menu( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$menu_id  = (int) $request->get_param( 'id' );

		$menu = wp_get_nav_menu_object( $menu_id );

		if ( ! $menu ) {
			return $this->respira_error(
				'respira_menu_not_found',
				__( 'Menu not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$update_args = array();

		if ( $request->get_param( 'name' ) ) {
			$update_args['name'] = $request->get_param( 'name' );
		}

		if ( $request->get_param( 'description' ) !== null ) {
			$update_args['description'] = $request->get_param( 'description' );
		}

		if ( ! empty( $update_args ) ) {
			$result = wp_update_term( $menu_id, 'nav_menu', $update_args );

			if ( is_wp_error( $result ) ) {
				return $this->respira_error(
					'respira_menu_update_failed',
					$result->get_error_message(),
					array( 'status' => 400 ),
					'error'
				);
			}
		}

		$menu = wp_get_nav_menu_object( $menu_id );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_menu', 'menu', $menu_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'menu'    => $this->format_menu_response( $menu ),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete a menu.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_menu( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$menu_id  = (int) $request->get_param( 'id' );

		$menu = wp_get_nav_menu_object( $menu_id );

		if ( ! $menu ) {
			return $this->respira_error(
				'respira_menu_not_found',
				__( 'Menu not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$result = wp_delete_nav_menu( $menu_id );

		if ( is_wp_error( $result ) || ! $result ) {
			return $this->respira_error(
				'respira_menu_delete_failed',
				__( 'Failed to delete menu.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_menu', 'menu', $menu_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * List all menu locations.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response Response object.
	 */
	public function list_menu_locations( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );

		$registered_locations = get_registered_nav_menus();
		$assigned_locations   = get_nav_menu_locations();
		$locations            = array();

		foreach ( $registered_locations as $slug => $name ) {
			$menu_id   = isset( $assigned_locations[ $slug ] ) ? $assigned_locations[ $slug ] : 0;
			$menu_name = '';

			if ( $menu_id ) {
				$menu = wp_get_nav_menu_object( $menu_id );
				if ( $menu ) {
					$menu_name = $menu->name;
				}
			}

			$locations[] = array(
				'slug'      => $slug,
				'name'      => $name,
				'menu_id'   => $menu_id,
				'menu_name' => $menu_name,
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_menu_locations', 'menu', null );

		return new WP_REST_Response(
			array(
				'locations' => $locations,
				'total'     => count( $locations ),
			),
			200
		);
	}

	/**
	 * Assign a menu to a location.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function assign_menu_to_location( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$location = $request->get_param( 'location' );
		$menu_id  = (int) $request->get_param( 'menu_id' );

		// Verify location exists.
		$registered_locations = get_registered_nav_menus();
		if ( ! isset( $registered_locations[ $location ] ) ) {
			return $this->respira_error(
				'respira_location_not_found',
				__( 'Menu location not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		// Verify menu exists (0 = unassign).
		if ( $menu_id > 0 ) {
			$menu = wp_get_nav_menu_object( $menu_id );
			if ( ! $menu ) {
				return $this->respira_error(
					'respira_menu_not_found',
					__( 'Menu not found.', 'respira-for-wordpress' ),
					array( 'status' => 404 ),
					'error'
				);
			}
		}

		$locations             = get_nav_menu_locations();
		$locations[ $location ] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'assign_menu_location', 'menu', $menu_id );

		return new WP_REST_Response(
			array(
				'success'  => true,
				'location' => $location,
				'menu_id'  => $menu_id,
				'message'  => $this->add_success_footer( $this->format_respira_message(
					$menu_id > 0
						? __( 'Menu assigned to location successfully.', 'respira-for-wordpress' )
						: __( 'Menu unassigned from location successfully.', 'respira-for-wordpress' ),
					'success'
				) ),
			),
			200
		);
	}

	/**
	 * List items in a menu.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function list_menu_items( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$menu_id  = (int) $request->get_param( 'menu_id' );

		$menu = wp_get_nav_menu_object( $menu_id );

		if ( ! $menu ) {
			return $this->respira_error(
				'respira_menu_not_found',
				__( 'Menu not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$items = wp_get_nav_menu_items( $menu_id );
		$formatted_items = array();

		if ( $items ) {
			foreach ( $items as $item ) {
				$formatted_items[] = $this->format_menu_item_response( $item );
			}
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'list_menu_items', 'menu', $menu_id );

		return new WP_REST_Response(
			array(
				'menu_id' => $menu_id,
				'items'   => $formatted_items,
				'total'   => count( $formatted_items ),
			),
			200
		);
	}

	/**
	 * Create a menu item.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function create_menu_item( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$menu_id  = (int) $request->get_param( 'menu_id' );

		$menu = wp_get_nav_menu_object( $menu_id );

		if ( ! $menu ) {
			return $this->respira_error(
				'respira_menu_not_found',
				__( 'Menu not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$item_data = array(
			'menu-item-title'     => $request->get_param( 'title' ),
			'menu-item-url'       => $request->get_param( 'url' ) ?? '',
			'menu-item-type'      => $request->get_param( 'object_type' ) ?? 'custom',
			'menu-item-object'    => $request->get_param( 'object' ) ?? 'custom',
			'menu-item-object-id' => $request->get_param( 'object_id' ) ?? 0,
			'menu-item-parent-id' => $request->get_param( 'parent_id' ) ?? 0,
			'menu-item-position'  => $request->get_param( 'position' ) ?? 0,
			'menu-item-target'    => $request->get_param( 'target' ) ?? '',
			'menu-item-classes'   => $request->get_param( 'classes' ) ? implode( ' ', $request->get_param( 'classes' ) ) : '',
			'menu-item-attr-title' => $request->get_param( 'attr_title' ) ?? '',
			'menu-item-description' => $request->get_param( 'description' ) ?? '',
			'menu-item-status'    => 'publish',
		);

		$item_id = wp_update_nav_menu_item( $menu_id, 0, $item_data );

		if ( is_wp_error( $item_id ) ) {
			return $this->respira_error(
				'respira_menu_item_create_failed',
				$item_id->get_error_message(),
				array( 'status' => 400 ),
				'error'
			);
		}

		$item = wp_setup_nav_menu_item( get_post( $item_id ) );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'create_menu_item', 'menu_item', $item_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'item'    => $this->format_menu_item_response( $item ),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu item created successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			201
		);
	}

	/**
	 * Get a single menu item.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function get_menu_item( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$item_id  = (int) $request->get_param( 'item_id' );

		$post = get_post( $item_id );

		if ( ! $post || 'nav_menu_item' !== $post->post_type ) {
			return $this->respira_error(
				'respira_menu_item_not_found',
				__( 'Menu item not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$item = wp_setup_nav_menu_item( $post );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'get_menu_item', 'menu_item', $item_id );

		return new WP_REST_Response( $this->format_menu_item_response( $item ), 200 );
	}

	/**
	 * Update a menu item.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function update_menu_item( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$item_id  = (int) $request->get_param( 'item_id' );

		$post = get_post( $item_id );

		if ( ! $post || 'nav_menu_item' !== $post->post_type ) {
			return $this->respira_error(
				'respira_menu_item_not_found',
				__( 'Menu item not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		// Get existing item data.
		$existing_item = wp_setup_nav_menu_item( $post );

		// Get menu ID.
		$menu_terms = wp_get_object_terms( $item_id, 'nav_menu' );
		$menu_id    = ! empty( $menu_terms ) ? $menu_terms[0]->term_id : 0;

		// Build update data, preserving existing values.
		$item_data = array(
			'menu-item-title'      => $request->get_param( 'title' ) ?? $existing_item->title,
			'menu-item-url'        => $request->get_param( 'url' ) ?? $existing_item->url,
			'menu-item-type'       => $existing_item->type,
			'menu-item-object'     => $existing_item->object,
			'menu-item-object-id'  => $existing_item->object_id,
			'menu-item-parent-id'  => $request->get_param( 'parent_id' ) ?? $existing_item->menu_item_parent,
			'menu-item-position'   => $request->get_param( 'position' ) ?? $existing_item->menu_order,
			'menu-item-target'     => $request->get_param( 'target' ) ?? $existing_item->target,
			'menu-item-classes'    => $request->get_param( 'classes' ) ? implode( ' ', $request->get_param( 'classes' ) ) : implode( ' ', (array) $existing_item->classes ),
			'menu-item-attr-title' => $request->get_param( 'attr_title' ) ?? $existing_item->attr_title,
			'menu-item-description' => $request->get_param( 'description' ) ?? $existing_item->description,
			'menu-item-status'     => 'publish',
		);

		$result = wp_update_nav_menu_item( $menu_id, $item_id, $item_data );

		if ( is_wp_error( $result ) ) {
			return $this->respira_error(
				'respira_menu_item_update_failed',
				$result->get_error_message(),
				array( 'status' => 400 ),
				'error'
			);
		}

		$item = wp_setup_nav_menu_item( get_post( $item_id ) );

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'update_menu_item', 'menu_item', $item_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'item'    => $this->format_menu_item_response( $item ),
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu item updated successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Delete a menu item.
	 *
	 * @since 1.8.46
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function delete_menu_item( $request ) {
		$key_data = $request->get_param( '_respira_key_data' );
		$item_id  = (int) $request->get_param( 'item_id' );

		$post = get_post( $item_id );

		if ( ! $post || 'nav_menu_item' !== $post->post_type ) {
			return $this->respira_error(
				'respira_menu_item_not_found',
				__( 'Menu item not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 ),
				'error'
			);
		}

		$result = wp_delete_post( $item_id, true );

		if ( ! $result ) {
			return $this->respira_error(
				'respira_menu_item_delete_failed',
				__( 'Failed to delete menu item.', 'respira-for-wordpress' ),
				array( 'status' => 500 ),
				'error'
			);
		}

		Respira_Auth::log_action( $key_data['id'], $key_data['user_id'], 'delete_menu_item', 'menu_item', $item_id );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $this->add_success_footer( $this->format_respira_message( __( 'Menu item deleted successfully.', 'respira-for-wordpress' ), 'success' ) ),
			),
			200
		);
	}

	/**
	 * Format menu response with WPML support.
	 *
	 * @since 1.8.46
	 * @param WP_Term $menu          The menu term object.
	 * @param bool    $include_items Whether to include menu items.
	 * @return array Formatted menu data.
	 */
	private function format_menu_response( $menu, $include_items = false ) {
		$data = array(
			'id'          => $menu->term_id,
			'name'        => $menu->name,
			'slug'        => $menu->slug,
			'description' => $menu->description,
			'count'       => $menu->count,
		);

		// Add WPML language info if available.
		if ( class_exists( 'SitePress' ) || defined( 'ICL_LANGUAGE_CODE' ) ) {
			global $sitepress;

			$data['wpml'] = array(
				'language_code' => null,
				'translations'  => array(),
			);

			// Get menu language from WPML.
			if ( function_exists( 'wpml_get_element_trid' ) ) {
				$trid = apply_filters( 'wpml_element_trid', null, $menu->term_id, 'tax_nav_menu' );
				if ( $trid ) {
					$translations = apply_filters( 'wpml_get_element_translations', array(), $trid, 'tax_nav_menu' );
					foreach ( $translations as $lang_code => $translation ) {
						if ( $translation->element_id == $menu->term_id ) {
							$data['wpml']['language_code'] = $lang_code;
						}
						$data['wpml']['translations'][ $lang_code ] = array(
							'id'   => (int) $translation->element_id,
							'name' => $translation->name ?? '',
						);
					}
				}
			}

			// Get current language.
			if ( defined( 'ICL_LANGUAGE_CODE' ) && ! $data['wpml']['language_code'] ) {
				$data['wpml']['language_code'] = ICL_LANGUAGE_CODE;
			}
		}

		// Add locations where this menu is assigned.
		$locations         = get_nav_menu_locations();
		$assigned_locations = array();
		foreach ( $locations as $location => $menu_id ) {
			if ( $menu_id === $menu->term_id ) {
				$assigned_locations[] = $location;
			}
		}
		$data['locations'] = $assigned_locations;

		// Include items if requested.
		if ( $include_items ) {
			$items = wp_get_nav_menu_items( $menu->term_id );
			$data['items'] = array();

			if ( $items ) {
				foreach ( $items as $item ) {
					$data['items'][] = $this->format_menu_item_response( $item );
				}
			}
		}

		return $data;
	}

	/**
	 * Format menu item response with WPML support.
	 *
	 * @since 1.8.46
	 * @param WP_Post $item The menu item post object.
	 * @return array Formatted menu item data.
	 */
	private function format_menu_item_response( $item ) {
		$data = array(
			'id'          => $item->ID,
			'title'       => $item->title,
			'url'         => $item->url,
			'target'      => $item->target,
			'attr_title'  => $item->attr_title,
			'description' => $item->description,
			'classes'     => array_filter( (array) $item->classes ),
			'xfn'         => $item->xfn,
			'parent_id'   => (int) $item->menu_item_parent,
			'position'    => (int) $item->menu_order,
			'object_type' => $item->type,
			'object'      => $item->object,
			'object_id'   => (int) $item->object_id,
		);

		// Add WPML translation info for linked content.
		if ( ( class_exists( 'SitePress' ) || defined( 'ICL_LANGUAGE_CODE' ) ) && $item->object_id > 0 ) {
			$data['wpml'] = array(
				'object_translations' => array(),
			);

			// Get translations for the linked object (page, post, etc.).
			if ( $item->type === 'post_type' && function_exists( 'wpml_get_element_trid' ) ) {
				$post_type = $item->object;
				$trid = apply_filters( 'wpml_element_trid', null, $item->object_id, 'post_' . $post_type );

				if ( $trid ) {
					$translations = apply_filters( 'wpml_get_element_translations', array(), $trid, 'post_' . $post_type );
					foreach ( $translations as $lang_code => $translation ) {
						$data['wpml']['object_translations'][ $lang_code ] = array(
							'id'    => (int) $translation->element_id,
							'title' => get_the_title( $translation->element_id ),
							'url'   => get_permalink( $translation->element_id ),
						);
					}
				}
			}

			// For taxonomy items.
			if ( $item->type === 'taxonomy' && function_exists( 'wpml_get_element_trid' ) ) {
				$taxonomy = $item->object;
				$trid = apply_filters( 'wpml_element_trid', null, $item->object_id, 'tax_' . $taxonomy );

				if ( $trid ) {
					$translations = apply_filters( 'wpml_get_element_translations', array(), $trid, 'tax_' . $taxonomy );
					foreach ( $translations as $lang_code => $translation ) {
						$term = get_term( $translation->element_id, $taxonomy );
						if ( $term && ! is_wp_error( $term ) ) {
							$data['wpml']['object_translations'][ $lang_code ] = array(
								'id'   => (int) $translation->element_id,
								'name' => $term->name,
								'url'  => get_term_link( $term ),
							);
						}
					}
				}
			}
		}

		return $data;
	}

	/**
	 * Register v2 REST routes.
	 *
	 * @since 3.1.0
	 * @return void
	 */
	private function register_element_ops_routes() {
		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-element-ops.php';
		$element_ops = new Respira_Element_Ops();
		$element_ops->register_routes();

		// HTML-to-builder conversion (WS10).
		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-html-converter.php';
		Respira_HTML_Converter::register_rest_routes();
	}

	/**
	 * Register v2 REST routes.
	 *
	 * @since 3.1.0
	 * @return void
	 */
	private function register_v2_routes() {
		$include_arg = $this->get_v2_include_arg();

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_v2_status' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/pages',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_pages_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array_merge( $this->get_list_args(), array( 'include' => $include_arg ) ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/pages/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_page_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
				array(
					'methods'             => 'PUT,POST',
					'callback'            => array( $this, 'update_page_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/pages/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_page_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'suffix' => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include' => $include_arg,
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_posts_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array_merge( $this->get_list_args(), array( 'include' => $include_arg ) ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/posts/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_post_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
				array(
					'methods'             => 'PUT,POST',
					'callback'            => array( $this, 'update_post_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/posts/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_post_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'suffix'  => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include' => $include_arg,
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_custom_posts_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array_merge( $this->get_list_args(), array( 'include' => $include_arg ) ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_custom_post_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
				array(
					'methods'             => 'PUT,POST',
					'callback'            => array( $this, 'update_custom_post_v2' ),
					'permission_callback' => array( $this, 'api_key_permission_check' ),
					'args'                => array( 'include' => $include_arg ),
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/post-types/(?P<type>[a-zA-Z0-9_-]+)/posts/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_custom_post_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
				'args'                => array(
					'suffix'  => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include' => $include_arg,
				),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/snapshots',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_snapshots_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/snapshots/(?P<snapshot_uuid>[a-f0-9\\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_snapshot_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/snapshots/diff',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'diff_snapshots_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/snapshots/restore',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'restore_snapshot_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);

		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/(?P<builder>[a-zA-Z0-9_-]+)/patch/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'apply_builder_patch_v2' ),
				'permission_callback' => array( $this, 'api_key_permission_check' ),
			)
		);
	}

	/**
	 * Get include arg schema.
	 *
	 * @since 3.1.0
	 * @return array
	 */
	private function get_v2_include_arg() {
		return array(
			'type'              => 'string',
			'required'          => false,
			'default'           => 'basic',
			'sanitize_callback' => 'sanitize_text_field',
		);
	}

	/**
	 * Require v2 scope for current request.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @param string          $scope Scope.
	 * @return WP_Error|null
	 */
	private function require_v2_scope( $request, $scope ) {
		$key_data = $request->get_param( '_respira_key_data' );
		if ( empty( $key_data ) || ! is_array( $key_data ) ) {
			return new WP_Error(
				'respira_unauthorized',
				__( 'API key required.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		if ( ! Respira_Auth::has_v2_scope( $key_data, $scope ) ) {
			return new WP_Error(
				'respira_scope_denied',
				sprintf(
					/* translators: %s: scope */
					__( 'Missing required v2 scope: %s', 'respira-for-wordpress' ),
					$scope
				),
				array( 'status' => 403 )
			);
		}

		return null;
	}

	/**
	 * Parse include list and enforce include-specific scopes.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	private function get_v2_includes_or_error( $request ) {
		$includes = Respira_Fidelity::parse_include( $request->get_param( 'include' ) );
		$key_data = $request->get_param( '_respira_key_data' );
		$fidelity_tokens = array(
			'content.rendered',
			'content.clean_html',
			'content.text',
			'builder.payload',
			'builder.extracted',
			'assets',
			'snapshot.current',
			'snapshot.history',
			'meta.allowlisted',
			'meta.all',
		);

		$requires_fidelity_scope = false;
		foreach ( $fidelity_tokens as $token ) {
			if ( in_array( $token, $includes, true ) ) {
				$requires_fidelity_scope = true;
				break;
			}
		}

		if ( $requires_fidelity_scope && ! Respira_Auth::has_v2_scope( $key_data, 'read_fidelity' ) ) {
			return new WP_Error(
				'respira_scope_denied',
				__( 'Requested include fields require read_fidelity scope.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		if ( in_array( 'meta.all', $includes, true ) && ! Respira_Auth::has_v2_scope( $key_data, 'read_meta_all' ) ) {
			return new WP_Error(
				'respira_scope_denied',
				__( 'include=meta.all requires read_meta_all scope.', 'respira-for-wordpress' ),
				array( 'status' => 403 )
			);
		}

		return $includes;
	}

	/**
	 * Resolve target duplicate for mandatory v2 write safety.
	 *
	 * @since 3.1.0
	 * @param int    $post_id Post ID from request.
	 * @param string $post_type Expected post type.
	 * @return array|WP_Error
	 */
	private function resolve_v2_duplicate_target( $post_id, $post_type ) {
		$post = get_post( $post_id );
		if ( ! $post || $post->post_type !== $post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$result = array(
			'original_id'             => (int) $post_id,
			'target_id'               => (int) $post_id,
			'duplicate_created'       => false,
			'used_existing_duplicate' => false,
		);

		if ( Respira_Duplicator::is_duplicate( $post_id ) ) {
			return $result;
		}

		$duplicates = Respira_Duplicator::get_duplicates( $post_id );
		if ( ! empty( $duplicates ) ) {
			$result['target_id'] = (int) $duplicates[0]->ID;
			$result['used_existing_duplicate'] = true;
			return $result;
		}

		$new_duplicate = Respira_Duplicator::duplicate_post( $post_id, '_duplicate_' . time() );
		if ( is_wp_error( $new_duplicate ) ) {
			return $new_duplicate;
		}

		$result['target_id']         = (int) $new_duplicate;
		$result['duplicate_created'] = true;

		return $result;
	}

	/**
	 * Build v2 post envelope.
	 *
	 * @since 3.1.0
	 * @param WP_Post $post Post.
	 * @param array   $includes Includes.
	 * @return array
	 */
	private function build_v2_post_envelope( $post, $includes ) {
		return Respira_Fidelity::build_v2_post_envelope( $post, $includes, Respira_Snapshots::get_instance() );
	}

	/**
	 * Get v2 status and capability negotiation payload.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_v2_status( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		return new WP_REST_Response(
			array(
				'namespace'    => RESPIRA_REST_NAMESPACE_V2,
				'status'       => 'ok',
				'capabilities' => array(
					'include_tokens' => Respira_Fidelity::INCLUDE_TOKENS,
					'snapshots'      => true,
					'builder_patch'  => true,
					'duplicate_before_edit' => true,
					'direct_edit_enabled' => (bool) get_option( 'respira_allow_direct_edit', 0 ),
					'approval_stale_base_protection' => true,
					'patch_identifier_priority' => array( 'id', 'path', 'type+match_content' ),
				),
				'retention' => array(
					'days'        => (int) get_option( 'respira_snapshot_retention_days', 90 ),
					'max_per_post' => (int) get_option( 'respira_snapshot_max_per_post', 50 ),
				),
				'compatibility' => array(
					'v1_unchanged' => true,
					'fallback_namespace' => RESPIRA_REST_NAMESPACE_V1,
				),
			),
			200
		);
	}

	/**
	 * V2 list pages endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_pages_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$args = array(
			'post_type'      => 'page',
			'posts_per_page' => $request->get_param( 'per_page' ) ? absint( $request->get_param( 'per_page' ) ) : 20,
			'paged'          => $request->get_param( 'page' ) ? absint( $request->get_param( 'page' ) ) : 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending' ),
		);

		$query = new WP_Query( $args );
		$pages = array();

		foreach ( $query->posts as $post ) {
			$pages[] = $this->build_v2_post_envelope( $post, $includes );
		}

		return new WP_REST_Response(
			array(
				'pages'       => $pages,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
				'includes'    => $includes,
			),
			200
		);
	}

	/**
	 * V2 get page endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_page_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$page_id = absint( $request->get_param( 'id' ) );
		$post    = get_post( $page_id );

		if ( ! $post || 'page' !== $post->post_type ) {
			return $this->respira_error(
				'respira_page_not_found',
				__( 'Page not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response( $this->build_v2_post_envelope( $post, $includes ), 200 );
	}

	/**
	 * V2 list posts endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_posts_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $request->get_param( 'per_page' ) ? absint( $request->get_param( 'per_page' ) ) : 20,
			'paged'          => $request->get_param( 'page' ) ? absint( $request->get_param( 'page' ) ) : 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending' ),
		);

		$query = new WP_Query( $args );
		$posts = array();

		foreach ( $query->posts as $post ) {
			$posts[] = $this->build_v2_post_envelope( $post, $includes );
		}

		return new WP_REST_Response(
			array(
				'posts'       => $posts,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
				'includes'    => $includes,
			),
			200
		);
	}

	/**
	 * V2 get post endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$post_id = absint( $request->get_param( 'id' ) );
		$post    = get_post( $post_id );

		if ( ! $post || 'post' !== $post->post_type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response( $this->build_v2_post_envelope( $post, $includes ), 200 );
	}

	/**
	 * V2 list custom posts endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_custom_posts_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$type = sanitize_key( (string) $request->get_param( 'type' ) );
		if ( ! post_type_exists( $type ) ) {
			return $this->respira_error(
				'respira_post_type_not_found',
				__( 'Post type not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$args = array(
			'post_type'      => $type,
			'posts_per_page' => $request->get_param( 'per_page' ) ? absint( $request->get_param( 'per_page' ) ) : 20,
			'paged'          => $request->get_param( 'page' ) ? absint( $request->get_param( 'page' ) ) : 1,
			's'              => $request->get_param( 'search' ) ?? '',
			'post_status'    => $request->get_param( 'status' ) ?? array( 'publish', 'draft', 'pending' ),
		);

		$query = new WP_Query( $args );
		$posts = array();

		foreach ( $query->posts as $post ) {
			$posts[] = $this->build_v2_post_envelope( $post, $includes );
		}

		return new WP_REST_Response(
			array(
				'posts'       => $posts,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
				'includes'    => $includes,
			),
			200
		);
	}

	/**
	 * V2 get custom post endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_custom_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_basic' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$type    = sanitize_key( (string) $request->get_param( 'type' ) );
		$post_id = absint( $request->get_param( 'id' ) );
		$post    = get_post( $post_id );

		if ( ! $post || $post->post_type !== $type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response( $this->build_v2_post_envelope( $post, $includes ), 200 );
	}

	/**
	 * V2 duplicate page endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function duplicate_page_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$page_id = absint( $request->get_param( 'id' ) );
		$suffix  = $request->get_param( 'suffix' ) ?? '_duplicate_' . time();

		$duplicate_id = Respira_Duplicator::duplicate_post( $page_id, $suffix );
		if ( is_wp_error( $duplicate_id ) ) {
			return $duplicate_id;
		}

		$post = get_post( $duplicate_id );
		return new WP_REST_Response(
			array(
				'success'   => true,
				'duplicate' => $this->build_v2_post_envelope( $post, $includes ),
				'message'   => __( 'Page duplicated successfully.', 'respira-for-wordpress' ),
			),
			201
		);
	}

	/**
	 * V2 duplicate post endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function duplicate_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$post_id = absint( $request->get_param( 'id' ) );
		$suffix  = $request->get_param( 'suffix' ) ?? '_duplicate_' . time();

		$duplicate_id = Respira_Duplicator::duplicate_post( $post_id, $suffix );
		if ( is_wp_error( $duplicate_id ) ) {
			return $duplicate_id;
		}

		$post = get_post( $duplicate_id );
		return new WP_REST_Response(
			array(
				'success'   => true,
				'duplicate' => $this->build_v2_post_envelope( $post, $includes ),
				'message'   => __( 'Post duplicated successfully.', 'respira-for-wordpress' ),
			),
			201
		);
	}

	/**
	 * V2 duplicate custom post endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function duplicate_custom_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$type    = sanitize_key( (string) $request->get_param( 'type' ) );
		$post_id = absint( $request->get_param( 'id' ) );
		$post    = get_post( $post_id );

		if ( ! $post || $post->post_type !== $type ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$suffix       = $request->get_param( 'suffix' ) ?? '_duplicate_' . time();
		$duplicate_id = Respira_Duplicator::duplicate_post( $post_id, $suffix );
		if ( is_wp_error( $duplicate_id ) ) {
			return $duplicate_id;
		}

		$duplicate = get_post( $duplicate_id );
		return new WP_REST_Response(
			array(
				'success'   => true,
				'duplicate' => $this->build_v2_post_envelope( $duplicate, $includes ),
				'message'   => __( 'Post duplicated successfully.', 'respira-for-wordpress' ),
			),
			201
		);
	}

	/**
	 * Capture before/after snapshots around a write operation.
	 *
	 * @since 3.1.0
	 * @param int             $target_id Target post ID.
	 * @param WP_REST_Request $request Request.
	 * @param callable        $writer Writer callback.
	 * @param string          $response_key Response post key.
	 * @return WP_REST_Response|WP_Error
	 */
	private function execute_v2_write_with_snapshots( $target_id, $request, $writer, $response_key ) {
		$includes = $this->get_v2_includes_or_error( $request );
		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		$key_data = $request->get_param( '_respira_key_data' );
		$key_id   = isset( $key_data['id'] ) ? (int) $key_data['id'] : null;

		$snapshots = Respira_Snapshots::get_instance();
		$before = $snapshots->capture_snapshot(
			$target_id,
			'before_edit',
			array( 'actor_api_key_id' => $key_id )
		);
		if ( is_wp_error( $before ) ) {
			return $before;
		}

		$result = call_user_func( $writer, $request );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = $result instanceof WP_REST_Response ? $result->get_data() : $result;
		$edited_id = $target_id;
		if ( is_array( $data ) && isset( $data[ $response_key ]['id'] ) ) {
			$edited_id = (int) $data[ $response_key ]['id'];
		}

		$after = $snapshots->capture_snapshot(
			$edited_id,
			'after_edit',
			array( 'actor_api_key_id' => $key_id )
		);
		if ( is_wp_error( $after ) ) {
			return $after;
		}

		// Ensure object cache is fresh before constructing the response.
		clean_post_cache( $edited_id );
		$edited_post = get_post( $edited_id );
		if ( ! $edited_post ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found after update.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		$response = array(
			'success'    => true,
			'post'       => $this->build_v2_post_envelope( $edited_post, $includes ),
			'snapshot'   => array(
				'before' => $before,
				'after'  => $after,
			),
			'includes'   => $includes,
		);

		if ( is_array( $data ) ) {
			foreach ( array( 'duplicate_created', 'duplicate_id', 'original_id', 'approval_url', 'message', 'instructions' ) as $passthrough ) {
				if ( array_key_exists( $passthrough, $data ) ) {
					$response[ $passthrough ] = $data[ $passthrough ];
				}
			}
		}

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * V2 update page endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_page_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$target_info = $this->resolve_mutation_target( $request, absint( $request->get_param( 'id' ) ), 'page' );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}

		$subrequest = new WP_REST_Request( $request->get_method(), $request->get_route() );
		foreach ( $request->get_params() as $key => $value ) {
			if ( in_array( $key, array( 'include', 'force', 'editTarget', 'edit_target' ), true ) ) {
				continue;
			}
			$subrequest->set_param( $key, $value );
		}
		$subrequest->set_param( 'id', $target_info['target_id'] );
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );
		$subrequest->set_param( 'force', $is_live_original );
		if ( $is_live_original ) {
			$subrequest->set_param( 'confirm_live_edit', true );
		}
		$subrequest->set_param( '_respira_key_data', $request->get_param( '_respira_key_data' ) );

		$response = $this->execute_v2_write_with_snapshots(
			$target_info['target_id'],
			$request,
			function ( $ignored_request = null ) use ( $subrequest ) {
				return $this->update_page( $subrequest );
			},
			'page'
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( 'duplicate' === $target_info['edit_target'] && $target_info['target_id'] !== $target_info['original_id'] ) {
			$data['duplicate_id'] = $target_info['target_id'];
			$data['original_id']  = $target_info['original_id'];
			if ( $target_info['duplicate_created'] ) {
				$data['duplicate_created'] = true;
			}
		}
		if ( $is_live_original ) {
			$data['edit_target'] = 'live';
			$data['rollback']    = array(
				'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
				'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
			);
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * V2 update post endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$target_info = $this->resolve_mutation_target( $request, absint( $request->get_param( 'id' ) ), 'post' );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}

		$subrequest = new WP_REST_Request( $request->get_method(), $request->get_route() );
		foreach ( $request->get_params() as $key => $value ) {
			if ( in_array( $key, array( 'include', 'force', 'editTarget', 'edit_target' ), true ) ) {
				continue;
			}
			$subrequest->set_param( $key, $value );
		}
		$subrequest->set_param( 'id', $target_info['target_id'] );
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );
		$subrequest->set_param( 'force', $is_live_original );
		if ( $is_live_original ) {
			$subrequest->set_param( 'confirm_live_edit', true );
		}
		$subrequest->set_param( '_respira_key_data', $request->get_param( '_respira_key_data' ) );

		$response = $this->execute_v2_write_with_snapshots(
			$target_info['target_id'],
			$request,
			function ( $ignored_request = null ) use ( $subrequest ) {
				return $this->update_post( $subrequest );
			},
			'post'
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( 'duplicate' === $target_info['edit_target'] && $target_info['target_id'] !== $target_info['original_id'] ) {
			$data['duplicate_id'] = $target_info['target_id'];
			$data['original_id']  = $target_info['original_id'];
			if ( $target_info['duplicate_created'] ) {
				$data['duplicate_created'] = true;
			}
		}
		if ( $is_live_original ) {
			$data['edit_target'] = 'live';
			$data['rollback']    = array(
				'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
				'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
			);
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * V2 update custom post endpoint with duplicate-before-edit enforcement.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_custom_post_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$type       = sanitize_key( (string) $request->get_param( 'type' ) );
		$target_info = $this->resolve_mutation_target( $request, absint( $request->get_param( 'id' ) ), $type );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}

		$subrequest = new WP_REST_Request( $request->get_method(), $request->get_route() );
		foreach ( $request->get_params() as $key => $value ) {
			if ( in_array( $key, array( 'include', 'force', 'editTarget', 'edit_target' ), true ) ) {
				continue;
			}
			$subrequest->set_param( $key, $value );
		}
		$subrequest->set_param( 'id', $target_info['target_id'] );
		$subrequest->set_param( 'type', $type );
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );
		$subrequest->set_param( 'force', $is_live_original );
		if ( $is_live_original ) {
			$subrequest->set_param( 'confirm_live_edit', true );
		}
		$subrequest->set_param( '_respira_key_data', $request->get_param( '_respira_key_data' ) );

		$response = $this->execute_v2_write_with_snapshots(
			$target_info['target_id'],
			$request,
			function ( $ignored_request = null ) use ( $subrequest ) {
				return $this->update_custom_post( $subrequest );
			},
			'post'
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( 'duplicate' === $target_info['edit_target'] && $target_info['target_id'] !== $target_info['original_id'] ) {
			$data['duplicate_created'] = ! empty( $target_info['duplicate_created'] );
			$data['duplicate_id']      = $target_info['target_id'];
			$data['original_id']       = $target_info['original_id'];
		}
		if ( $is_live_original ) {
			$data['edit_target'] = 'live';
			$data['rollback']    = array(
				'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
				'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
			);
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * V2 list snapshots endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_snapshots_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_fidelity' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$snapshots = Respira_Snapshots::get_instance()->list_snapshots(
			array(
				'post_id'   => $request->get_param( 'post_id' ),
				'post_type' => $request->get_param( 'post_type' ),
				'kind'      => $request->get_param( 'kind' ),
				'limit'     => $request->get_param( 'limit' ),
				'cursor'    => $request->get_param( 'cursor' ),
			)
		);

		return new WP_REST_Response( $snapshots, 200 );
	}

	/**
	 * V2 get snapshot endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_snapshot_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_fidelity' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$snapshot_uuid = (string) $request->get_param( 'snapshot_uuid' );
		$snapshot      = Respira_Snapshots::get_instance()->get_snapshot( $snapshot_uuid, true );

		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}

		return new WP_REST_Response( $snapshot, 200 );
	}

	/**
	 * V2 diff snapshots endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function diff_snapshots_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'read_fidelity' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$snapshot_a = (string) $request->get_param( 'snapshot_uuid_a' );
		$snapshot_b = (string) $request->get_param( 'snapshot_uuid_b' );

		if ( '' === $snapshot_a || '' === $snapshot_b ) {
			return new WP_Error(
				'respira_snapshot_diff_missing_params',
				__( 'snapshot_uuid_a and snapshot_uuid_b are required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$diff = Respira_Snapshots::get_instance()->diff_snapshots( $snapshot_a, $snapshot_b );
		if ( is_wp_error( $diff ) ) {
			return $diff;
		}

		return new WP_REST_Response( $diff, 200 );
	}

	/**
	 * V2 restore snapshot endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function restore_snapshot_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$snapshot_uuid = (string) $request->get_param( 'snapshot_uuid' );
		if ( '' === $snapshot_uuid ) {
			return new WP_Error(
				'respira_snapshot_restore_missing_uuid',
				__( 'snapshot_uuid is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$key_data = $request->get_param( '_respira_key_data' );
		$actor_id = isset( $key_data['id'] ) ? (int) $key_data['id'] : null;

		$restored = Respira_Snapshots::get_instance()->restore_snapshot(
			$snapshot_uuid,
			array( 'actor_api_key_id' => $actor_id )
		);
		if ( is_wp_error( $restored ) ) {
			return $restored;
		}

		return new WP_REST_Response( $restored, 200 );
	}

	/**
	 * V2 builder patch endpoint.
	 *
	 * @since 3.1.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function apply_builder_patch_v2( $request ) {
		$scope_error = $this->require_v2_scope( $request, 'write' );
		if ( is_wp_error( $scope_error ) ) {
			return $scope_error;
		}

		$builder    = sanitize_key( (string) $request->get_param( 'builder' ) );
		$post_id    = absint( $request->get_param( 'post_id' ) );
		$operations = $request->get_param( 'operations' );
		$includes   = $this->get_v2_includes_or_error( $request );

		if ( is_wp_error( $includes ) ) {
			return $includes;
		}

		if ( empty( $operations ) || ! is_array( $operations ) ) {
			return new WP_Error(
				'respira_patch_missing_operations',
				__( 'operations[] is required.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$target_info = $this->resolve_mutation_target( $request, $post_id, get_post_type( $post_id ) );
		if ( is_wp_error( $target_info ) ) {
			return $target_info;
		}
		if ( $target_info instanceof WP_REST_Response ) {
			return $target_info;
		}
		$post_id = (int) $target_info['target_id'];
		$is_live_original = 'live' === $target_info['edit_target'] && (int) $target_info['target_id'] === (int) $target_info['original_id'] && empty( $target_info['is_duplicate'] );

		$key_data = $request->get_param( '_respira_key_data' );
		$key_id   = isset( $key_data['id'] ) ? (int) $key_data['id'] : null;

		$snapshots = Respira_Snapshots::get_instance();
		$before    = $snapshots->capture_snapshot(
			$post_id,
			'before_edit',
			array( 'actor_api_key_id' => $key_id )
		);
		if ( is_wp_error( $before ) ) {
			return $before;
		}

		$patcher = new Respira_Builder_Patcher();
		$result  = $patcher->apply_patch( $builder, $post_id, $operations );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$after = $snapshots->capture_snapshot(
			$post_id,
			'after_edit',
			array( 'actor_api_key_id' => $key_id )
		);
		if ( is_wp_error( $after ) ) {
			return $after;
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return $this->respira_error(
				'respira_post_not_found',
				__( 'Post not found after patch.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response(
			array(
				'success'   => true,
				'result'    => $result,
				'post'      => $this->build_v2_post_envelope( $post, $includes ),
				'snapshot'  => array(
					'before' => $before,
					'after'  => $after,
				),
				'fidelity'  => array(
					'hashes' => Respira_Fidelity::compute_hashes( $post_id ),
				),
				'duplicate_id' => ( 'duplicate' === $target_info['edit_target'] && (int) $target_info['target_id'] !== (int) $target_info['original_id'] ) ? (int) $target_info['target_id'] : null,
				'original_id'  => ( 'duplicate' === $target_info['edit_target'] && (int) $target_info['target_id'] !== (int) $target_info['original_id'] ) ? (int) $target_info['original_id'] : null,
				'duplicate_created' => ! empty( $target_info['duplicate_created'] ),
				'edit_target' => $target_info['edit_target'],
				'rollback'    => $is_live_original ? array(
					'wordpress_revisions' => __( 'If something goes wrong, restore a previous revision from the WordPress edit screen.', 'respira-for-wordpress' ),
					'edit_screen_url'     => admin_url( 'post.php?post=' . absint( $target_info['original_id'] ) . '&action=edit' ),
				) : null,
			),
			200
		);
	}

	/**
	 * Force post_type to 'page' in WP_Query.
	 *
	 * Used to override WPML and other plugins that modify queries.
	 *
	 * @since 1.8.43
	 * @param WP_Query $query The query object.
	 */
	public function force_page_post_type( $query ) {
		$query->set( 'post_type', 'page' );
	}

	/**
	 * Force post_type to 'post' in WP_Query.
	 *
	 * Used to override WPML and other plugins that modify queries.
	 *
	 * @since 1.8.43
	 * @param WP_Query $query The query object.
	 */
	public function force_post_post_type( $query ) {
		$query->set( 'post_type', 'post' );
	}

	/**
	 * Force post_type to 'attachment' in WP_Query.
	 *
	 * Used to override WPML and other plugins that modify media queries.
	 *
	 * @since 1.8.45
	 * @param WP_Query $query The query object.
	 */
	public function force_attachment_post_type( $query ) {
		$query->set( 'post_type', 'attachment' );
	}

}
