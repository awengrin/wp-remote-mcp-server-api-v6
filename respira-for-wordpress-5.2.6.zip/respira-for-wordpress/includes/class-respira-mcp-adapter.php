<?php
/**
 * WordPress MCP Adapter integration.
 *
 * Registers Respira as a custom MCP server via the official
 * WordPress MCP Adapter so abilities are exposed through the
 * adapter's transport layer (HTTP and STDIO).
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      2.0.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Handles MCP Adapter server registration.
 *
 * @since 2.0.0
 */
class Respira_MCP_Adapter {

	/**
	 * Whether this process already registered the Respira MCP server.
	 *
	 * @var bool
	 */
	private $server_registered = false;

	/**
	 * Initialize the MCP Adapter integration.
	 *
	 * @since 2.0.0
	 */
	public function __construct() {
		// Abilities API is required because this server exposes ability IDs.
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		// Current MCP Adapter registration lifecycle.
		add_action( 'mcp_adapter_init', array( $this, 'register_server' ) );
		add_action( 'mcp_adapter_init', array( $this, 'maybe_register_resources' ), 20 );

		// Legacy MCP Adapter hook kept for backward compatibility with older installs.
		add_action( 'mcp_adapter_register_servers', array( $this, 'register_server' ) );
		add_action( 'mcp_adapter_register_resources', array( $this, 'register_resources' ) );
	}

	/**
	 * Register Respira as an MCP server in the adapter.
	 *
	 * @since 2.0.0
	 * @param object $manager The MCP Adapter server manager.
	 */
	public function register_server( $manager ) {
		if ( $this->server_registered ) {
			return;
		}
		if ( ! method_exists( $manager, 'create_server' ) ) {
			return;
		}
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		$abilities = array();
		if ( class_exists( 'Respira_WebMCP_Integration' ) && method_exists( 'Respira_WebMCP_Integration', 'get_ability_ids_for_adapter' ) ) {
			$abilities = Respira_WebMCP_Integration::get_ability_ids_for_adapter();
		}

		if ( empty( $abilities ) ) {
			return;
		}

		$server_args = array(
			'respira-press',
			'respira/v1',
			'mcp',
			'Respira for WordPress',
			'Complete WordPress AI toolkit exposing Respira WebMCP abilities for content, media, builders, menus, plugins, SEO, and WooCommerce (when licensed), with automatic v2 fidelity/snapshot capabilities when available.',
			RESPIRA_VERSION,
			$this->get_transport_classes(),
			$this->get_error_handler_class(),
			$this->get_observability_handler_class(),
			$abilities,
			array(),
			array(),
			array( $this, 'transport_permission_callback' ),
		);

		$created = $this->create_server_compat( $manager, $server_args, $abilities );
		if ( is_wp_error( $created ) ) {
			return;
		}

		$this->server_registered = true;
	}

	/**
	 * Call create_server() using modern or legacy adapter signature.
	 *
	 * @param object $manager      MCP adapter manager.
	 * @param array  $modern_args  Arguments for modern create_server() signature.
	 * @param array  $ability_ids  Ability IDs for legacy fallback.
	 * @return mixed
	 */
	private function create_server_compat( $manager, $modern_args, $ability_ids ) {
		try {
			$reflection = new ReflectionMethod( $manager, 'create_server' );
			if ( $reflection->getNumberOfParameters() >= 13 ) {
				return call_user_func_array( array( $manager, 'create_server' ), $modern_args );
			}
		} catch ( ReflectionException $e ) {
			// Fall through to legacy signature attempt.
		}

		return $manager->create_server(
			'respira-press',
			'respira/v1',
			'mcp',
			'Respira for WordPress',
			'Complete WordPress AI toolkit exposing Respira WebMCP abilities for content, media, builders, menus, plugins, SEO, and WooCommerce (when licensed), with automatic v2 fidelity/snapshot capabilities when available.',
			RESPIRA_VERSION,
			$this->get_transport_classes(),
			array(),
			array(),
			$ability_ids
		);
	}

	/**
	 * Get supported transport classes for modern MCP Adapter.
	 *
	 * @return array<int,string>
	 */
	private function get_transport_classes() {
		$transports = array();
		if ( class_exists( '\WP\MCP\Transport\HttpTransport' ) ) {
			$transports[] = \WP\MCP\Transport\HttpTransport::class;
		}

		return $transports;
	}

	/**
	 * Get MCP error handler class when available.
	 *
	 * @return string|null
	 */
	private function get_error_handler_class() {
		if ( class_exists( '\WP\MCP\Infrastructure\ErrorHandling\ErrorLogMcpErrorHandler' ) ) {
			return \WP\MCP\Infrastructure\ErrorHandling\ErrorLogMcpErrorHandler::class;
		}

		return null;
	}

	/**
	 * Get MCP observability handler class when available.
	 *
	 * @return string|null
	 */
	private function get_observability_handler_class() {
		if ( class_exists( '\WP\MCP\Infrastructure\Observability\NullMcpObservabilityHandler' ) ) {
			return \WP\MCP\Infrastructure\Observability\NullMcpObservabilityHandler::class;
		}

		return null;
	}

	/**
	 * Transport-level auth callback for MCP adapter.
	 *
	 * @return bool
	 */
	public function transport_permission_callback() {
		return current_user_can( 'read' );
	}

	/**
	 * Register resources for adapter variants that support direct resource registration.
	 *
	 * @param object $manager The MCP Adapter manager.
	 * @return void
	 */
	public function maybe_register_resources( $manager ) {
		if ( method_exists( $manager, 'register_resource' ) ) {
			$this->register_resources( $manager );
		}
	}

	/**
	 * Register builder intelligence docs as MCP resources.
	 *
	 * These let AI agents understand builder-specific syntax before editing.
	 *
	 * @since 2.0.0
	 * @param object $manager The MCP Adapter resource manager.
	 */
	public function register_resources( $manager ) {
		if ( ! method_exists( $manager, 'register_resource' ) ) {
			return;
		}

		$builders = array(
			'divi'             => 'Divi Builder module reference (200+ modules)',
			'elementor'        => 'Elementor widget reference (all widgets)',
			'gutenberg'        => 'Gutenberg block reference (all registered blocks)',
			'bricks'           => 'Bricks Builder element reference',
			'oxygen'           => 'Oxygen Builder component reference',
			'wpbakery'         => 'WPBakery Page Builder element reference',
			'beaver-builder'   => 'Beaver Builder module reference',
			'brizy'            => 'Brizy Builder element reference',
			'visual-composer'  => 'Visual Composer element reference',
			'thrive-architect' => 'Thrive Architect element reference',
		);

		foreach ( $builders as $slug => $description ) {
			$manager->register_resource(
				'respira://builder-docs/' . $slug,
				$description,
				'application/json',
				array( $this, 'get_builder_docs_resource' ),
				array( 'builder' => $slug )
			);
		}
	}

	/**
	 * Provide builder documentation as an MCP resource.
	 *
	 * @since 2.0.0
	 * @param array $params Resource parameters including builder slug.
	 * @return array Builder documentation data.
	 */
	public function get_builder_docs_resource( $params ) {
		$builder = isset( $params['builder'] ) ? $params['builder'] : '';
		$request = new WP_REST_Request( 'GET', '/' . RESPIRA_REST_NAMESPACE . '/builder-info' );
		$request->set_param( 'builder', $builder );
		$response = rest_do_request( $request );

		if ( $response->is_error() ) {
			return array(
				'error'   => true,
				'message' => 'Builder documentation not available.',
			);
		}

		return $response->get_data();
	}
}
