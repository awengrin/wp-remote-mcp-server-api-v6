<?php
/**
 * Site context extraction functionality.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * Site context extraction functionality.
 *
 * Extracts information about the WordPress site, theme, plugins,
 * and page builders to provide context to the AI.
 *
 * @since 1.0.0
 */
class Respira_Context {

	/**
	 * Get comprehensive site information.
	 *
	 * @since 1.0.0
	 * @return array Site information array.
	 */
	public static function get_site_info() {
		// Check transient first.
		$cached = get_transient( 'respira_site_context' );
		if ( false !== $cached ) {
			$cached_divi = isset( $cached['divi_context'] ) && is_array( $cached['divi_context'] ) ? $cached['divi_context'] : null;
			if ( ! $cached_divi || isset( $cached_divi['block_support'] ) ) {
				return $cached;
			}
		}

		global $wpdb;

		$theme = wp_get_theme();

		$page_builder = self::detect_page_builder();

		$info = array(
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version'       => phpversion(),
			'mysql_version'     => $wpdb->db_version(),
			'site_url'          => get_site_url(),
			'home_url'          => get_home_url(),
			'site_name'         => get_bloginfo( 'name' ),
			'site_description'  => get_bloginfo( 'description' ),
			'language'          => get_bloginfo( 'language' ),
			'is_multisite'      => is_multisite(),
			'active_theme'      => array(
				'name'        => $theme->get( 'Name' ),
				'version'     => $theme->get( 'Version' ),
				'author'      => $theme->get( 'Author' ),
				'template'    => $theme->get_template(),
				'stylesheet'  => $theme->get_stylesheet(),
				'description' => $theme->get( 'Description' ),
			),
			'active_plugins'    => self::get_active_plugins(),
			'custom_post_types' => self::get_custom_post_types(),
			'taxonomies'        => self::get_taxonomies(),
			'database_tables'   => self::get_database_tables(),
			'page_builder'      => $page_builder,
			'addons'            => self::get_addons_context(),
		);

		// Add Divi-specific context if Divi is detected.
		if ( $page_builder && 'Divi' === $page_builder['name'] ) {
			$info['divi_context'] = self::get_divi_context();
		}

		$woo_addon = $info['addons']['woocommerce'] ?? array();
		if ( ! empty( $woo_addon['installed'] ) && ! empty( $woo_addon['licensed'] ) && class_exists( '\Respira_WooCommerce\WooCommerce_Integration' ) ) {
			try {
				$woo_context = \Respira_WooCommerce\WooCommerce_Integration::get_context();
				if ( ! empty( $woo_context ) ) {
					$info['woocommerce'] = $woo_context;
				}
			} catch ( \Throwable $e ) {
				$info['woocommerce'] = array(
					'active'  => true,
					'version' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
				);
			}
		} elseif ( self::is_woocommerce_active() ) {
			$info['woocommerce'] = array(
				'active'  => true,
				'version' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
			);
			$info['upsell']      = array(
				'message' => __( 'WooCommerce detected. Install the Respira WooCommerce add-on to manage products, orders, and inventory with AI.', 'respira-for-wordpress' ),
				'url'     => 'https://respira.press/addons/woocommerce',
			);
		}

		// Cache for 1 hour.
		set_transient( 'respira_site_context', $info, HOUR_IN_SECONDS );

		return $info;
	}

	/**
	 * Get active plugins information.
	 *
	 * @since  1.0.0
	 * @return array Active plugins array.
	 */
	private static function get_active_plugins() {
		$active_plugins = get_option( 'active_plugins', array() );
		$plugins_info   = array();

		foreach ( $active_plugins as $plugin ) {
			$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
			$plugins_info[] = array(
				'name'        => $plugin_data['Name'],
				'version'     => $plugin_data['Version'],
				'author'      => $plugin_data['Author'],
				'description' => $plugin_data['Description'],
				'file'        => $plugin,
			);
		}

		return $plugins_info;
	}

	/**
	 * Get custom post types.
	 *
	 * @since  1.0.0
	 * @return array Custom post types array.
	 */
	private static function get_custom_post_types() {
		$post_types = get_post_types(
			array(
				'public'   => true,
				'_builtin' => false,
			),
			'objects'
		);

		// Include non-public post types used by page builders (e.g. Elementor Theme Builder templates).
		$extra_slugs = array( 'elementor_library' );

		/**
		 * Filter additional non-public post type slugs to include in site context.
		 *
		 * @since 4.0.12
		 * @param string[] $extra_slugs Non-public post type slugs to whitelist.
		 */
		$extra_slugs = apply_filters( 'respira_extra_context_post_types', $extra_slugs );

		foreach ( $extra_slugs as $slug ) {
			if ( post_type_exists( $slug ) && ! isset( $post_types[ $slug ] ) ) {
				$post_types[ $slug ] = get_post_type_object( $slug );
			}
		}

		$cpts = array();

		foreach ( $post_types as $post_type ) {
			$cpts[] = array(
				'name'        => $post_type->name,
				'label'       => $post_type->label,
				'description' => $post_type->description,
				'supports'    => get_all_post_type_supports( $post_type->name ),
			);
		}

		return $cpts;
	}

	/**
	 * Get taxonomies.
	 *
	 * @since  1.0.0
	 * @return array Taxonomies array.
	 */
	private static function get_taxonomies() {
		$taxonomies = get_taxonomies(
			array(
				'public'   => true,
				'_builtin' => false,
			),
			'objects'
		);

		$taxes = array();

		foreach ( $taxonomies as $taxonomy ) {
			$taxes[] = array(
				'name'          => $taxonomy->name,
				'label'         => $taxonomy->label,
				'description'   => $taxonomy->description,
				'object_types'  => $taxonomy->object_type,
				'hierarchical'  => $taxonomy->hierarchical,
			);
		}

		return $taxes;
	}

	/**
	 * Get database tables.
	 *
	 * @since  1.0.0
	 * @return array Database tables array.
	 */
	private static function get_database_tables() {
		global $wpdb;

		$tables = $wpdb->get_col( 'SHOW TABLES' );

		return array_map(
			function( $table ) use ( $wpdb ) {
				return str_replace( $wpdb->prefix, '', $table );
			},
			$tables
		);
	}

	/**
	 * Detect active page builder.
	 *
	 * @since  1.0.0
	 * @return array|null Page builder info or null.
	 */
	private static function detect_page_builder() {
		$builder = Respira_Builder_Interface::detect_builder();

		if ( $builder ) {
			return array(
				'name'    => $builder->get_name(),
				'version' => $builder->get_version(),
			);
		}

		return null;
	}

	/**
	 * Get theme documentation.
	 *
	 * @since 1.0.0
	 * @return array Theme documentation array.
	 */
	public static function get_theme_docs() {
		$theme = wp_get_theme();

		$docs = array(
			'theme_name'        => $theme->get( 'Name' ),
			'theme_version'     => $theme->get( 'Version' ),
			'theme_uri'         => $theme->get( 'ThemeURI' ),
			'author_uri'        => $theme->get( 'AuthorURI' ),
			'readme'            => self::get_theme_readme(),
			'template_files'    => self::get_theme_template_files(),
			'custom_functions'  => self::get_theme_functions(),
		);

		return $docs;
	}

	/**
	 * Build add-ons state included in site context.
	 *
	 * @since 2.1.0
	 * @return array<string,mixed>
	 */
	private static function get_addons_context() {
		$installed = self::is_plugin_active_by_basename( 'respira-woocommerce-addon/respira-woocommerce-addon.php' );
		$licensed  = false;

		if ( $installed && class_exists( '\Respira_WooCommerce\License_Manager' ) ) {
			$licensed = \Respira_WooCommerce\License_Manager::instance()->is_valid();
		}

		return array(
			'woocommerce' => array(
				'installed' => $installed,
				'licensed'  => $licensed,
			),
		);
	}

	/**
	 * Check if WooCommerce plugin is active.
	 *
	 * @since 2.1.0
	 * @return bool
	 */
	private static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' ) || self::is_plugin_active_by_basename( 'woocommerce/woocommerce.php' );
	}

	/**
	 * Frontend-safe plugin active check.
	 *
	 * @since 2.1.0
	 * @param string $plugin_basename Plugin basename.
	 * @return bool
	 */
	private static function is_plugin_active_by_basename( $plugin_basename ) {
		$active_plugins = (array) get_option( 'active_plugins', array() );
		if ( in_array( $plugin_basename, $active_plugins, true ) ) {
			return true;
		}

		if ( is_multisite() ) {
			$network_plugins = array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) );
			if ( in_array( $plugin_basename, $network_plugins, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get theme readme content.
	 *
	 * @since  1.0.0
	 * @return string|null Readme content or null.
	 */
	private static function get_theme_readme() {
		$theme_dir = get_stylesheet_directory();
		$readme_files = array( 'README.md', 'readme.txt', 'README.txt', 'readme.md' );

		foreach ( $readme_files as $file ) {
			$path = $theme_dir . '/' . $file;
			if ( file_exists( $path ) ) {
				return file_get_contents( $path );
			}
		}

		return null;
	}

	/**
	 * Get theme template files.
	 *
	 * @since  1.0.0
	 * @return array Template files array.
	 */
	private static function get_theme_template_files() {
		$theme_dir = get_stylesheet_directory();
		$files     = array();

		$templates = array(
			'index.php',
			'header.php',
			'footer.php',
			'sidebar.php',
			'single.php',
			'page.php',
			'archive.php',
			'functions.php',
		);

		foreach ( $templates as $template ) {
			if ( file_exists( $theme_dir . '/' . $template ) ) {
				$files[] = $template;
			}
		}

		return $files;
	}

	/**
	 * Get theme functions (from functions.php).
	 *
	 * @since  1.0.0
	 * @return array Custom functions array.
	 */
	private static function get_theme_functions() {
		$theme_dir     = get_stylesheet_directory();
		$functions_file = $theme_dir . '/functions.php';

		if ( ! file_exists( $functions_file ) ) {
			return array();
		}

		$content = file_get_contents( $functions_file );

		// Extract function names using regex.
		preg_match_all( '/function\s+([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*\(/', $content, $matches );

		return $matches[1] ?? array();
	}

	/**
	 * Get page builder information.
	 *
	 * @since 1.0.0
	 * @return array Page builder information array.
	 */
	public static function get_builder_info() {
		// Check transient first.
		$cached = get_transient( 'respira_builder_info' );
		if ( false !== $cached ) {
			$cached_divi = isset( $cached['builders']['Divi'] ) && is_array( $cached['builders']['Divi'] ) ? $cached['builders']['Divi'] : null;
			$cached_docs = isset( $cached_divi['documentation'] ) && is_array( $cached_divi['documentation'] ) ? $cached_divi['documentation'] : null;
			if ( ! $cached_divi || ( $cached_docs && isset( $cached_docs['block_support'] ) ) ) {
				return $cached;
			}
		}

		// Get all available builders.
		$builder_classes = array(
			'Respira_Builder_Divi',
			'Respira_Builder_Elementor',
			'Respira_Builder_WPBakery',
			'Respira_Builder_Oxygen',
			'Respira_Builder_Bricks',
			'Respira_Builder_Beaver',
			'Respira_Builder_Brizy',
			'Respira_Builder_Visual_Composer',
			'Respira_Builder_Thrive',
			'Respira_Builder_Breakdance',
			'Respira_Builder_Gutenberg',
		);

		$builders_info     = array();
		$detected_builders = array();

		foreach ( $builder_classes as $builder_class ) {
			if ( ! class_exists( $builder_class ) ) {
				continue;
			}

			$builder = new $builder_class();
			$is_detected = $builder->detect();
			$intelligence_available = $builder->is_intelligence_available();

			$builder_info = array(
				'name'                  => $builder->get_name(),
				'version'              => $builder->get_version(),
				'detected'              => $is_detected,
				'intelligence_available' => $intelligence_available,
				'intelligence_active'   => $intelligence_available && $is_detected,
			);

			// Get module/widget/block count if available.
			if ( $is_detected ) {
				$modules = $builder->get_available_modules();
				$builder_info['module_count'] = count( $modules );
				$builder_info['documentation'] = $builder->get_documentation();
				if ( isset( $builder_info['documentation']['generation'] ) ) {
					$builder_info['generation'] = $builder_info['documentation']['generation'];
				}

				$detected_builders[] = array(
					'name'    => $builder->get_name(),
					'version' => $builder->get_version(),
				);
			}

			$builders_info[ $builder->get_name() ] = $builder_info;
		}

		// Get theme information.
		$theme_info = Respira_Theme_Detector::get_theme_info();
		$active_builder = Respira_Builder_Interface::detect_builder();

		$info = array(
			'builders'       => $builders_info,
			'detected_builders' => $detected_builders,
			'active_builder' => $active_builder ? array(
				'name'    => $active_builder->get_name(),
				'version' => $active_builder->get_version(),
			) : null,
			'theme'          => $theme_info,
		);

		// Cache for 1 hour.
		set_transient( 'respira_builder_info', $info, HOUR_IN_SECONDS );

		return $info;
	}

	/**
	 * Invalidate cached builder info.
	 *
	 * Hooked to `activated_plugin` and `deactivated_plugin` so that builder
	 * detection re-runs after any plugin state change.
	 *
	 * @since 5.2.5
	 */
	public static function invalidate_builder_cache() {
		delete_transient( 'respira_builder_info' );
		delete_transient( 'respira_detected_builders' );
		delete_transient( 'respira_site_context' );
	}

	/**
	 * Get Divi-specific context information.
	 *
	 * @since 1.0.0
	 * @return array Divi context array.
	 */
	private static function get_divi_context() {
		$context = array(
			'builder_name'    => 'Divi',
			'builder_version' => defined( 'ET_BUILDER_PLUGIN_VERSION' ) ? ET_BUILDER_PLUGIN_VERSION : 'unknown',
			'is_theme'        => ( 'Divi' === wp_get_theme()->get( 'Name' ) ),
			'is_plugin'       => defined( 'ET_BUILDER_PLUGIN_VERSION' ),
		);

		// Get module information if registry is available.
		if ( class_exists( 'Respira_Divi_Module_Registry' ) ) {
			$all_modules       = Respira_Divi_Module_Registry::get_all_modules();
			$safe_modules      = Respira_Divi_Module_Registry::get_ai_safe_modules();
			$registered_blocks = Respira_Divi_Module_Registry::get_block_modules();
			$safe_blocks       = Respira_Divi_Module_Registry::get_ai_safe_block_modules();
			$restricted_blocks = Respira_Divi_Module_Registry::get_ai_restricted_block_modules();
			$context['modules'] = array(
				'mode'      => 'ai_safe_defaults',
				'total'     => count( $safe_modules ),
				'available' => array_column( $safe_modules, 'name' ),
			);
			$context['registered_modules'] = array(
				'total'     => count( $all_modules ),
				'available' => array_column( $all_modules, 'name' ),
			);
			if ( ! empty( $registered_blocks ) ) {
				$context['block_support'] = array(
					'mode'                        => 'conservative',
					'registered_blocks'           => array_column( $registered_blocks, 'name' ),
					'safe_default_blocks'         => array_column( $safe_blocks, 'name' ),
					'restricted_registered_blocks'=> array_column( $restricted_blocks, 'name' ),
					'warning'                     => __(
						'Respira advertises only a conservative subset of native Divi 5 blocks by default. Extend the allowlist via filters only after validating save and frontend render behavior on this site.',
						'respira-for-wordpress'
					),
				);
			}
		}

		return $context;
	}

	/**
	 * Get Divi module information.
	 *
	 * @since 1.0.0
	 * @param Respira_Builder_Interface $builder Builder instance.
	 * @return array Module information.
	 */
	private static function get_divi_module_info( $builder ) {
		$modules = $builder->get_available_modules();

		return array(
			'count'   => count( $modules ),
			'modules' => array_slice( $modules, 0, 20 ), // Limit to first 20 for performance.
		);
	}

	/**
	 * Get Divi patterns information.
	 *
	 * @since 1.0.0
	 * @return array Patterns information.
	 */
	private static function get_divi_patterns_info() {
		$patterns_file = RESPIRA_PLUGIN_DIR . 'includes/divi-intelligence/divi-patterns.php';
		if ( file_exists( $patterns_file ) ) {
			require_once $patterns_file;
			if ( function_exists( 'respira_get_divi_patterns' ) ) {
				$patterns = respira_get_divi_patterns();
				return array(
					'count'    => count( $patterns ),
					'patterns' => array_keys( $patterns ),
				);
			}
		}

		return array(
			'count'    => 0,
			'patterns' => array(),
		);
	}
}
