<?php
/**
 * HTML-to-Builder Conversion Orchestrator.
 *
 * Converts raw HTML into native page builder content.
 * Coordinates CSS extraction, section mapping, style translation,
 * and fidelity checking.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_HTML_Converter {

	/**
	 * Maximum HTML input size in bytes (5MB).
	 *
	 * @var int
	 */
	const MAX_INPUT_SIZE = 5242880;

	/**
	 * Current CSS tokens for variable resolution during style matching.
	 *
	 * @since 5.2.0
	 * @var array
	 */
	private $_current_tokens = array();

	/**
	 * Source container max-width detected from CSS (e.g. 1200px).
	 *
	 * @since 5.2.2
	 * @var int
	 */
	private $_source_container_width = 1200;

	/**
	 * Convert HTML to a native builder page.
	 *
	 * @param string $html    Full HTML string.
	 * @param string $builder Target builder slug ('auto' for auto-detect).
	 * @param array  $options Conversion options.
	 * @return array|WP_Error Conversion result or error.
	 */
	public function convert( $html, $builder = 'auto', $options = array() ) {
		$defaults = array(
			'title'            => 'Imported Page',
			'status'           => 'draft',
			'preserve_tokens'  => false,
			'font_substitution' => 'closest',
			'responsive'       => true,
		);
		$options = wp_parse_args( $options, $defaults );

		// Size check.
		if ( strlen( $html ) > self::MAX_INPUT_SIZE ) {
			return new WP_Error(
				'respira_html_too_large',
				sprintf(
					__( 'HTML input exceeds %s limit.', 'respira-for-wordpress' ),
					size_format( self::MAX_INPUT_SIZE )
				),
				array( 'status' => 413 )
			);
		}

		// XSS sanitization (runs FIRST before any processing).
		$sanitize_result = $this->sanitize_input( $html );
		$html            = $sanitize_result['html'];
		$stripped        = $sanitize_result['stripped'];

		// Auto-detect builder.
		if ( 'auto' === $builder ) {
			$builder = $this->detect_builder();
		}

		// Load converter dependencies.
		$this->load_dependencies();

		// Step 1: Extract CSS.
		$css_extractor = new Respira_CSS_Extractor();
		$css_data      = $css_extractor->extract( $html );
		if ( is_wp_error( $css_data ) ) {
			return $css_data;
		}

		// Step 2: Map sections.
		$section_mapper = new Respira_Section_Mapper();
		$source_analysis = $section_mapper->map( $html );
		if ( is_wp_error( $source_analysis ) ) {
			return $source_analysis;
		}

		// Step 3: Map styles to builder settings.
		$style_mapper = new Respira_Style_Mapper();
		$sections     = isset( $source_analysis['sections'] ) ? $source_analysis['sections'] : array();
		$styled_sections = $this->apply_styles( $sections, $css_data, $style_mapper, $builder );

		// Step 4: Map responsive styles.
		$responsive_settings = array();
		if ( $options['responsive'] && ! empty( $css_data['media_queries'] ) ) {
			$responsive_settings = $style_mapper->map_responsive( $css_data['media_queries'], $builder );
		}

		// Step 4b: Extract source layout metrics for Elementor fidelity.
		if ( 'elementor' === $builder ) {
			$this->_source_container_width = $this->detect_container_max_width( $css_data );
		}

		// Step 5: Build the page.
		$builder_result = $this->build_page(
			$styled_sections,
			$builder,
			$options,
			$css_data,
			$responsive_settings,
			$html
		);
		if ( is_wp_error( $builder_result ) ) {
			return $builder_result;
		}

		// Add security stripped info.
		$builder_result['security_stripped'] = $stripped;
		$builder_result['responsive_mapped'] = ! empty( $responsive_settings );

		// Step 6: Fidelity check.
		$fidelity_checker = new Respira_Fidelity_Checker();
		$fidelity_report  = $fidelity_checker->check( $source_analysis, $builder_result, $css_data );

		return array(
			'success'     => true,
			'page_id'     => $builder_result['page_id'],
			'edit_url'    => $builder_result['edit_url'],
			'preview_url' => $builder_result['preview_url'],
			'fidelity'    => $fidelity_report,
			'_note'       => 'This is an intelligent import, not a pixel-perfect conversion. Review the fidelity report for details.',
		);
	}

	/**
	 * Sanitize HTML input — strip dangerous elements before any processing.
	 *
	 * @param string $html Raw HTML input.
	 * @return array {html: string, stripped: array}
	 */
	private function sanitize_input( $html ) {
		$stripped = array();

		// Strip dangerous tags.
		$dangerous_tags = array( 'script', 'object', 'embed', 'applet' );
		foreach ( $dangerous_tags as $tag ) {
			$count = 0;
			$html  = preg_replace( '/<' . $tag . '\b[^>]*>.*?<\/' . $tag . '>/si', '', $html, -1, $count );
			$html  = preg_replace( '/<' . $tag . '\b[^>]*\/?>/si', '', $html, -1, $count2 );
			$total = $count + $count2;
			if ( $total > 0 ) {
				$stripped[] = sprintf( '%d %s tag(s) removed', $total, $tag );
			}
		}

		// Note: <iframe> and <form> are preserved but neutered (converted to placeholders).
		// They may be relevant content (embedded videos, contact forms).
		$iframe_count = 0;
		preg_match_all( '/<iframe\b/i', $html, $iframe_matches );
		$iframe_count = count( $iframe_matches[0] );

		// Strip event handlers (onclick, onerror, onload, etc.).
		$handler_count = 0;
		$html = preg_replace_callback(
			'/\s+on\w+\s*=\s*["\'][^"\']*["\']/i',
			function () use ( &$handler_count ) {
				++$handler_count;
				return '';
			},
			$html
		);
		$html = preg_replace_callback(
			'/\s+on\w+\s*=\s*\S+/i',
			function () use ( &$handler_count ) {
				++$handler_count;
				return '';
			},
			$html
		);
		if ( $handler_count > 0 ) {
			$stripped[] = sprintf( '%d event handler(s) removed', $handler_count );
		}

		// Strip javascript: and data: URIs in href/src/action attributes.
		$uri_count = 0;
		$html = preg_replace_callback(
			'/(?:href|src|action)\s*=\s*["\']?\s*(?:javascript|data):/i',
			function () use ( &$uri_count ) {
				++$uri_count;
				return 'href="removed:';
			},
			$html
		);
		if ( $uri_count > 0 ) {
			$stripped[] = sprintf( '%d dangerous URI(s) removed', $uri_count );
		}

		return array(
			'html'     => $html,
			'stripped' => $stripped,
		);
	}

	/**
	 * Auto-detect the active page builder.
	 *
	 * @return string Builder slug.
	 */
	private function detect_builder() {
		if ( ! class_exists( 'Respira_Context' ) ) {
			return 'gutenberg';
		}

		$builder_info = Respira_Context::get_builder_info();
		if ( empty( $builder_info['builders'] ) ) {
			return 'gutenberg';
		}

		foreach ( $builder_info['builders'] as $name => $data ) {
			if ( ! empty( $data['detected'] ) ) {
				return strtolower( $name );
			}
		}

		return 'gutenberg';
	}

	/**
	 * Load HTML converter dependency classes.
	 */
	private function load_dependencies() {
		$dir = RESPIRA_PLUGIN_DIR . 'includes/html-converter/';
		require_once $dir . 'class-css-extractor.php';
		require_once $dir . 'class-section-mapper.php';
		require_once $dir . 'class-style-mapper.php';
		require_once $dir . 'class-fidelity-checker.php';
	}

	/**
	 * Apply CSS styles to mapped sections.
	 *
	 * @param array                $sections     Section mapper output.
	 * @param array                $css_data     CSS extractor output.
	 * @param Respira_Style_Mapper $style_mapper Style mapper instance.
	 * @param string               $builder      Builder slug.
	 * @return array Sections with builder settings applied.
	 */
	private function apply_styles( $sections, $css_data, $style_mapper, $builder ) {
		$element_styles = isset( $css_data['element_styles'] ) ? $css_data['element_styles'] : array();

		// Store tokens for inline style variable resolution.
		$this->_current_tokens = isset( $css_data['tokens'] ) ? $css_data['tokens'] : array();

		foreach ( $sections as &$section ) {
			$this->apply_styles_recursive( $section, $element_styles, $style_mapper, $builder );
		}

		return $sections;
	}

	/**
	 * Recursively apply styles to an element and its children.
	 *
	 * @param array                $element       Element data (by reference).
	 * @param array                $element_styles CSS element styles.
	 * @param Respira_Style_Mapper $style_mapper  Style mapper.
	 * @param string               $builder       Builder slug.
	 */
	private function apply_styles_recursive( &$element, $element_styles, $style_mapper, $builder ) {
		$matched_styles = $this->match_styles_for_element( $element, $element_styles );

		if ( ! empty( $matched_styles ) ) {
			$element_type = isset( $element['type'] ) ? $element['type'] : '';
			$result = $style_mapper->map_properties( $matched_styles, $builder, $element_type );
			$element['builder_settings'] = $result['settings'];
			$element['unmapped_css']     = $result['unmapped'];

			// Detect layout from CSS-matched styles (not just inline).
			if ( empty( $element['layout'] ) && in_array( $element_type, array( 'section', 'container' ), true ) ) {
				if ( isset( $matched_styles['display'] ) && 'flex' === $matched_styles['display'] ) {
					$dir = isset( $matched_styles['flex-direction'] ) ? $matched_styles['flex-direction'] : 'row';
					$element['layout'] = 'flex-' . $dir;
				} elseif ( isset( $matched_styles['display'] ) && 'grid' === $matched_styles['display'] ) {
					$element['layout'] = 'grid';
				}
			}
		}

		if ( ! empty( $element['children'] ) ) {
			foreach ( $element['children'] as &$child ) {
				$this->apply_styles_recursive( $child, $element_styles, $style_mapper, $builder );
			}
		}
	}

	/**
	 * Match CSS styles to an element based on its selectors.
	 *
	 * Supports: tag, .class, #id, tag.class, .class1.class2,
	 * and descendant selectors like '.parent .child', '.parent tag'.
	 *
	 * @param array $element        Element data.
	 * @param array $element_styles CSS selector → properties map.
	 * @return array Matched CSS properties.
	 */
	private function match_styles_for_element( $element, $element_styles ) {
		$matched = array();

		$tag     = isset( $element['tag'] ) ? strtolower( $element['tag'] ) : '';
		$classes = isset( $element['classes'] ) ? $element['classes'] : '';
		$id      = isset( $element['id'] ) ? $element['id'] : '';

		$class_list = ! empty( $classes ) ? preg_split( '/\s+/', $classes ) : array();

		foreach ( $element_styles as $selector => $props ) {
			// Skip inline style entries.
			if ( 0 === strpos( $selector, '_inline_' ) ) {
				continue;
			}

			if ( $this->selector_matches_element( $selector, $tag, $class_list, $id ) ) {
				$matched = array_merge( $matched, $props );
			}
		}

		// Match inline styles.
		if ( ! empty( $element['style'] ) ) {
			$inline_props = array();
			$parts = array_filter( array_map( 'trim', explode( ';', $element['style'] ) ) );
			foreach ( $parts as $part ) {
				$colon = strpos( $part, ':' );
				if ( false !== $colon ) {
					$prop = strtolower( trim( substr( $part, 0, $colon ) ) );
					$val  = trim( substr( $part, $colon + 1 ) );
					$inline_props[ $prop ] = $val;
				}
			}
			// Resolve CSS variables in inline styles too.
			if ( ! empty( $this->_current_tokens ) ) {
				$css_extractor = new Respira_CSS_Extractor();
				$inline_props = $css_extractor->resolve_variables( $inline_props, $this->_current_tokens );
			}
			$matched = array_merge( $matched, $inline_props );
		}

		return $matched;
	}

	/**
	 * Check if a CSS selector matches an element.
	 *
	 * Handles: tag, .class, #id, tag.class, .class1.class2.
	 * For descendant selectors (space-separated), matches the rightmost part
	 * against the element — a simplified heuristic that covers most real-world cases.
	 *
	 * @since 5.2.0
	 * @param string $selector   CSS selector string.
	 * @param string $tag        Element tag name.
	 * @param array  $class_list Element class list.
	 * @param string $id         Element ID.
	 * @return bool True if selector matches.
	 */
	private function selector_matches_element( $selector, $tag, $class_list, $id ) {
		$selector = trim( $selector );

		// Handle comma-separated selectors.
		if ( false !== strpos( $selector, ',' ) ) {
			$parts = explode( ',', $selector );
			foreach ( $parts as $part ) {
				if ( $this->selector_matches_element( trim( $part ), $tag, $class_list, $id ) ) {
					return true;
				}
			}
			return false;
		}

		// For descendant selectors, match against the rightmost part.
		if ( preg_match( '/\s/', $selector ) ) {
			$parts = preg_split( '/\s+/', $selector );
			$selector = end( $parts );
		}

		// Strip pseudo-classes and pseudo-elements.
		$selector = preg_replace( '/::?[\w-]+(\([^)]*\))?/', '', $selector );
		$selector = trim( $selector );

		if ( empty( $selector ) || '*' === $selector ) {
			return ! empty( $tag );
		}

		// Parse the simple selector: tag.class1.class2#id
		$sel_tag     = '';
		$sel_classes = array();
		$sel_id      = '';

		// Extract #id.
		if ( preg_match( '/#([\w-]+)/', $selector, $m ) ) {
			$sel_id   = $m[1];
			$selector = str_replace( $m[0], '', $selector );
		}

		// Extract .classes.
		if ( preg_match_all( '/\.([\w-]+)/', $selector, $m ) ) {
			$sel_classes = $m[1];
			$selector    = preg_replace( '/\.[\w-]+/', '', $selector );
		}

		// Remaining is the tag.
		$sel_tag = trim( $selector );

		// Match checks.
		if ( ! empty( $sel_tag ) && strtolower( $sel_tag ) !== $tag ) {
			return false;
		}
		if ( ! empty( $sel_id ) && $sel_id !== $id ) {
			return false;
		}
		foreach ( $sel_classes as $sc ) {
			if ( ! in_array( $sc, $class_list, true ) ) {
				return false;
			}
		}

		// At least one part must have been specified.
		return ! empty( $sel_tag ) || ! empty( $sel_classes ) || ! empty( $sel_id );
	}

	/**
	 * Build the actual WordPress page from processed sections.
	 *
	 * @param array  $sections            Styled sections.
	 * @param string $builder             Builder slug.
	 * @param array  $options             Conversion options.
	 * @param array  $css_data            CSS data.
	 * @param array  $responsive_settings Responsive settings.
	 * @param string $source_html         Original sanitized HTML input.
	 * @return array|WP_Error Build result.
	 */
	private function build_page( $sections, $builder, $options, $css_data, $responsive_settings, $source_html ) {
		// Create the post.
		$post_id = wp_insert_post(
			array(
				'post_title'  => sanitize_text_field( $options['title'] ),
				'post_status' => sanitize_key( $options['status'] ),
				'post_type'   => 'page',
				'post_content' => '',
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Convert sections to builder-native format.
		$builder_content = $this->sections_to_builder_content( $sections, $builder );

		if ( 'elementor' === $builder && is_array( $builder_content ) ) {
			$builder_content = $this->prepend_elementor_global_assets(
				$builder_content,
				$this->extract_presentational_head_assets( $source_html )
			);
		}

		// Track conversion stats.
		$section_count     = 0;
		$element_count     = 0;
		$html_fallback_count = 0;
		$sections_dropped  = array();
		$elements_dropped  = array();

		$this->count_conversion_stats(
			$sections,
			$section_count,
			$element_count,
			$html_fallback_count,
			$sections_dropped,
			$elements_dropped
		);

		// Inject content via the builder interface.
		$inject_result = $this->inject_via_builder( $post_id, $builder_content, $builder );
		if ( is_wp_error( $inject_result ) ) {
			wp_delete_post( $post_id, true );
			return $inject_result;
		}

		// Learning L2: Elementor imports must use the canvas template so the
		// page renders full-width without theme header/footer chrome. Also set
		// the template type so Elementor's editor recognises the page correctly.
		if ( 'elementor' === $builder ) {
			update_post_meta( $post_id, '_wp_page_template', 'elementor_canvas' );
			update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
		}

		// Create global tokens if requested.
		$tokens_mapped = array();
		if ( $options['preserve_tokens'] && ! empty( $css_data['tokens'] ) ) {
			$tokens_mapped = $this->create_global_tokens( $css_data['tokens'], $builder );
		}

		$edit_url    = get_edit_post_link( $post_id, 'raw' );
		$preview_url = get_preview_post_link( $post_id );

		return array(
			'page_id'             => $post_id,
			'edit_url'            => $edit_url ? $edit_url : admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
			'preview_url'         => $preview_url ? $preview_url : get_permalink( $post_id ) . '?preview=true',
			'section_count'       => $section_count,
			'element_count'       => $element_count,
			'html_fallback_count' => $html_fallback_count,
			'sections_dropped'    => $sections_dropped,
			'elements_dropped'    => $elements_dropped,
			'tokens_mapped'       => $tokens_mapped,
			'fonts_available'     => array(),
			'fonts_substituted'   => array(),
		);
	}

	/**
	 * Convert mapped sections to builder-native content structure.
	 *
	 * @param array  $sections Styled sections.
	 * @param string $builder  Builder slug.
	 * @return mixed Builder-specific content.
	 */
	private function sections_to_builder_content( $sections, $builder ) {
		// For Gutenberg, convert to block markup.
		if ( in_array( $builder, array( 'gutenberg', 'block-editor' ), true ) ) {
			return $this->sections_to_gutenberg( $sections );
		}

		// For other builders, produce a simplified structure that the builder
		// interface's inject_content() can consume.
		$simplified = $this->sections_to_simplified( $sections, $builder );

		// Beaver Builder requires row > column-group > column > module hierarchy.
		if ( in_array( $builder, array( 'beaver_builder', 'beaver builder' ), true ) ) {
			$simplified = $this->wrap_in_beaver_hierarchy( $simplified );
		}

		// Divi requires section > row > column > module hierarchy.
		if ( in_array( $builder, array( 'divi', 'divi5' ), true ) ) {
			$simplified = $this->ensure_divi_hierarchy( $simplified );
		}

		return $simplified;
	}

	/**
	 * Wrap flat elements in Beaver Builder row > column-group > column hierarchy.
	 *
	 * @since 5.2.0
	 * @param array $elements Flat simplified elements.
	 * @return array Elements wrapped in BB hierarchy.
	 */
	private function wrap_in_beaver_hierarchy( $elements ) {
		$structural = array( 'row', 'column-group', 'column' );
		$rows = array();

		foreach ( $elements as $element ) {
			$type = isset( $element['type'] ) ? $element['type'] : '';
			if ( 'row' === $type ) {
				$rows[] = $element;
			} elseif ( in_array( $type, $structural, true ) ) {
				$rows[] = $element;
			} else {
				// Wrap non-structural element in row > column-group > column.
				$rows[] = array(
					'type'     => 'row',
					'settings' => array(),
					'children' => array(
						array(
							'type'     => 'column-group',
							'settings' => array(),
							'children' => array(
								array(
									'type'     => 'column',
									'settings' => array( 'size' => '100' ),
									'children' => array( $element ),
								),
							),
						),
					),
				);
			}
		}

		return $rows;
	}

	/**
	 * Ensure Divi section > row > column > module hierarchy.
	 *
	 * Divi requires modules to be nested inside et_pb_column inside et_pb_row
	 * inside et_pb_section. This method walks the structure and wraps any
	 * modules that aren't properly nested.
	 *
	 * @since 5.2.0
	 * @param array $elements Simplified Divi elements.
	 * @return array Elements with proper Divi hierarchy.
	 */
	private function ensure_divi_hierarchy( $elements ) {
		$result = array();

		foreach ( $elements as $element ) {
			$type = isset( $element['type'] ) ? $element['type'] : '';

			if ( 'et_pb_section' === $type ) {
				// Section — ensure children are rows.
				$element['children'] = $this->ensure_divi_rows( isset( $element['children'] ) ? $element['children'] : array() );
				$result[] = $element;
			} elseif ( 'et_pb_row' === $type ) {
				// Row without section — wrap in section.
				$element['children'] = $this->ensure_divi_columns( isset( $element['children'] ) ? $element['children'] : array() );
				$result[] = array(
					'type'       => 'et_pb_section',
					'attributes' => array(),
					'children'   => array( $element ),
				);
			} else {
				// Module without section/row — wrap in full hierarchy.
				$result[] = array(
					'type'       => 'et_pb_section',
					'attributes' => array(),
					'children'   => array(
						array(
							'type'       => 'et_pb_row',
							'attributes' => array(),
							'children'   => array(
								array(
									'type'       => 'et_pb_column',
									'attributes' => array( 'type' => '4_4' ),
									'children'   => array( $element ),
								),
							),
						),
					),
				);
			}
		}

		return $result;
	}

	/**
	 * Ensure Divi section children are rows.
	 *
	 * @since 5.2.0
	 * @param array $children Section children.
	 * @return array Children wrapped as rows.
	 */
	private function ensure_divi_rows( $children ) {
		$rows = array();

		foreach ( $children as $child ) {
			$type = isset( $child['type'] ) ? $child['type'] : '';

			if ( 'et_pb_row' === $type ) {
				$child['children'] = $this->ensure_divi_columns( isset( $child['children'] ) ? $child['children'] : array() );
				$rows[] = $child;
			} else {
				// Not a row — wrap in row > column.
				$rows[] = array(
					'type'       => 'et_pb_row',
					'attributes' => array(),
					'children'   => array(
						array(
							'type'       => 'et_pb_column',
							'attributes' => array( 'type' => '4_4' ),
							'children'   => array( $child ),
						),
					),
				);
			}
		}

		return $rows;
	}

	/**
	 * Ensure Divi row children are columns.
	 *
	 * @since 5.2.0
	 * @param array $children Row children.
	 * @return array Children wrapped as columns.
	 */
	private function ensure_divi_columns( $children ) {
		$columns = array();

		foreach ( $children as $child ) {
			$type = isset( $child['type'] ) ? $child['type'] : '';

			if ( 'et_pb_column' === $type ) {
				$columns[] = $child;
			} else {
				// Not a column — wrap in column.
				$columns[] = array(
					'type'       => 'et_pb_column',
					'attributes' => array( 'type' => '4_4' ),
					'children'   => array( $child ),
				);
			}
		}

		return $columns;
	}

	/**
	 * Convert sections to Gutenberg block markup.
	 *
	 * @param array $sections Sections.
	 * @return string Block markup.
	 */
	private function sections_to_gutenberg( $sections ) {
		$blocks = '';

		foreach ( $sections as $section ) {
			$blocks .= $this->section_to_gutenberg_block( $section );
		}

		return $blocks;
	}

	/**
	 * Convert a single section/element to a Gutenberg block.
	 *
	 * @param array $element Element data.
	 * @return string Block markup.
	 */
	private function section_to_gutenberg_block( $element ) {
		$type = isset( $element['type'] ) ? $element['type'] : '';
		$content = isset( $element['content'] ) ? $element['content'] : array();
		$settings = isset( $element['builder_settings'] ) ? $element['builder_settings'] : array();

		switch ( $type ) {
			case 'heading':
				$text  = isset( $content['text'] ) ? esc_html( $content['text'] ) : '';
				$level = isset( $content['level'] ) ? $content['level'] : 2;
				$attrs = ! empty( $settings ) ? ' ' . wp_json_encode( $settings ) : '';
				return "<!-- wp:heading {\"level\":$level}$attrs -->\n<h$level>$text</h$level>\n<!-- /wp:heading -->\n\n";

			case 'text':
				$html = isset( $content['html'] ) ? $content['html'] : ( isset( $content['text'] ) ? '<p>' . esc_html( $content['text'] ) . '</p>' : '' );
				return "<!-- wp:paragraph -->\n$html\n<!-- /wp:paragraph -->\n\n";

			case 'image':
				$src = isset( $content['src'] ) ? esc_url( $content['src'] ) : '';
				$alt = isset( $content['alt'] ) ? esc_attr( $content['alt'] ) : '';
				return "<!-- wp:image -->\n<figure class=\"wp-block-image\"><img src=\"$src\" alt=\"$alt\"/></figure>\n<!-- /wp:image -->\n\n";

			case 'button':
				$text = isset( $content['text'] ) ? esc_html( $content['text'] ) : '';
				$href = isset( $content['href'] ) ? esc_url( $content['href'] ) : '#';
				return "<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"$href\">$text</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n";

			case 'divider':
				return "<!-- wp:separator -->\n<hr class=\"wp-block-separator\"/>\n<!-- /wp:separator -->\n\n";

			case 'list':
				$html = isset( $content['html'] ) ? $content['html'] : '';
				return "<!-- wp:list -->\n$html\n<!-- /wp:list -->\n\n";

			case 'section':
			case 'container':
				$inner = '';
				if ( ! empty( $element['children'] ) ) {
					foreach ( $element['children'] as $child ) {
						$inner .= $this->section_to_gutenberg_block( $child );
					}
				}
				return "<!-- wp:group -->\n<div class=\"wp-block-group\">\n$inner</div>\n<!-- /wp:group -->\n\n";

			case 'html_fallback':
				$html = isset( $element['html'] ) ? $element['html'] : '';
				return "<!-- wp:html -->\n$html\n<!-- /wp:html -->\n\n";

			default:
				// Unknown type — wrap in HTML block.
				if ( ! empty( $element['children'] ) ) {
					$inner = '';
					foreach ( $element['children'] as $child ) {
						$inner .= $this->section_to_gutenberg_block( $child );
					}
					return $inner;
				}
				$text = isset( $content['text'] ) ? $content['text'] : '';
				if ( ! empty( $text ) ) {
					return "<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->\n\n";
				}
				return '';
		}
	}

	/**
	 * Convert sections to a simplified builder structure.
	 *
	 * @param array  $sections Sections.
	 * @param string $builder  Builder slug.
	 * @return array Simplified structure.
	 */
	private function sections_to_simplified( $sections, $builder ) {
		$structure = array();

		foreach ( $sections as $section ) {
			$structure[] = $this->element_to_simplified( $section, $builder );
		}

		return $structure;
	}

	/**
	 * Convert a single element to simplified builder format.
	 *
	 * @param array  $element Element data.
	 * @param string $builder Builder slug.
	 * @return array Simplified element.
	 */
	private function element_to_simplified( $element, $builder ) {
		$type     = isset( $element['type'] ) ? $element['type'] : 'container';
		$content  = isset( $element['content'] ) ? $element['content'] : array();
		$settings = isset( $element['builder_settings'] ) ? $element['builder_settings'] : array();

		$builder_type = $this->map_type_to_builder( $type, $builder );

		// Each builder has a specific format for structural vs leaf elements,
		// and stores content in different settings/attribute keys.
		switch ( $builder ) {
			case 'elementor':
				$simplified = $this->build_elementor_simplified( $builder_type, $type, $content, $settings );
				break;

			case 'divi':
			case 'divi5':
				$simplified = $this->build_divi_simplified( $builder_type, $type, $content, $settings );
				break;

			case 'bricks':
				$simplified = $this->build_bricks_simplified( $builder_type, $type, $content, $settings );
				break;

			case 'beaver_builder':
			case 'beaver builder':
				$simplified = $this->build_beaver_simplified( $builder_type, $type, $content, $settings );
				break;

			case 'visual-composer':
			case 'visual_composer':
			case 'wpbakery':
				$simplified = $this->build_vc_simplified( $builder_type, $type, $content, $settings );
				break;

			default:
				$simplified = array(
					'type'     => $builder_type,
					'settings' => $settings,
				);
				if ( ! empty( $content ) ) {
					$simplified['content'] = $content;
				}
				break;
		}

		// Recurse into children using builder-specific children key.
		if ( ! empty( $element['children'] ) && $this->element_supports_builder_children( $builder, $simplified ) ) {
			$children_key = $this->get_builder_children_key( $builder );
			$layout       = isset( $element['layout'] ) ? $element['layout'] : null;

			// Multi-column layout detection for Elementor.
			if ( 'elementor' === $builder && in_array( $layout, array( 'flex-row', 'grid' ), true ) && count( $element['children'] ) > 1 ) {
				$simplified = $this->build_elementor_columns( $element, $simplified, $builder );
			} elseif ( in_array( $builder, array( 'beaver_builder', 'beaver builder' ), true ) && 'row' === $simplified['type'] && in_array( $layout, array( 'flex-row', 'grid' ), true ) && count( $element['children'] ) > 1 ) {
				// Multi-column layout for Beaver: row with flex children → column-group > columns.
				$simplified = $this->build_beaver_columns( $element, $simplified, $builder );
			} else {
				$simplified[ $children_key ] = array();
				foreach ( $element['children'] as $child ) {
					$simplified[ $children_key ][] = $this->element_to_simplified( $child, $builder );
				}
			}
		}

		return $simplified;
	}

	/**
	 * Build Elementor-specific simplified element.
	 *
	 * Elementor distinguishes structural elements (section, container, column)
	 * from widgets. Widgets must have type='widget' and a 'widget' key with
	 * the widget type. Content must be merged into settings using Elementor's
	 * native setting keys (e.g. 'title' for heading, 'editor' for text-editor).
	 *
	 * @since 5.2.0
	 * @param string $builder_type Mapped builder type.
	 * @param string $source_type  Original generic type.
	 * @param array  $content      Content data from section mapper.
	 * @param array  $settings     Builder settings from style mapper.
	 * @return array Elementor simplified element.
	 */
	private function build_elementor_simplified( $builder_type, $source_type, $content, $settings ) {
		$structural_types = array( 'section', 'container', 'column' );

		if ( in_array( $builder_type, $structural_types, true ) ) {
			$simplified = array(
				'type'     => $builder_type,
				'settings' => $settings,
			);
			// All structural elements need _column_size for Elementor's layout engine.
			if ( ! isset( $settings['_column_size'] ) ) {
				$simplified['settings']['_column_size'] = 100;
			}
			// Set background type if background_color is present.
			if ( isset( $settings['background_color'] ) && ! isset( $settings['background_background'] ) ) {
				$simplified['settings']['background_background'] = 'classic';
			}

			// Learning L3: Top-level sections should be boxed at the source's
			// container max-width so cards/grids don't stretch edge-to-edge.
			if ( 'section' === $builder_type && 'column' !== $source_type ) {
				if ( ! isset( $simplified['settings']['content_width'] ) ) {
					$simplified['settings']['content_width'] = array(
						'unit' => 'px',
						'size' => $this->_source_container_width,
					);
					$simplified['settings']['layout'] = 'boxed';
				}
			}

			// Learning L4: Flex/grid containers need stretch alignment
			// so child cards render at equal height.
			if ( isset( $settings['flex_direction'] ) || isset( $settings['display'] ) ) {
				$display   = isset( $settings['display'] ) ? $settings['display'] : '';
				$direction = isset( $settings['flex_direction'] ) ? $settings['flex_direction'] : 'row';
				if ( 'flex' === $display || 'grid' === $display || ! empty( $settings['flex_direction'] ) ) {
					$simplified['settings']['flex_align_items'] = 'stretch';
				}
			}

			return $simplified;
		}

		// Leaf widget — merge content into Elementor-native settings.
		$widget_settings = $this->merge_content_to_elementor_settings( $builder_type, $content, $settings );

		return array(
			'type'     => 'widget',
			'widget'   => $builder_type,
			'settings' => $widget_settings,
		);
	}

	/**
	 * Merge source content into Elementor widget settings.
	 *
	 * Each Elementor widget stores its content in specific setting keys:
	 * - heading: 'title', 'header_size'
	 * - text-editor: 'editor'
	 * - button: 'text', 'link' => ['url' => ...]
	 * - image: 'image' => ['url' => ...], 'image_size' => 'full'
	 * - video: 'youtube_url' or 'video_type' + url
	 * - icon-list: 'icon_list' array
	 * - divider: (no content keys needed)
	 * - html: 'html'
	 *
	 * @since 5.2.0
	 * @param string $widget_type Elementor widget type.
	 * @param array  $content     Source content.
	 * @param array  $settings    Existing builder settings.
	 * @return array Merged settings.
	 */
	/**
	 * Build Elementor column structure from a flex-row/grid container.
	 *
	 * Creates a section with columns, distributing children evenly.
	 * Each child becomes a column containing its own converted elements.
	 *
	 * @since 5.2.0
	 * @param array  $element    Original element with children and layout info.
	 * @param array  $simplified Current simplified element (section/container).
	 * @param string $builder    Builder slug.
	 * @return array Simplified element with column structure.
	 */
	private function build_elementor_columns( $element, $simplified, $builder ) {
		$children     = $element['children'];
		$child_count  = count( $children );
		$column_width = round( 100 / $child_count );

		// Ensure the parent is a section type.
		if ( ! in_array( $simplified['type'], array( 'section', 'container' ), true ) ) {
			$simplified['type'] = 'container';
		}

		// Set flex-row layout on container.
		if ( ! isset( $simplified['settings'] ) ) {
			$simplified['settings'] = array();
		}
		$simplified['settings']['flex_direction'] = 'row';
		$simplified['settings']['flex_wrap']       = 'wrap';

		// Learning L4: Equal-height children in flex grids.
		$simplified['settings']['flex_align_items'] = 'stretch';

		// Learning L6: Detect source CSS gap and map to Elementor column padding.
		// Elementor sections don't support CSS gap natively — instead, each column
		// gets left/right padding equal to half the source gap value.
		$source_gap = 24; // default gap matching common CSS grid/flex gap values.
		if ( isset( $element['builder_settings']['gap'] ) ) {
			$gap_val = $element['builder_settings']['gap'];
			if ( preg_match( '/(\d+)/', $gap_val, $m ) ) {
				$source_gap = (int) $m[1];
			}
		}
		$half_gap = max( 1, (int) floor( $source_gap / 2 ) );

		$columns = array();
		foreach ( $children as $child ) {
			$child_content = $this->element_to_simplified( $child, $builder );

			// If the child is already a structural element, use it as the column.
			if ( in_array( isset( $child_content['type'] ) ? $child_content['type'] : '', array( 'container', 'column' ), true ) ) {
				if ( ! isset( $child_content['settings']['_column_size'] ) ) {
					$child_content['settings']['_column_size'] = $column_width;
				}
				$columns[] = $child_content;
			} else {
				// Wrap in a column container with gap-derived padding (L6).
				$col_settings = array(
					'_column_size' => $column_width,
					'padding'      => array(
						'unit'     => 'px',
						'top'      => '0',
						'right'    => (string) $half_gap,
						'bottom'   => '0',
						'left'     => (string) $half_gap,
						'isLinked' => false,
					),
				);

				// Transfer background/padding from child if it's a container-like element.
				$child_builder_settings = isset( $element['children'][ count( $columns ) ]['builder_settings'] )
					? $element['children'][ count( $columns ) ]['builder_settings']
					: array();
				if ( ! empty( $child_builder_settings ) ) {
					$col_settings = array_merge( $col_settings, $child_builder_settings );
				}

				$columns[] = array(
					'type'     => 'container',
					'settings' => $col_settings,
					'elements' => array( $child_content ),
				);
			}
		}

		$simplified['elements'] = $columns;
		return $simplified;
	}

	private function merge_content_to_elementor_settings( $widget_type, $content, $settings ) {
		if ( is_string( $content ) && '' !== $content ) {
			$content = array( 'text' => $content );
		}
		if ( empty( $content ) || ! is_array( $content ) ) {
			return $settings;
		}

		switch ( $widget_type ) {
			case 'heading':
				if ( isset( $content['text'] ) ) {
					$settings['title'] = $content['text'];
				}
				if ( isset( $content['level'] ) ) {
					$settings['header_size'] = 'h' . intval( $content['level'] );
				}
				break;

			case 'text-editor':
				if ( isset( $content['html'] ) ) {
					$settings['editor'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$settings['editor'] = '<p>' . esc_html( $content['text'] ) . '</p>';
				}
				break;

			case 'button':
				if ( isset( $content['text'] ) ) {
					$settings['text'] = $content['text'];
				}
				if ( isset( $content['href'] ) ) {
					$settings['link'] = array( 'url' => $content['href'] );
				}
				break;

			case 'image':
				$src = isset( $content['src'] ) ? $content['src'] : '';
				if ( ! empty( $src ) ) {
					$settings['image'] = array(
						'url' => $src,
						'id'  => '',
					);
					$settings['image_size'] = 'full';
				}
				if ( isset( $content['alt'] ) ) {
					$settings['caption'] = $content['alt'];
				}
				break;

			case 'video':
				if ( isset( $content['src'] ) ) {
					$settings['youtube_url'] = $content['src'];
				}
				break;

			case 'html':
				if ( isset( $content['html'] ) ) {
					$settings['html'] = $content['html'];
				}
				break;

			case 'icon-list':
				if ( isset( $content['items'] ) && is_array( $content['items'] ) ) {
					$settings['icon_list'] = $content['items'];
				}
				break;
		}

		return $settings;
	}

	/**
	 * Build Divi-specific simplified element.
	 *
	 * Divi uses shortcode-style modules: et_pb_section, et_pb_row, et_pb_column
	 * for structure, and et_pb_text, et_pb_image, et_pb_button for content.
	 * Content goes into either 'content' (inner shortcode text) or 'attributes'.
	 *
	 * @since 5.2.0
	 * @param string $builder_type Mapped builder type (et_pb_* format).
	 * @param string $source_type  Original generic type.
	 * @param array  $content      Content data from section mapper.
	 * @param array  $settings     Builder settings from style mapper.
	 * @return array Divi simplified element.
	 */
	private function build_divi_simplified( $builder_type, $source_type, $content, $settings ) {
		$structural_types = array( 'et_pb_section', 'et_pb_row', 'et_pb_column' );

		$simplified = array(
			'type'       => $builder_type,
			'attributes' => $settings,
		);

		if ( in_array( $builder_type, $structural_types, true ) ) {
			// Rows need a default column structure.
			if ( 'et_pb_row' === $builder_type && ! isset( $settings['column_structure'] ) ) {
				$simplified['attributes']['column_structure'] = '4_4';
			}
			return $simplified;
		}

		// Leaf module — merge content into Divi-native attributes/content.
		$merged = $this->merge_content_to_divi( $builder_type, $content, $settings );
		$simplified['attributes'] = $merged['attributes'];
		if ( ! empty( $merged['content'] ) ) {
			$simplified['content'] = $merged['content'];
		}

		return $simplified;
	}

	/**
	 * Merge source content into Divi module attributes and content.
	 *
	 * Divi modules store text between shortcode tags (in 'content') and
	 * other settings as shortcode attributes. For example:
	 * [et_pb_text]<p>Hello</p>[/et_pb_text]
	 * [et_pb_button button_text="Click" button_url="#"]
	 *
	 * @since 5.2.0
	 * @param string $module_type Divi module type.
	 * @param array  $content     Source content.
	 * @param array  $attrs       Existing builder settings/attributes.
	 * @return array { attributes: array, content: string }
	 */
	private function merge_content_to_divi( $module_type, $content, $attrs ) {
		$inner_content = '';

		// Handle string content (bare text nodes from section mapper).
		if ( is_string( $content ) && '' !== $content ) {
			$content = array( 'text' => $content );
		}

		if ( ! empty( $content ) && is_array( $content ) ) {
			switch ( $module_type ) {
				case 'et_pb_text':
					if ( isset( $content['html'] ) ) {
						$inner_content = $content['html'];
					} elseif ( isset( $content['text'] ) ) {
						$level = isset( $content['level'] ) ? intval( $content['level'] ) : 0;
						if ( $level > 0 ) {
							$inner_content = '<h' . $level . '>' . esc_html( $content['text'] ) . '</h' . $level . '>';
						} else {
							$inner_content = '<p>' . esc_html( $content['text'] ) . '</p>';
						}
					}
					break;

				case 'et_pb_button':
					if ( isset( $content['text'] ) ) {
						$attrs['button_text'] = $content['text'];
					}
					if ( isset( $content['href'] ) ) {
						// Ensure URL is absolute for Divi validation.
						$url = $content['href'];
						if ( ! empty( $url ) && '#' !== $url && 0 !== strpos( $url, 'http' ) && 0 !== strpos( $url, '//' ) ) {
							$url = home_url( $url );
						}
						$attrs['button_url'] = $url;
					}
					break;

				case 'et_pb_image':
					if ( isset( $content['src'] ) ) {
						$attrs['src'] = $content['src'];
					}
					if ( isset( $content['alt'] ) ) {
						$attrs['alt'] = $content['alt'];
					}
					break;

				case 'et_pb_video':
					if ( isset( $content['src'] ) ) {
						$attrs['src'] = $content['src'];
					}
					break;

				case 'et_pb_divider':
					// No content keys needed.
					break;

				case 'et_pb_code':
					if ( isset( $content['html'] ) ) {
						$inner_content = $content['html'];
					}
					break;

				default:
					// Generic: put text/html into inner content.
					if ( isset( $content['html'] ) ) {
						$inner_content = $content['html'];
					} elseif ( isset( $content['text'] ) ) {
						$inner_content = esc_html( $content['text'] );
					}
					break;
			}
		}

		// Divi validator requires 'content' attribute on et_pb_text — ensure it's set.
		if ( 'et_pb_text' === $module_type ) {
			if ( '' === $inner_content ) {
				$inner_content = '<p>&nbsp;</p>';
			}
			// Divi validator checks attributes['content'], so put it there too.
			$attrs['content'] = $inner_content;
		}

		return array(
			'attributes' => $attrs,
			'content'    => $inner_content,
		);
	}

	/**
	 * Build Beaver Builder-specific simplified element.
	 *
	 * Beaver Builder uses a flat node map with row > column-group > column > module
	 * hierarchy. Modules store their type in settings.type and content in
	 * module-specific setting keys (e.g. 'heading' for heading, 'text' for
	 * rich-text, 'html' for html modules).
	 *
	 * @since 5.2.0
	 * @param string $builder_type Mapped builder type (heading, rich-text, photo, etc.).
	 * @param string $source_type  Original generic type from section mapper.
	 * @param array  $content      Content data from section mapper.
	 * @param array  $settings     Builder settings from style mapper.
	 * @return array Beaver Builder simplified element.
	 */
	private function build_beaver_simplified( $builder_type, $source_type, $content, $settings ) {
		// Structural types pass through — wrap_in_beaver_hierarchy handles positioning.
		if ( 'row' === $builder_type ) {
			return array(
				'type'     => 'row',
				'settings' => $settings,
			);
		}

		// Leaf module — merge content into Beaver module settings.
		$module_settings = $this->merge_content_to_beaver( $builder_type, $content, $settings );

		// Beaver modules carry their module type inside settings.type.
		$module_settings['type'] = $builder_type;

		return array(
			'type'     => 'module',
			'settings' => $module_settings,
		);
	}

	/**
	 * Build Beaver Builder column structure from a flex-row/grid container.
	 *
	 * Creates a row with column-group > columns, distributing children evenly.
	 * Each child becomes a column containing its converted module(s).
	 *
	 * @since 5.2.0
	 * @param array  $element    Original element with children and layout info.
	 * @param array  $simplified Current simplified row element.
	 * @param string $builder    Builder slug.
	 * @return array Row element with column-group and column children.
	 */
	private function build_beaver_columns( $element, $simplified, $builder ) {
		$children    = $element['children'];
		$child_count = count( $children );
		$col_size    = (string) round( 100 / $child_count );

		$columns = array();
		foreach ( $children as $child ) {
			$child_modules = array();
			// If the child itself has children, recursively convert them.
			if ( ! empty( $child['children'] ) ) {
				foreach ( $child['children'] as $grandchild ) {
					$child_modules[] = $this->element_to_simplified( $grandchild, $builder );
				}
			} else {
				$child_modules[] = $this->element_to_simplified( $child, $builder );
			}

			$columns[] = array(
				'type'     => 'column',
				'settings' => array( 'size' => $col_size ),
				'children' => $child_modules,
			);
		}

		$simplified['children'] = array(
			array(
				'type'     => 'column-group',
				'settings' => array(),
				'children' => $columns,
			),
		);

		return $simplified;
	}

	/**
	 * Merge source content into Beaver Builder module settings.
	 *
	 * Each BB module stores content in specific setting keys:
	 * - heading: 'heading' (text), 'tag' (h1-h6)
	 * - rich-text: 'text' (HTML content)
	 * - photo: 'photo_src' (URL), 'alt' (alt text)
	 * - button: 'text' (label), 'link' (URL)
	 * - video: 'link' (URL) or 'embed_code'
	 * - separator: 'style', 'height', 'color'
	 * - html: 'html' (raw HTML)
	 *
	 * @since 5.2.0
	 * @param string $module_type Beaver module type.
	 * @param array  $content     Source content from section mapper.
	 * @param array  $settings    Existing builder settings from style mapper.
	 * @return array Merged settings for the Beaver module.
	 */
	private function merge_content_to_beaver( $module_type, $content, $settings ) {
		if ( is_string( $content ) && '' !== $content ) {
			$content = array( 'text' => $content );
		}
		if ( empty( $content ) || ! is_array( $content ) ) {
			return $settings;
		}

		switch ( $module_type ) {
			case 'heading':
				if ( isset( $content['text'] ) ) {
					$settings['heading'] = $content['text'];
				}
				if ( isset( $content['level'] ) ) {
					$settings['tag'] = 'h' . intval( $content['level'] );
				} else {
					$settings['tag'] = 'h2';
				}
				break;

			case 'rich-text':
				if ( isset( $content['html'] ) ) {
					$settings['text'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$level = isset( $content['level'] ) ? intval( $content['level'] ) : 0;
					if ( $level > 0 ) {
						$settings['text'] = '<h' . $level . '>' . esc_html( $content['text'] ) . '</h' . $level . '>';
					} else {
						$settings['text'] = '<p>' . esc_html( $content['text'] ) . '</p>';
					}
				}
				break;

			case 'photo':
				if ( isset( $content['src'] ) ) {
					$settings['photo_src']    = $content['src'];
					$settings['photo_source'] = 'url';
				}
				if ( isset( $content['alt'] ) ) {
					$settings['alt'] = $content['alt'];
				}
				break;

			case 'button':
				if ( isset( $content['text'] ) ) {
					$settings['text'] = $content['text'];
				}
				if ( isset( $content['href'] ) ) {
					$settings['link'] = $content['href'];
				}
				break;

			case 'video':
				if ( isset( $content['src'] ) ) {
					$settings['link'] = $content['src'];
				}
				break;

			case 'separator':
				// Style settings come from the style mapper — no content keys.
				break;

			case 'html':
				if ( isset( $content['html'] ) ) {
					$settings['html'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$settings['html'] = esc_html( $content['text'] );
				}
				break;
		}

		return $settings;
	}

	/**
	 * Build Bricks-specific simplified element.
	 *
	 * Bricks uses a flat element list with parent references, but also supports
	 * nested children arrays. Content is stored in settings with element-specific
	 * keys (e.g. settings.text for headings and paragraphs).
	 *
	 * @since 5.2.0
	 * @param string $builder_type Mapped builder type.
	 * @param string $source_type  Original generic type.
	 * @param array  $content      Content data from section mapper.
	 * @param array  $settings     Builder settings from style mapper.
	 * @return array Bricks simplified element.
	 */
	private function build_bricks_simplified( $builder_type, $source_type, $content, $settings ) {
		$structural_types = array( 'section', 'container', 'block', 'div' );

		if ( in_array( $builder_type, $structural_types, true ) ) {
			return array(
				'type'     => $builder_type,
				'settings' => $settings,
			);
		}

		// Leaf element — merge content into Bricks-native settings.
		$settings = $this->merge_content_to_bricks_settings( $builder_type, $content, $settings );

		return array(
			'type'     => $builder_type,
			'settings' => $settings,
		);
	}

	/**
	 * Merge source content into Bricks element settings.
	 *
	 * Bricks stores content in settings with element-specific keys:
	 * - heading: settings.text + settings.tag
	 * - text: settings.text (rich HTML)
	 * - button: settings.text + settings.link (with url subkey)
	 * - image: settings.image (with url subkey)
	 * - code: settings.code
	 *
	 * @since 5.2.0
	 * @param string $element_type Bricks element type.
	 * @param array  $content      Source content.
	 * @param array  $settings     Existing builder settings.
	 * @return array Merged settings.
	 */
	private function merge_content_to_bricks_settings( $element_type, $content, $settings ) {
		if ( is_string( $content ) && '' !== $content ) {
			$content = array( 'text' => $content );
		}
		if ( empty( $content ) || ! is_array( $content ) ) {
			return $settings;
		}

		switch ( $element_type ) {
			case 'heading':
				if ( isset( $content['text'] ) ) {
					$settings['text'] = $content['text'];
				}
				if ( isset( $content['level'] ) ) {
					$settings['tag'] = 'h' . intval( $content['level'] );
				}
				break;

			case 'text':
				if ( isset( $content['html'] ) ) {
					$settings['text'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$settings['text'] = '<p>' . esc_html( $content['text'] ) . '</p>';
				}
				break;

			case 'button':
				if ( isset( $content['text'] ) ) {
					$settings['text'] = $content['text'];
				}
				if ( isset( $content['href'] ) ) {
					$settings['link'] = array( 'url' => $content['href'] );
				}
				break;

			case 'image':
				if ( isset( $content['src'] ) ) {
					$settings['image'] = array( 'url' => $content['src'] );
				}
				if ( isset( $content['alt'] ) ) {
					$settings['alt'] = $content['alt'];
				}
				break;

			case 'video':
				if ( isset( $content['src'] ) ) {
					$settings['video_url'] = $content['src'];
				}
				break;

			case 'code':
				if ( isset( $content['html'] ) ) {
					$settings['code'] = $content['html'];
				}
				break;

			default:
				if ( isset( $content['html'] ) ) {
					$settings['text'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$settings['text'] = $content['text'];
				}
				break;
		}

		return $settings;
	}

	/**
	 * Build Visual Composer (WPBakery)-specific simplified element.
	 *
	 * Visual Composer uses 'tag' for element type and 'attributes' for settings.
	 * Content can go into attributes (e.g. attributes.text) or as separate content.
	 * complexify_structure adds elementType, designOptions, customAttributes.
	 *
	 * @since 5.2.0
	 * @param string $builder_type Mapped builder type (VC tag name).
	 * @param string $source_type  Original generic type.
	 * @param array  $content      Content data from section mapper.
	 * @param array  $settings     Builder settings from style mapper.
	 * @return array VC simplified element.
	 */
	private function build_vc_simplified( $builder_type, $source_type, $content, $settings ) {
		$structural_types = array( 'row', 'column', 'section' );

		$simplified = array(
			'type'       => $builder_type,
			'attributes' => $settings,
		);

		if ( in_array( $builder_type, $structural_types, true ) ) {
			return $simplified;
		}

		// Leaf element — merge content into VC-native attributes.
		$simplified['attributes'] = $this->merge_content_to_vc_attributes( $builder_type, $content, $settings );

		return $simplified;
	}

	/**
	 * Merge source content into Visual Composer element attributes.
	 *
	 * VC widgets store content in attributes:
	 * - textBlock: attributes.text (rich HTML)
	 * - singleImage: attributes.image (URL or attachment ID)
	 * - rawHtml: attributes.rawHtml
	 * - separator: (no content needed)
	 *
	 * @since 5.2.0
	 * @param string $tag        VC element tag.
	 * @param array  $content    Source content.
	 * @param array  $attributes Existing builder settings/attributes.
	 * @return array Merged attributes.
	 */
	private function merge_content_to_vc_attributes( $tag, $content, $attributes ) {
		if ( is_string( $content ) && '' !== $content ) {
			$content = array( 'text' => $content );
		}
		if ( empty( $content ) || ! is_array( $content ) ) {
			return $attributes;
		}

		switch ( $tag ) {
			case 'textBlock':
				if ( isset( $content['html'] ) ) {
					$attributes['text'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$level = isset( $content['level'] ) ? intval( $content['level'] ) : 0;
					if ( $level > 0 ) {
						$attributes['text'] = '<h' . $level . '>' . esc_html( $content['text'] ) . '</h' . $level . '>';
					} else {
						$attributes['text'] = '<p>' . esc_html( $content['text'] ) . '</p>';
					}
				}
				break;

			case 'singleImage':
				if ( isset( $content['src'] ) ) {
					$attributes['image'] = $content['src'];
				}
				if ( isset( $content['alt'] ) ) {
					$attributes['alt'] = $content['alt'];
				}
				break;

			case 'rawHtml':
				if ( isset( $content['html'] ) ) {
					$attributes['rawHtml'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$attributes['rawHtml'] = esc_html( $content['text'] );
				}
				break;

			case 'separator':
				// No content keys needed.
				break;

			default:
				if ( isset( $content['html'] ) ) {
					$attributes['text'] = $content['html'];
				} elseif ( isset( $content['text'] ) ) {
					$attributes['text'] = esc_html( $content['text'] );
				}
				break;
		}

		return $attributes;
	}

	/**
	 * Get the children key for a specific builder.
	 *
	 * @since 5.2.0
	 * @param string $builder Builder slug.
	 * @return string Children key name.
	 */
	private function get_builder_children_key( $builder ) {
		if ( class_exists( 'Respira_Builder_Interface' ) ) {
			$instance = Respira_Builder_Interface::get_builder( $builder );
			if ( ! is_wp_error( $instance ) && method_exists( $instance, 'get_children_key' ) ) {
				return $instance->get_children_key();
			}
		}

		// Fallback defaults by builder slug.
		$key_map = array(
			'elementor'        => 'elements',
			'gutenberg'        => 'inner_blocks',
			'block-editor'     => 'inner_blocks',
			'beaver_builder'   => 'children',
			'beaver builder'   => 'children',
			'divi'             => 'children',
			'divi5'            => 'children',
			'bricks'           => 'children',
			'visual-composer'  => 'children',
			'visual_composer'  => 'children',
			'wpbakery'         => 'children',
		);

		return isset( $key_map[ $builder ] ) ? $key_map[ $builder ] : 'children';
	}

	/**
	 * Determine whether a simplified builder node may own child elements.
	 *
	 * Elementor widgets must remain leaf nodes; only structural nodes should
	 * receive nested `elements` arrays during HTML conversion.
	 *
	 * @since 5.2.1
	 * @param string $builder    Builder slug.
	 * @param array  $simplified Simplified builder node.
	 * @return bool
	 */
	private function element_supports_builder_children( $builder, $simplified ) {
		$type = isset( $simplified['type'] ) ? (string) $simplified['type'] : '';

		if ( 'elementor' === $builder ) {
			return in_array( $type, array( 'section', 'container', 'column' ), true );
		}

		// Beaver Builder: only structural types (row, column-group, column) hold children.
		if ( in_array( $builder, array( 'beaver_builder', 'beaver builder' ), true ) ) {
			return in_array( $type, array( 'row', 'column-group', 'column' ), true );
		}

		return true;
	}

	/**
	 * Map generic element type to builder-specific widget type.
	 *
	 * @param string $type    Generic type.
	 * @param string $builder Builder slug.
	 * @return string Builder-specific type.
	 */
	private function map_type_to_builder( $type, $builder ) {
		$elementor_map = array(
			'heading'   => 'heading',
			'text'      => 'text-editor',
			'image'     => 'image',
			'button'    => 'button',
			'video'     => 'video',
			'divider'   => 'divider',
			'list'      => 'icon-list',
			'form'      => 'form',
			'section'   => 'section',
			'container' => 'container',
			'table'     => 'html',
			'link'      => 'button',
			'leaf'      => 'text-editor',
		);

		$divi_map = array(
			'heading'       => 'et_pb_text',
			'text'          => 'et_pb_text',
			'image'         => 'et_pb_image',
			'button'        => 'et_pb_button',
			'video'         => 'et_pb_video',
			'divider'       => 'et_pb_divider',
			'list'          => 'et_pb_text',
			'form'          => 'et_pb_code',
			'section'       => 'et_pb_section',
			'container'     => 'et_pb_row',
			'table'         => 'et_pb_code',
			'link'          => 'et_pb_button',
			'leaf'          => 'et_pb_text',
			'html_fallback' => 'et_pb_code',
		);

		$bricks_map = array(
			'heading'       => 'heading',
			'text'          => 'text',
			'image'         => 'image',
			'button'        => 'button',
			'video'         => 'video',
			'divider'       => 'divider',
			'list'          => 'text',
			'form'          => 'code',
			'section'       => 'section',
			'container'     => 'container',
			'table'         => 'code',
			'link'          => 'button',
			'leaf'          => 'text',
			'html_fallback' => 'code',
		);

		$vc_map = array(
			'heading'       => 'textBlock',
			'text'          => 'textBlock',
			'image'         => 'singleImage',
			'button'        => 'textBlock',
			'video'         => 'rawHtml',
			'divider'       => 'separator',
			'list'          => 'textBlock',
			'form'          => 'rawHtml',
			'section'       => 'row',
			'container'     => 'column',
			'table'         => 'rawHtml',
			'link'          => 'textBlock',
			'leaf'          => 'textBlock',
			'html_fallback' => 'rawHtml',
		);

		if ( 'elementor' === $builder && isset( $elementor_map[ $type ] ) ) {
			return $elementor_map[ $type ];
		}
		if ( in_array( $builder, array( 'divi', 'divi5' ), true ) && isset( $divi_map[ $type ] ) ) {
			return $divi_map[ $type ];
		}
		if ( 'bricks' === $builder && isset( $bricks_map[ $type ] ) ) {
			return $bricks_map[ $type ];
		}
		if ( in_array( $builder, array( 'visual-composer', 'visual_composer', 'wpbakery' ), true ) && isset( $vc_map[ $type ] ) ) {
			return $vc_map[ $type ];
		}

		$beaver_map = array(
			'heading'       => 'heading',
			'text'          => 'rich-text',
			'image'         => 'photo',
			'button'        => 'button',
			'video'         => 'video',
			'divider'       => 'separator',
			'list'          => 'rich-text',
			'form'          => 'html',
			'section'       => 'row',
			'container'     => 'row',
			'table'         => 'html',
			'link'          => 'button',
			'leaf'          => 'rich-text',
			'html_fallback' => 'html',
		);

		if ( in_array( $builder, array( 'beaver_builder', 'beaver builder' ), true ) && isset( $beaver_map[ $type ] ) ) {
			return $beaver_map[ $type ];
		}

		return $type;
	}

	/**
	 * Inject content into a post via the active builder interface.
	 *
	 * @param int    $post_id         Post ID.
	 * @param mixed  $builder_content Builder-specific content.
	 * @param string $builder         Builder slug.
	 * @return true|WP_Error
	 */
	private function inject_via_builder( $post_id, $builder_content, $builder ) {
		// For Gutenberg, directly set post_content.
		if ( in_array( $builder, array( 'gutenberg', 'block-editor' ), true ) ) {
			$result = wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => $builder_content,
				),
				true
			);
			return is_wp_error( $result ) ? $result : true;
		}

		// For other builders, attempt to use the builder interface.
		if ( class_exists( 'Respira_Builder_Interface' ) ) {
			$builder_instance = Respira_Builder_Interface::get_builder( $builder );
			if ( ! is_wp_error( $builder_instance ) && method_exists( $builder_instance, 'inject_content' ) ) {
				$inject_result = $builder_instance->inject_content( $post_id, $builder_content );
				if ( is_wp_error( $inject_result ) ) {
					if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
						error_log( 'Respira HTML Converter: inject_content failed for ' . $builder . ': ' . $inject_result->get_error_message() );
					}
					return $inject_result;
				}
				return true;
			} elseif ( is_wp_error( $builder_instance ) ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( 'Respira HTML Converter: get_builder failed for ' . $builder . ': ' . $builder_instance->get_error_message() );
				}
			}
		}

		// Fallback: write Elementor meta directly if we know the builder.
		if ( 'elementor' === $builder && is_array( $builder_content ) ) {
			update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $builder_content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
			update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
			update_post_meta( $post_id, '_elementor_version', '3.0.0' );
			// Set template type.
			$existing = get_post_meta( $post_id, '_elementor_template_type', true );
			if ( empty( $existing ) ) {
				update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
			}
			// Use Elementor Canvas template for full-width rendering without theme chrome.
			update_post_meta( $post_id, '_wp_page_template', 'elementor_canvas' );
			return true;
		}

		// Generic fallback: set as post_content.
		if ( is_array( $builder_content ) ) {
			$builder_content = wp_json_encode( $builder_content );
		}

		$result = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_content' => $builder_content,
			),
			true
		);

		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Create global design tokens in the builder.
	 *
	 * @param array  $tokens  CSS custom properties.
	 * @param string $builder Builder slug.
	 * @return array Token names that were mapped.
	 */
	private function create_global_tokens( $tokens, $builder ) {
		$mapped = array();

		if ( class_exists( 'Respira_Builder_Interface' ) ) {
			$builder_instance = Respira_Builder_Interface::get_builder( $builder );
			if ( ! is_wp_error( $builder_instance ) && method_exists( $builder_instance, 'create_global_tokens' ) ) {
				$result = $builder_instance->create_global_tokens( $tokens );
				if ( is_array( $result ) ) {
					$mapped = $result;
				}
			}
		}

		return $mapped;
	}

	/**
	 * Extract presentational <head> assets that materially affect fidelity.
	 *
	 * Preserve inline <style> blocks and Google Fonts links so Elementor's native
	 * widget tree can still inherit the original document-level CSS and fonts.
	 *
	 * @since 5.2.1
	 * @param string $html Sanitized HTML document.
	 * @return string HTML markup for inclusion in an HTML widget.
	 */
	/**
	 * Detect the source document's primary container max-width from CSS.
	 *
	 * Scans for common container class selectors (.container, .wrapper,
	 * .content-width, .site-width, [class*="container"]) and returns the
	 * max-width value. Falls back to 1200px if not found.
	 *
	 * Learning: Elementor sections default to full-width, but source HTML
	 * almost always constrains content inside a centered container. Without
	 * mapping this, cards/grids stretch edge-to-edge and break visual fidelity.
	 *
	 * @since 5.2.2
	 * @param array $css_data Extracted CSS data from Respira_CSS_Extractor.
	 * @return int Container width in pixels.
	 */
	private function detect_container_max_width( $css_data ) {
		$container_selectors = array( '.container', '.wrapper', '.content-width', '.site-width', '.page-width' );
		$element_styles      = isset( $css_data['element_styles'] ) ? $css_data['element_styles'] : array();

		foreach ( $element_styles as $selector => $props ) {
			foreach ( $container_selectors as $pattern ) {
				if ( false !== strpos( $selector, $pattern ) && isset( $props['max-width'] ) ) {
					$val = $props['max-width'];
					if ( preg_match( '/(\d+)\s*px/i', $val, $m ) ) {
						return (int) $m[1];
					}
				}
			}
		}

		return 1200; // sensible default.
	}

	private function extract_presentational_head_assets( $html ) {
		if ( ! is_string( $html ) || '' === trim( $html ) ) {
			return '';
		}

		$assets = array();

		if ( preg_match_all( '/<link\b[^>]*href=["\'][^"\']*fonts\.(?:googleapis|gstatic)\.com[^"\']*["\'][^>]*>/i', $html, $link_matches ) ) {
			foreach ( $link_matches[0] as $link_tag ) {
				$link_tag = trim( $link_tag );
				if ( '' !== $link_tag ) {
					$assets[] = $link_tag;
				}
			}
		}

		if ( preg_match_all( '/<style\b[^>]*>.*?<\/style>/si', $html, $style_matches ) ) {
			foreach ( $style_matches[0] as $style_tag ) {
				$style_tag = trim( $style_tag );
				if ( '' !== $style_tag ) {
					$assets[] = $style_tag;
				}
			}
		}

		$assets = array_values( array_unique( $assets ) );

		return implode( "\n", $assets );
	}

	/**
	 * Prepend a non-visual Elementor container that carries document-level assets.
	 *
	 * This keeps the import editable as native Elementor content while preserving
	 * the source page's CSS variables, utility classes, and Google Fonts links.
	 *
	 * @since 5.2.1
	 * @param array  $builder_content Native Elementor document array.
	 * @param string $assets_markup   HTML markup for the assets widget.
	 * @return array
	 */
	private function prepend_elementor_global_assets( $builder_content, $assets_markup ) {
		if ( empty( $builder_content ) || ! is_array( $builder_content ) ) {
			return $builder_content;
		}

		$assets_markup = is_string( $assets_markup ) ? trim( $assets_markup ) : '';
		if ( '' === $assets_markup ) {
			return $builder_content;
		}

		// Learning L5/L7/L8: Inject Elementor-specific CSS overrides that improve
		// fidelity for common patterns: widget overflow for navbars, ensure
		// CSS hover transitions from source styles aren't blocked by Elementor
		// defaults, and neutralize theme heading color overrides that would
		// override the source document's color scheme.
		$elementor_overrides = '<style>'
			. '.elementor-widget-text-editor .elementor-widget-container{overflow:visible}'
			. '.elementor-widget .elementor-widget-container *{transition-property:inherit}'
			// L8: Theme heading neutralization — Elementor themes (Hello, Astra, etc.)
			// set their own heading colors that override the source CSS. We reset headings
			// to inherit color from the source document's styles.
			. '.elementor-widget-text-editor h1,.elementor-widget-text-editor h2,'
			. '.elementor-widget-text-editor h3,.elementor-widget-text-editor h4,'
			. '.elementor-widget-text-editor h5,.elementor-widget-text-editor h6'
			. '{color:inherit!important}'
			. '.elementor-widget-text-editor a{color:inherit;text-decoration:none}'
			. '</style>';
		$assets_markup = $elementor_overrides . "\n" . $assets_markup;

		$assets_container = array(
			'id'      => uniqid( 'respira_' ),
			'elType'  => 'container',
			'settings' => array(
				'_column_size' => 100,
				'padding'      => array(
					'unit'     => 'px',
					'isLinked' => false,
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
				),
				'margin'       => array(
					'unit'     => 'px',
					'isLinked' => false,
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
				),
				'gap'          => '0',
			),
			'isInner' => false,
			'elements' => array(
				array(
					'id'         => uniqid( 'respira_' ),
					'elType'     => 'widget',
					'widgetType' => 'html',
					'settings'   => array(
						'html' => $assets_markup,
					),
					'isInner'    => false,
				),
			),
		);

		array_unshift( $builder_content, $assets_container );

		return $builder_content;
	}

	/**
	 * Count conversion statistics recursively.
	 *
	 * @param array $sections           Sections to count.
	 * @param int   $section_count      Running section count (by ref).
	 * @param int   $element_count      Running element count (by ref).
	 * @param int   $html_fallback_count Running fallback count (by ref).
	 * @param array $sections_dropped   Dropped section names (by ref).
	 * @param array $elements_dropped   Dropped element data (by ref).
	 */
	private function count_conversion_stats( $sections, &$section_count, &$element_count, &$html_fallback_count, &$sections_dropped, &$elements_dropped ) {
		foreach ( $sections as $section ) {
			$type = isset( $section['type'] ) ? $section['type'] : '';

			if ( in_array( $type, array( 'section', 'container' ), true ) ) {
				++$section_count;
			}

			++$element_count;

			if ( 'html_fallback' === $type ) {
				++$html_fallback_count;
				$reason = isset( $section['reason'] ) ? $section['reason'] : 'Unknown';
				$elements_dropped[] = array(
					'type'   => isset( $section['tag'] ) ? $section['tag'] : 'unknown',
					'reason' => $reason,
				);
			}

			if ( ! empty( $section['children'] ) ) {
				$this->count_conversion_stats(
					$section['children'],
					$section_count,
					$element_count,
					$html_fallback_count,
					$sections_dropped,
					$elements_dropped
				);
			}
		}
	}

	/**
	 * Register REST endpoint for HTML conversion.
	 */
	public static function register_rest_routes() {
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/convert',
			array(
				'methods'             => 'POST',
				'callback'            => array( new self(), 'handle_convert_request' ),
				'permission_callback' => function ( $request ) {
					$api = new Respira_API();
					return $api->api_key_permission_check( $request );
				},
				'args'                => array(
					'html'    => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => function ( $value ) {
							return $value; // Raw — sanitized internally.
						},
					),
					'builder' => array(
						'required' => false,
						'type'     => 'string',
						'default'  => 'auto',
					),
					'options' => array(
						'required' => false,
						'type'     => 'object',
						'default'  => array(),
					),
				),
			)
		);
	}

	/**
	 * Handle the REST API convert request.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_convert_request( $request ) {
		$html    = $request->get_param( 'html' );
		$builder = $request->get_param( 'builder' );
		$options = $request->get_param( 'options' );

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$result = $this->convert( $html, $builder, $options );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $result );
	}
}
