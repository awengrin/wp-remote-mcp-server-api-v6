<?php
/**
 * Elementor Dynamic Schema Generator.
 *
 * Reads Elementor's control registry at runtime and maps control types
 * to JSON Schema types. Caches results in transients (12hr TTL) and
 * invalidates on Elementor version change.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/elementor-intelligence
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Dynamic schema generator for Elementor widgets.
 *
 * @since 5.2.0
 */
class Respira_Elementor_Schema_Generator {

	/**
	 * Transient cache TTL in seconds (12 hours).
	 *
	 * @var int
	 */
	const CACHE_TTL = 43200;

	/**
	 * Transient key prefix.
	 *
	 * @var string
	 */
	const CACHE_PREFIX = 'respira_elem_schema_';

	/**
	 * Allowed responsive suffixes.
	 *
	 * @since 5.2.0
	 * @var array
	 */
	const RESPONSIVE_SUFFIXES = array( '_mobile', '_tablet', '_widescreen' );

	/**
	 * Map of Elementor control types to JSON Schema types.
	 *
	 * @since 5.2.0
	 * @var array
	 */
	private static $control_type_map = array(
		// String types.
		'text'            => array( 'type' => 'string' ),
		'textarea'        => array( 'type' => 'string' ),
		'wysiwyg'         => array( 'type' => 'string', 'format' => 'html' ),
		'code'            => array( 'type' => 'string', 'format' => 'code' ),
		'hidden'          => array( 'type' => 'string' ),
		'raw_html'        => array( 'type' => 'string', 'format' => 'html' ),

		// Number types.
		'number'          => array( 'type' => 'number' ),
		'slider'          => array( 'type' => 'number' ),

		// Select/enum types.
		'select'          => array( 'type' => 'string', 'has_enum' => true ),
		'select2'         => array( 'type' => 'string', 'has_enum' => true ),
		'choose'          => array( 'type' => 'string', 'has_enum' => true ),

		// Boolean types.
		'switcher'        => array( 'type' => 'boolean' ),

		// Color types.
		'color'           => array( 'type' => 'string', 'format' => 'color' ),

		// Media types.
		'media'           => array(
			'type'       => 'object',
			'properties' => array(
				'url' => array( 'type' => 'string', 'format' => 'uri' ),
				'id'  => array( 'type' => 'integer' ),
			),
		),
		'gallery'         => array(
			'type'  => 'array',
			'items' => array(
				'type'       => 'object',
				'properties' => array(
					'id'  => array( 'type' => 'integer' ),
					'url' => array( 'type' => 'string', 'format' => 'uri' ),
				),
			),
		),

		// URL type.
		'url'             => array(
			'type'       => 'object',
			'properties' => array(
				'url'         => array( 'type' => 'string', 'format' => 'uri' ),
				'is_external' => array( 'type' => 'string' ),
				'nofollow'    => array( 'type' => 'string' ),
			),
		),

		// Dimensions type.
		'dimensions'      => array(
			'type'       => 'object',
			'properties' => array(
				'top'      => array( 'type' => 'string' ),
				'right'    => array( 'type' => 'string' ),
				'bottom'   => array( 'type' => 'string' ),
				'left'     => array( 'type' => 'string' ),
				'unit'     => array( 'type' => 'string', 'enum' => array( 'px', 'em', '%', 'rem' ) ),
				'isLinked' => array( 'type' => 'boolean' ),
			),
		),

		// Icon type.
		'icons'           => array(
			'type'       => 'object',
			'properties' => array(
				'value'   => array( 'type' => 'string' ),
				'library' => array( 'type' => 'string' ),
			),
		),

		// Font type.
		'font'            => array( 'type' => 'string' ),

		// Date/time type.
		'date_time'       => array( 'type' => 'string', 'format' => 'date-time' ),

		// Repeater type.
		'repeater'        => array( 'type' => 'array' ),

		// Popover/Group type.
		'popover_toggle'  => array( 'type' => 'string' ),

		// Shadow types.
		'box_shadow'      => array(
			'type'       => 'object',
			'properties' => array(
				'horizontal' => array( 'type' => 'number' ),
				'vertical'   => array( 'type' => 'number' ),
				'blur'       => array( 'type' => 'number' ),
				'spread'     => array( 'type' => 'number' ),
				'color'      => array( 'type' => 'string', 'format' => 'color' ),
				'position'   => array( 'type' => 'string', 'enum' => array( '', 'inset' ) ),
			),
		),
		'text_shadow'     => array(
			'type'       => 'object',
			'properties' => array(
				'horizontal' => array( 'type' => 'number' ),
				'vertical'   => array( 'type' => 'number' ),
				'blur'       => array( 'type' => 'number' ),
				'color'      => array( 'type' => 'string', 'format' => 'color' ),
			),
		),
	);

	/**
	 * Generate a JSON Schema for a specific Elementor widget.
	 *
	 * @since 5.2.0
	 * @param string $widget_name Widget name (e.g., 'heading', 'button').
	 * @return array|null JSON Schema array or null if widget not found.
	 */
	public static function generate_widget_schema( $widget_name ) {
		// Check cache.
		$cache_key = self::CACHE_PREFIX . $widget_name . '_' . self::get_cache_version();
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		// Get controls from Elementor registry.
		if ( ! class_exists( 'Respira_Elementor_Widget_Registry' ) ) {
			return null;
		}

		$controls = Respira_Elementor_Widget_Registry::get_widget_controls( $widget_name );
		if ( false === $controls || empty( $controls ) ) {
			return null;
		}

		$schema = array(
			'widget'     => $widget_name,
			'properties' => array(),
		);

		foreach ( $controls as $control_id => $control_def ) {
			$control_type = strtolower( $control_def['type'] ?? 'text' );
			$property     = self::map_control_to_schema( $control_type, $control_def );

			if ( null === $property ) {
				// Unknown control type — map to string and log warning.
				$property = array( 'type' => 'string' );
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( sprintf( 'Respira: Unknown Elementor control type "%s" for widget "%s" control "%s". Mapped to string.', $control_type, $widget_name, $control_id ) );
				}
			}

			// Add label/description.
			if ( isset( $control_def['label'] ) ) {
				$property['description'] = $control_def['label'];
			}

			// Add default value.
			if ( isset( $control_def['default'] ) ) {
				$property['default'] = $control_def['default'];
			}

			$schema['properties'][ $control_id ] = $property;
		}

		// Cache for 12 hours.
		set_transient( $cache_key, $schema, self::CACHE_TTL );

		return $schema;
	}

	/**
	 * Generate schemas for multiple widgets (batch).
	 *
	 * @since 5.2.0
	 * @param array $widget_names Array of widget names.
	 * @return array Map of widget_name => schema.
	 */
	public static function generate_batch( $widget_names ) {
		$schemas = array();
		foreach ( $widget_names as $name ) {
			$schema = self::generate_widget_schema( $name );
			if ( null !== $schema ) {
				$schemas[ $name ] = $schema;
			}
		}
		return $schemas;
	}

	/**
	 * Map an Elementor control type to a JSON Schema property definition.
	 *
	 * @since 5.2.0
	 * @param string $control_type Elementor control type (lowercase).
	 * @param array  $control_def  Full control definition from Elementor.
	 * @return array|null JSON Schema property or null for unknown types.
	 */
	private static function map_control_to_schema( $control_type, $control_def ) {
		if ( ! isset( self::$control_type_map[ $control_type ] ) ) {
			return null;
		}

		$schema = self::$control_type_map[ $control_type ];

		// Remove internal flags.
		unset( $schema['has_enum'] );

		// Handle enum types (select, choose).
		if ( isset( self::$control_type_map[ $control_type ]['has_enum'] ) ) {
			if ( isset( $control_def['options'] ) && is_array( $control_def['options'] ) ) {
				$schema['enum'] = array_keys( $control_def['options'] );
			}
		}

		// Handle slider min/max.
		if ( 'slider' === $control_type || 'number' === $control_type ) {
			$range = $control_def['range'] ?? $control_def;
			if ( isset( $range['min'] ) ) {
				$schema['minimum'] = $range['min'];
			}
			if ( isset( $range['max'] ) ) {
				$schema['maximum'] = $range['max'];
			}
			// Slider has size sub-ranges.
			if ( 'slider' === $control_type && isset( $control_def['range'] ) ) {
				$schema['units'] = array_keys( $control_def['range'] );
			}
		}

		// Handle repeater with field schemas.
		if ( 'repeater' === $control_type && isset( $control_def['fields'] ) ) {
			$items = array(
				'type'       => 'object',
				'properties' => array(),
			);
			foreach ( $control_def['fields'] as $field_id => $field_def ) {
				$field_type = strtolower( $field_def['type'] ?? 'text' );
				$field_schema = self::map_control_to_schema( $field_type, $field_def );
				if ( null !== $field_schema ) {
					$items['properties'][ $field_id ] = $field_schema;
				}
			}
			$schema['items'] = $items;
		}

		return $schema;
	}

	/**
	 * Strip a responsive suffix from a control name.
	 *
	 * @since 5.2.0
	 * @param string $control_name Control name possibly with suffix.
	 * @return array {base_name: string, suffix: string|null}
	 */
	public static function parse_responsive_name( $control_name ) {
		foreach ( self::RESPONSIVE_SUFFIXES as $suffix ) {
			if ( substr( $control_name, -strlen( $suffix ) ) === $suffix ) {
				return array(
					'base_name' => substr( $control_name, 0, -strlen( $suffix ) ),
					'suffix'    => $suffix,
				);
			}
		}

		return array(
			'base_name' => $control_name,
			'suffix'    => null,
		);
	}

	/**
	 * Check if a suffix is a valid responsive suffix.
	 *
	 * @since 5.2.0
	 * @param string $suffix Suffix to check.
	 * @return bool
	 */
	public static function is_valid_responsive_suffix( $suffix ) {
		return in_array( $suffix, self::RESPONSIVE_SUFFIXES, true );
	}

	/**
	 * Get cache version key (changes when Elementor version changes).
	 *
	 * @since 5.2.0
	 * @return string Version hash for cache key.
	 */
	private static function get_cache_version() {
		$elementor_version = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : 'none';
		$plugin_version    = defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '0.0.0';
		return substr( md5( $elementor_version . $plugin_version ), 0, 8 );
	}

	/**
	 * Clear all generated schema caches.
	 *
	 * @since 5.2.0
	 */
	public static function clear_cache() {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::CACHE_PREFIX ) . '%'
			)
		);
	}
}
