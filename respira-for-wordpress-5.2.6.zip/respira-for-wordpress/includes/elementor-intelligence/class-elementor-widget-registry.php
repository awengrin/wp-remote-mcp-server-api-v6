<?php
/**
 * Elementor widget registry.
 *
 * Dynamic widget detection from Elementor's registry.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/page-builders/elementor-intelligence
 * @since      1.3.0
 */

/**
 * Elementor widget registry class.
 *
 * @since 1.3.0
 */
class Respira_Elementor_Widget_Registry {

	/**
	 * Get all registered widgets with metadata.
	 *
	 * @since  1.3.0
	 * @return array Array of widget information.
	 */
	public static function get_all_widgets() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return array();
		}

		// Check cache version to invalidate old caches (pre-1.8.19 had controls in cache).
		$cache_version = get_option( 'respira_elementor_widgets_cache_version', '0' );
		$current_version = defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '1.8.19';
		
		// If cache version doesn't match or is older than 1.8.19, clear it.
		if ( version_compare( $cache_version, '1.8.19', '<' ) ) {
			delete_transient( 'respira_elementor_widgets' );
			update_option( 'respira_elementor_widgets_cache_version', $current_version );
		}

		// Check cache first.
		$cached = get_transient( 'respira_elementor_widgets' );
		if ( false !== $cached ) {
			// Validate cached data structure - if it has 'controls' key, it's old format.
			if ( isset( $cached[0]['controls'] ) && ! empty( $cached[0]['controls'] ) ) {
				// Old cache format detected - clear it.
				delete_transient( 'respira_elementor_widgets' );
				$cached = false;
			} else {
				return $cached;
			}
		}

		$widgets_manager = \Elementor\Plugin::$instance->widgets_manager;
		$widget_types    = $widgets_manager->get_widget_types();

		$widget_list = array();

		foreach ( $widget_types as $widget_type ) {
			$widget_info = array(
				'name'         => $widget_type->get_name(),
				'title'        => $widget_type->get_title(),
				'icon'         => $widget_type->get_icon(),
				'categories'   => $widget_type->get_categories(),
				'keywords'     => $widget_type->get_keywords(),
			);

			$widget_list[] = $widget_info;
		}

		// Cache for 24 hours.
		set_transient( 'respira_elementor_widgets', $widget_list, DAY_IN_SECONDS );

		return $widget_list;
	}

	/**
	 * Get widget by name.
	 *
	 * @since  1.3.0
	 * @param  string $widget_name Widget name.
	 * @return array|null Widget information or null if not found.
	 */
	public static function get_widget( $widget_name ) {
		$widgets = self::get_all_widgets();

		foreach ( $widgets as $widget ) {
			if ( $widget['name'] === $widget_name ) {
				return $widget;
			}
		}

		return null;
	}

	/**
	 * Get widgets by category.
	 *
	 * @since  1.3.0
	 * @param  string $category Category name.
	 * @return array Widgets in category.
	 */
	public static function get_widgets_by_category( $category ) {
		$widgets = self::get_all_widgets();

		return array_filter(
			$widgets,
			function( $widget ) use ( $category ) {
				return in_array( $category, $widget['categories'], true );
			}
		);
	}

	/**
	 * Get widget controls on-demand (not cached).
	 *
	 * Loads controls only when needed, preventing memory exhaustion from caching
	 * all widget controls at once.
	 *
	 * @since  1.8.19
	 * @param  string $widget_name Widget name.
	 * @return array|false Widget controls or false on error.
	 */
	public static function get_widget_controls( $widget_name ) {
		// Try to get widget type and load controls.
		try {
			if ( ! class_exists( '\Elementor\Plugin' ) ) {
				return false;
			}

			$widgets_manager = \Elementor\Plugin::$instance->widgets_manager;
			$widget_types = $widgets_manager->get_widget_types();
			
			// Find the specific widget type.
			$widget_type = null;
			foreach ( $widget_types as $type ) {
				if ( $type->get_name() === $widget_name ) {
					$widget_type = $type;
					break;
				}
			}

			if ( ! $widget_type || ! method_exists( $widget_type, 'get_controls' ) ) {
				return false;
			}

			return $widget_type->get_controls();
		} catch ( Exception $e ) {
			// Log error but don't break the flow.
			error_log( 'Respira: Failed to load controls for widget ' . $widget_name . ': ' . $e->getMessage() );
			return false;
		} catch ( Error $e ) {
			// Catch fatal errors (PHP 7+).
			error_log( 'Respira: Fatal error loading controls for widget ' . $widget_name . ': ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Clear widget cache.
	 *
	 * @since 1.3.0
	 */
	public static function clear_cache() {
		delete_transient( 'respira_elementor_widgets' );
	}
}

