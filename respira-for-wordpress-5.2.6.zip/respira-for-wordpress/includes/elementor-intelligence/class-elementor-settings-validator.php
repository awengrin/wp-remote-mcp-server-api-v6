<?php
/**
 * Elementor Settings Validator.
 *
 * Validates widget settings against dynamic schemas before save.
 * Accepts responsive suffixes and returns actionable error messages
 * including "did you mean?" suggestions for unknown settings.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes/elementor-intelligence
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Elementor settings validator class.
 *
 * @since 5.2.0
 */
class Respira_Elementor_Settings_Validator {

	/**
	 * Validate widget settings against the dynamic schema.
	 *
	 * @since 5.2.0
	 * @param string $widget_name Widget name (e.g., 'heading').
	 * @param array  $settings    Settings to validate.
	 * @return array {valid: bool, errors: string[], warnings: string[]}
	 */
	public static function validate( $widget_name, $settings ) {
		$errors   = array();
		$warnings = array();

		if ( ! class_exists( 'Respira_Elementor_Schema_Generator' ) ) {
			return array(
				'valid'    => true,
				'errors'   => array(),
				'warnings' => array( 'Schema generator not available — skipping validation.' ),
			);
		}

		$schema = Respira_Elementor_Schema_Generator::generate_widget_schema( $widget_name );
		if ( null === $schema ) {
			return array(
				'valid'    => true,
				'errors'   => array(),
				'warnings' => array( sprintf( 'No schema available for widget "%s" — skipping validation.', $widget_name ) ),
			);
		}

		$known_properties = array_keys( $schema['properties'] );

		foreach ( $settings as $setting_name => $setting_value ) {
			// Parse responsive suffix.
			$parsed    = Respira_Elementor_Schema_Generator::parse_responsive_name( $setting_name );
			$base_name = $parsed['base_name'];
			$suffix    = $parsed['suffix'];

			// If there's a suffix that's not in the allowed list, strip and warn.
			if ( null !== $suffix && ! Respira_Elementor_Schema_Generator::is_valid_responsive_suffix( $suffix ) ) {
				$warnings[] = sprintf(
					'Unknown responsive suffix "%s" on setting "%s". Valid suffixes: %s.',
					$suffix,
					$setting_name,
					implode( ', ', Respira_Elementor_Schema_Generator::RESPONSIVE_SUFFIXES )
				);
				continue;
			}

			// Check if the base setting name exists in schema.
			if ( ! isset( $schema['properties'][ $base_name ] ) ) {
				// Skip internal Elementor settings (prefixed with _).
				if ( strpos( $base_name, '_' ) === 0 ) {
					continue;
				}

				// Try to find a close match for "did you mean?" suggestion.
				$suggestion = self::find_closest_match( $base_name, $known_properties );
				if ( $suggestion ) {
					$errors[] = sprintf(
						'Unknown setting "%s" for %s widget. Did you mean "%s"?',
						$setting_name,
						$widget_name,
						$suggestion
					);
				} else {
					$warnings[] = sprintf(
						'Unknown setting "%s" for %s widget. It may be a dynamic or third-party setting.',
						$setting_name,
						$widget_name
					);
				}
				continue;
			}

			// Validate the value against the schema property.
			$property = $schema['properties'][ $base_name ];
			$value_errors = self::validate_value( $setting_name, $setting_value, $property, $widget_name );
			$errors = array_merge( $errors, $value_errors );
		}

		return array(
			'valid'    => empty( $errors ),
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Validate a single setting value against its schema property.
	 *
	 * @since 5.2.0
	 * @param string $name        Setting name.
	 * @param mixed  $value       Setting value.
	 * @param array  $property    JSON Schema property definition.
	 * @param string $widget_name Widget name for error messages.
	 * @return array Error messages (empty if valid).
	 */
	private static function validate_value( $name, $value, $property, $widget_name ) {
		$errors = array();
		$type   = $property['type'] ?? 'string';

		// Type validation.
		switch ( $type ) {
			case 'number':
				if ( ! is_numeric( $value ) && '' !== $value ) {
					$errors[] = sprintf(
						'Setting "%s" for %s must be a number, got "%s".',
						$name,
						$widget_name,
						gettype( $value )
					);
					break;
				}
				// Min/max validation.
				if ( is_numeric( $value ) ) {
					if ( isset( $property['minimum'] ) && (float) $value < $property['minimum'] ) {
						$errors[] = sprintf(
							'Setting "%s" for %s must be >= %s, got %s.',
							$name,
							$widget_name,
							$property['minimum'],
							$value
						);
					}
					if ( isset( $property['maximum'] ) && (float) $value > $property['maximum'] ) {
						$errors[] = sprintf(
							'Setting "%s" for %s must be <= %s, got %s.',
							$name,
							$widget_name,
							$property['maximum'],
							$value
						);
					}
				}
				break;

			case 'boolean':
				// Elementor uses 'yes'/'no' strings for switchers.
				if ( ! is_bool( $value ) && 'yes' !== $value && '' !== $value ) {
					$errors[] = sprintf(
						'Setting "%s" for %s must be "yes" or empty string, got "%s".',
						$name,
						$widget_name,
						$value
					);
				}
				break;

			case 'object':
				if ( ! is_array( $value ) && ! is_object( $value ) && '' !== $value ) {
					$errors[] = sprintf(
						'Setting "%s" for %s must be an object/array, got "%s".',
						$name,
						$widget_name,
						gettype( $value )
					);
				}
				break;

			case 'array':
				if ( ! is_array( $value ) && '' !== $value ) {
					$errors[] = sprintf(
						'Setting "%s" for %s must be an array, got "%s".',
						$name,
						$widget_name,
						gettype( $value )
					);
				}
				break;
		}

		// Enum validation.
		if ( isset( $property['enum'] ) && ! empty( $value ) ) {
			if ( ! in_array( $value, $property['enum'], true ) ) {
				$errors[] = sprintf(
					'Setting "%s" for %s must be one of: %s. Got "%s".',
					$name,
					$widget_name,
					implode( ', ', $property['enum'] ),
					$value
				);
			}
		}

		// Color format validation.
		if ( isset( $property['format'] ) && 'color' === $property['format'] && ! empty( $value ) ) {
			// Accept hex, rgb, rgba, and Elementor Global Color references.
			if ( ! preg_match( '/^(#[0-9A-Fa-f]{3,8}|rgba?\([^)]+\))$/', $value ) && strpos( $value, 'var(' ) !== 0 ) {
				$errors[] = sprintf(
					'Setting "%s" for %s must be a valid color (hex, rgb, rgba). Got "%s".',
					$name,
					$widget_name,
					$value
				);
			}
		}

		return $errors;
	}

	/**
	 * Find the closest matching property name using Levenshtein distance.
	 *
	 * @since 5.2.0
	 * @param string $input    The unknown setting name.
	 * @param array  $haystack Array of known property names.
	 * @return string|null Closest match or null if none close enough.
	 */
	private static function find_closest_match( $input, $haystack ) {
		$best_match    = null;
		$best_distance = PHP_INT_MAX;
		$max_distance  = max( 3, (int) ( strlen( $input ) * 0.4 ) );

		foreach ( $haystack as $candidate ) {
			$distance = levenshtein( strtolower( $input ), strtolower( $candidate ) );
			if ( $distance < $best_distance && $distance <= $max_distance ) {
				$best_distance = $distance;
				$best_match    = $candidate;
			}
		}

		return $best_match;
	}
}
