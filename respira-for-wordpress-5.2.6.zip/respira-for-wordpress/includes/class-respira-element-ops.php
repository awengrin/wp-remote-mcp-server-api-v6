<?php
/**
 * Element-level operations REST API endpoints.
 *
 * Provides REST endpoints for find, update, move, duplicate, remove,
 * batch_update, reorder, and build_page operations.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Element-level operations class.
 *
 * @since 5.2.0
 */
class Respira_Element_Ops {

	/**
	 * Register REST API routes for element operations.
	 *
	 * @since 5.2.0
	 */
	public function register_routes() {
		// Find element.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/find/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'find_element' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'identifier_type'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'enum'              => array( 'id', 'type', 'admin_label', 'content', 'class' ),
					),
					'identifier_value' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'match_content'    => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Update element.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/update/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'update_element' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'identifier_type'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'identifier_value' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'updates'          => array(
						'required' => true,
						'type'     => 'object',
					),
				),
			)
		);

		// Move element.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/move/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'move_element' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'element_id_type'       => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'element_id_value'      => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'target_container_path' => array(
						'required' => true,
						'type'     => 'string',
					),
					'position'              => array(
						'required' => false,
						'type'     => 'integer',
						'default'  => -1,
					),
				),
			)
		);

		// Duplicate element.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/duplicate/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_element' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'identifier_type'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'identifier_value' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Remove element.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/remove/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'remove_element' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'identifier_type'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'identifier_value' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Batch update (atomic).
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/batch/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'batch_update' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'operations' => array(
						'required' => true,
						'type'     => 'array',
					),
				),
			)
		);

		// Reorder children.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/elements/reorder/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reorder_elements' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'container_path' => array(
						'required' => true,
						'type'     => 'string',
					),
					'new_order'      => array(
						'required' => true,
						'type'     => 'array',
					),
				),
			)
		);

		// Build page.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/build',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'build_page' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'title'     => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'structure' => array(
						'required' => true,
						'type'     => 'array',
					),
					'status'    => array(
						'required'          => false,
						'type'              => 'string',
						'default'           => 'draft',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'builder'   => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// Server compatibility endpoint (WS7 — version negotiation).
		// Register on both v1 and v2 for backwards compatibility.
		$compat_route = array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_server_compatibility' ),
			'permission_callback' => '__return_true',
		);
		register_rest_route( RESPIRA_REST_NAMESPACE, '/server/compatibility', $compat_route );
		register_rest_route( RESPIRA_REST_NAMESPACE_V2, '/server/compatibility', $compat_route );

		// Add version header to all Respira REST responses.
		add_filter( 'rest_post_dispatch', array( $this, 'add_version_header' ), 10, 3 );

		// Stock image search.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/stock-images/search',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'search_stock_images' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'query'   => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'license_type'  => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'source'        => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'aspect_ratio'  => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'size'          => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'category'      => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);

		// Stock image sideload.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/stock-images/sideload',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'sideload_stock_image' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'url'     => array(
						'required' => true,
						'type'     => 'string',
					),
					'title'   => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'alt'     => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'author'  => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'license' => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'source'  => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);

		// Bulk page operations (WS4).
		if ( file_exists( RESPIRA_PLUGIN_DIR . 'includes/class-respira-bulk-operations.php' ) ) {
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-bulk-operations.php';
			$bulk_ops = new Respira_Bulk_Operations();
			$bulk_ops->register_routes();
		}

		// Widget shortcuts (WS4).
		if ( file_exists( RESPIRA_PLUGIN_DIR . 'includes/class-respira-widget-shortcuts.php' ) ) {
			require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-widget-shortcuts.php';
			$shortcuts = new Respira_Widget_Shortcuts();
			$shortcuts->register_routes();
		}
	}

	/**
	 * Permission check for element operations.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function permission_check( $request ) {
		// Delegate to main API permission check.
		$api = new Respira_API();
		return $api->api_key_permission_check( $request );
	}

	/**
	 * Get builder instance for a post.
	 *
	 * @since 5.2.0
	 * @param int    $post_id  Post ID.
	 * @param string $builder  Optional. Builder name override.
	 * @return Respira_Builder_Interface|WP_Error
	 */
	private function get_builder( $post_id, $builder = '' ) {
		if ( ! empty( $builder ) ) {
			$instance = Respira_Builder_Interface::get_builder( $builder );
			if ( ! is_wp_error( $instance ) ) {
				return $instance;
			}
		}

		$instance = Respira_Builder_Interface::detect_builder( $post_id );
		if ( ! $instance ) {
			return new WP_Error(
				'respira_no_builder',
				__( 'No page builder detected for this post.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		return $instance;
	}

	/**
	 * Log action via auth system.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @param string          $action  Action name.
	 * @param int             $post_id Post ID.
	 */
	private function log_action( $request, $action, $post_id = null ) {
		$key_data = $request->get_param( '_respira_key_data' );
		if ( $key_data && class_exists( 'Respira_Auth' ) ) {
			Respira_Auth::log_action(
				$key_data['id'] ?? 0,
				$key_data['user_id'] ?? 0,
				$action,
				'element_ops',
				$post_id
			);
		}
	}

	/**
	 * Capture a before-edit or after-edit snapshot for element operations.
	 *
	 * @since 5.2.3
	 * @param int             $post_id Post ID.
	 * @param string          $kind    Snapshot kind: 'before_edit' or 'after_edit'.
	 * @param WP_REST_Request $request Request (for API key ID).
	 * @param string|null     $label   Optional snapshot label.
	 */
	private function capture_snapshot( $post_id, $kind, $request, $label = null ) {
		if ( ! class_exists( 'Respira_Snapshots' ) ) {
			return;
		}
		$key_data     = $request->get_param( '_respira_key_data' );
		$is_duplicate = (bool) get_post_meta( $post_id, '_respira_original_id', true );
		$snap_kind    = $is_duplicate ? $kind : str_replace( '_edit', '_live_edit', $kind );

		Respira_Snapshots::get_instance()->capture_snapshot(
			$post_id,
			$snap_kind,
			array(
				'actor_api_key_id' => $key_data['id'] ?? null,
				'label'            => $label,
			)
		);
	}

	// =========================================================================
	// Endpoint Handlers
	// =========================================================================

	/**
	 * Find an element in a post's builder content.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function find_element( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'find_element', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$result = $builder->find_element(
			$post_id,
			$request->get_param( 'identifier_type' ),
			$request->get_param( 'identifier_value' ),
			$request->get_param( 'match_content' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( null === $result ) {
			return new WP_Error(
				'respira_element_not_found',
				__( 'Element not found matching the given criteria.', 'respira-for-wordpress' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'element' => $result,
			),
			200
		);
	}

	/**
	 * Update an element's settings.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_element( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'update_element', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->update_element(
			$post_id,
			$request->get_param( 'identifier_type' ),
			$request->get_param( 'identifier_value' ),
			$request->get_param( 'updates' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'update_element' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Element updated successfully.', 'respira-for-wordpress' ),
				'changes' => $result,
			),
			200
		);
	}

	/**
	 * Move an element to a new location.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function move_element( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'move_element', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		// Parse target container path (dot-notation → array). "root" or empty = top level.
		$target_path = $request->get_param( 'target_container_path' );
		if ( is_string( $target_path ) && ( '' === $target_path || 'root' === $target_path ) ) {
			$target_path = array();
		} elseif ( is_string( $target_path ) ) {
			$target_path = array_map( 'intval', explode( '.', $target_path ) );
		}

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->move_element(
			$post_id,
			$request->get_param( 'element_id_type' ),
			$request->get_param( 'element_id_value' ),
			$target_path,
			(int) $request->get_param( 'position' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'move_element' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Element moved successfully.', 'respira-for-wordpress' ),
			),
			200
		);
	}

	/**
	 * Duplicate an element.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function duplicate_element( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'duplicate_element', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->duplicate_element(
			$post_id,
			$request->get_param( 'identifier_type' ),
			$request->get_param( 'identifier_value' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'duplicate_element' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Element duplicated successfully.', 'respira-for-wordpress' ),
			),
			200
		);
	}

	/**
	 * Remove an element.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function remove_element( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'remove_element', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->remove_element(
			$post_id,
			$request->get_param( 'identifier_type' ),
			$request->get_param( 'identifier_value' )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'remove_element' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Element removed successfully.', 'respira-for-wordpress' ),
			),
			200
		);
	}

	/**
	 * Batch update — atomic (all or nothing).
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function batch_update( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'batch_update', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$operations = $request->get_param( 'operations' );
		if ( ! is_array( $operations ) || empty( $operations ) ) {
			return new WP_Error(
				'respira_invalid_operations',
				__( 'Operations must be a non-empty array.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->batch_update( $post_id, $operations );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'batch_update' );

		return new WP_REST_Response(
			array(
				'success'    => true,
				'message'    => __( 'Batch update completed successfully.', 'respira-for-wordpress' ),
				'operations' => count( $operations ),
				'results'    => $result,
			),
			200
		);
	}

	/**
	 * Reorder children of a container.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function reorder_elements( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$this->log_action( $request, 'reorder_elements', $post_id );

		$builder = $this->get_builder( $post_id );
		if ( is_wp_error( $builder ) ) {
			return $builder;
		}

		$container_path = $request->get_param( 'container_path' );
		$new_order      = $request->get_param( 'new_order' );

		$this->capture_snapshot( $post_id, 'before_edit', $request );

		$result = $builder->reorder_elements( $post_id, $container_path, $new_order );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->capture_snapshot( $post_id, 'after_edit', $request, 'reorder_elements' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Elements reordered successfully.', 'respira-for-wordpress' ),
			),
			200
		);
	}

	/**
	 * Build a complete page from a declarative structure.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function build_page( $request ) {
		$this->log_action( $request, 'build_page' );

		try {
			$builder_name = $request->get_param( 'builder' );

			// Auto-detect builder if not specified.
			if ( empty( $builder_name ) ) {
				$builder = Respira_Builder_Interface::detect_builder();
				if ( ! $builder ) {
					return new WP_Error(
						'respira_no_builder',
						__( 'No page builder detected. Specify the "builder" parameter.', 'respira-for-wordpress' ),
						array( 'status' => 400 )
					);
				}
			} else {
				$builder = Respira_Builder_Interface::get_builder( $builder_name );
				if ( is_wp_error( $builder ) ) {
					return $builder;
				}
			}

			$result = $builder->build_page(
				$request->get_param( 'title' ),
				$request->get_param( 'structure' ),
				$request->get_param( 'status' )
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			// build_page() returns an array with page_id, edit_url, preview_url, element_count.
			$page_id       = $result['page_id'] ?? 0;
			$element_count = $result['element_count'] ?? 0;
			$edit_url      = get_edit_post_link( $page_id, 'raw' );
			$preview_url   = get_preview_post_link( $page_id );

			return new WP_REST_Response(
				array(
					'success'       => true,
					'page_id'       => $page_id,
					'edit_url'      => $edit_url,
					'preview_url'   => $preview_url,
					'element_count' => $element_count,
					'message'       => __( 'Page built successfully.', 'respira-for-wordpress' ),
				),
				201
			);
		} catch ( \Throwable $e ) {
			error_log( 'Respira: build_page error — ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
			return new WP_Error(
				'respira_build_page_error',
				__( 'An unexpected error occurred while building the page.', 'respira-for-wordpress' ),
				array( 'status' => 500 )
			);
		}
	}

	// =========================================================================
	// Version Negotiation (WS7)
	// =========================================================================

	/**
	 * Add X-Respira-Plugin-Version header to all Respira REST responses.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Response $response REST response.
	 * @param WP_REST_Server   $server   REST server.
	 * @param WP_REST_Request  $request  REST request.
	 * @return WP_REST_Response
	 */
	public function add_version_header( $response, $server, $request ) {
		$route = $request->get_route();
		if ( strpos( $route, '/respira/' ) === 0 ) {
			$version = defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '0.0.0';
			$response->header( 'X-Respira-Plugin-Version', $version );
		}
		return $response;
	}

	/**
	 * Server compatibility endpoint for MCP server version negotiation.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_server_compatibility( $request ) {
		$features = array( 'element_ops', 'build_page', 'stock_images', 'html_converter', 'tool_governance' );

		// Add dynamic schema feature if available.
		if ( class_exists( 'Respira_Elementor_Schema_Generator' ) ) {
			$features[] = 'dynamic_schemas';
		}

		return new WP_REST_Response(
			array(
				'plugin_version'  => defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : '0.0.0',
				'min_mcp_version' => '5.2.0',
				'max_mcp_version' => '5.99.99',
				'features'        => $features,
			),
			200
		);
	}

	// =========================================================================
	// Stock Image Handlers
	// =========================================================================

	/**
	 * Search stock images via Openverse.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function search_stock_images( $request ) {
		$this->log_action( $request, 'search_stock_images' );

		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-openverse-client.php';

		$filters = array();
		foreach ( array( 'license_type', 'source', 'aspect_ratio', 'size', 'category' ) as $key ) {
			$val = $request->get_param( $key );
			if ( ! empty( $val ) ) {
				$filters[ $key ] = $val;
			}
		}

		$result = Respira_Openverse_Client::search(
			$request->get_param( 'query' ),
			$filters
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Sideload a stock image into the Media Library.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function sideload_stock_image( $request ) {
		$this->log_action( $request, 'sideload_image' );

		require_once RESPIRA_PLUGIN_DIR . 'includes/class-respira-openverse-client.php';

		$meta = array();
		foreach ( array( 'title', 'alt', 'author', 'license', 'source' ) as $key ) {
			$val = $request->get_param( $key );
			if ( ! empty( $val ) ) {
				$meta[ $key ] = $val;
			}
		}

		$result = Respira_Openverse_Client::sideload(
			$request->get_param( 'url' ),
			$meta
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response(
			array_merge(
				array( 'success' => true ),
				$result
			),
			201
		);
	}
}
