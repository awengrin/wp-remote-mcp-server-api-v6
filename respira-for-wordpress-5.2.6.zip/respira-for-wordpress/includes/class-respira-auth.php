<?php
/**
 * Authentication and authorization functionality.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 */

/**
 * Authentication and authorization functionality.
 *
 * Handles API key generation, validation, and rate limiting.
 *
 * @since 1.0.0
 */
class Respira_Auth {
	/**
	 * Encrypt a plain API key for recoverable storage.
	 *
	 * @since 2.3.0
	 * @param string $api_key Plain API key.
	 * @return string|false Encrypted payload or false on failure.
	 */
	private static function encrypt_api_key( $api_key ) {
		if ( function_exists( 'openssl_encrypt' ) && function_exists( 'random_bytes' ) ) {
			$encryption_key = hash( 'sha256', wp_salt( 'auth' ), true );
			$iv             = random_bytes( 12 );
			$tag            = '';
			$ciphertext     = openssl_encrypt( $api_key, 'aes-256-gcm', $encryption_key, OPENSSL_RAW_DATA, $iv, $tag );

			if ( false !== $ciphertext && ! empty( $tag ) ) {
				return base64_encode( $iv . $tag . $ciphertext );
			}
		}

		// Fallback: obfuscated base64 (prefixed with "b64:" so decrypt knows the format).
		return 'b64:' . base64_encode( $api_key );
	}

	/**
	 * Decrypt a stored API key payload.
	 *
	 * @since 2.3.0
	 * @param string $encrypted_payload Encrypted payload.
	 * @return string|false Decrypted API key or false on failure.
	 */
	private static function decrypt_api_key( $encrypted_payload ) {
		if ( empty( $encrypted_payload ) ) {
			return false;
		}

		// Fallback format: base64-only.
		if ( 0 === strpos( $encrypted_payload, 'b64:' ) ) {
			$decoded = base64_decode( substr( $encrypted_payload, 4 ), true );
			return ( false !== $decoded && ! empty( $decoded ) ) ? $decoded : false;
		}

		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return false;
		}

		$decoded = base64_decode( $encrypted_payload, true );
		if ( false === $decoded || strlen( $decoded ) <= 28 ) {
			return false;
		}

		$encryption_key = hash( 'sha256', wp_salt( 'auth' ), true );
		$iv             = substr( $decoded, 0, 12 );
		$tag            = substr( $decoded, 12, 16 );
		$ciphertext     = substr( $decoded, 28 );

		return openssl_decrypt( $ciphertext, 'aes-256-gcm', $encryption_key, OPENSSL_RAW_DATA, $iv, $tag );
	}

	/**
	 * Get default permission set for dashboard-issued site tokens.
	 *
	 * @since 4.2.0
	 * @return array
	 */
	private static function get_dashboard_site_token_permissions() {
		return array(
			'read_pages',
			'write_pages',
			'read_posts',
			'write_posts',
			'read_context',
			'upload_media',
			'read_basic',
			'read_fidelity',
			'write',
		);
	}

	/**
	 * Build transient cache key for dashboard site token validation.
	 *
	 * @since 4.2.0
	 * @param string $api_key Site token.
	 * @return string
	 */
	private static function get_dashboard_site_token_cache_key( $api_key ) {
		return 'respira_site_token_' . md5( home_url() . '|' . (string) $api_key );
	}

	/**
	 * Validate dashboard-issued site token against respira.press.
	 *
	 * @since 4.2.0
	 * @param string $api_key Site token.
	 * @return array|WP_Error
	 */
	private static function validate_dashboard_site_token( $api_key ) {
		$cache_key = self::get_dashboard_site_token_cache_key( $api_key );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$base_url = apply_filters( 'respira_dashboard_base_url', 'https://www.respira.press' );
		$endpoint = trailingslashit( untrailingslashit( (string) $base_url ) ) . 'api/mcp/site-token/introspect';
		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 15,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
					'User-Agent'   => 'Respira-WordPress/' . ( defined( 'RESPIRA_VERSION' ) ? RESPIRA_VERSION : 'unknown' ),
				),
				'body'    => wp_json_encode(
					array(
						'token'    => (string) $api_key,
						'site_url' => home_url(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'respira_site_token_validation_failed',
				__( 'Could not validate dashboard site token with respira.press.', 'respira-for-wordpress' ),
				array( 'status' => 503 )
			);
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $status < 200 || $status >= 300 ) {
			return new WP_Error(
				'respira_invalid_site_token',
				! empty( $body['error'] ) ? sanitize_text_field( $body['error'] ) : __( 'Dashboard site token is invalid for this site.', 'respira-for-wordpress' ),
				array( 'status' => $status > 0 ? $status : 401 )
			);
		}

		$permissions = self::get_dashboard_site_token_permissions();
		if ( ! empty( $body['permissions'] ) && is_array( $body['permissions'] ) ) {
			$permissions = array_values( array_unique( array_map( 'sanitize_text_field', $body['permissions'] ) ) );
		}

		$synthetic_key_id = (int) sprintf( '%u', crc32( (string) $api_key ) );
		if ( $synthetic_key_id <= 0 ) {
			$synthetic_key_id = 1;
		}

		$key_data = array(
			'id'                => $synthetic_key_id,
			'user_id'           => 0,
			'name'              => __( 'Dashboard site token', 'respira-for-wordpress' ),
			'permissions'       => $permissions,
			'license_key'       => isset( $body['license_key'] ) ? sanitize_text_field( (string) $body['license_key'] ) : null,
			'auth_source'       => 'dashboard_site_token',
			'site_id'           => isset( $body['site_id'] ) ? sanitize_text_field( (string) $body['site_id'] ) : null,
			'dashboard_user_id' => isset( $body['user_id'] ) ? sanitize_text_field( (string) $body['user_id'] ) : null,
		);

		$rate_limit_check = self::check_rate_limit( $synthetic_key_id );
		if ( is_wp_error( $rate_limit_check ) ) {
			return $rate_limit_check;
		}

		// Keep this cache short so rotated tokens expire quickly even without push invalidation.
		set_transient( $cache_key, $key_data, MINUTE_IN_SECONDS );

		return $key_data;
	}

	/**
	 * Generate a new API key.
	 *
	 * @since 1.0.0
	 * @param int    $user_id  The user ID who owns this key.
	 * @param string $name     Optional. A friendly name for the key.
	 * @param array  $permissions Optional. Array of permissions for this key.
	 * @return string|WP_Error The generated API key or WP_Error on failure.
	 */
	public static function generate_api_key( $user_id, $name = null, $permissions = array() ) {
		global $wpdb;

		// Verify user has required capability.
		$user = get_user_by( 'id', $user_id );
		if ( ! $user || ! user_can( $user, 'manage_options' ) ) {
			return new WP_Error(
				'respira_insufficient_permissions',
				__( 'User does not have permission to generate API keys.', 'respira-for-wordpress' )
			);
		}

		// Dev mode bypasses license checks for local testing.
		$is_dev_mode = defined( 'RESPIRA_DEV_MODE' ) && RESPIRA_DEV_MODE;
		$license_key = get_option( 'respira_license_key', '' );

		if ( ! $is_dev_mode ) {
			// Check if license is active (required for API key generation).
			$license_status = get_option( 'respira_license_status' );

			// If license status is not active/trial, force revalidation before checking
			// This allows licenses updated server-side to work without waiting for 7-day auto-validation
			if ( ! empty( $license_key ) && 'active' !== $license_status && 'trial' !== $license_status ) {
				// Force immediate validation to check for server-side updates
				Respira_License::validate_license( $license_key );
				// Re-fetch status after validation
				$license_status = get_option( 'respira_license_status' );
			}

			if ( empty( $license_key ) || ( 'active' !== $license_status && 'trial' !== $license_status ) ) {
				return new WP_Error(
					'respira_license_required',
					__( 'An active license is required to generate API keys. Please activate your license first.', 'respira-for-wordpress' ),
					array( 'status' => 403 )
				);
			}

			// Validate license matches current domain
			if ( ! Respira_License::is_pro_active() ) {
				return new WP_Error(
					'respira_license_invalid',
					__( 'License validation failed. The license may not be valid for this domain. Please check your license in the License page.', 'respira-for-wordpress' ),
					array( 'status' => 403 )
				);
			}
		}

		// Generate UUID v4 format key.
		$api_key = 'respira_' . self::generate_uuid();

		// Store a prefix for identification (first 8 chars of the UUID part).
		$key_prefix = substr( $api_key, 0, 16 ); // "respira_" + first 8 chars.

		// Hash the key for storage.
		$hashed_key = wp_hash_password( $api_key );

		// Default permissions.
		if ( empty( $permissions ) ) {
			$permissions = array(
				'read_pages',
				'write_pages',
				'read_posts',
				'write_posts',
				'read_context',
				'upload_media',
				'read_basic',
				'read_fidelity',
				'write',
			);
		}

		// Insert into database.
		$table_name = $wpdb->prefix . 'respira_api_keys';
		
		// Check if table exists
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );
		if ( ! $table_exists ) {
			// Table doesn't exist - try to create it
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$charset_collate = $wpdb->get_charset_collate();
			$sql = "CREATE TABLE IF NOT EXISTS $table_name (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				api_key varchar(255) NOT NULL,
				encrypted_key longtext DEFAULT NULL,
				user_id bigint(20) NOT NULL,
				name varchar(255) DEFAULT NULL,
				permissions text DEFAULT NULL,
				license_key varchar(255) DEFAULT NULL,
				last_used datetime DEFAULT NULL,
				created_at datetime NOT NULL,
				expires_at datetime DEFAULT NULL,
				is_active tinyint(1) DEFAULT 1,
				PRIMARY KEY  (id),
				UNIQUE KEY api_key (api_key),
				KEY user_id (user_id),
				KEY license_key (license_key)
			) $charset_collate;";
			dbDelta( $sql );
		} else {
			// Table exists - check if license_key column exists
			// Table name is safe - it's from $wpdb->prefix which is sanitized by WordPress
			$column_exists = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
					WHERE TABLE_SCHEMA = %s
					AND TABLE_NAME = %s
					AND COLUMN_NAME = %s",
					DB_NAME,
					$table_name,
					'license_key'
				)
			);

			if ( empty( $column_exists ) ) {
				// Column doesn't exist - add it
				// Table name is safe - it's from $wpdb->prefix which is sanitized by WordPress
				$wpdb->query(
					"ALTER TABLE `{$table_name}`
					ADD COLUMN license_key varchar(255) DEFAULT NULL AFTER permissions"
				);
				// Add index separately (only if column was added successfully)
				if ( empty( $wpdb->last_error ) ) {
					$wpdb->query(
						"ALTER TABLE `{$table_name}` ADD INDEX license_key (license_key)"
					);
				}
			}

			// Check if key_prefix column exists.
			$prefix_column_exists = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
					WHERE TABLE_SCHEMA = %s
					AND TABLE_NAME = %s
					AND COLUMN_NAME = %s",
					DB_NAME,
					$table_name,
					'key_prefix'
				)
			);

			if ( empty( $prefix_column_exists ) ) {
				// Add key_prefix column.
				$wpdb->query(
					"ALTER TABLE `{$table_name}`
					ADD COLUMN key_prefix varchar(20) DEFAULT NULL AFTER api_key"
				);
			}

			// Check if encrypted_key column exists.
			$encrypted_column_exists = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
					WHERE TABLE_SCHEMA = %s
					AND TABLE_NAME = %s
					AND COLUMN_NAME = %s",
					DB_NAME,
					$table_name,
					'encrypted_key'
				)
			);

			if ( empty( $encrypted_column_exists ) ) {
				$wpdb->query(
					"ALTER TABLE `{$table_name}`
					ADD COLUMN encrypted_key longtext DEFAULT NULL AFTER api_key"
				);
			}
		}
		
		$encrypted_key = self::encrypt_api_key( $api_key );

		$result = $wpdb->insert(
			$table_name,
			array(
				'api_key'     => $hashed_key,
				'encrypted_key' => $encrypted_key ? $encrypted_key : null,
				'key_prefix'  => $key_prefix,
				'user_id'     => $user_id,
				'name'        => $name,
				'permissions' => wp_json_encode( $permissions ),
				'license_key' => $license_key,
				'created_at'  => current_time( 'mysql' ),
				'is_active'   => 1,
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( false === $result ) {
			$error_message = __( 'Failed to create API key in database.', 'respira-for-wordpress' );
			if ( ! empty( $wpdb->last_error ) ) {
				$error_message .= ' ' . sprintf(
					/* translators: %s: database error message */
					__( 'Database error: %s', 'respira-for-wordpress' ),
					$wpdb->last_error
				);
			}
			return new WP_Error(
				'respira_db_error',
				$error_message
			);
		}

		$new_key_id = $wpdb->insert_id;

		// Fallback: also store encrypted key in user meta keyed by row ID.
		if ( $encrypted_key && $new_key_id ) {
			update_user_meta( $user_id, '_respira_enc_key_' . $new_key_id, $encrypted_key );
		}

		// Log the key generation.
		self::log_action( $new_key_id, $user_id, 'generate_api_key', 'api_key', $new_key_id );

		// Return the plain text key (only time it will be visible).
		return $api_key;
	}

	/**
	 * Validate an API key.
	 *
	 * @since 1.0.0
	 * @param string $api_key The API key to validate.
	 * @return array|WP_Error Array with key info on success, WP_Error on failure.
	 */
	public static function validate_api_key( $api_key ) {
		global $wpdb;

		if ( empty( $api_key ) || ! is_string( $api_key ) ) {
			return new WP_Error(
				'respira_invalid_key_format',
				__( 'Invalid API key format.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		if ( 0 === strpos( $api_key, 'respira_site_' ) ) {
			return self::validate_dashboard_site_token( $api_key );
		}

		// Remove 'respira_' prefix if present for validation.
		if ( 0 !== strpos( $api_key, 'respira_' ) ) {
			return new WP_Error(
				'respira_invalid_key_prefix',
				__( 'API key must start with "respira_" prefix.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		// Get all active API keys.
		$table_name = $wpdb->prefix . 'respira_api_keys';
		$keys       = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE is_active = %d",
				1
			)
		);

		if ( empty( $keys ) ) {
			return new WP_Error(
				'respira_no_active_keys',
				__( 'No active API keys found.', 'respira-for-wordpress' ),
				array( 'status' => 401 )
			);
		}

		// Check each key using wp_check_password.
		foreach ( $keys as $key_data ) {
			if ( wp_check_password( $api_key, $key_data->api_key ) ) {
				// Check if key has expired.
				if ( ! empty( $key_data->expires_at ) ) {
					$expires = strtotime( $key_data->expires_at );
					if ( $expires < time() ) {
						return new WP_Error(
							'respira_key_expired',
							__( 'API key has expired.', 'respira-for-wordpress' ),
							array( 'status' => 401 )
						);
					}
				}

				// Check if license is still active (if key is linked to a license).
				if ( ! empty( $key_data->license_key ) ) {
					$current_license_key = get_option( 'respira_license_key' );
					$license_status = get_option( 'respira_license_status' );

					// If license key changed or license is inactive, disable this API key.
					if ( $key_data->license_key !== $current_license_key || 'active' !== $license_status ) {
						// Disable the API key.
						$wpdb->update(
							$table_name,
							array( 'is_active' => 0 ),
							array( 'id' => $key_data->id ),
							array( '%d' ),
							array( '%d' )
						);

						return new WP_Error(
							'respira_license_inactive',
							__( 'API key is disabled because the license is inactive or has been changed. Please reactivate your license.', 'respira-for-wordpress' ),
							array( 'status' => 403 )
						);
					}

					// Re-validate license periodically (every 7 days).
					$last_check = get_option( 'respira_license_last_check', 0 );
					if ( ( time() - $last_check ) > ( 7 * DAY_IN_SECONDS ) ) {
						Respira_License::validate_license( $key_data->license_key );
						$license_status = get_option( 'respira_license_status' );
						if ( 'active' !== $license_status ) {
							// Disable the API key.
							$wpdb->update(
								$table_name,
								array( 'is_active' => 0 ),
								array( 'id' => $key_data->id ),
								array( '%d' ),
								array( '%d' )
							);

							return new WP_Error(
								'respira_license_expired',
								__( 'API key is disabled because the license has expired. Please renew your license.', 'respira-for-wordpress' ),
								array( 'status' => 403 )
							);
						}
					}
				}

				// Check rate limiting.
				$rate_limit_check = self::check_rate_limit( $key_data->id );
				if ( is_wp_error( $rate_limit_check ) ) {
					return $rate_limit_check;
				}

				// Update last used timestamp.
				$wpdb->update(
					$table_name,
					array( 'last_used' => current_time( 'mysql' ) ),
					array( 'id' => $key_data->id ),
					array( '%s' ),
					array( '%d' )
				);

				// Return key data.
				return array(
					'id'          => $key_data->id,
					'user_id'     => $key_data->user_id,
					'name'        => $key_data->name,
					'permissions' => json_decode( $key_data->permissions, true ),
					'license_key' => $key_data->license_key ?? null,
				);
			}
		}

		return new WP_Error(
			'respira_invalid_key',
			__( 'Invalid API key.', 'respira-for-wordpress' ),
			array( 'status' => 401 )
		);
	}

	/**
	 * Revoke an API key.
	 *
	 * @since 1.0.0
	 * @param int $key_id The ID of the key to revoke.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function revoke_api_key( $key_id, $user_id = null ) {
		global $wpdb;

		$key_id = absint( $key_id );
		if ( $key_id <= 0 ) {
			return new WP_Error(
				'respira_invalid_key_id',
				__( 'Invalid API key ID.', 'respira-for-wordpress' )
			);
		}

		$table_name = $wpdb->prefix . 'respira_api_keys';
		$where      = array( 'id' => $key_id );
		$where_fmt  = array( '%d' );
		if ( null !== $user_id ) {
			$where['user_id'] = absint( $user_id );
			$where_fmt[]      = '%d';
		}

		if ( null !== $user_id ) {
			$key_row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, is_active FROM $table_name WHERE id = %d AND user_id = %d LIMIT 1",
					$key_id,
					absint( $user_id )
				)
			);
		} else {
			$key_row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, is_active FROM $table_name WHERE id = %d LIMIT 1",
					$key_id
				)
			);
		}

		if ( ! $key_row ) {
			return new WP_Error(
				'respira_key_not_found',
				__( 'API key not found.', 'respira-for-wordpress' )
			);
		}

		// Already revoked; treat as success for idempotency.
		if ( 0 === (int) $key_row->is_active ) {
			return true;
		}

		$result = $wpdb->update(
			$table_name,
			array( 'is_active' => 0 ),
			$where,
			array( '%d' ),
			$where_fmt
		);

		if ( false === $result ) {
			return new WP_Error(
				'respira_revoke_failed',
				__( 'Failed to revoke API key.', 'respira-for-wordpress' )
			);
		}

		// Log the revocation.
		$actor_user_id = null !== $user_id ? absint( $user_id ) : get_current_user_id();
		self::log_action( $key_id, $actor_user_id, 'revoke_api_key', 'api_key', $key_id );

		return true;
	}

	/**
	 * Check if API key has permission for an action.
	 *
	 * @since 1.0.0
	 * @param array  $key_data   The key data from validate_api_key().
	 * @param string $permission The permission to check.
	 * @return bool True if has permission, false otherwise.
	 */
	public static function has_permission( $key_data, $permission ) {
		if ( ! isset( $key_data['permissions'] ) ) {
			return false;
		}
		$perms = $key_data['permissions'];
		// New structured format.
		if ( is_array( $perms ) && isset( $perms['scopes'] ) ) {
			return in_array( $permission, (array) $perms['scopes'], true );
		}
		// Legacy flat array.
		if ( is_array( $perms ) ) {
			return in_array( $permission, $perms, true );
		}
		return false;
	}

	/**
	 * Map legacy key permissions into v2 scopes.
	 *
	 * @since 3.1.0
	 * @param array $key_data Key data from validate_api_key.
	 * @return array
	 */
	public static function get_v2_scopes( $key_data ) {
		$permissions = array();
		if ( isset( $key_data['permissions'] ) && is_array( $key_data['permissions'] ) ) {
			// New structured format.
			if ( isset( $key_data['permissions']['scopes'] ) ) {
				$permissions = (array) $key_data['permissions']['scopes'];
			} else {
				// Legacy flat array.
				$permissions = $key_data['permissions'];
			}
		}

		$scopes = array();

		// Explicit v2 scopes.
		foreach ( array( 'read_basic', 'read_fidelity', 'read_meta_all', 'write', 'approve_force' ) as $scope ) {
			if ( in_array( $scope, $permissions, true ) ) {
				$scopes[] = $scope;
			}
		}

		// Legacy read permissions map to safe default read scopes.
		$legacy_read_permissions = array(
			'read_pages',
			'read_posts',
			'read_context',
			'upload_media',
		);
		foreach ( $legacy_read_permissions as $legacy_permission ) {
			if ( in_array( $legacy_permission, $permissions, true ) ) {
				$scopes[] = 'read_basic';
				$scopes[] = 'read_fidelity';
				break;
			}
		}

		// Legacy write permissions map to v2 write scope.
		$legacy_write_permissions = array( 'write_pages', 'write_posts' );
		foreach ( $legacy_write_permissions as $legacy_permission ) {
			if ( in_array( $legacy_permission, $permissions, true ) ) {
				$scopes[] = 'write';
				break;
			}
		}

		/**
		 * Filter resolved v2 scopes for an API key.
		 *
		 * @since 3.1.0
		 * @param array $scopes Resolved scopes.
		 * @param array $key_data Key metadata.
		 */
		$scopes = apply_filters( 'respira_auth_v2_scopes', $scopes, $key_data );

		return array_values( array_unique( array_filter( $scopes ) ) );
	}

	/**
	 * Check if key has a required v2 scope.
	 *
	 * @since 3.1.0
	 * @param array  $key_data Key data.
	 * @param string $scope Required scope.
	 * @return bool
	 */
	public static function has_v2_scope( $key_data, $scope ) {
		$scope  = (string) $scope;
		$scopes = self::get_v2_scopes( $key_data );
		return in_array( $scope, $scopes, true );
	}

	/**
	 * Get the allowed tools for an API key.
	 *
	 * @since 5.2.0
	 * @param array $key_data Key data from validate_api_key.
	 * @return array Array of canonical tool names, or array('*') for full access.
	 */
	public static function get_allowed_tools( $key_data ) {
		if ( ! isset( $key_data['permissions'] ) || ! is_array( $key_data['permissions'] ) ) {
			return array( '*' ); // Legacy keys = full access.
		}
		$perms = $key_data['permissions'];
		if ( isset( $perms['allowed_tools'] ) && is_array( $perms['allowed_tools'] ) ) {
			return $perms['allowed_tools'];
		}
		return array( '*' ); // Legacy format = full access.
	}

	/**
	 * Check rate limiting for an API key.
	 *
	 * @since 1.0.0
	 * @param int $key_id The API key ID.
	 * @return bool|WP_Error True if within limits, WP_Error if exceeded.
	 */
	private static function check_rate_limit( $key_id ) {
		global $wpdb;

		$rate_limit = get_option( 'respira_rate_limit', 100 );
		$table_name = $wpdb->prefix . 'respira_audit_log';

		// Count requests in the last hour.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name
				WHERE api_key_id = %d
				AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
				$key_id
			)
		);

		if ( $count >= $rate_limit ) {
			return new WP_Error(
				'respira_rate_limit_exceeded',
				sprintf(
					/* translators: %d: rate limit */
					__( 'Rate limit exceeded. Maximum %d requests per hour.', 'respira-for-wordpress' ),
					$rate_limit
				),
				array( 'status' => 429 )
			);
		}

		return true;
	}

	/**
	 * Sanitize request telemetry token values.
	 *
	 * @since 4.1.0
	 * @param mixed  $value   Raw value.
	 * @param string $pattern Allowed character strip pattern.
	 * @return string|null
	 */
	private static function sanitize_telemetry_token( $value, $pattern = '/[^a-zA-Z0-9\.\-\+_\/]/' ) {
		if ( ! is_string( $value ) ) {
			return null;
		}

		$value = trim( $value );
		if ( '' === $value ) {
			return null;
		}

		$value = preg_replace( $pattern, '', $value );
		if ( '' === $value ) {
			return null;
		}

		return substr( strtolower( (string) $value ), 0, 64 );
	}

	/**
	 * Infer likely assistant client from request user-agent.
	 *
	 * @since 4.1.0
	 * @return string|null
	 */
	private static function infer_agent_from_user_agent() {
		if ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
			return null;
		}

		$user_agent = strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) );
		if ( false !== strpos( $user_agent, 'cursor' ) ) {
			return 'cursor';
		}
		if ( false !== strpos( $user_agent, 'claude' ) ) {
			return 'claude-code';
		}
		if ( false !== strpos( $user_agent, 'codex' ) ) {
			return 'codex';
		}
		if ( false !== strpos( $user_agent, 'windsurf' ) || false !== strpos( $user_agent, 'codeium' ) ) {
			return 'windsurf';
		}
		if ( false !== strpos( $user_agent, 'copilot' ) ) {
			return 'copilot';
		}
		return null;
	}

	/**
	 * Build request telemetry metadata for audit log entries.
	 *
	 * @since 4.1.0
	 * @return array
	 */
	private static function get_request_telemetry_metadata() {
		$metadata = array();

		$mcp_version = self::sanitize_telemetry_token(
			isset( $_SERVER['HTTP_X_RESPIRA_MCP_VERSION'] ) ? wp_unslash( $_SERVER['HTTP_X_RESPIRA_MCP_VERSION'] ) : null,
			'/[^a-zA-Z0-9\.\-\+_]/'
		);
		if ( ! empty( $mcp_version ) ) {
			$metadata['mcp_version'] = $mcp_version;
		}

		$agent_client = self::sanitize_telemetry_token(
			isset( $_SERVER['HTTP_X_RESPIRA_AGENT_CLIENT'] ) ? wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_CLIENT'] ) : null
		);
		if ( empty( $agent_client ) ) {
			$agent_client = self::infer_agent_from_user_agent();
		}
		if ( ! empty( $agent_client ) ) {
			$metadata['agent_client'] = $agent_client;
		}

		$agent_version = self::sanitize_telemetry_token(
			isset( $_SERVER['HTTP_X_RESPIRA_AGENT_VERSION'] ) ? wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_VERSION'] ) : null,
			'/[^a-zA-Z0-9\.\-\+_]/'
		);
		if ( ! empty( $agent_version ) ) {
			$metadata['agent_version'] = $agent_version;
		}

		$agent_transport = self::sanitize_telemetry_token(
			isset( $_SERVER['HTTP_X_RESPIRA_AGENT_TRANSPORT'] ) ? wp_unslash( $_SERVER['HTTP_X_RESPIRA_AGENT_TRANSPORT'] ) : null,
			'/[^a-zA-Z0-9\.\-\+_]/'
		);
		if ( ! empty( $agent_transport ) ) {
			$metadata['agent_transport'] = $agent_transport;
		}

		return $metadata;
	}

	/**
	 * Log an API action to the audit log.
	 *
	 * @since 1.0.0
	 * @param int    $api_key_id    The API key ID.
	 * @param int    $user_id       The user ID.
	 * @param string $action        The action performed.
	 * @param string $resource_type The type of resource.
	 * @param int    $resource_id   The resource ID.
	 * @param array  $request_data  Optional. Request data.
	 * @param int    $response_code Optional. HTTP response code.
	 */
	public static function log_action( $api_key_id, $user_id, $action, $resource_type = null, $resource_id = null, $request_data = array(), $response_code = 200 ) {
		global $wpdb;

		// Check if audit logging is enabled.
		if ( ! get_option( 'respira_audit_logging', 1 ) ) {
			return;
		}

		$table_name = $wpdb->prefix . 'respira_audit_log';

		if ( ! is_array( $request_data ) ) {
			$request_data = array();
		}
		$request_data = array_merge(
			self::get_request_telemetry_metadata(),
			$request_data
		);

		$wpdb->insert(
			$table_name,
			array(
				'api_key_id'    => $api_key_id,
				'user_id'       => $user_id,
				'action'        => $action,
				'resource_type' => $resource_type,
				'resource_id'   => $resource_id,
				'ip_address'    => self::get_client_ip(),
				'user_agent'    => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				'request_data'  => ! empty( $request_data ) ? wp_json_encode( $request_data ) : null,
				'response_code' => $response_code,
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s' )
		);
	}

	/**
	 * Generate a UUID v4.
	 *
	 * @since  1.0.0
	 * @return string UUID v4 string.
	 */
	private static function generate_uuid() {
		$data    = random_bytes( 16 );
		$data[6] = chr( ord( $data[6] ) & 0x0f | 0x40 );
		$data[8] = chr( ord( $data[8] ) & 0x3f | 0x80 );
		return vsprintf( '%s%s-%s-%s-%s-%s%s%s', str_split( bin2hex( $data ), 4 ) );
	}

	/**
	 * Get client IP address.
	 *
	 * @since  1.0.0
	 * @return string IP address.
	 */
	private static function get_client_ip() {
		$ip_keys = array(
			'HTTP_CLIENT_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_FORWARDED',
			'HTTP_X_CLUSTER_CLIENT_IP',
			'HTTP_FORWARDED_FOR',
			'HTTP_FORWARDED',
			'REMOTE_ADDR',
		);

		foreach ( $ip_keys as $key ) {
			if ( isset( $_SERVER[ $key ] ) && filter_var( wp_unslash( $_SERVER[ $key ] ), FILTER_VALIDATE_IP ) ) {
				return sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
			}
		}

		return '0.0.0.0';
	}

	/**
	 * Get all API keys for a user.
	 *
	 * @since 1.0.0
	 * @param int $user_id The user ID.
	 * @return array Array of API key data (without the actual keys).
	 */
	public static function get_user_keys( $user_id ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'respira_api_keys';
		
		// Check if table exists
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );
		if ( ! $table_exists ) {
			// Table doesn't exist - return empty array
			return array();
		}
		
		$encrypted_column_exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM `$table_name` LIKE %s", 'encrypted_key' ) );
		$select_encrypted_column = $encrypted_column_exists ? 'encrypted_key' : 'NULL AS encrypted_key';

		$keys = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, key_prefix, $select_encrypted_column, name, permissions, last_used, created_at, expires_at, is_active
				FROM $table_name
				WHERE user_id = %d
				ORDER BY created_at DESC",
				$user_id
			)
		);

		// Return empty array if query failed
		if ( false === $keys ) {
			return array();
		}

		return $keys;
	}

	/**
	 * Return plaintext API key for a user-owned key when recoverable.
	 *
	 * @since 2.3.0
	 * @param int $key_id  API key row ID.
	 * @param int $user_id Owner user ID.
	 * @return string|false Plain key when available, otherwise false.
	 */
	public static function get_plaintext_key( $key_id, $user_id ) {
		global $wpdb;

		$table_name  = $wpdb->prefix . 'respira_api_keys';
		$encrypted   = null;

		// Try DB column first.
		$encrypted_column_exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM `$table_name` LIKE %s", 'encrypted_key' ) );
		if ( $encrypted_column_exists ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT encrypted_key FROM $table_name WHERE id = %d AND user_id = %d LIMIT 1",
					$key_id,
					$user_id
				)
			);
			if ( $row && ! empty( $row->encrypted_key ) ) {
				$encrypted = $row->encrypted_key;
			}
		}

		// Fallback: check user meta.
		if ( empty( $encrypted ) ) {
			$encrypted = get_user_meta( $user_id, '_respira_enc_key_' . (int) $key_id, true );
		}

		if ( empty( $encrypted ) ) {
			return false;
		}

		$plaintext = self::decrypt_api_key( $encrypted );
		if ( false === $plaintext || empty( $plaintext ) ) {
			return false;
		}

		return $plaintext;
	}
}
