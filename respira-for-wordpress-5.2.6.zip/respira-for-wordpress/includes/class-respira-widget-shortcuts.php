<?php
/**
 * Widget Shortcuts — convenience tools for common widget creation patterns.
 *
 * Data-driven registry with a single dispatch endpoint. 27 shortcuts
 * registered as individual MCP tools via the registry.
 *
 * @package    Respira_For_WordPress
 * @subpackage Respira_For_WordPress/includes
 * @since      5.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Respira_Widget_Shortcuts {

	/**
	 * Widget shortcut registry.
	 *
	 * @var array
	 */
	private static $shortcuts = array(
		'add_heading'       => array( 'widget' => 'heading', 'required' => array( 'title' ), 'optional' => array( 'tag' => 'h2', 'alignment' => 'left' ) ),
		'add_text'          => array( 'widget' => 'text-editor', 'required' => array( 'content' ), 'optional' => array( 'alignment' => 'left' ) ),
		'add_button'        => array( 'widget' => 'button', 'required' => array( 'text' ), 'optional' => array( 'url' => '#', 'style' => 'primary', 'alignment' => 'left' ) ),
		'add_image'         => array( 'widget' => 'image', 'required' => array( 'src' ), 'optional' => array( 'alt' => '', 'width' => '', 'height' => '' ) ),
		'add_section'       => array( 'widget' => 'section', 'required' => array(), 'optional' => array( 'background_color' => '', 'padding' => '' ) ),
		'add_video'         => array( 'widget' => 'video', 'required' => array( 'url' ), 'optional' => array( 'autoplay' => false ) ),
		'add_divider'       => array( 'widget' => 'divider', 'required' => array(), 'optional' => array( 'style' => 'solid', 'color' => '' ) ),
		'add_spacer'        => array( 'widget' => 'spacer', 'required' => array(), 'optional' => array( 'height' => '50px' ) ),
		'add_icon'          => array( 'widget' => 'icon', 'required' => array( 'icon' ), 'optional' => array( 'size' => 'md', 'color' => '' ) ),
		'add_icon_list'     => array( 'widget' => 'icon-list', 'required' => array( 'items' ), 'optional' => array() ),
		'add_social_icons'  => array( 'widget' => 'social-icons', 'required' => array( 'networks' ), 'optional' => array() ),
		'add_form'          => array( 'widget' => 'form', 'required' => array( 'fields' ), 'optional' => array( 'submit_text' => 'Submit' ) ),
		'add_map'           => array( 'widget' => 'google-maps', 'required' => array( 'address' ), 'optional' => array( 'zoom' => 14 ) ),
		'add_counter'       => array( 'widget' => 'counter', 'required' => array( 'number' ), 'optional' => array( 'title' => '', 'prefix' => '', 'suffix' => '' ) ),
		'add_progress_bar'  => array( 'widget' => 'progress-bar', 'required' => array( 'title', 'percentage' ), 'optional' => array( 'color' => '' ) ),
		'add_testimonial'   => array( 'widget' => 'testimonial', 'required' => array( 'content', 'name' ), 'optional' => array( 'title' => '', 'image' => '' ) ),
		'add_tabs'          => array( 'widget' => 'tabs', 'required' => array( 'tabs' ), 'optional' => array() ),
		'add_accordion'     => array( 'widget' => 'accordion', 'required' => array( 'items' ), 'optional' => array() ),
		'add_toggle'        => array( 'widget' => 'toggle', 'required' => array( 'title', 'content' ), 'optional' => array() ),
		'add_alert'         => array( 'widget' => 'alert', 'required' => array( 'message' ), 'optional' => array( 'type' => 'info', 'dismissible' => false ) ),
		'add_html'          => array( 'widget' => 'html', 'required' => array( 'content' ), 'optional' => array() ),
		'add_menu'          => array( 'widget' => 'nav-menu', 'required' => array( 'menu_id' ), 'optional' => array() ),
		'add_sidebar'       => array( 'widget' => 'sidebar', 'required' => array( 'sidebar_id' ), 'optional' => array() ),
		'add_search'        => array( 'widget' => 'search-form', 'required' => array(), 'optional' => array( 'placeholder' => 'Search...' ) ),
		'add_gallery'       => array( 'widget' => 'gallery', 'required' => array( 'images' ), 'optional' => array( 'columns' => 3 ) ),
		'add_slider'        => array( 'widget' => 'slides', 'required' => array( 'slides' ), 'optional' => array( 'autoplay' => true ) ),
		'add_pricing_table' => array( 'widget' => 'price-table', 'required' => array( 'title', 'price' ), 'optional' => array( 'period' => '/mo', 'features' => array(), 'button_text' => 'Buy Now', 'button_url' => '#' ) ),
	);

	/**
	 * Register REST routes.
	 *
	 * @since 5.2.0
	 */
	public function register_routes() {
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/widget/(?P<shortcut_name>[a-z_]+)/(?P<post_id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_shortcut' ),
				'permission_callback' => array( $this, 'permission_check' ),
				'args'                => array(
					'shortcut_name' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'post_id'       => array(
						'required' => true,
						'type'     => 'integer',
					),
				),
			)
		);

		// Registry endpoint for MCP server tool generation.
		register_rest_route(
			RESPIRA_REST_NAMESPACE_V2,
			'/builder/widget-registry',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_registry_endpoint' ),
				'permission_callback' => array( $this, 'permission_check' ),
			)
		);
	}

	/**
	 * Permission check.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function permission_check( $request ) {
		$api = new Respira_API();
		return $api->api_key_permission_check( $request );
	}

	/**
	 * Handle a widget shortcut request.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_shortcut( $request ) {
		$shortcut_name = $request->get_param( 'shortcut_name' );
		$post_id       = (int) $request->get_param( 'post_id' );

		if ( ! isset( self::$shortcuts[ $shortcut_name ] ) ) {
			return new WP_Error(
				'respira_unknown_shortcut',
				sprintf(
					__( 'Unknown widget shortcut: %s. Use GET /builder/widget-registry for available shortcuts.', 'respira-for-wordpress' ),
					$shortcut_name
				),
				array( 'status' => 400 )
			);
		}

		$shortcut = self::$shortcuts[ $shortcut_name ];

		// Validate required parameters.
		$params = $request->get_json_params();
		foreach ( $shortcut['required'] as $param ) {
			if ( ! isset( $params[ $param ] ) || '' === $params[ $param ] ) {
				return new WP_Error(
					'respira_missing_param',
					sprintf(
						__( 'Required parameter "%s" is missing for %s.', 'respira-for-wordpress' ),
						$param,
						$shortcut_name
					),
					array( 'status' => 400 )
				);
			}
		}

		// Merge defaults.
		$settings = array_merge( $shortcut['optional'], $params );

		// Remove non-setting keys.
		unset( $settings['shortcut_name'], $settings['post_id'] );

		// Detect builder.
		if ( ! class_exists( 'Respira_Builder_Interface' ) ) {
			return new WP_Error(
				'respira_no_builder',
				__( 'Builder interface not available.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		$builder = Respira_Builder_Interface::detect_builder( $post_id );
		if ( ! $builder ) {
			return new WP_Error(
				'respira_no_builder',
				__( 'No page builder detected for this post.', 'respira-for-wordpress' ),
				array( 'status' => 400 )
			);
		}

		// Map generic widget name to builder-native type.
		$native_type = $this->map_widget_to_builder( $shortcut['widget'], $builder );

		// Build widget element and append to the page via the tree utility.
		$new_element = array(
			'type'    => $native_type,
			'content' => $this->build_widget_content( $shortcut['widget'], $settings, $builder ),
		);

		// Use builder-specific attribute keys.
		$attrs_key    = method_exists( $builder, 'get_attributes_key' ) ? $builder->get_attributes_key() : 'attributes';
		$children_key = method_exists( $builder, 'get_children_key' ) ? $builder->get_children_key() : 'children';

		$new_element[ $attrs_key ] = $settings;

		// Extract current content and append the new element.
		$content = $builder->extract_content( $post_id );
		if ( is_array( $content ) ) {
			$content[] = $new_element;
		} else {
			$content = array( $new_element );
		}

		// Inject updated content back.
		$result = $builder->inject_content( $post_id, $content );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Log action.
		$key_data = $request->get_param( '_respira_key_data' );
		if ( $key_data && class_exists( 'Respira_Auth' ) ) {
			Respira_Auth::log_action(
				isset( $key_data['id'] ) ? $key_data['id'] : 0,
				isset( $key_data['user_id'] ) ? $key_data['user_id'] : 0,
				'widget_shortcut_' . $shortcut_name,
				'widget_shortcuts',
				$post_id
			);
		}

		return new WP_REST_Response(
			array(
				'success'  => true,
				'shortcut' => $shortcut_name,
				'widget'   => $shortcut['widget'],
				'post_id'  => $post_id,
				'message'  => sprintf(
					__( 'Widget "%s" added to page %d.', 'respira-for-wordpress' ),
					$shortcut['widget'],
					$post_id
				),
			),
			201
		);
	}

	/**
	 * REST endpoint to return the shortcut registry.
	 *
	 * @since 5.2.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_registry_endpoint( $request ) {
		return new WP_REST_Response(
			array(
				'shortcuts' => self::get_registry(),
			),
			200
		);
	}

	/**
	 * Get the full shortcut registry.
	 *
	 * @since 5.2.0
	 * @return array
	 */
	public static function get_registry() {
		return self::$shortcuts;
	}

	/**
	 * Map a generic widget name to a builder-native type name.
	 *
	 * @since 5.2.0
	 * @param string                   $widget  Generic widget name.
	 * @param Respira_Builder_Interface $builder Builder instance.
	 * @return string Builder-native type name.
	 */
	private function map_widget_to_builder( $widget, $builder ) {
		$builder_name = strtolower( $builder->get_name() );

		$gutenberg_map = array(
			'heading'     => 'core/heading',
			'text-editor' => 'core/paragraph',
			'button'      => 'core/button',
			'image'       => 'core/image',
			'video'       => 'core/video',
			'divider'     => 'core/separator',
			'spacer'      => 'core/spacer',
			'html'        => 'core/html',
			'gallery'     => 'core/gallery',
			'icon-list'   => 'core/list',
			'section'     => 'core/group',
			'columns'     => 'core/columns',
			'accordion'   => 'core/details',
			'search-form' => 'core/search',
		);

		$elementor_map = array(
			'heading'     => 'heading',
			'text-editor' => 'text-editor',
			'button'      => 'button',
			'image'       => 'image',
			'video'       => 'video',
			'divider'     => 'divider',
			'spacer'      => 'spacer',
			'html'        => 'html',
		);

		if ( 'gutenberg' === $builder_name ) {
			// Map known widgets or fall back to core/html for complex widgets.
			return isset( $gutenberg_map[ $widget ] ) ? $gutenberg_map[ $widget ] : 'core/html';
		}

		return $widget;
	}

	/**
	 * Build widget content string from settings (for builders that store content as innerHTML).
	 *
	 * @since 5.2.0
	 * @param string                   $widget   Generic widget name.
	 * @param array                    $settings Widget settings.
	 * @param Respira_Builder_Interface $builder  Builder instance.
	 * @return string Content string.
	 */
	private function build_widget_content( $widget, $settings, $builder ) {
		$builder_name = strtolower( $builder->get_name() );

		if ( 'gutenberg' !== $builder_name ) {
			return '';
		}

		switch ( $widget ) {
			case 'heading':
				$tag  = isset( $settings['tag'] ) ? $settings['tag'] : 'h2';
				$text = isset( $settings['title'] ) ? esc_html( $settings['title'] ) : '';
				return "<{$tag}>{$text}</{$tag}>";

			case 'text-editor':
				return isset( $settings['content'] ) ? wp_kses_post( $settings['content'] ) : '';

			case 'button':
				$text = isset( $settings['text'] ) ? esc_html( $settings['text'] ) : '';
				$url  = isset( $settings['url'] ) ? esc_url( $settings['url'] ) : '#';
				return "<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"{$url}\">{$text}</a></div>";

			case 'html':
				return isset( $settings['content'] ) ? $settings['content'] : '';

			default:
				return '';
		}
	}

	/**
	 * Get JSON Schema for a specific shortcut's parameters.
	 *
	 * @since 5.2.0
	 * @param string $name Shortcut name.
	 * @return array|null JSON Schema or null if not found.
	 */
	public static function get_shortcut_schema( $name ) {
		if ( ! isset( self::$shortcuts[ $name ] ) ) {
			return null;
		}

		$shortcut   = self::$shortcuts[ $name ];
		$properties = array();
		$required   = array();

		foreach ( $shortcut['required'] as $param ) {
			$properties[ $param ] = array( 'type' => 'string' );
			$required[] = $param;
		}

		foreach ( $shortcut['optional'] as $param => $default ) {
			$type = 'string';
			if ( is_bool( $default ) ) {
				$type = 'boolean';
			} elseif ( is_int( $default ) ) {
				$type = 'integer';
			} elseif ( is_array( $default ) ) {
				$type = 'array';
			}

			$properties[ $param ] = array(
				'type'    => $type,
				'default' => $default,
			);
		}

		return array(
			'type'       => 'object',
			'properties' => $properties,
			'required'   => $required,
		);
	}
}
