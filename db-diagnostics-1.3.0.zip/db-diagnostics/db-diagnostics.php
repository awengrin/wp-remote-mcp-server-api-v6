<?php
/**
 * Plugin Name: DB Diagnostics
 * Plugin URI: https://digitalberry.sk
 * Description: REST API diagnostický plugin pre Digital Berry support workflow. Poskytuje error log, plugin konflikty, site health, plugin nastavenia audit, databázový health check a akčné endpointy (cache purge, WooCommerce maintenance).
 * Version: 1.3.0
 * Author: Digital Berry s.r.o.
 * Author URI: https://digitalberry.sk
 * License: Proprietary
 * Text Domain: db-diagnostics
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DB_DIAG_VERSION', '1.3.0' );
define( 'DB_DIAG_NAMESPACE', 'db-diag/v1' );

/**
 * Permission check — admin only via Application Password
 */
function db_diag_permission_check( $request ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error(
            'rest_forbidden',
            'Prístup zamietnutý. Vyžaduje sa admin rola.',
            array( 'status' => 403 )
        );
    }
    return true;
}

/**
 * Audit log — zapisuje každú akciu do vlastnej tabuľky
 */
function db_diag_log_action( $action, $details = '', $result = 'success' ) {
    $log_file = WP_CONTENT_DIR . '/db-diag-audit.log';
    $entry = sprintf(
        "[%s] User: %s | Action: %s | Result: %s | Details: %s\n",
        current_time( 'mysql' ),
        wp_get_current_user()->user_login ?? 'unknown',
        $action,
        $result,
        $details
    );
    file_put_contents( $log_file, $entry, FILE_APPEND | LOCK_EX );
}

// ============================================================
// REGISTER ALL REST ROUTES
// ============================================================

add_action( 'rest_api_init', function() {

    // --- ENDPOINT 1: Error Log ---
    register_rest_route( DB_DIAG_NAMESPACE, '/error-log', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_error_log',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'lines' => array(
                'default'           => 100,
                'sanitize_callback' => 'absint',
            ),
            'severity' => array(
                'default'           => 'all',
                'sanitize_callback' => 'sanitize_text_field',
            ),
        ),
    ));

    // --- ENDPOINT 2: Plugin Conflicts ---
    register_rest_route( DB_DIAG_NAMESPACE, '/plugin-conflicts', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_plugin_conflicts',
        'permission_callback' => 'db_diag_permission_check',
    ));

    // --- ENDPOINT 3: Site Health ---
    register_rest_route( DB_DIAG_NAMESPACE, '/site-health', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_site_health',
        'permission_callback' => 'db_diag_permission_check',
    ));

    // --- ENDPOINT 4: Plugin Settings Audit ---
    register_rest_route( DB_DIAG_NAMESPACE, '/plugin-settings', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_plugin_settings',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'plugin' => array(
                'default'           => 'all',
                'sanitize_callback' => 'sanitize_text_field',
            ),
        ),
    ));

    // --- ENDPOINT 5: Database Health Check ---
    register_rest_route( DB_DIAG_NAMESPACE, '/database', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_database',
        'permission_callback' => 'db_diag_permission_check',
    ));

    // --- ENDPOINT 6: Cache & Regeneration Actions ---
    register_rest_route( DB_DIAG_NAMESPACE, '/action/cache', array(
        'methods'             => 'POST',
        'callback'            => 'db_diag_action_cache',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'target' => array(
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'post_id' => array(
                'default'           => 0,
                'sanitize_callback' => 'absint',
            ),
        ),
    ));

    // --- ENDPOINT 7: WooCommerce Maintenance Actions ---
    register_rest_route( DB_DIAG_NAMESPACE, '/action/woocommerce', array(
        'methods'             => 'POST',
        'callback'            => 'db_diag_action_woocommerce',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'action' => array(
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'confirm' => array(
                'default'           => false,
                'sanitize_callback' => 'rest_sanitize_boolean',
            ),
            'days' => array(
                'default'           => 7,
                'sanitize_callback' => 'absint',
            ),
        ),
    ));

    // --- Audit Log (read) ---
    register_rest_route( DB_DIAG_NAMESPACE, '/audit-log', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_audit_log',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'lines' => array(
                'default'           => 50,
                'sanitize_callback' => 'absint',
            ),
        ),
    ));

    // --- ENDPOINT 8: Autoload Analysis ---
    register_rest_route( DB_DIAG_NAMESPACE, '/autoload-analysis', array(
        'methods'             => 'GET',
        'callback'            => 'db_diag_autoload_analysis',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'limit' => array(
                'default'           => 50,
                'sanitize_callback' => 'absint',
            ),
        ),
    ));

    // --- ENDPOINT 9: Autoload Optimize ---
    register_rest_route( DB_DIAG_NAMESPACE, '/autoload-optimize', array(
        'methods'             => 'POST',
        'callback'            => 'db_diag_autoload_optimize',
        'permission_callback' => 'db_diag_permission_check',
        'args' => array(
            'action' => array(
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'enum'              => array( 'disable', 'enable', 'delete-transients' ),
            ),
            'options' => array(
                'default'           => array(),
                'sanitize_callback' => function( $val ) {
                    if ( is_string( $val ) ) {
                        $val = json_decode( $val, true );
                    }
                    return is_array( $val ) ? array_map( 'sanitize_text_field', $val ) : array();
                },
            ),
        ),
    ));

    // --- ENDPOINT 10: Orphaned Postmeta ---
    register_rest_route( DB_DIAG_NAMESPACE, '/orphaned-postmeta', array(
        array(
            'methods'             => 'GET',
            'callback'            => 'db_diag_orphaned_postmeta_analyze',
            'permission_callback' => 'db_diag_permission_check',
        ),
        array(
            'methods'             => 'POST',
            'callback'            => 'db_diag_orphaned_postmeta_clean',
            'permission_callback' => 'db_diag_permission_check',
            'args' => array(
                'confirm' => array(
                    'required'          => true,
                    'sanitize_callback' => 'rest_sanitize_boolean',
                ),
                'limit' => array(
                    'default'           => 1000,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ),
    ));
});

// ============================================================
// ENDPOINT 1: ERROR LOG
// ============================================================

function db_diag_error_log( $request ) {
    $lines    = min( $request->get_param( 'lines' ), 500 );
    $severity = $request->get_param( 'severity' );

    // Check if debug logging is enabled
    $debug_enabled = defined( 'WP_DEBUG' ) && WP_DEBUG;
    $log_enabled   = defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG;

    $log_path = WP_CONTENT_DIR . '/debug.log';
    if ( is_string( WP_DEBUG_LOG ) ) {
        $log_path = WP_DEBUG_LOG;
    }

    if ( ! $debug_enabled || ! $log_enabled ) {
        return rest_ensure_response( array(
            'status'        => 'disabled',
            'message'       => 'WP_DEBUG alebo WP_DEBUG_LOG nie je zapnuté v wp-config.php',
            'wp_debug'      => $debug_enabled,
            'wp_debug_log'  => $log_enabled,
            'entries'       => array(),
        ));
    }

    if ( ! file_exists( $log_path ) ) {
        return rest_ensure_response( array(
            'status'   => 'empty',
            'message'  => 'debug.log súbor neexistuje — žiadne chyby neboli zaznamenané',
            'log_path' => $log_path,
            'entries'  => array(),
        ));
    }

    // Read last N lines efficiently
    $file_content = file_get_contents( $log_path );
    $all_lines    = array_filter( explode( "\n", $file_content ) );
    $tail_lines   = array_slice( $all_lines, -$lines );

    // Parse and filter by severity
    $entries        = array();
    $severity_map   = array(
        'fatal'      => array( 'Fatal error', 'Fatal Error', 'Uncaught Error', 'Uncaught Exception' ),
        'warning'    => array( 'Warning', 'PHP Warning' ),
        'notice'     => array( 'Notice', 'PHP Notice' ),
        'deprecated' => array( 'Deprecated', 'PHP Deprecated' ),
    );

    foreach ( $tail_lines as $line ) {
        $line = trim( $line );
        if ( empty( $line ) ) continue;

        $entry_severity = 'other';
        foreach ( $severity_map as $sev => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( stripos( $line, $pattern ) !== false ) {
                    $entry_severity = $sev;
                    break 2;
                }
            }
        }

        if ( $severity !== 'all' && $entry_severity !== $severity ) {
            continue;
        }

        $entries[] = array(
            'severity' => $entry_severity,
            'message'  => mb_substr( $line, 0, 500 ),
        );
    }

    // Summary
    $summary = array_count_values( array_column( $entries, 'severity' ) );

    return rest_ensure_response( array(
        'status'      => 'active',
        'log_path'    => $log_path,
        'file_size'   => size_format( filesize( $log_path ) ),
        'total_lines' => count( $all_lines ),
        'returned'    => count( $entries ),
        'summary'     => $summary,
        'entries'     => $entries,
    ));
}

// ============================================================
// ENDPOINT 2: PLUGIN CONFLICTS
// ============================================================

function db_diag_plugin_conflicts( $request ) {
    if ( ! function_exists( 'get_plugins' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $all_plugins    = get_plugins();
    $active_plugins = get_option( 'active_plugins', array() );
    $active_data    = array();

    foreach ( $active_plugins as $plugin_file ) {
        if ( isset( $all_plugins[ $plugin_file ] ) ) {
            $active_data[ $plugin_file ] = $all_plugins[ $plugin_file ];
        }
    }

    $conflicts = array();
    $warnings  = array();
    $outdated  = array();

    // --- Known conflict patterns ---
    $conflict_rules = array(
        array(
            'plugins'     => array( 'wp-rocket', 'elementor' ),
            'description' => 'WP Rocket + Elementor: Delay JS Execution alebo Defer JS môže rozbiť Elementor frontend interakcie. Skontroluj exclude list pre elementor-frontend a elementor-pro-frontend JS súbory.',
        ),
        array(
            'plugins'     => array( 'wp-rocket', 'woocommerce' ),
            'description' => 'WP Rocket + WooCommerce: Lazy load obrázkov môže rozbiť produktové galérie. Minifikácia JS môže rozbiť checkout. Skontroluj exclude listy.',
        ),
        array(
            'plugins'     => array( 'autoptimize', 'woocommerce' ),
            'description' => 'Autoptimize + WooCommerce: Inline script agregácia môže rozbiť WC cart fragments a checkout JS.',
        ),
        array(
            'plugins'     => array( 'autoptimize', 'elementor' ),
            'description' => 'Autoptimize + Elementor: CSS/JS optimalizácia môže kolidovať s Elementor asset loading.',
        ),
        array(
            'plugins'     => array( 'litespeed-cache', 'wp-rocket' ),
            'description' => 'LiteSpeed Cache + WP Rocket: Dva plnohodnotné caching pluginy — duplicitná cache, nepredvídateľné správanie. Použi len jeden.',
        ),
        array(
            'plugins'     => array( 'w3-total-cache', 'wp-rocket' ),
            'description' => 'W3 Total Cache + WP Rocket: Duplicitný caching systém. Deaktivuj jeden.',
        ),
        array(
            'plugins'     => array( 'wp-super-cache', 'wp-rocket' ),
            'description' => 'WP Super Cache + WP Rocket: Duplicitný page cache. Deaktivuj jeden.',
        ),
        array(
            'plugins'     => array( 'wordpress-seo', 'seo-by-rank-math' ),
            'description' => 'Yoast SEO + RankMath: Dva SEO pluginy — duplicitné meta tagy, schema markup konflikty.',
        ),
        array(
            'plugins'     => array( 'wordpress-seo', 'all-in-one-seo-pack' ),
            'description' => 'Yoast SEO + All in One SEO: Duplicitné SEO meta tagy a sitemaps.',
        ),
    );

    $active_slugs = array();
    foreach ( $active_plugins as $pf ) {
        $slug = dirname( $pf );
        if ( $slug === '.' ) {
            $slug = str_replace( '.php', '', $pf );
        }
        $active_slugs[] = $slug;
    }

    foreach ( $conflict_rules as $rule ) {
        $matched = array_intersect( $rule['plugins'], $active_slugs );
        if ( count( $matched ) === count( $rule['plugins'] ) ) {
            $conflicts[] = $rule['description'];
        }
    }

    // --- Duplicate functionality detection ---
    $functionality_groups = array(
        'caching'   => array( 'wp-rocket', 'w3-total-cache', 'wp-super-cache', 'litespeed-cache', 'wp-fastest-cache', 'sg-cachepress', 'breeze', 'hummingbird-performance' ),
        'seo'       => array( 'wordpress-seo', 'seo-by-rank-math', 'all-in-one-seo-pack', 'squirrly-seo' ),
        'lazyload'  => array( 'a3-lazy-load', 'rocket-lazy-load', 'lazy-load-optimizer', 'smush-wp' ),
        'security'  => array( 'wordfence', 'sucuri-scanner', 'ithemes-security', 'all-in-one-wp-security-and-firewall' ),
        'minify'    => array( 'autoptimize', 'fast-velocity-minify', 'merge-minify-refresh' ),
    );

    foreach ( $functionality_groups as $func => $group_slugs ) {
        $active_in_group = array_intersect( $group_slugs, $active_slugs );
        if ( count( $active_in_group ) > 1 ) {
            $warnings[] = sprintf(
                'Duplicitná funkcionalita (%s): %s — aktívne %d pluginy s rovnakou funkciou. Odporúčame ponechať iba jeden.',
                $func,
                implode( ', ', $active_in_group ),
                count( $active_in_group )
            );
        }
    }

    // --- Outdated plugins (not updated >90 days) ---
    $update_plugins = get_site_transient( 'update_plugins' );
    if ( $update_plugins && ! empty( $update_plugins->response ) ) {
        foreach ( $update_plugins->response as $plugin_file => $update_info ) {
            if ( isset( $active_data[ $plugin_file ] ) ) {
                $outdated[] = array(
                    'plugin'          => $active_data[ $plugin_file ]['Name'],
                    'current_version' => $active_data[ $plugin_file ]['Version'],
                    'new_version'     => $update_info->new_version ?? 'unknown',
                    'slug'            => $update_info->slug ?? dirname( $plugin_file ),
                );
            }
        }
    }

    return rest_ensure_response( array(
        'active_plugins_count' => count( $active_plugins ),
        'conflicts'            => $conflicts,
        'conflicts_count'      => count( $conflicts ),
        'warnings'             => $warnings,
        'warnings_count'       => count( $warnings ),
        'outdated_plugins'     => $outdated,
        'outdated_count'       => count( $outdated ),
    ));
}

// ============================================================
// ENDPOINT 3: SITE HEALTH
// ============================================================

function db_diag_site_health( $request ) {
    global $wpdb;

    $data = array(
        'wordpress' => array(
            'version'        => get_bloginfo( 'version' ),
            'site_url'       => get_site_url(),
            'home_url'       => get_home_url(),
            'multisite'      => is_multisite(),
            'locale'         => get_locale(),
            'timezone'       => wp_timezone_string(),
            'permalink'      => get_option( 'permalink_structure' ) ?: 'Plain',
            'debug_mode'     => defined( 'WP_DEBUG' ) && WP_DEBUG,
            'debug_log'      => defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG,
            'cron_enabled'   => ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ),
            'memory_limit'   => defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : 'default',
            'max_memory'     => defined( 'WP_MAX_MEMORY_LIMIT' ) ? WP_MAX_MEMORY_LIMIT : 'default',
        ),
        'php' => array(
            'version'            => phpversion(),
            'memory_limit'       => ini_get( 'memory_limit' ),
            'max_execution_time' => ini_get( 'max_execution_time' ),
            'upload_max_size'    => ini_get( 'upload_max_filesize' ),
            'post_max_size'      => ini_get( 'post_max_size' ),
            'opcache_enabled'    => function_exists( 'opcache_get_status' ) && opcache_get_status() !== false,
            'extensions'         => get_loaded_extensions(),
        ),
        'database' => array(
            'server'     => $wpdb->db_server_info(),
            'name'       => $wpdb->dbname,
            'prefix'     => $wpdb->prefix,
            'charset'    => $wpdb->charset,
        ),
        'server' => array(
            'software'       => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
            'https'          => is_ssl(),
            'php_sapi'       => php_sapi_name(),
        ),
        'theme' => array(
            'name'        => wp_get_theme()->get( 'Name' ),
            'version'     => wp_get_theme()->get( 'Version' ),
            'parent'      => wp_get_theme()->parent() ? wp_get_theme()->parent()->get( 'Name' ) : null,
            'template'    => get_template(),
        ),
        'disk' => array(
            'uploads_dir'  => wp_upload_dir()['basedir'],
            'uploads_size' => db_diag_dir_size( wp_upload_dir()['basedir'] ),
            'content_size' => db_diag_dir_size( WP_CONTENT_DIR ),
        ),
        'rest_api' => array(
            'available' => true,
            'url'       => get_rest_url(),
        ),
    );

    // Cron check
    $cron_jobs  = _get_cron_array();
    $next_cron  = $cron_jobs ? min( array_keys( $cron_jobs ) ) : 0;
    $data['cron'] = array(
        'total_events' => $cron_jobs ? array_sum( array_map( 'count', $cron_jobs ) ) : 0,
        'next_run'     => $next_cron ? date( 'Y-m-d H:i:s', $next_cron ) : 'N/A',
        'overdue'      => $next_cron && $next_cron < time(),
    );

    return rest_ensure_response( $data );
}

function db_diag_dir_size( $dir ) {
    if ( ! is_dir( $dir ) ) return 'N/A';
    $size = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ( $iterator as $file ) {
        if ( $file->isFile() ) {
            $size += $file->getSize();
        }
    }
    return size_format( $size );
}

// ============================================================
// ENDPOINT 4: PLUGIN SETTINGS AUDIT
// ============================================================

function db_diag_plugin_settings( $request ) {
    $plugin = $request->get_param( 'plugin' );
    // Normalize: accept both wp_rocket and wp-rocket formats
    if ( $plugin !== 'all' ) {
        $plugin = str_replace( '_', '-', $plugin );
    }
    $result = array();

    // WP Rocket
    if ( $plugin === 'all' || $plugin === 'wp-rocket' ) {
        $rocket = get_option( 'wp_rocket_settings', array() );
        if ( ! empty( $rocket ) ) {
            $result['wp_rocket'] = array(
                'active'                => true,
                'minify_css'            => ! empty( $rocket['minify_css'] ),
                'minify_js'             => ! empty( $rocket['minify_js'] ),
                'minify_concatenate_css'=> ! empty( $rocket['minify_concatenate_css'] ),
                'minify_concatenate_js' => ! empty( $rocket['minify_concatenate_js'] ),
                'defer_all_js'          => ! empty( $rocket['defer_all_js'] ),
                'delay_js'              => ! empty( $rocket['delay_js'] ),
                'delay_js_exclusions'   => $rocket['delay_js_exclusions'] ?? array(),
                'lazyload'              => ! empty( $rocket['lazyload'] ),
                'lazyload_iframes'      => ! empty( $rocket['lazyload_iframes'] ),
                'lazyload_youtube'      => ! empty( $rocket['lazyload_youtube'] ),
                'cdn'                   => ! empty( $rocket['cdn'] ),
                'cdn_cnames'            => $rocket['cdn_cnames'] ?? array(),
                'cache_mobile'          => ! empty( $rocket['cache_mobile'] ),
                'do_caching_mobile_files' => ! empty( $rocket['do_caching_mobile_files'] ),
                'preload'               => ! empty( $rocket['manual_preload'] ),
                'exclude_js'            => $rocket['exclude_js'] ?? array(),
                'exclude_css'           => $rocket['exclude_css'] ?? array(),
            );
        } else {
            $result['wp_rocket'] = array( 'active' => false );
        }
    }

    // WooCommerce
    if ( $plugin === 'all' || $plugin === 'woocommerce' ) {
        if ( class_exists( 'WooCommerce' ) ) {
            $result['woocommerce'] = array(
                'active'             => true,
                'version'            => defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown',
                'cart_page_id'       => get_option( 'woocommerce_cart_page_id' ),
                'cart_page_exists'   => get_post_status( get_option( 'woocommerce_cart_page_id' ) ) === 'publish',
                'checkout_page_id'   => get_option( 'woocommerce_checkout_page_id' ),
                'checkout_page_exists' => get_post_status( get_option( 'woocommerce_checkout_page_id' ) ) === 'publish',
                'myaccount_page_id'  => get_option( 'woocommerce_myaccount_page_id' ),
                'myaccount_page_exists' => get_post_status( get_option( 'woocommerce_myaccount_page_id' ) ) === 'publish',
                'terms_page_id'      => get_option( 'woocommerce_terms_page_id' ),
                'currency'           => get_option( 'woocommerce_currency' ),
                'calc_taxes'         => get_option( 'woocommerce_calc_taxes' ),
                'enable_coupons'     => get_option( 'woocommerce_enable_coupons' ),
                'hpos_enabled'       => db_diag_wc_hpos_enabled(),
                'active_gateways'    => db_diag_wc_active_gateways(),
            );
        } else {
            $result['woocommerce'] = array( 'active' => false );
        }
    }

    // Elementor
    if ( $plugin === 'all' || $plugin === 'elementor' ) {
        if ( defined( 'ELEMENTOR_VERSION' ) ) {
            $result['elementor'] = array(
                'active'                   => true,
                'version'                  => ELEMENTOR_VERSION,
                'pro_active'               => defined( 'ELEMENTOR_PRO_VERSION' ),
                'pro_version'              => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null,
                'css_print_method'         => get_option( 'elementor_css_print_method', 'external' ),
                'optimized_dom'            => get_option( 'elementor_experiment-e_dom_optimization', '' ),
                'improved_assets_loading'   => get_option( 'elementor_experiment-e_optimized_assets_loading', '' ),
                'font_display'             => get_option( 'elementor_font_display', 'auto' ),
                'google_font'              => get_option( 'elementor_google_font', '1' ),
            );
        } else {
            $result['elementor'] = array( 'active' => false );
        }
    }

    // Yoast SEO
    if ( $plugin === 'all' || $plugin === 'yoast' ) {
        $wpseo = get_option( 'wpseo', array() );
        if ( ! empty( $wpseo ) ) {
            $result['yoast'] = array(
                'active'           => true,
                'version'          => $wpseo['version'] ?? 'unknown',
                'enable_xml_sitemap' => get_option( 'wpseo_xml', array() ),
                'disableadvanced_meta' => $wpseo['disableadvanced_meta'] ?? null,
                'enable_text_link_counter' => $wpseo['enable_text_link_counter'] ?? null,
            );
        } else {
            $result['yoast'] = array( 'active' => false );
        }
    }

    // RankMath
    if ( $plugin === 'all' || $plugin === 'rankmath' ) {
        if ( class_exists( 'RankMath' ) ) {
            $result['rankmath'] = array(
                'active'  => true,
                'version' => defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : 'unknown',
            );
        } else {
            $result['rankmath'] = array( 'active' => false );
        }
    }

    return rest_ensure_response( $result );
}

function db_diag_wc_hpos_enabled() {
    if ( ! class_exists( 'Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
        return 'unknown';
    }
    try {
        return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    } catch ( \Exception $e ) {
        return 'error';
    }
}

function db_diag_wc_active_gateways() {
    if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
        return array();
    }
    $gateways = WC()->payment_gateways()->get_available_payment_gateways();
    $result   = array();
    foreach ( $gateways as $id => $gw ) {
        $result[] = array(
            'id'      => $id,
            'title'   => $gw->get_title(),
            'enabled' => $gw->is_available(),
        );
    }
    return $result;
}

// ============================================================
// ENDPOINT 5: DATABASE HEALTH CHECK
// ============================================================

function db_diag_database( $request ) {
    global $wpdb;

    // wp_options analysis
    $options_total    = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options}" );
    $autoload_size    = $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload = 'yes'" );
    $autoload_count   = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options} WHERE autoload = 'yes'" );
    $transient_count  = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '%_transient_%'" );
    $expired_transients = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->options} o1
         JOIN {$wpdb->options} o2 ON o2.option_name = CONCAT('_transient_timeout_', SUBSTRING(o1.option_name, 12))
         WHERE o1.option_name LIKE '_transient_%'
         AND o1.option_name NOT LIKE '_transient_timeout_%'
         AND o2.option_value < UNIX_TIMESTAMP()"
    );

    // Post revisions
    $revisions_count = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" );

    // Postmeta
    $postmeta_count = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta}" );
    $orphaned_meta  = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL"
    );

    // Table sizes
    $tables = $wpdb->get_results(
        "SELECT table_name, ROUND(data_length/1024/1024, 2) as data_mb,
                ROUND(index_length/1024/1024, 2) as index_mb
         FROM information_schema.tables
         WHERE table_schema = '{$wpdb->dbname}'
         ORDER BY data_length DESC
         LIMIT 20"
    );

    $table_sizes = array();
    foreach ( $tables as $t ) {
        $table_sizes[] = array(
            'table'    => $t->table_name,
            'data_mb'  => floatval( $t->data_mb ),
            'index_mb' => floatval( $t->index_mb ),
        );
    }

    // WooCommerce specific
    $wc_data = array();
    if ( class_exists( 'WooCommerce' ) ) {
        $wc_sessions = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_sessions"
        );
        $wc_expired_sessions = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_sessions
             WHERE session_expiry < UNIX_TIMESTAMP()"
        );

        // Orphaned variations
        $orphaned_variations = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} v
             LEFT JOIN {$wpdb->posts} p ON v.post_parent = p.ID
             WHERE v.post_type = 'product_variation'
             AND (p.ID IS NULL OR p.post_type != 'product')"
        );

        $wc_data = array(
            'sessions_total'       => intval( $wc_sessions ),
            'sessions_expired'     => intval( $wc_expired_sessions ),
            'orphaned_variations'  => intval( $orphaned_variations ),
        );
    }

    return rest_ensure_response( array(
        'wp_options' => array(
            'total_options'       => intval( $options_total ),
            'autoload_count'      => intval( $autoload_count ),
            'autoload_size'       => size_format( $autoload_size ),
            'autoload_size_bytes' => intval( $autoload_size ),
            'transient_count'     => intval( $transient_count ),
            'expired_transients'  => intval( $expired_transients ),
            'autoload_warning'    => $autoload_size > 1048576, // > 1MB
        ),
        'posts' => array(
            'revisions_count' => intval( $revisions_count ),
            'postmeta_count'  => intval( $postmeta_count ),
            'orphaned_meta'   => intval( $orphaned_meta ),
        ),
        'woocommerce'  => $wc_data,
        'largest_tables' => $table_sizes,
    ));
}

// ============================================================
// ENDPOINT 6: CACHE & REGENERATION ACTIONS
// ============================================================

function db_diag_action_cache( $request ) {
    $target  = $request->get_param( 'target' );
    $post_id = $request->get_param( 'post_id' );
    $results = array();

    $actions = ( $target === 'all-cache' )
        ? array( 'wp-rocket-purge', 'elementor-css', 'autoptimize-purge', 'litespeed-purge', 'object-cache-flush', 'transient-cleanup' )
        : array( $target );

    foreach ( $actions as $act ) {
        switch ( $act ) {
            case 'wp-rocket-purge':
                if ( function_exists( 'rocket_clean_domain' ) ) {
                    rocket_clean_domain();
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'WP Rocket cache vymazaný' );
                    db_diag_log_action( $act, 'Full domain cache purge' );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'WP Rocket nie je aktívny' );
                }
                break;

            case 'wp-rocket-purge-page':
                if ( function_exists( 'rocket_clean_post' ) && $post_id > 0 ) {
                    rocket_clean_post( $post_id );
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => "Cache stránky #{$post_id} vymazaný" );
                    db_diag_log_action( $act, "Post ID: {$post_id}" );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'WP Rocket nie je aktívny alebo chýba post_id' );
                }
                break;

            case 'wp-rocket-preload':
                if ( function_exists( 'run_rocket_bot' ) ) {
                    run_rocket_bot();
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'WP Rocket preload spustený' );
                    db_diag_log_action( $act );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'WP Rocket preload nie je dostupný' );
                }
                break;

            case 'elementor-css':
                if ( defined( 'ELEMENTOR_VERSION' ) && class_exists( '\Elementor\Plugin' ) ) {
                    \Elementor\Plugin::instance()->files_manager->clear_cache();
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'Elementor CSS cache vymazaný a regenerovaný' );
                    db_diag_log_action( $act );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'Elementor nie je aktívny' );
                }
                break;

            case 'elementor-data':
                if ( defined( 'ELEMENTOR_VERSION' ) && class_exists( '\Elementor\Plugin' ) ) {
                    delete_post_meta_by_key( '_elementor_css' );
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'Elementor data cache vymazaný' );
                    db_diag_log_action( $act );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'Elementor nie je aktívny' );
                }
                break;

            case 'autoptimize-purge':
                if ( class_exists( 'autoptimizeCache' ) ) {
                    \autoptimizeCache::clearall();
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'Autoptimize cache vymazaný' );
                    db_diag_log_action( $act );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'Autoptimize nie je aktívny' );
                }
                break;

            case 'litespeed-purge':
                if ( class_exists( 'LiteSpeed\Purge' ) ) {
                    do_action( 'litespeed_purge_all' );
                    $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'LiteSpeed cache vymazaný' );
                    db_diag_log_action( $act );
                } else {
                    $results[] = array( 'action' => $act, 'status' => 'skipped', 'message' => 'LiteSpeed nie je aktívny' );
                }
                break;

            case 'object-cache-flush':
                $flushed = wp_cache_flush();
                $results[] = array( 'action' => $act, 'status' => $flushed ? 'success' : 'failed', 'message' => $flushed ? 'Object cache flushed' : 'Object cache flush failed' );
                db_diag_log_action( $act, '', $flushed ? 'success' : 'failed' );
                break;

            case 'permalink-flush':
                flush_rewrite_rules();
                $results[] = array( 'action' => $act, 'status' => 'success', 'message' => 'Rewrite rules flushed — rieši 404 chyby po zmene URL štruktúry' );
                db_diag_log_action( $act );
                break;

            case 'transient-cleanup':
                global $wpdb;
                $deleted = $wpdb->query(
                    "DELETE a, b FROM {$wpdb->options} a
                     INNER JOIN {$wpdb->options} b ON b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
                     WHERE a.option_name LIKE '_transient_%'
                     AND a.option_name NOT LIKE '_transient_timeout_%'
                     AND b.option_value < UNIX_TIMESTAMP()"
                );
                $results[] = array( 'action' => $act, 'status' => 'success', 'message' => "Vymazaných {$deleted} expirovaných transientov" );
                db_diag_log_action( $act, "Deleted: {$deleted}" );
                break;

            default:
                $results[] = array( 'action' => $act, 'status' => 'error', 'message' => "Neznáma akcia: {$act}" );
        }
    }

    return rest_ensure_response( array(
        'timestamp' => current_time( 'mysql' ),
        'results'   => $results,
    ));
}

// ============================================================
// ENDPOINT 7: WOOCOMMERCE MAINTENANCE ACTIONS
// ============================================================

function db_diag_action_woocommerce( $request ) {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return rest_ensure_response( array(
            'status'  => 'error',
            'message' => 'WooCommerce nie je aktívny na tejto stránke.',
        ));
    }

    global $wpdb;
    $action  = $request->get_param( 'action' );
    $confirm = $request->get_param( 'confirm' );
    $days    = $request->get_param( 'days' );

    // Actions that require confirmation
    $destructive_actions = array(
        'delete-orphaned-variations',
        'delete-orphaned-product-meta',
        'cleanup-draft-orders',
        'cleanup-trash-orders',
        'update-db',
        'optimize-tables',
    );

    if ( in_array( $action, $destructive_actions ) && ! $confirm ) {
        return rest_ensure_response( array(
            'status'  => 'confirmation_required',
            'action'  => $action,
            'message' => "Táto akcia vyžaduje potvrdenie. Pošli parameter confirm=true pre vykonanie.",
        ));
    }

    $result = array( 'action' => $action, 'timestamp' => current_time( 'mysql' ) );

    switch ( $action ) {

        // --- Transients & Cache ---
        case 'clear-transients':
            wc_delete_product_transients();
            if ( function_exists( 'wc_delete_shop_order_transients' ) ) {
                wc_delete_shop_order_transients();
            }
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wc_%'" );
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wc_%'" );
            $result['status']  = 'success';
            $result['message'] = 'Všetky WooCommerce transienty vymazané';
            db_diag_log_action( 'wc-clear-transients' );
            break;

        case 'clear-expired-transients':
            if ( function_exists( 'wc_delete_expired_transients' ) ) {
                wc_delete_expired_transients();
            }
            $result['status']  = 'success';
            $result['message'] = 'Expirované WC transienty vymazané';
            db_diag_log_action( 'wc-clear-expired-transients' );
            break;

        case 'clear-session-data':
            $deleted = $wpdb->query(
                "DELETE FROM {$wpdb->prefix}woocommerce_sessions WHERE session_expiry < UNIX_TIMESTAMP()"
            );
            $result['status']  = 'success';
            $result['deleted'] = intval( $deleted );
            $result['message'] = "Vymazaných {$deleted} expirovaných customer sessions";
            db_diag_log_action( 'wc-clear-sessions', "Deleted: {$deleted}" );
            break;

        case 'clear-template-cache':
            $template_transients = $wpdb->query(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wc_template_%'"
            );
            $result['status']  = 'success';
            $result['message'] = 'WC template cache vymazaný';
            db_diag_log_action( 'wc-clear-template-cache' );
            break;

        // --- Products & Database ---
        case 'delete-orphaned-variations':
            $orphans = $wpdb->get_col(
                "SELECT v.ID FROM {$wpdb->posts} v
                 LEFT JOIN {$wpdb->posts} p ON v.post_parent = p.ID
                 WHERE v.post_type = 'product_variation'
                 AND (p.ID IS NULL OR p.post_type != 'product')"
            );
            $count = count( $orphans );
            foreach ( $orphans as $orphan_id ) {
                wp_delete_post( $orphan_id, true );
            }
            $result['status']  = 'success';
            $result['deleted'] = $count;
            $result['message'] = "Vymazaných {$count} osirotených variácií";
            db_diag_log_action( 'wc-delete-orphaned-variations', "Deleted: {$count}" );
            break;

        case 'delete-orphaned-product-meta':
            $deleted = $wpdb->query(
                "DELETE pm FROM {$wpdb->postmeta} pm
                 LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE p.ID IS NULL"
            );
            $result['status']  = 'success';
            $result['deleted'] = intval( $deleted );
            $result['message'] = "Vymazaných {$deleted} osirotených meta záznamov";
            db_diag_log_action( 'wc-delete-orphaned-meta', "Deleted: {$deleted}" );
            break;

        case 'recount-terms':
            $product_cats = get_terms( array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
                'fields'     => 'ids',
            ));
            if ( ! is_wp_error( $product_cats ) ) {
                _update_generic_term_count( $product_cats, get_taxonomy( 'product_cat' ) );
            }
            $product_tags = get_terms( array(
                'taxonomy'   => 'product_tag',
                'hide_empty' => false,
                'fields'     => 'ids',
            ));
            if ( ! is_wp_error( $product_tags ) ) {
                _update_generic_term_count( $product_tags, get_taxonomy( 'product_tag' ) );
            }
            $result['status']  = 'success';
            $result['message'] = 'Počty produktov v kategóriách a tagoch prepočítané';
            db_diag_log_action( 'wc-recount-terms' );
            break;

        case 'regenerate-product-lookup':
            if ( function_exists( 'wc_update_product_lookup_tables' ) ) {
                wc_update_product_lookup_tables();
            }
            $result['status']  = 'success';
            $result['message'] = 'Product lookup tabuľka regenerovaná — rieši problémy s filtrovaním a radením';
            db_diag_log_action( 'wc-regenerate-product-lookup' );
            break;

        // --- Orders ---
        case 'cleanup-draft-orders':
            $cutoff  = date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
            $deleted = $wpdb->query( $wpdb->prepare(
                "DELETE FROM {$wpdb->posts} WHERE post_type = 'shop_order' AND post_status IN ('wc-checkout-draft', 'wc-pending') AND post_date < %s",
                $cutoff
            ));
            $result['status']  = 'success';
            $result['deleted'] = intval( $deleted );
            $result['message'] = "Vymazaných {$deleted} draft/pending objednávok starších ako {$days} dní";
            db_diag_log_action( 'wc-cleanup-draft-orders', "Days: {$days}, Deleted: {$deleted}" );
            break;

        case 'cleanup-trash-orders':
            $cutoff  = date( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
            $deleted = $wpdb->query( $wpdb->prepare(
                "DELETE FROM {$wpdb->posts} WHERE post_type = 'shop_order' AND post_status = 'trash' AND post_modified < %s",
                $cutoff
            ));
            $result['status']  = 'success';
            $result['deleted'] = intval( $deleted );
            $result['message'] = "Permanentne vymazaných {$deleted} objednávok z koša starších ako 30 dní";
            db_diag_log_action( 'wc-cleanup-trash-orders', "Deleted: {$deleted}" );
            break;

        case 'update-order-stats':
            if ( class_exists( 'Automattic\WooCommerce\Admin\API\Reports\Cache' ) ) {
                \Automattic\WooCommerce\Admin\API\Reports\Cache::invalidate();
            }
            $result['status']  = 'success';
            $result['message'] = 'Order stats cache invalidovaný — prepočítajú sa pri ďalšom načítaní reportov';
            db_diag_log_action( 'wc-update-order-stats' );
            break;

        // --- Database Tables ---
        case 'verify-base-tables':
            if ( class_exists( 'WC_Install' ) ) {
                $missing = \WC_Install::verify_base_tables();
                $result['status']  = empty( $missing ) ? 'success' : 'warning';
                $result['missing'] = $missing;
                $result['message'] = empty( $missing )
                    ? 'Všetky WooCommerce tabuľky sú v poriadku'
                    : 'Chýbajúce tabuľky: ' . implode( ', ', $missing );
            } else {
                $result['status']  = 'error';
                $result['message'] = 'WC_Install class nie je dostupná';
            }
            db_diag_log_action( 'wc-verify-base-tables' );
            break;

        case 'update-db':
            if ( class_exists( 'WC_Install' ) ) {
                \WC_Install::update();
                $result['status']  = 'success';
                $result['message'] = 'WooCommerce database update spustený';
            } else {
                $result['status']  = 'error';
                $result['message'] = 'WC_Install class nie je dostupná';
            }
            db_diag_log_action( 'wc-update-db' );
            break;

        case 'optimize-tables':
            $tables_to_optimize = array(
                "{$wpdb->prefix}woocommerce_sessions",
                "{$wpdb->prefix}woocommerce_order_items",
                "{$wpdb->prefix}woocommerce_order_itemmeta",
            );
            $optimized = array();
            foreach ( $tables_to_optimize as $table ) {
                $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" );
                if ( $exists ) {
                    $wpdb->query( "OPTIMIZE TABLE {$table}" );
                    $optimized[] = $table;
                }
            }
            $result['status']    = 'success';
            $result['optimized'] = $optimized;
            $result['message']   = 'Optimalizované tabuľky: ' . implode( ', ', $optimized );
            db_diag_log_action( 'wc-optimize-tables', implode( ', ', $optimized ) );
            break;

        // --- Diagnostic (read-only) ---
        case 'check-pages':
            $pages = array(
                'cart'       => get_option( 'woocommerce_cart_page_id' ),
                'checkout'   => get_option( 'woocommerce_checkout_page_id' ),
                'myaccount'  => get_option( 'woocommerce_myaccount_page_id' ),
                'terms'      => get_option( 'woocommerce_terms_page_id' ),
            );
            $checks = array();
            foreach ( $pages as $name => $page_id ) {
                $status = $page_id ? get_post_status( $page_id ) : null;
                $checks[ $name ] = array(
                    'page_id' => $page_id ?: 'not set',
                    'exists'  => $status === 'publish',
                    'status'  => $status ?: 'missing',
                );
            }
            $result['status'] = 'success';
            $result['pages']  = $checks;
            break;

        case 'check-payment-gateways':
            $gateways = WC()->payment_gateways()->payment_gateways();
            $checks   = array();
            foreach ( $gateways as $id => $gw ) {
                $checks[] = array(
                    'id'      => $id,
                    'title'   => $gw->get_title(),
                    'enabled' => $gw->enabled === 'yes',
                    'method'  => $gw->get_method_title(),
                );
            }
            $result['status']   = 'success';
            $result['gateways'] = $checks;
            break;

        case 'check-shipping-zones':
            $zones  = \WC_Shipping_Zones::get_zones();
            $checks = array();
            foreach ( $zones as $zone ) {
                $methods = array();
                foreach ( $zone['shipping_methods'] as $method ) {
                    $methods[] = array(
                        'id'      => $method->id,
                        'title'   => $method->get_title(),
                        'enabled' => $method->is_enabled(),
                    );
                }
                $checks[] = array(
                    'id'      => $zone['id'],
                    'name'    => $zone['zone_name'],
                    'methods' => $methods,
                );
            }
            $result['status'] = 'success';
            $result['zones']  = $checks;
            break;

        case 'check-hpos-status':
            $result['status']  = 'success';
            $result['hpos']    = array(
                'enabled' => db_diag_wc_hpos_enabled(),
            );
            break;

        case 'count-orphans':
            $orphaned_variations = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} v
                 LEFT JOIN {$wpdb->posts} p ON v.post_parent = p.ID
                 WHERE v.post_type = 'product_variation'
                 AND (p.ID IS NULL OR p.post_type != 'product')"
            );
            $orphaned_meta = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
                 LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE p.ID IS NULL"
            );
            $expired_sessions = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_sessions WHERE session_expiry < UNIX_TIMESTAMP()"
            );
            $result['status'] = 'success';
            $result['counts'] = array(
                'orphaned_variations' => intval( $orphaned_variations ),
                'orphaned_meta'       => intval( $orphaned_meta ),
                'expired_sessions'    => intval( $expired_sessions ),
            );
            break;

        default:
            $result['status']  = 'error';
            $result['message'] = "Neznáma WooCommerce akcia: {$action}";
    }

    return rest_ensure_response( $result );
}

// ============================================================
// AUDIT LOG ENDPOINT
// ============================================================

function db_diag_audit_log( $request ) {
    $lines    = min( $request->get_param( 'lines' ), 200 );
    $log_file = WP_CONTENT_DIR . '/db-diag-audit.log';

    if ( ! file_exists( $log_file ) ) {
        return rest_ensure_response( array(
            'status'  => 'empty',
            'message' => 'Žiadne záznamy v audit logu',
            'entries' => array(),
        ));
    }

    $content = file_get_contents( $log_file );
    $all     = array_filter( explode( "\n", $content ) );
    $tail    = array_slice( $all, -$lines );

    $parsed = array();
    foreach ( $tail as $line ) {
        if ( preg_match( '/^\[(.+?)\] User: (.+?) \| Action: (.+?) \| Result: (.+?) \| Details: (.*)$/', $line, $m ) ) {
            $parsed[] = array(
                'timestamp' => $m[1],
                'user'      => $m[2],
                'action'    => $m[3],
                'result'    => $m[4],
                'details'   => $m[5],
            );
        } else {
            $parsed[] = array(
                'timestamp' => '?',
                'user'      => '?',
                'action'    => '?',
                'result'    => '?',
                'details'   => $line,
            );
        }
    }

    return rest_ensure_response( array(
        'status'       => 'active',
        'total_lines'  => count( $all ),
        'returned'     => count( $parsed ),
        'entries'      => $parsed,
    ));
}

// ============================================================
// ENDPOINT 8: AUTOLOAD ANALYSIS
// ============================================================

function db_diag_autoload_analysis( $request ) {
    global $wpdb;
    $limit = min( $request->get_param( 'limit' ), 200 );

    // Total autoload size
    $total = $wpdb->get_row(
        "SELECT COUNT(*) as count, SUM(LENGTH(option_value)) as total_bytes
         FROM {$wpdb->options} WHERE autoload = 'yes'"
    );

    $total_size   = (int) $total->total_bytes;
    $total_count  = (int) $total->count;
    $total_size_mb = round( $total_size / 1048576, 2 );

    // Top N largest autoloaded options
    $top_options = $wpdb->get_results( $wpdb->prepare(
        "SELECT option_name, LENGTH(option_value) as size_bytes, autoload
         FROM {$wpdb->options}
         WHERE autoload = 'yes'
         ORDER BY LENGTH(option_value) DESC
         LIMIT %d",
        $limit
    ) );

    $top = array();
    foreach ( $top_options as $opt ) {
        $size_bytes = (int) $opt->size_bytes;
        $top[] = array(
            'option_name' => $opt->option_name,
            'size_bytes'  => $size_bytes,
            'size_kb'     => round( $size_bytes / 1024, 2 ),
            'is_transient' => ( strpos( $opt->option_name, '_transient_' ) === 0 || strpos( $opt->option_name, '_site_transient_' ) === 0 ),
        );
    }

    // Autoloaded transients summary
    $transients = $wpdb->get_row(
        "SELECT COUNT(*) as count, COALESCE(SUM(LENGTH(option_value)),0) as total_bytes
         FROM {$wpdb->options}
         WHERE autoload = 'yes'
         AND (option_name LIKE '\_transient\_%' OR option_name LIKE '\_site\_transient\_%')"
    );

    // Categorize by plugin prefix
    $by_prefix = $wpdb->get_results(
        "SELECT
            CASE
                WHEN option_name LIKE 'woocommerce%' OR option_name LIKE 'wc_%' THEN 'woocommerce'
                WHEN option_name LIKE 'elementor%' THEN 'elementor'
                WHEN option_name LIKE 'wp_rocket%' OR option_name LIKE 'rocket_%' THEN 'wp-rocket'
                WHEN option_name LIKE 'rank_math%' OR option_name LIKE 'rankmath%' THEN 'rank-math'
                WHEN option_name LIKE 'yoast%' OR option_name LIKE 'wpseo%' THEN 'yoast'
                WHEN option_name LIKE 'jetpack%' THEN 'jetpack'
                WHEN option_name LIKE 'litespeed%' THEN 'litespeed'
                WHEN option_name LIKE 'autoptimize%' THEN 'autoptimize'
                WHEN option_name LIKE '\_transient\_%' OR option_name LIKE '\_site\_transient\_%' THEN 'transients'
                WHEN option_name LIKE 'widget_%' THEN 'widgets'
                WHEN option_name LIKE 'theme_mods_%' THEN 'theme-mods'
                ELSE 'other'
            END as category,
            COUNT(*) as count,
            SUM(LENGTH(option_value)) as total_bytes
         FROM {$wpdb->options}
         WHERE autoload = 'yes'
         GROUP BY category
         ORDER BY total_bytes DESC"
    );

    $categories = array();
    foreach ( $by_prefix as $row ) {
        $categories[] = array(
            'category'    => $row->category,
            'count'       => (int) $row->count,
            'total_bytes' => (int) $row->total_bytes,
            'total_kb'    => round( (int) $row->total_bytes / 1024, 2 ),
        );
    }

    // Health assessment
    $health = 'good';
    $recommendations = array();
    if ( $total_size_mb > 2 ) {
        $health = 'critical';
        $recommendations[] = 'Autoload presahuje 2MB. Okamzite treba optimalizovat.';
    } elseif ( $total_size_mb > 1 ) {
        $health = 'warning';
        $recommendations[] = 'Autoload presahuje 1MB. Odporuca sa optimalizacia.';
    }

    $transient_bytes = (int) $transients->total_bytes;
    if ( $transient_bytes > 524288 ) {
        $recommendations[] = sprintf(
            'Transients zaberaju %s KB v autoloade. Odporuca sa vycistit.',
            round( $transient_bytes / 1024, 2 )
        );
    }

    if ( $total_count > 1000 ) {
        $recommendations[] = sprintf( 'Pocet autoload zaznamov (%d) je prilis vysoky.', $total_count );
    }

    db_diag_log_action( 'autoload-analysis', sprintf( 'Total: %s MB, %d records', $total_size_mb, $total_count ) );

    return rest_ensure_response( array(
        'status'   => 'ok',
        'health'   => $health,
        'summary'  => array(
            'total_size_bytes'  => $total_size,
            'total_size_mb'     => $total_size_mb,
            'total_count'       => $total_count,
            'transient_count'   => (int) $transients->count,
            'transient_bytes'   => $transient_bytes,
        ),
        'top_options'      => $top,
        'by_category'      => $categories,
        'recommendations'  => $recommendations,
    ));
}

// ============================================================
// ENDPOINT 9: AUTOLOAD OPTIMIZE
// ============================================================

function db_diag_autoload_optimize( $request ) {
    global $wpdb;
    $action  = $request->get_param( 'action' );
    $options = $request->get_param( 'options' );

    $results = array();

    switch ( $action ) {

        case 'disable':
            // Disable autoload for specified options
            if ( empty( $options ) ) {
                return new WP_Error( 'missing_options', 'Parameter options je prazdny.', array( 'status' => 400 ) );
            }

            // Safety: never disable critical WP core options
            $protected = array(
                'siteurl', 'home', 'blogname', 'blogdescription',
                'active_plugins', 'template', 'stylesheet',
                'current_theme', 'wp_user_roles', 'db_version',
                'initial_db_version', 'rewrite_rules',
            );

            $disabled = array();
            $skipped  = array();
            foreach ( $options as $opt_name ) {
                if ( in_array( $opt_name, $protected, true ) ) {
                    $skipped[] = $opt_name . ' (protected)';
                    continue;
                }
                $updated = $wpdb->update(
                    $wpdb->options,
                    array( 'autoload' => 'no' ),
                    array( 'option_name' => $opt_name, 'autoload' => 'yes' )
                );
                if ( $updated ) {
                    $disabled[] = $opt_name;
                } else {
                    $skipped[] = $opt_name . ' (not found or already disabled)';
                }
            }

            db_diag_log_action( 'autoload-optimize-disable', sprintf( 'Disabled: %d, Skipped: %d', count( $disabled ), count( $skipped ) ) );

            $results = array(
                'action'   => 'disable',
                'disabled' => $disabled,
                'skipped'  => $skipped,
            );
            break;

        case 'enable':
            // Re-enable autoload for specified options
            if ( empty( $options ) ) {
                return new WP_Error( 'missing_options', 'Parameter options je prazdny.', array( 'status' => 400 ) );
            }

            $enabled = array();
            foreach ( $options as $opt_name ) {
                $updated = $wpdb->update(
                    $wpdb->options,
                    array( 'autoload' => 'yes' ),
                    array( 'option_name' => $opt_name, 'autoload' => 'no' )
                );
                if ( $updated ) {
                    $enabled[] = $opt_name;
                }
            }

            db_diag_log_action( 'autoload-optimize-enable', sprintf( 'Enabled: %d', count( $enabled ) ) );

            $results = array(
                'action'  => 'enable',
                'enabled' => $enabled,
            );
            break;

        case 'delete-transients':
            // Delete all expired transients from autoload
            $deleted_expired = $wpdb->query(
                "DELETE a, b FROM {$wpdb->options} a
                 INNER JOIN {$wpdb->options} b ON b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
                 WHERE a.option_name LIKE '\_transient\_%'
                 AND a.option_name NOT LIKE '\_transient\_timeout\_%'
                 AND b.option_value < UNIX_TIMESTAMP()"
            );

            // Also delete site transients
            $deleted_site = $wpdb->query(
                "DELETE a, b FROM {$wpdb->options} a
                 INNER JOIN {$wpdb->options} b ON b.option_name = CONCAT('_site_transient_timeout_', SUBSTRING(a.option_name, 17))
                 WHERE a.option_name LIKE '\_site\_transient\_%'
                 AND a.option_name NOT LIKE '\_site\_transient\_timeout\_%'
                 AND b.option_value < UNIX_TIMESTAMP()"
            );

            $total_deleted = (int) $deleted_expired + (int) $deleted_site;

            db_diag_log_action( 'autoload-optimize-transients', sprintf( 'Deleted: %d expired transients', $total_deleted ) );

            $results = array(
                'action'        => 'delete-transients',
                'deleted_count' => $total_deleted,
            );
            break;

        default:
            return new WP_Error( 'invalid_action', 'Neplatna akcia. Povolene: disable, enable, delete-transients.', array( 'status' => 400 ) );
    }

    return rest_ensure_response( array(
        'status'  => 'ok',
        'results' => $results,
    ));
}

// ============================================================
// ENDPOINT 10: ORPHANED POSTMETA
// ============================================================

function db_diag_orphaned_postmeta_analyze( $request ) {
    global $wpdb;

    // Count orphaned postmeta (postmeta referencing non-existent posts)
    $orphaned_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL"
    );

    // Total postmeta for context
    $total_postmeta = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta}" );

    // Size estimate of orphaned data
    $orphaned_size = $wpdb->get_var(
        "SELECT COALESCE(SUM(LENGTH(meta_key) + LENGTH(meta_value)), 0)
         FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL"
    );
    $orphaned_size = (int) $orphaned_size;

    // Top orphaned post_ids (which deleted posts left most garbage)
    $top_orphaned = $wpdb->get_results(
        "SELECT pm.post_id, COUNT(*) as meta_count
         FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL
         GROUP BY pm.post_id
         ORDER BY meta_count DESC
         LIMIT 20"
    );

    $top = array();
    foreach ( $top_orphaned as $row ) {
        $top[] = array(
            'post_id'    => (int) $row->post_id,
            'meta_count' => (int) $row->meta_count,
        );
    }

    $health = 'good';
    if ( $orphaned_count > 5000 ) {
        $health = 'critical';
    } elseif ( $orphaned_count > 1000 ) {
        $health = 'warning';
    }

    db_diag_log_action( 'orphaned-postmeta-analyze', sprintf( 'Found: %d orphaned, Total: %d', $orphaned_count, $total_postmeta ) );

    return rest_ensure_response( array(
        'status'  => 'ok',
        'health'  => $health,
        'summary' => array(
            'orphaned_count'  => $orphaned_count,
            'total_postmeta'  => $total_postmeta,
            'orphaned_pct'    => $total_postmeta > 0 ? round( ( $orphaned_count / $total_postmeta ) * 100, 2 ) : 0,
            'orphaned_bytes'  => $orphaned_size,
            'orphaned_kb'     => round( $orphaned_size / 1024, 2 ),
        ),
        'top_orphaned_posts' => $top,
    ));
}

function db_diag_orphaned_postmeta_clean( $request ) {
    global $wpdb;

    $confirm = $request->get_param( 'confirm' );
    $limit   = min( $request->get_param( 'limit' ), 10000 );

    if ( ! $confirm ) {
        return new WP_Error( 'not_confirmed', 'Parameter confirm=true je povinny.', array( 'status' => 400 ) );
    }

    // Count before cleanup
    $before = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL"
    );

    // Delete in batches to avoid timeout
    $deleted = 0;
    $batch_size = 500;
    $remaining = $limit;

    while ( $remaining > 0 ) {
        $current_batch = min( $batch_size, $remaining );
        $affected = $wpdb->query( $wpdb->prepare(
            "DELETE pm FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE p.ID IS NULL
             LIMIT %d",
            $current_batch
        ) );

        if ( $affected === false || $affected === 0 ) {
            break;
        }

        $deleted += $affected;
        $remaining -= $affected;
    }

    // Count after cleanup
    $after = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
         WHERE p.ID IS NULL"
    );

    db_diag_log_action( 'orphaned-postmeta-clean', sprintf( 'Deleted: %d (before: %d, after: %d)', $deleted, $before, $after ) );

    return rest_ensure_response( array(
        'status'  => 'ok',
        'results' => array(
            'deleted'          => $deleted,
            'orphaned_before'  => $before,
            'orphaned_after'   => $after,
        ),
    ));
}
