# DB Diagnostics — WordPress Plugin

REST API diagnostický plugin pre Digital Berry support workflow.

## Inštalácia

1. Nahraj `db-diagnostics` priečinok do `wp-content/plugins/`
2. Aktivuj plugin v WordPress admin
3. Vytvor Application Password pre admin používateľa (Users > Profile > Application Passwords)

## Predpoklady

- WordPress 5.6+
- PHP 7.4+
- Pre error log endpoint: `WP_DEBUG` a `WP_DEBUG_LOG` zapnuté v `wp-config.php`

## Endpointy

Všetky endpointy vyžadujú autentifikáciu cez Application Password s admin rolou.

### Diagnostické (read-only)

| Endpoint | Metóda | Popis |
|----------|--------|-------|
| `/wp-json/db-diag/v1/error-log` | GET | Posledných N riadkov z debug.log |
| `/wp-json/db-diag/v1/plugin-conflicts` | GET | Known plugin konflikty a duplicity |
| `/wp-json/db-diag/v1/site-health` | GET | WP, PHP, DB, server info |
| `/wp-json/db-diag/v1/plugin-settings` | GET | Audit nastavení WP Rocket, WC, Elementor, Yoast |
| `/wp-json/db-diag/v1/database` | GET | DB health: autoload bloat, transienty, orphaned meta |
| `/wp-json/db-diag/v1/audit-log` | GET | Audit log akcií vykonaných cez plugin |

### Akčné — Cache & Regenerácia

`POST /wp-json/db-diag/v1/action/cache`

Parametre: `target` (required), `post_id` (optional)

Targets: `wp-rocket-purge`, `wp-rocket-purge-page`, `wp-rocket-preload`, `elementor-css`, `elementor-data`, `autoptimize-purge`, `litespeed-purge`, `object-cache-flush`, `permalink-flush`, `transient-cleanup`, `all-cache`

### Akčné — WooCommerce Maintenance

`POST /wp-json/db-diag/v1/action/woocommerce`

Parametre: `action` (required), `confirm` (boolean, required pre deštruktívne akcie), `days` (int, pre cleanup)

Safe akcie: `clear-transients`, `clear-expired-transients`, `clear-session-data`, `clear-template-cache`, `recount-terms`, `regenerate-product-lookup`, `update-order-stats`, `verify-base-tables`, `check-pages`, `check-payment-gateways`, `check-shipping-zones`, `check-hpos-status`, `count-orphans`

Vyžadujú potvrdenie (confirm=true): `delete-orphaned-variations`, `delete-orphaned-product-meta`, `cleanup-draft-orders`, `cleanup-trash-orders`, `update-db`, `optimize-tables`

## Bezpečnosť

- Prístup len cez Application Password s admin rolou
- Deštruktívne akcie vyžadujú explicitný `confirm=true`
- Všetky akcie sa logujú do `wp-content/db-diag-audit.log`
- Rate limiting: odporúčaný max 10 akcií/minútu

## Autor

Digital Berry s.r.o. — https://digitalberry.sk
